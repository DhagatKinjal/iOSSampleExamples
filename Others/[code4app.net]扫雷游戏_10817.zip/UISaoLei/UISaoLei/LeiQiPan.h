//
//  QiPan.h
//  UIBaoShiXiaoChu
//
//  Created by Mac on 13-2-4.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#define ROWS 8
#define COLS 8

@interface LeiQiPan : UIView

- (id)initWithRows:(NSInteger)rows cols:(NSInteger)cols;
- (id)initWithButtonRows:(NSInteger)rows cols:(NSInteger)cols;

@end
