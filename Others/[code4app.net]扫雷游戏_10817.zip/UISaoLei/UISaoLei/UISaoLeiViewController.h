//
//  UISaoLeiViewController.h
//  UISaoLei
//
//  Created by Mac on 13-2-5.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LeiQiPan;

@interface UISaoLeiViewController : UIViewController
{
    NSMutableArray *_leiArray;
    LeiQiPan *_leiQiPan;
    LeiQiPan *_leiQiPanCover;
}

@end
