//
//  UISaoLeiViewController.m
//  UISaoLei
//
//  Created by Mac on 13-2-5.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "UISaoLeiViewController.h"
#import "LeiQiPan.h"
#import "LeiView.h"

@interface UISaoLeiViewController ()

@end

@implementation UISaoLeiViewController

-(void)dealloc
{
    [_leiArray release];
    [_leiQiPan release];
    [super dealloc];
}

- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
        _leiArray = [[NSMutableArray alloc] initWithCapacity:20];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    _leiQiPan = [[LeiQiPan alloc] initWithRows:ROWS cols:COLS];
    [self.view addSubview:_leiQiPan];
    self.view.backgroundColor = [UIColor grayColor];
    [self randLeiWithCount:8];
    [self addNumber];
    
    _leiQiPanCover = [[LeiQiPan alloc] initWithButtonRows:ROWS cols:COLS];
    [self.view addSubview:_leiQiPanCover];
}
//按下按钮如果是数字就把按钮的背景色设为clearColor，如果是雷就调用函数gameOver把所有雷都显示出来，如果是空就遍历bianLi,显示所有连在一起的空和空相邻的数字
-(void)buttonTouchUp:(UIButton *)sender
{
    LeiView *leiView = (LeiView *)[_leiQiPan viewWithTag:sender.tag-100];
    if ([leiView.subviews count] != 0) {
        UILabel *leiLabel = [leiView.subviews objectAtIndex:0];
        if ([leiLabel.text integerValue] >= 1&&[leiLabel.text integerValue] <= 8 ) {
            sender.backgroundColor = [UIColor clearColor];
        } else {
            [self gameOver];
        }
    } else {
        [self bianLi:sender];
    }
}

-(void)gameOver
{
    for (LeiView *leiView in _leiArray) {
        UIButton *button = (UIButton *)[_leiQiPanCover viewWithTag:leiView.tag+100];
        button.backgroundColor = [UIColor clearColor];
    }
    
    UILabel *gameOverLabel = [[UILabel alloc] initWithFrame:CGRectMake(110, 45*8+20, 100, 30)];
    gameOverLabel.text = @"GameOver!";
    [self.view addSubview:gameOverLabel];
    [gameOverLabel release];
    
    for (UIButton *button in _leiQiPanCover.subviews) {
        [button setUserInteractionEnabled:NO];
    }
}
//遍历与点击按钮相邻的按钮如果其内容为空，则以其为当前按钮继续遍历，否则即为数字，设置为clearColor
-(void)bianLi:(UIButton *)sender
{
    sender.backgroundColor = [UIColor clearColor];
    
    if ((sender.tag-1)%10 != 0) {
        [self leftRightTopButton:sender.tag-1];
    }
    if ((sender.tag-1)%10 != 9) {
        [self leftRightTopButton:sender.tag+1];
    }
    if ((sender.tag-1)/10%10 != 0) {
        [self leftRightTopButton:sender.tag-10];
    }
    if ((sender.tag-1)/10%10 != 9) {
        [self leftRightTopButton:sender.tag+10];
    }
    
    
    
}

-(void)leftRightTopButton:(NSInteger)tag
{
    UIButton *sender = (UIButton *)[_leiQiPanCover viewWithTag:tag];
    //如果当前按钮超过范围或已经clearColor过，则返回
    if (sender == nil||sender.backgroundColor == [UIColor clearColor]) {
        return;
    }
    LeiView *leiView = (LeiView *)[_leiQiPan viewWithTag:sender.tag-100];
    if ([leiView.subviews count] == 0) {
        [self bianLi:sender];
    } else {
        sender.backgroundColor = [UIColor clearColor];
    }
}

//随机产生地雷，count是产生地雷的个数
-(void)randLeiWithCount:(NSInteger)count
{
    for (int i = 1; i <= count; i++) {
        NSNumber *rand1 = [[NSNumber alloc] initWithInteger:arc4random()%8+11];
        NSNumber *rand2 = [[NSNumber alloc] initWithInteger:arc4random()%8+21];
        NSNumber *rand3 = [[NSNumber alloc] initWithInteger:arc4random()%8+31];
        NSNumber *rand4 = [[NSNumber alloc] initWithInteger:arc4random()%8+41];
        NSNumber *rand5 = [[NSNumber alloc] initWithInteger:arc4random()%8+51];
        NSNumber *rand6 = [[NSNumber alloc] initWithInteger:arc4random()%8+61];
        NSNumber *rand7 = [[NSNumber alloc] initWithInteger:arc4random()%8+71];
        NSNumber *rand8 = [[NSNumber alloc] initWithInteger:arc4random()%8+81];
        NSArray *randArray = [[NSArray alloc] initWithObjects:rand1,rand2,rand3,rand4,rand5,rand6,rand7,rand8, nil];
        [rand1 release];
        [rand2 release];
        [rand3 release];
        [rand4 release];
        [rand5 release];
        [rand6 release];
        [rand7 release];
        [rand8 release];
        
        LeiView *leiView = (LeiView *)[_leiQiPan viewWithTag:[[randArray objectAtIndex:arc4random()%8] integerValue]];
        [randArray release];
        
        UILabel *leiLabel = [[UILabel alloc] initWithFrame:leiView.bounds];
        [leiView addSubview:leiLabel];
        [leiLabel release];
        leiLabel.text = @"*";
        leiLabel.textAlignment = UITextAlignmentCenter;
        
        [_leiArray addObject:leiView];
    }
}

-(void)addNumber
{
    for (LeiView *leiView in _leiArray) {
        LeiView *leiViewLeft = (LeiView *)[_leiQiPan viewWithTag:leiView.tag-1];
        [self addLabel:leiViewLeft];
        LeiView *leiViewRight = (LeiView *)[_leiQiPan viewWithTag:leiView.tag+1];
        [self addLabel:leiViewRight];
        LeiView *leiViewTop = (LeiView *)[_leiQiPan viewWithTag:leiView.tag-10];
        [self addLabel:leiViewTop];
        LeiView *leiViewButtom = (LeiView *)[_leiQiPan viewWithTag:leiView.tag+10];
        [self addLabel:leiViewButtom];
        
        LeiView *leiViewLeftTop = (LeiView *)[_leiQiPan viewWithTag:leiView.tag-10-1];
        [self addLabel:leiViewLeftTop];
        LeiView *leiViewRightTop = (LeiView *)[_leiQiPan viewWithTag:leiView.tag-10+1];
        [self addLabel:leiViewRightTop];
        LeiView *leiViewLeftButtom = (LeiView *)[_leiQiPan viewWithTag:leiView.tag+10-1];
        [self addLabel:leiViewLeftButtom];
        LeiView *leiViewRightButtom = (LeiView *)[_leiQiPan viewWithTag:leiView.tag+10+1];
        [self addLabel:leiViewRightButtom];
    }
}

-(void)addLabel:(LeiView *)leiView
{
    if ([leiView.subviews count] == 0) {
        UILabel *numLabel = [[UILabel alloc] initWithFrame:leiView.bounds];
        [leiView addSubview:numLabel];
        [numLabel release];
        numLabel.text = @"1";
        numLabel.textAlignment = UITextAlignmentCenter;
    } 
    else if ([[leiView.subviews objectAtIndex:0] text] != @"*") {
        UILabel *numLabel = [leiView.subviews objectAtIndex:0];
        numLabel.text = [NSString stringWithFormat:@"%d",[numLabel.text integerValue]+1];
    }
}

@end
