//
//  QiPan.m
//  UIBaoShiXiaoChu
//
//  Created by Mac on 13-2-4.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "LeiQiPan.h"
#import "LeiView.h"

@implementation LeiQiPan

- (id)initWithRows:(NSInteger)rows cols:(NSInteger)cols
{
    self = [super initWithFrame:CGRectMake(0, 0, LEIVIEWWIDTH*cols, LEIVIEWHEIGHT*rows)];
    if (self) {
        // Initialization code
        
        CGRect rect = CGRectMake(3, 5, LEIVIEWWIDTH, LEIVIEWHEIGHT);
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= cols; j++) {
                LeiView *leiView = [[LeiView alloc] initWithFrame:rect];
                [self addSubview:leiView];
                [leiView release];
                [leiView setTag:i*10+j];
                leiView.backgroundColor = [UIColor whiteColor];
                rect.origin.x += LEIVIEWWIDTH+5;
            }
            rect.origin.x = 3;
            rect.origin.y += LEIVIEWHEIGHT+5;
        }
    }
    return self;
}
//创建覆盖在view上边的button
- (id)initWithButtonRows:(NSInteger)rows cols:(NSInteger)cols
{
    self = [super initWithFrame:CGRectMake(0, 0, LEIVIEWWIDTH*cols, LEIVIEWHEIGHT*rows)];
    if (self) {
        // Initialization code
        
        CGRect rect = CGRectMake(3, 5, LEIVIEWWIDTH, LEIVIEWHEIGHT);
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= cols; j++) {
                UIButton *button = [[UIButton alloc] initWithFrame:rect];
                [self addSubview:button];
                [button release];
                [button setTag:100+i*10+j];
                button.backgroundColor = [UIColor blueColor];
                rect.origin.x += LEIVIEWWIDTH+5;
                [button addTarget:self.superview action:@selector(buttonTouchUp:) forControlEvents:UIControlEventTouchUpInside];
            }
            rect.origin.x = 3;
            rect.origin.y += LEIVIEWHEIGHT+5;
        }
    }
    return self;
}

@end
