//
//  BaoShi.h
//  UIBaoShiXiaoChu
//
//  Created by Mac on 13-2-4.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#define LEIVIEWHEIGHT 40.0f
#define LEIVIEWWIDTH 35.0f

@interface LeiView : UIView

@end
