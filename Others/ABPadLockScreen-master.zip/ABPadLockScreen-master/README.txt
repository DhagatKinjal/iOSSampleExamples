ABPadLockScreen README
ABPadLockScreen 2.0
Aron Bury 2012

ABPadLockScreen provides a simple keypad style unlock feature for your iPhone or iPad app. 

To use in your app:
1. Import the framework anywhere into your project.
2. Add the ABPadLockScreen files into your Xcode project
3. Import the ABPadLockScreenController.h into your project and go from there!

A demo project is included to help you get started. The framework is smart enough to detect if your app is running on an iPhone or iPad and will do most of the logic for you.

To view the full release notes visit https://github.com/abury/ABPadLockScreen/wiki/Version-2.0-Release-Notes

Happy Coding!

- Aron