//
//  KYConfirmButton.h
//  UIBezierPathSymbol_Demo
//
//  Created by Kaijie Yu on 7/4/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "KYButton.h"

@interface KYConfirmButton : KYButton

@end
