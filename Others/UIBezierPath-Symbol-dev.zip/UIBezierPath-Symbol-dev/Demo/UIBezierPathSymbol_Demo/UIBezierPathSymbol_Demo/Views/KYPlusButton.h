//
//  KYPlusButton.h
//  UIBezierPathSymbol_Demo
//
//  Created by Kjuly on 10/3/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "KYButton.h"

@interface KYPlusButton : KYButton

@end
