//
//  KYArrowButton.h
//  UIBezierPathSymbol_Demo
//
//  Created by Kjuly on 8/13/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "KYButton.h"

@interface KYArrowButton : KYButton

@property (nonatomic, assign) UIBezierPathArrowDirection direction;

@end
