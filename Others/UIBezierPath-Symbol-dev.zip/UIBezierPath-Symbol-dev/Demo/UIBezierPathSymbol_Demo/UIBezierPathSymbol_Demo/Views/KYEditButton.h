//
//  KYEditButton.h
//  UIBezierPathSymbol_Demo
//
//  Created by Kaijie Yu on 7/3/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "KYButton.h"

@interface KYEditButton : KYButton

@end
