//
//  squareThree.m
//  square
//
//  Created by user on 12-3-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "squareThree.h"

@implementation squareThree
-(id)init
{
    self = [super init];
    if (self) {
        case1.x = 0;
        case1.y = 0;
        case2.x = 0;
        case2.y = 1;
        case3.x = 1;
        case3.y = 0;
        case4.x = 1;
        case4.y = 1;
        state = 1;

    }
    return self;    
}

@end
