//
//  squarefive.h
//  square
//
//  Created by user on 12-3-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "baseSquareCase.h"

@interface squarefive : baseSquareCase

@end
