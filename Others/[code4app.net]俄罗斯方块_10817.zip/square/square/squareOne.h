//
//  squareOne.h
//  square
//
//  Created by user on 12-3-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "baseSquareCase.h"

@interface squareOne : baseSquareCase
-(void)squareRound;

@end
