//
//  squareDelegate.h
//  square
//
//  Created by user on 12-2-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol squareDelegate <NSObject>
-(void)squareDownToEnd;

@end
