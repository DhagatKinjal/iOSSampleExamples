//
//  RateStarsTests.h
//  RateStarsTests
//
//  Created by Edward Chiang on 12/2/23.
//  Copyright (c) 2012年 Polydice Inc. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface RateStarsTests : SenTestCase

@end
