//
//  ViewController.h
//  testOurApps
//
//  Created by 建红 杨 on 12-7-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OurAppsViewController.h"

@interface ViewController : UIViewController <OurAppsVCDelegate>

@end
