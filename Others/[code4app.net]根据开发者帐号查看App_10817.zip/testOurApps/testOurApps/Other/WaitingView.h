//
//  WaitingView.h
//  
//
//  Created by Jianhong Yang on 12-1-7.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WaitingView : UIView {
@private
    //
    UIView *_viewBackground;
    UIActivityIndicatorView *_viewActivityIndicator;
    UILabel *_labelText;
}

- (void)setWaitingText:(NSString *)text;

@end
