//
//  ViewController.h
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MorseCoder.h"

@interface ViewController : UIViewController
{
    MorseCoder* coder;
}

- (IBAction)onStart:(id)sender;

- (IBAction)onStop:(id)sender;

@end
