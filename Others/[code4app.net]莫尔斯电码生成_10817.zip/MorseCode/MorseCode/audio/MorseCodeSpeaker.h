//
//  MorseCodeSpeaker.h
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioUnit/AudioUnit.h>

#define SAMPLE_RATE 44100;

@interface MorseCodeSpeaker : NSObject
{
    AudioComponentInstance toneUnit;
    
@public
    double frequency;
	double sampleRate;
	double theta;
    double amplitude;
}

- (void)start;
- (void)stop;

@end
