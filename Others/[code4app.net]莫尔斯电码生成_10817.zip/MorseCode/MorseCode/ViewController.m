//
//  ViewController.m
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    coder = [[MorseCoder alloc] initWithString:@"kmrkkkmmmrrrmmmkkkrrr"];
}

- (void)dealloc
{
    [coder release];
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)onStart:(id)sender {
    [coder startPlay];
}

- (IBAction)onStop:(id)sender {
    [coder stopPlay];
}
- (IBAction)onValueChanged:(id)sender {
    UISlider* slider = (UISlider*)sender;
    NSLog(@"%f",slider.value);
    coder.interval = slider.value;
}

@end
