//
//  MorseCodeTable.h
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MorseCodeTable;

@interface MorseCodeTable : NSObject
{
    NSMutableDictionary* table;
}

+ (MorseCodeTable*)shareInstance;
- (NSString*)getCode:(NSString*)chr;

@end
