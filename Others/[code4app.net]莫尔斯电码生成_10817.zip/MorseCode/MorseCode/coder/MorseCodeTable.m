//
//  MorseCodeTable.m
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import "MorseCodeTable.h"

@interface MorseCodeTable ()
- (void)createMorseCodeTable;
@end

static MorseCodeTable* codeTable = nil;

@implementation MorseCodeTable

+ (MorseCodeTable*)shareInstance
{
    if(codeTable == nil)
    {
        codeTable = [[MorseCodeTable alloc] init];
    }
    return codeTable;
}

- (id)init
{
    self = [super init];
    if(self)
    {
        table = [[NSMutableDictionary alloc] init];
        [self createMorseCodeTable];
    }
    return self;
}

- (void)createMorseCodeTable
{
    [table setObject:@"   " forKey:@" "];
    [table setObject:@".-" forKey:@"a"];
    [table setObject:@"-..." forKey:@"b"];
    [table setObject:@"-.-." forKey:@"c"];
    [table setObject:@"-.." forKey:@"d"];
    [table setObject:@"." forKey:@"e"];
    [table setObject:@"..-." forKey:@"f"];
    [table setObject:@"--." forKey:@"g"];
    [table setObject:@"...." forKey:@"h"];
    [table setObject:@".." forKey:@"i"];
    [table setObject:@".---" forKey:@"j"];
    [table setObject:@"-.-" forKey:@"k"];
    [table setObject:@".-.." forKey:@"l"];
    [table setObject:@"--" forKey:@"m"];
    [table setObject:@"-." forKey:@"n"];
    [table setObject:@"---" forKey:@"o"];
    [table setObject:@".--." forKey:@"p"];
    [table setObject:@"--.-" forKey:@"q"];
    [table setObject:@".-." forKey:@"r"];
    [table setObject:@"..." forKey:@"s"];
    [table setObject:@"-" forKey:@"t"];
    [table setObject:@"..-" forKey:@"u"];
    [table setObject:@"...-" forKey:@"v"];
    [table setObject:@".--" forKey:@"w"];
    [table setObject:@"-..-" forKey:@"x"];
    [table setObject:@"-.--" forKey:@"y"];
    [table setObject:@"--.." forKey:@"z"];
    [table setObject:@".----" forKey:@"1"];
    [table setObject:@"..---" forKey:@"2"];
    [table setObject:@"...--" forKey:@"3"];
    [table setObject:@"....-" forKey:@"4"];
    [table setObject:@"....." forKey:@"5"];
    [table setObject:@"-...." forKey:@"6"];
    [table setObject:@"--..." forKey:@"7"];
    [table setObject:@"---.." forKey:@"8"];
    [table setObject:@"----." forKey:@"9"];
    [table setObject:@"-----" forKey:@"0"];
}

- (NSString*)getCode:(NSString*)chr
{
    NSString* code = (NSString*)[table objectForKey:[NSString stringWithFormat:@"%@",chr]];
    if(code != nil)
    {
        return [[[NSString alloc] initWithString:code] autorelease];
    }
    else
    {
        return nil;
    }
}

@end
