//
//  MorseCoder.h
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MorseCodeSpeaker.h"

typedef enum _MoserCoderStats
{
    MoserCoderStat_str_start,
    MoserCoderStat_code_start,
    MoserCoderStat_code_up,
    MoserCoderStat_code_down,
    MoserCoderStat_finish,
    
}MoserCoderStat;

@interface MorseCoder : NSObject
{    
    NSString* text;
    NSTimer* timmer;
    
    MorseCodeSpeaker* speaker;
    
    NSTimeInterval interval;
    
    NSString* chrString;
    NSString* codeString;
    NSString* codeChrString;
    NSInteger status;
    NSInteger charIndex;
    NSInteger codeIndex;
    NSInteger soundLong;
    
    
    
    NSInteger strStartWait;
    NSInteger codeStartWait;
    NSInteger codeUpWait;
    
}

@property (nonatomic) NSTimeInterval interval;
@property (nonatomic,retain) NSString* code;

@property (nonatomic,retain) NSString* chrString;
@property (nonatomic,retain) NSString* codeString;
@property (nonatomic,retain) NSString* codeChrString;

- (id)initWithString:(NSString*)text;

- (void)startPlay;
- (void)stopPlay;

@end
