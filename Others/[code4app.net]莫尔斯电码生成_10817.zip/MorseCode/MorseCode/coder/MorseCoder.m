//
//  MorseCoder.m
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import "MorseCoder.h"
#import "MorseCodeTable.h"

@implementation MorseCoder

@synthesize interval,code;
@synthesize codeString, chrString, codeChrString;

- (id)initWithString:(NSString*)str
{
    self = [super init];
    if(self)
    {
        text = [[NSString alloc] initWithString:str];
        speaker = [[MorseCodeSpeaker alloc] init];
        
    }
    return self;
}

- (void)dealloc
{
    [text release];
    [speaker release];
    [super dealloc];
}

- (void)onTimmer
{
    timmer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(onTimmer) userInfo:nil repeats:NO];
    switch (status) {
        case MoserCoderStat_str_start:
            
            if(charIndex >= [text length])
            {
                status = MoserCoderStat_finish;
                break;
            }
            
            if(soundLong >10)
            {
                codeIndex = 0;
                self.chrString = [text substringWithRange:NSMakeRange(charIndex++, 1)];
                self.codeString = [[MorseCodeTable shareInstance] getCode:chrString ];
                
                NSLog(@"%@ (%@)",self.chrString, self.codeString);
                
                status = MoserCoderStat_code_start;

            }
            else
            {
                soundLong ++;
            }
            
                        
            break;
            
        case MoserCoderStat_code_start:
            
            if(codeIndex >= [self.codeString length])
            {
                soundLong = 0;
                status = MoserCoderStat_str_start;
                break;
            }

            self.codeChrString = [self.codeString substringWithRange:NSMakeRange(codeIndex++, 1)];
            NSLog(@"%@",self.codeChrString);
            
            status = MoserCoderStat_code_up;
            soundLong = 0;
            
            break;
            
        case MoserCoderStat_code_up:
            
            if([self.codeChrString isEqualToString:@" "])
            {
                soundLong = 0;
                status = MoserCoderStat_code_down;
                break;
            }

            speaker->amplitude = 0.25;
            if([self.codeChrString isEqualToString:@"-"] && soundLong > 20)
            {
                soundLong = 0;
                status = MoserCoderStat_code_down;
                break;
            }
            else if([self.codeChrString isEqualToString:@"."] && soundLong > 1)
            {
                soundLong = 0;
                status = MoserCoderStat_code_down;
                break;
            }
            
            soundLong ++;
            break;
            
        case MoserCoderStat_code_down:
            speaker->amplitude = 0;
            if(soundLong >4)
            {
                status = MoserCoderStat_code_start;
            }
            soundLong ++;
            break;
            
        case MoserCoderStat_finish:
            [self stopPlay];
            
        default:
            break;
    }
    
}

- (void)startPlay
{
    if(timmer)
    {
        [self stopPlay];
    }
    charIndex = 0;
    codeIndex = 0;
    strStartWait = 0;
    codeStartWait = 0;
    codeUpWait = 0;
    status = MoserCoderStat_str_start;
    interval = 0.008;
    
    timmer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(onTimmer) userInfo:nil repeats:NO];
    [speaker start];
}

- (void)stopPlay
{
    [timmer invalidate];
    timmer = nil;
    [speaker stop];
}

@end
