//
//  AppDelegate.h
//  MorseCode
//
//  Created by song fei on 7/18/12.
//  Copyright (c) 2012 Songfei.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
