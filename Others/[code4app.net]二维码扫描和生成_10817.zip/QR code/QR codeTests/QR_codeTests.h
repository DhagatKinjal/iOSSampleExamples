//
//  QR_codeTests.h
//  QR codeTests
//
//  Created by 斌 on 12-8-2.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface QR_codeTests : SenTestCase

@end
