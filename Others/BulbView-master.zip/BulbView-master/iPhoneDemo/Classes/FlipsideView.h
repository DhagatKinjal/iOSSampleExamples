//
//  FlipsideView.h
//  LcdiPhone
//
//  Created by Ryan Morlok on 5/26/09.
//  Copyright Morlok Technologies 2009. All rights reserved.
//

@interface FlipsideView : UIView {
	
}

@end
