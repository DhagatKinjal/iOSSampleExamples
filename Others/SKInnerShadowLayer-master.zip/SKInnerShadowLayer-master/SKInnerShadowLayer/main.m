//
//  main.m
//  SKInnerShadowLayer
//
//  Created by Soroush Khanlou on 10/5/12.
//  Copyright (c) 2012 SK. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SKAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([SKAppDelegate class]));
	}
}
