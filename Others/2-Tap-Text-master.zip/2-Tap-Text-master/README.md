Text template application, available in the App Store.

https://itunes.apple.com/us/app/2-tap-text/id523957178?mt=8
