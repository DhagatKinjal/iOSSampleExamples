//
//  ViewController.m
//  MyTouchUndo
//
//  Created by 鑫宇 王 on 12-10-30.
//  Copyright (c) 2012年 师大. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize label,undoManage,num;
-(void)dealloc
{
    [undoManage release];
    [label release];
    [super dealloc];
}
-(void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)undo
{
    [self.undoManage undo];
}
-(void)redo
{
    [self.undoManage redo];
}
-(void)apper
{
    if (!num) {
        self.navigationItem.rightBarButtonItem=nil;
    }
    else
    {
        if (self.undoManage.canUndo) {
            UIBarButtonItem*right=[[UIBarButtonItem alloc] initWithTitle:@"undo" style:UIBarButtonItemStyleBordered target:self action:@selector(undo)];
            self.navigationItem.rightBarButtonItem=right;
            [right release];
        }
    }
    if (!num) {
        self.navigationItem.leftBarButtonItem=nil;
    }
    else
    {
        UIBarButtonItem*left=[[UIBarButtonItem alloc] initWithTitle:@"redo" style:UIBarButtonItemStyleBordered target:self action:@selector(redo)];
        self.navigationItem.leftBarButtonItem=left;
        [left release];

        
    }
}
-(void)sub
{
    num-=10;
    [[self.undoManage prepareWithInvocationTarget:self] add];
    label.text=[NSString stringWithFormat:@"%d",num];
    [self apper];
    
}
-(void)add
{
    num+=10;
    [[self.undoManage prepareWithInvocationTarget:self] sub];
    label.text=[NSString stringWithFormat:@"%d",num];
    [self apper];
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    label=[[UILabel alloc] initWithFrame:CGRectMake(50, 50, 100, 100)];
    UIButton*btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame=CGRectMake(150, 150, 100, 100);
    [btn setTitle:@"add" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(add) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    [self.view addSubview:label];
    num=0;
    label.text=[NSString stringWithFormat:@"%d",num];
    undoManage=[[NSUndoManager alloc] init];
    [self.undoManage setLevelsOfUndo:999];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
