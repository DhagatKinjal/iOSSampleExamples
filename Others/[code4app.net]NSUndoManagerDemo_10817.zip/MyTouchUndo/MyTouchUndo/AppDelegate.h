//
//  AppDelegate.h
//  MyTouchUndo
//
//  Created by 鑫宇 王 on 12-10-30.
//  Copyright (c) 2012年 师大. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;
@property(strong,nonatomic)UINavigationController*navition;

@end
