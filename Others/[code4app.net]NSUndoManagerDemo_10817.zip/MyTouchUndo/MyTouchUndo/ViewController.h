//
//  ViewController.h
//  MyTouchUndo
//
//  Created by 鑫宇 王 on 12-10-30.
//  Copyright (c) 2012年 师大. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property(nonatomic,retain) UILabel*label;
@property(nonatomic,retain)NSUndoManager*undoManage;
@property(assign)NSInteger num;
-(void)add;

@end
