#import <UIKit/UIKit.h>

@interface AMRatingControlViewController : UIViewController
{
	IBOutlet UILabel *label;
    IBOutlet UILabel *endLabel;
}

@end

