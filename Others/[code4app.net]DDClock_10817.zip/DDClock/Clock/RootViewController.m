//
//  RootViewController.m
//  Clock
//
//  Created by dxl dxl on 12-7-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "DDDialView.h"
#import "DDNeedleView.h"
#import "DDClockView.h"

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    /*
    DialView *dialView =[[DialView alloc] initWithFrame:CGRectMake(60, 150, 300, 300)];
    dialView.center =self.view.center;
    [self.view addSubview:dialView];
    [dialView release];
     */
    
    /*
    NeedleHourView *hourNeedleView =[[NeedleHourView alloc] initWithFrame:CGRectMake(60, 150, 300, 300)];
    hourNeedleView.center =self.view.center;
    [self.view addSubview:hourNeedleView];
    [hourNeedleView release];
     */
    
    DDClockView *clockView =[[DDClockView alloc] initWithFrame:CGRectMake(60, 150, 300, 300)];
    clockView.center =self.view.center;
    [self.view addSubview:clockView];
    [clockView release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
