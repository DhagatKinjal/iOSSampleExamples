//
//  DialView.h
//  Clock
//
//  Created by dxl dxl on 12-7-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDDialView : UIView

@end
