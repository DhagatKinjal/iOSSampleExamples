//
//  SUserViewController.h
//  SDatabase
//
//  Created by SunJiangting on 12-10-20.
//  Copyright (c) 2012年 sun. All rights reserved.
//

#import "SUser.h"
#import <QuartzCore/QuartzCore.h>

@interface SUserViewController : UIViewController

- (id) initWithUser:(SUser *) user;

@end
