//
//  MSOKVC.m
//  MSVCLeakHunterSampleProject
//
//  Created by Javier Soto on 10/20/12.
//  Copyright (c) 2012 MindSnacks. All rights reserved.
//

#import "MSOKVC.h"

@interface MSOKVC ()

@end

@implementation MSOKVC

@end
