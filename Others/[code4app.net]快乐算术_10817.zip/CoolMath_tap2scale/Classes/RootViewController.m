
#import "RootViewController.h"

@implementation RootViewController

- (void)loadView {
    [super loadView];

    m_scrollView = [[UIScrollView alloc] initWithFrame:[[self view] bounds]];
    m_scrollView.backgroundColor = [UIColor blackColor];
    m_scrollView.delegate = self;
    m_scrollView.bouncesZoom = YES;
    
    // 打开下面这两句话，可以看到一些UIScrollView的本质.
    //m_scrollView = [[UIScrollView alloc] initWithFrame: CGRectMake(50, 50, 200, 200)];
    //m_scrollView.clipsToBounds = NO;
    
    
    [[self view] addSubview:m_scrollView];
    
    m_viewController = [[MathViewController alloc] init];
    m_viewController.m_parentScrollView = m_scrollView;
    m_viewController.m_tapDetectingDelegate = self;
    
    //CGAffineTransform scaleTransform = CGAffineTransformMakeScale(1.5, 1.5);
    //m_viewController.view.transform = scaleTransform;

    m_viewController.view.backgroundColor = [UIColor greenColor];

    [m_scrollView addSubview: m_viewController.view];
    [m_scrollView setContentSize: [m_viewController.view frame].size];

    
    // calculate minimum scale to perfectly fit image width, and begin at that scale
    float minimumScale = m_scrollView.frame.size.width  / m_viewController.view.frame.size.width;
    
    NSLog(@"[m_scrollView frame].size.width = %f, ", 
          [m_scrollView frame].size.width, 
          m_viewController.view.frame.size.width);

    m_scrollView.maximumZoomScale = 5.0;
    m_scrollView.minimumZoomScale = minimumScale;

    // 宽度正合适的大小
    [m_scrollView setZoomScale: minimumScale];
}

- (void)dealloc {
    [m_viewController release];
    [m_scrollView release];
    [super dealloc];
}

#pragma mark TapDetectingDelegate

- (void)tapDetectView:(UIView *)view gotDoubleTapAtPoint: (CGPoint)tapPoint
{
    NSLog(@"m_scrollView = %@, point = %@", m_scrollView, [NSValue valueWithCGPoint: tapPoint]);

    //CGAffineTransform scaleTransform = CGAffineTransformMakeScale(1.5, 1.5);
    //view.transform = scaleTransform;
    
    if(m_scrollView.zoomScale != 1)
    {
        [m_scrollView setZoomScale: 1.0 animated: YES];
    }
    else 
    {
        [m_scrollView setZoomScale: 2 animated: YES];
    }
}

#pragma mark UIScrollViewDelegate methods

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView 
{
    return m_viewController.view;
}


/************************************** NOTE **************************************/
/* The following delegate method works around a known bug in zoomToRect:animated: */
/* In the next release after 3.0 this workaround will no longer be necessary      */
/**********************************************************************************/
/*
- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(float)scale {
    [scrollView setZoomScale:scale+0.01 animated:NO];
    [scrollView setZoomScale:scale animated:NO];
}
 */



@end
