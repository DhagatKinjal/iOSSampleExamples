
#import "MathViewController.h"
#import "TapDetectingDelegate.h"


@interface RootViewController : UIViewController <UIScrollViewDelegate, TapDetectingDelegate> {
    UIScrollView *m_scrollView;
    
    MathViewController *m_viewController;
}

@end

