//
//  CoolMathAppDelegate.h
//  CoolMath
//
//  Created by 谢伟(xiewei.max@gmail.com) on 10-4-30.
//  Copyright Apple 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioServices.h>

@interface SoundWrapper : NSObject {
	SystemSoundID _soundID;
}

+ (id)soundEffectWithContentsOfFile:(NSString *)aPath;
- (id)initWithContentsOfFile:(NSString *)path;
- (void)play;

@end
