//
//  DetectTapProtocol.h
//  CoolMath
//
//  Created by Xie Wei on 10-5-29.
//  Copyright 2010 xiewei.max@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol TapDetectingDelegate <NSObject>

@required
- (void)tapDetectView:(UIView *)view gotDoubleTapAtPoint: (CGPoint)tapPoint;

@end
