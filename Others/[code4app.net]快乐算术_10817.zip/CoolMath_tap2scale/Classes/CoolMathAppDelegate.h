//
//  CoolMathAppDelegate.h
//  CoolMath
//
//  Created by 谢伟(xiewei.max@gmail.com) on 10-4-30.
//  Copyright Apple 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RootViewController;

@interface CoolMathAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    
    RootViewController *m_firstViewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

