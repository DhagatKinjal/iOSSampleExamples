//
//  CoolMathAppDelegate.m
//  CoolMath
//
//  Created by 谢伟(xiewei.max@gmail.com) on 10-4-30.
//  Copyright Apple 2010. All rights reserved.
//

//将整个界面加载到scrollView上，可以对视图进行捏合操作；

#import "CoolMathAppDelegate.h"
#import "RootViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation CoolMathAppDelegate

@synthesize window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions 
{
    window = [[UIWindow alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
    window.backgroundColor = [UIColor redColor];
    
    m_firstViewController = [[RootViewController alloc] init];

	[window addSubview: m_firstViewController.view];

    [window makeKeyAndVisible];
	
	return YES;
}

- (void)dealloc 
{
    [m_firstViewController release];
    [window release];
    [super dealloc];
}


@end
