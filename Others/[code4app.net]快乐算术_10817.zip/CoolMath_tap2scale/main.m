//
//  main.m
//  CoolMath
//
//  Created by 谢伟(xiewei.max@gmail.com) on 10-4-30.
//  Copyright Apple 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"CoolMathAppDelegate");
    [pool release];
    return retVal;
}
