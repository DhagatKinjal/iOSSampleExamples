//
//  SimplerMaskTestAppDelegate.h
//  SimplerMaskTest
//

#import <UIKit/UIKit.h>

@interface SimplerMaskTestAppDelegate : NSObject <UIApplicationDelegate> {
    IBOutlet UIWindow *window;
    IBOutlet UIViewController *viewController;
}

@end

