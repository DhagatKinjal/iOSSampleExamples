//
//  main.m
//  FTWCache
//
//  Created by Soroush Khanlou on 8/12/12.
//  Copyright (c) 2012 FTW. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FTWAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([FTWAppDelegate class]));
	}
}
