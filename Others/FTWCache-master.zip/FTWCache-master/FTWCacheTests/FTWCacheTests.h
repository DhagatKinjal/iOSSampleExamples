//
//  FTWCacheTests.h
//  FTWCacheTests
//
//  Created by Soroush Khanlou on 8/12/12.
//  Copyright (c) 2012 FTW. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface FTWCacheTests : SenTestCase

@end
