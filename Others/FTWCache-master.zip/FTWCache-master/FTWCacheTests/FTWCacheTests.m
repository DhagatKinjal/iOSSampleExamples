//
//  FTWCacheTests.m
//  FTWCacheTests
//
//  Created by Soroush Khanlou on 8/12/12.
//  Copyright (c) 2012 FTW. All rights reserved.
//

#import "FTWCacheTests.h"

@implementation FTWCacheTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in FTWCacheTests");
}

@end
