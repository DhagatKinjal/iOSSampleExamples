## Description

This app lets you import your photos from your Mac into the iOS Simulator.
