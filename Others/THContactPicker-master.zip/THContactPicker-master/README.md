THContactPicker
===============

An iOS view used for selecting multiple contacts. This was built to mimic the selecting contact functionality in the Apple Mail app

![Screenshot](https://raw.github.com/tristanhimmelman/THContactPicker/master/screenshot.png)