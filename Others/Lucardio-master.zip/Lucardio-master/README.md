How to use:
go to: https://devforums.apple.com/message/674055 to learn more!

Currently, I havent got it to work with the latest beta. Go crazy.