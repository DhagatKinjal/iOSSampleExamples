//
//  Calculator.m
//  
//
//  Created by 斌 on 12-11-19.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import "Calculator.h"

@interface Calculator ()

@end

@implementation Calculator

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    //初始化
    [self c:nil];
    self.navigationController.navigationBarHidden=NO;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 按钮事件
- (IBAction)c:(id)sender {
    amountlord.text=@"0";
    amount.text=@"零元";
    top=@"0";
    bottom=@"00";
    bottom1=nil;
    bottom2=nil;
    thedot=NO;
}

- (IBAction)back:(id)sender {
    int numl=[amountlord.text length];//取得长度
    NSLog(@"输入数字长度%d",numl);
    
    if (numl==1) {//仅有一位，执行清零
        [self c:nil];
    }else{//非一位

        if (thedot) {//有小数点
            if(bottom2!=nil){//小数点后2位不为空
                bottom2=nil;
            }else if (bottom1!=nil){//小数点后1位不为空
                bottom1=nil;
            }else if ([amountlord.text hasSuffix:@"."]) {//底部是小数点
                thedot=NO;
            }
            amountlord.text=[amountlord.text substringWithRange:NSMakeRange(0, numl-1)];
        }else{
            amountlord.text=[amountlord.text substringWithRange:NSMakeRange(0, numl-1)];
            amountlord.text=[self AddComma:amountlord.text];
            top=amountlord.text;
        }
        [self Converter];
    }

    
}

- (IBAction)zero:(id)sender {
    if ([amountlord.text isEqualToString:@"0"]) {
        [self c:nil];
    }else{
        [self num:@"0"];
    }
}

- (IBAction)dot:(id)sender {
    if (!thedot) {
        amountlord.text=[NSString stringWithFormat:@"%@.",amountlord.text];
        thedot=YES;
    }
}

- (IBAction)one:(id)sender {
    [self num:@"1"];
}

- (IBAction)two:(id)sender {
    [self num:@"2"];
}

- (IBAction)three:(id)sender {
    [self num:@"3"];
}

- (IBAction)four:(id)sender {
    [self num:@"4"];
}

- (IBAction)five:(id)sender {
    [self num:@"5"];
}

- (IBAction)six:(id)sender {
    [self num:@"6"];
}

- (IBAction)seven:(id)sender {
    [self num:@"7"];
}

- (IBAction)eight:(id)sender {
    [self num:@"8"];
}

- (IBAction)nine:(id)sender {
    [self num:@"9"];
}

#pragma mark - 实现方法
-(void)num:(NSString*)str{//输入数字
    
    if (!thedot) {//没有小数点
        if ([amountlord.text isEqualToString:@"0"]){//且仅有一位是0
            amountlord.text=[NSString stringWithFormat:@"%@",str]; 
        }else{//非一位
            if ([amountlord.text length]<11) {
                amountlord.text=[NSString stringWithFormat:@"%@%@",amountlord.text,str];
            }else{
                NSLog(@"交易额已达到亿位。");
            }
        }
        amountlord.text=[self AddComma:amountlord.text];
        top=amountlord.text;
        NSLog(@"数字顶部%@",top);
        [self Converter];
    }else{//有小数点
        if (bottom1==nil) {//首位为空
            bottom1=str;
            NSLog(@"小数点后第一位%@",bottom1);
            amountlord.text=[NSString stringWithFormat:@"%@%@",amountlord.text,str];
        }else{//首位非空
            bottom2=str;
            NSLog(@"小数点后第二位%@",bottom2);
            amountlord.text=[NSString stringWithFormat:@"%@.%@%@",top,bottom1,str];
        }
        [self Converter];
    }
}

- (NSString *)AddComma:(NSString *)string{//添加逗号
    
    NSString *str=[string stringByReplacingOccurrencesOfString:@"," withString:@""];
    int numl=[str length];
    NSLog(@"%d",numl);
    
        if (numl>3&&numl<7) {
          return [NSString stringWithFormat:@"%@,%@",
                  [str substringWithRange:NSMakeRange(0,numl-3)],
                  [str substringWithRange:NSMakeRange(numl-3,3)]];
        }else if (numl>6){
            return [NSString stringWithFormat:@"%@,%@,%@",
                    [str substringWithRange:NSMakeRange(0,numl-6)],
                    [str substringWithRange:NSMakeRange(numl-6,3)],
                    [str substringWithRange:NSMakeRange(numl-3,3)]];
        }else{  
            return str;
        }

}

-(void)Converter{//转换中文大写数字
    NSString *topstr=[top stringByReplacingOccurrencesOfString:@"," withString:@""];//过滤逗号
    int numl=[topstr length];//确定长度
    NSString *cache;//缓存
    if ((numl==2||numl==6)&&[topstr hasPrefix:@"1"] ){//十位或者万位为一时候
        cache=@"拾";
        for (int i=1; i<numl; i++) {
            cache=[NSString stringWithFormat:@"%@%@",cache,[self bit:topstr thenum:i]];
        }
    }else{//其他
        cache=@"";
        for (int i=0; i<numl; i++) {
            cache=[NSString stringWithFormat:@"%@%@",cache,[self bit:topstr thenum:i]];
        }
    }//转换完大写
    NSLog(@"cache:%@",cache);
    amount.text=@"";
    cache=[cache substringWithRange:NSMakeRange(0, [cache length]-1)];
    for (int i=[cache length]; i>0; i--) {//擦屁股，如果尾部为0就擦除
        if ([cache hasSuffix:@"零"]) {
            cache=[cache substringWithRange:NSMakeRange(0, i-1)];
        }else{
            continue;
        }
    }
    NSLog(@"cache2:%@",cache);
    for (int i=[cache length]; i>0; i--) {//重复零，删零
        NSString *a=[cache substringWithRange:NSMakeRange(i-1, 1)];
        NSString *b=[cache substringWithRange:NSMakeRange(i-2, 1)];
        if (!([a isEqualToString:b]&&[a isEqualToString:@"零"])) {
            amount.text=[NSString stringWithFormat:@"%@%@",a,amount.text];
        }
        cache=[cache substringWithRange:NSMakeRange(0, i-1)];
    }
    cache=amount.text;
    amount.text=@"元";
    NSLog(@"cache3:%@",cache);
    for (int i=[cache length]; i>0; i--) {//去掉 “零万” 和 “亿万”
        NSString *a=[cache substringWithRange:NSMakeRange(i-1, 1)];
        NSString *b=[cache substringWithRange:NSMakeRange(i-2, 1)];
        if ([a isEqualToString:@"万"]&&[b isEqualToString:@"零"]) {
            NSString *c=[cache substringWithRange:NSMakeRange(i-3, 1)];
            if ([c isEqualToString:@"亿"]){
                amount.text=[NSString stringWithFormat:@"%@%@",c,amount.text];
                cache=[cache substringWithRange:NSMakeRange(0, i-3)];
                i=i-2;
            }else{
                amount.text=[NSString stringWithFormat:@"%@%@",a,amount.text];
                cache=[cache substringWithRange:NSMakeRange(0, i-2)];
                i--;
            }
        }else{
            amount.text=[NSString stringWithFormat:@"%@%@",a,amount.text];
        }
        cache=[cache substringWithRange:NSMakeRange(0, i-1)];
    }
    
    
    if ([amount.text isEqualToString:@"元"]) {
        amount.text=@"零元";
    }
    
    
    if (bottom1!=nil ) {
        if (bottom2!=nil && ![bottom2 isEqualToString:@"0"]) {
            amount.text=[NSString stringWithFormat:@"%@%@角%@分",amount.text,[self NumtoCN:bottom1 site:0],[self NumtoCN:bottom2 site:0]];
        }else{
            if (![bottom1 isEqualToString:@"0"]) {
                amount.text=[NSString stringWithFormat:@"%@%@角",amount.text,[self NumtoCN:bottom1 site:0]];
            }
        }
    }
    
    
}

-(NSString*)NumtoCN:(NSString*)string site:(int)site{//阿拉伯数字转中文大写
    
    if ([string isEqualToString:@"0"]) {
        if (site==5) {
            return @"万零";
        }else{
            return @"零";
        }
    }else if ([string isEqualToString:@"1"]) {
        string=@"壹";
    }else if ([string isEqualToString:@"2"]) {
        string=@"贰";
    }else if ([string isEqualToString:@"3"]) {
        string=@"叁";
    }else if ([string isEqualToString:@"4"]) {
        string=@"肆";
    }else if ([string isEqualToString:@"5"]) {
        string=@"伍";
    }else if ([string isEqualToString:@"6"]) {
        string=@"陆";
    }else if ([string isEqualToString:@"7"]) {
        string=@"柒";
    }else if ([string isEqualToString:@"8"]) {
        string=@"捌";
    }else if ([string isEqualToString:@"9"]) {
        string=@"玖";
    }
    
    
    switch (site) {
        case 1:
            return [NSString stringWithFormat:@"%@元",string];
            break;
        case 2:
            return [NSString stringWithFormat:@"%@拾",string];
            break;
        case 3:
            return [NSString stringWithFormat:@"%@佰",string];
            break;
        case 4:
            return [NSString stringWithFormat:@"%@仟",string];
            break;
        case 5:
            return [NSString stringWithFormat:@"%@万",string];
            break;
        case 6:
            return [NSString stringWithFormat:@"%@拾",string];
            break;
        case 7:
            return [NSString stringWithFormat:@"%@佰",string];
            break;
        case 8:
            return [NSString stringWithFormat:@"%@仟",string];
            break;
        case 9:
            return [NSString stringWithFormat:@"%@亿",string];
            break;
        default:
            return string;
            break;
    }
}
-(NSString*)bit:(NSString*)string thenum:(int)num{//取位转大写
    int site=[string length]-num;
    string=[string stringByReplacingOccurrencesOfString:@"," withString:@""];
    NSLog(@"传入字符串%@，总长度%d,传入位%d",string,[string length],num);
    string=[string substringWithRange:NSMakeRange(num,1)];
    string=[self NumtoCN:string site:site];
    NSLog(@"转换后:%@",string);
    return string;
    
}

@end
