//
//  Calculator.h
//  
//
//  Created by 斌 on 12-11-19.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Calculator : UIViewController{

    IBOutlet UILabel *time;
    IBOutlet UILabel *amountlord;
    IBOutlet UILabel *amount;
    
    NSString *top,*bottom;//数字顶部，底部
    NSString *bottom1,*bottom2;//底部1位，底部2位
    BOOL thedot;
}
- (IBAction)c:(id)sender;
- (IBAction)back:(id)sender;
- (IBAction)zero:(id)sender;
- (IBAction)dot:(id)sender;
- (IBAction)one:(id)sender;
- (IBAction)two:(id)sender;
- (IBAction)three:(id)sender;
- (IBAction)four:(id)sender;
- (IBAction)five:(id)sender;
- (IBAction)six:(id)sender;
- (IBAction)seven:(id)sender;
- (IBAction)eight:(id)sender;
- (IBAction)nine:(id)sender;

@end
