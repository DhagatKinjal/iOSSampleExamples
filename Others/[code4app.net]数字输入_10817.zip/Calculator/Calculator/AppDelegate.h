//
//  AppDelegate.h
//  Calculator
//
//  Created by 斌 on 12-11-20.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Calculator;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Calculator *viewController;

@end
