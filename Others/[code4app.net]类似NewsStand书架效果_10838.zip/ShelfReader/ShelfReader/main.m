//
//  main.m
//  ShelfReader
//
//  Created by liu liu on 11-12-1.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ShelfReaderAppDelegate.h"

int main(int argc, char *argv[])
{
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([ShelfReaderAppDelegate class]));
    }
    return retVal;
}
