//
//  PopoverController.h
//  PerfectTable
//
//  Created by liu on 11-6-15.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController(background)

-(void)addBackgroundView:(NSString*)image;
@end