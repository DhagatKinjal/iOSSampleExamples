//
//  ViewController.h
//  MD5Demo
//
//  Created by zhangmh on 12-7-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyMD5.h"
@interface ViewController : UIViewController
{
    UITextField *inputField;
    UILabel     *outputLabel;
}
@end
