//
//  luminanceTests.m
//  luminanceTests
//
//  Created by 彦斌 刘 on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "luminanceTests.h"

@implementation luminanceTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in luminanceTests");
}

@end
