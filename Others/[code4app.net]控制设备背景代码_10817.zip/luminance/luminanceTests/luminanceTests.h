//
//  luminanceTests.h
//  luminanceTests
//
//  Created by 彦斌 刘 on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface luminanceTests : SenTestCase

@end
