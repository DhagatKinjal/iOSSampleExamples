//
//  ViewController.m
//  luminance
//
//  Created by 彦斌 刘 on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize mSlider;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setMSlider:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [mSlider release];
    [super dealloc];
}
- (IBAction)Slider:(id)sender {
  [[UIScreen mainScreen] setBrightness: mSlider.value];
}

- (IBAction)Stepper:(id)sender {
    [[UIScreen mainScreen] setBrightness:[(UIStepper *)sender value]];
}
@end
