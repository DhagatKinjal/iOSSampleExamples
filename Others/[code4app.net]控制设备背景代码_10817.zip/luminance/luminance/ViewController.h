//
//  ViewController.h
//  luminance
//
//  Created by 彦斌 刘 on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
IBOutlet UISlider *mSlider;
}
@property (retain, nonatomic) IBOutlet UISlider *mSlider;
- (IBAction)Slider:(id)sender;
- (IBAction)Stepper:(id)sender;

@end
