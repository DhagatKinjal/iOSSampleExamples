//
//  main.m
//  EBPurchase-Demo
//
//  Created by Dave Wooldridge, Electric Butterfly, Inc.
//  Copyright (c) 2012 Electric Butterfly, Inc. - http://www.ebutterfly.com/
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
