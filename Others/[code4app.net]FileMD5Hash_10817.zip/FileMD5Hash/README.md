FileMD5Hash
===========

simple arc objective-c wrapping of https://github.com/JoeKun/FileMD5Hash