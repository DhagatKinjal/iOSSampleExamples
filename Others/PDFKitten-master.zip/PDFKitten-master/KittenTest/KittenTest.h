#import <SenTestingKit/SenTestingKit.h>

@interface KittenTest : SenTestCase

@end
