#import <Foundation/Foundation.h>
#import "CompositeFont.h"

@interface Type0Font : CompositeFont {
	NSMutableArray *descendantFonts;
}

@end
