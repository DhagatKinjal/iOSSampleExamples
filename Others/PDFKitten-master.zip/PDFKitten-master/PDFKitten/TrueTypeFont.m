#import "TrueTypeFont.h"


@implementation TrueTypeFont

@end
