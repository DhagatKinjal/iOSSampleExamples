#import <Foundation/Foundation.h>
#import	"SimpleFont.h"

@interface MMType1Font : SimpleFont {
    
}

@end
