#import "MMType1Font.h"


@implementation MMType1Font

@end
