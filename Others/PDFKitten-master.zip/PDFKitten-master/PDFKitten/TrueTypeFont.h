#import <Foundation/Foundation.h>
#import "SimpleFont.h"


@interface TrueTypeFont : SimpleFont {
}

@end
