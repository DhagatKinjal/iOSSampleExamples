#import <Foundation/Foundation.h>
#import "CompositeFont.h"

@interface CIDType0Font : CompositeFont {
    
}

@end
