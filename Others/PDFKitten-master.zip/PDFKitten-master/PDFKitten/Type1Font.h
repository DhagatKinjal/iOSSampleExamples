#import <Foundation/Foundation.h>
#import "SimpleFont.h"

@interface Type1Font : SimpleFont {
}

@end
