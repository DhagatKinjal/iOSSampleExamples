#import "Type1Font.h"

@implementation Type1Font

- (id)initWithFontDictionary:(CGPDFDictionaryRef)dict
{
	if (self = [super initWithFontDictionary:dict])
	{
	}
	return self;
}

@end
