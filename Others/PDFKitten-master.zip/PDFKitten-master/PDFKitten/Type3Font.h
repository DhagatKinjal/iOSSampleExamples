#import <Foundation/Foundation.h>
#import "SimpleFont.h"

@interface Type3Font : SimpleFont {
    
}

@end
