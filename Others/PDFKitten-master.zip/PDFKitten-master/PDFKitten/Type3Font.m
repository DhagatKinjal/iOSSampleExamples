#import "Type3Font.h"


@implementation Type3Font

@end
