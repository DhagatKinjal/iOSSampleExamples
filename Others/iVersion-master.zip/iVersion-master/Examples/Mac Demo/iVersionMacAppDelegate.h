//
//  iVersionMacAppDelegate.h
//  iVersionMac
//
//  Created by Nick Lockwood on 06/02/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface iVersionMacAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *__weak window;
}

@property (weak) IBOutlet NSWindow *window;

@end
