//
//  MyAccountViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

#import "ViewController.h"
@interface MyAccountViewController : UIViewController< UITextViewDelegate,UITextFieldDelegate>{
    AppDelegate *appDelegate;
    NSString *str;
    NSURL *url;
    NSURLRequest *req;
    NSURLConnection *conn;
    NSMutableData *xmldata;
    NSMutableData *xmldata1;
   
    
    NSURL *url1;
    NSURLRequest *req1;
    NSURLConnection *conn1;
    
    NSString *currentElementValue;
	NSMutableString *CurrentText;
    NSMutableArray *fNameMutableArray,*lNameMutableArray,*addressMutableArray,*emailMutableArray;
    
    NSString *nameString;
    NSString *lastNameString;
    NSString *emailidString;
    NSString *addressString;
    
    NSMutableString *output;
    NSXMLParser *xml_parser;
}
@property (retain, nonatomic) IBOutlet UIView *newEditView;
@property (retain, nonatomic) IBOutlet UIView *editView;
- (IBAction)editYesMethod:(id)sender;
- (IBAction)editButtonMethod:(id)sender;
- (IBAction)editNoMethhod:(id)sender;

@property (retain, nonatomic) IBOutlet UILabel *youraccountLabel;
@property (retain, nonatomic) IBOutlet UIButton *submit;
@property (retain, nonatomic) IBOutlet UITextView *emailTextView;
@property (retain, nonatomic) IBOutlet UITextView *lastTextView;
@property (retain, nonatomic) IBOutlet UITextField *nameTextField;
@property (retain, nonatomic) IBOutlet UITextField *lastNameTextField;
@property (retain, nonatomic) IBOutlet UITextField *emailidTextField;
@property (retain, nonatomic) IBOutlet UITextField *addressTextfield;
@property (retain, nonatomic) IBOutlet UITextView *addresstextView;

@property (retain, nonatomic) IBOutlet UIScrollView *mainScroll;

- (IBAction)msgScreenMethod:(id)sender;
- (IBAction)venuesScreenMethod:(id)sender;
- (IBAction)homScreenMethod:(id)sender;

- (IBAction)updateMethod:(id)sender;
- (IBAction)backButtonMethod:(id)sender;
- (IBAction)submitButtonMethod:(id)sender;
@end
