//
//  ViewController.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"

#import "CheckXMLParser.h"

#import "DBHandler.h"
#import "AppDelegate.h"
#import "ScantableCustomCell.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,UIAlertViewDelegate,CLLocationManagerDelegate> {
    NSMutableArray *ChkDetailArr;
    CLLocationManager *locationManager;
    IBOutlet UILabel *latLabel;
    IBOutlet UILabel *longLabel;
    
    IBOutlet UIButton *myAccountButton;
	int firstTimeEnterVanue;
    NSMutableArray				*scanHistory;
	
    
    IBOutlet UIView *reoderAlterView;
    NSArray *timeDate;
    
	IBOutlet UITableView 		*scanHistoryTable;
	IBOutlet UILabel 			*appNameAndVersionLabel;
	IBOutlet UIView 			*firstTimeView;
    IBOutlet UILabel * venuesLable;
	NSString *MyUrlID1;
	//BarcodePickerController		*pickerController;
    DBHandler *dbh;
    
    AppDelegate *appDelegate;
    CheckXMLParser *check;
    
    
	NSString *currentElementValue;
	NSMutableString *CurrentText;
	
    NSMutableArray *CategoryName,*CategoryId;
    NSMutableString *output;
    NSXMLParser *xml_parser;
    NSMutableData *xmldata;
    NSURLRequest *req;
    NSURLConnection *conn;
    NSMutableDictionary *dics;
    NSURL *url;
    NSURL *url11;
    NSString *arrString;
    
    //CGRect screenBounds;
    
}
- (IBAction)chechInButtonMethoc:(id)sender;
- (IBAction)newOrderMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *newOrderButtonMethod;
- (IBAction)reoderderButtonMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *reorderView;
@property (retain, nonatomic) IBOutlet UITextView *feedbackTextView;
- (IBAction)feedbackSubmitButton:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *feedbackCommentView;
@property (retain, nonatomic) IBOutlet UIView *feedBackView;
- (IBAction)butterButtonAction:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *BtterButtonMethod;
- (IBAction)loveButtonMethod:(id)sender;
- (IBAction)closeButtonMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *CheckinMethod;
- (IBAction)reoderMethod:(id)sender;
- (IBAction)newOrder:(id)sender;
- (IBAction)scanMethod:(id)sender;

- (IBAction)feedBackMethod:(id)sender;

@property (retain, nonatomic) NSArray *timeDate;
@property (retain, nonatomic) NSString *MyUrlID1;
@property (retain, nonatomic) IBOutlet UILabel *CheckInLabel;
- (IBAction)MyOrderMethod:(id)sender;
- (IBAction)myAccountMethod:(id)sender;

@property(nonatomic,retain)IBOutlet UITableView 		*scanHistoryTable;
@property(nonatomic,retain)IBOutlet UILabel * venuesLable;
@property (nonatomic,retain)IBOutlet UIButton *messageButton;
@property(nonatomic,retain) NSString *lat;
@property(nonatomic,retain)  NSString *longt;

- (IBAction)infoButtonMethod:(id)sender;

- (IBAction) optionsButtonPressed:(id)sender;
- (IBAction) clearButtonPressed:(id)sender;

- (IBAction) scanButtonPressed;
- (IBAction) multiScanButtonPressed;
- (IBAction) redBoxScanButtonPressed;
-(IBAction)messageButtonMethod:(id)sender;

@property (retain, nonatomic) IBOutlet UIButton *scan;

@end
