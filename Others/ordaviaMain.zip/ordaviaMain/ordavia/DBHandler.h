//
//  DBHandler.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import "sqlite3.h"
@interface DBHandler : UIView
{
    AppDelegate *appdel;
    sqlite3 *db;
    NSString *dataPath;
    NSString *dataPath1;
    NSString *dataPath2;
    NSString *dataPath3;
    float field1;
    NSMutableArray *tempID;

}
@property(nonatomic,strong)NSMutableArray *tempID;
@property(nonatomic,retain)NSMutableArray *qtyPost;;
@property(nonatomic)float field1;
-(NSMutableArray *)SelectProItem;
-(BOOL)insert:(NSArray *)arr;
-(void)deleteall;
-(BOOL)UpadateTable:(NSArray *)arr;
-(NSMutableArray *)SelectQty;
-(NSMutableArray *)SelectAddItemID;
-(void)deletealll;
-(NSMutableArray *)selectinfo;
-(NSString *)SelectSUM;
-(BOOL)deleteOne:(NSString*)str;
-(NSString *)selectCount;
//// Time /////

-(bool)insertTimeDate:(NSArray *)arr;
-(NSMutableArray *)selecttime;
-(void)deleteTime;

////push/////

-(bool)insertPush:(NSArray *)arr;
-(bool)insertNewPush:(NSArray *)arr;

-(NSMutableArray *)selectPush:(NSString*)str;
-(NSMutableArray *)selectNewPushAll;
-(NSMutableArray *)selectNewPush:(NSString *)str;


-(BOOL)UpadetePush:(NSArray *)arr;
-(NSMutableArray *)selectPushCount:(NSString*)string;
-(BOOL)deleteOnePush:(NSString*)str;

//// Order Price ////

-(NSMutableArray *)SelectPrice:(NSString *)str;
-(BOOL)insertPrice:(NSArray *)arr;
-(BOOL)deleteOnePrice:(NSString*)str;
-(void)deleteallPrice;
@end
