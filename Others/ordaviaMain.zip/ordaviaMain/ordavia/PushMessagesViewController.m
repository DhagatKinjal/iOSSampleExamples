//
//  PushMessagesViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "PushMessagesViewController.h"
#import "ViewController.h"
#import "MainOrderViewController.h"
#import "PushMessagesCustomCell.h"
#import "AppDelegate.h"
#import "MapViewController.h"
#import "DBHandler.h";
static CGFloat padding = 20.0;

@interface PushMessagesViewController ()

@end

@implementation PushMessagesViewController
@synthesize NotifactionArray,NotificationTime,arrayPush,BID,productName1;
ViewController *objRLSampleViewController;
MainOrderViewController *objMainOrderViewController;
MapViewController *objMapViewController;
AppDelegate *objRLSampleAppDelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        objRLSampleAppDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)viewDidLoad
{
    msgArray =[[NSMutableArray alloc]init];
    messages=[[NSMutableArray alloc]init];

    
   // NSLog(@"%@",Barid);
   // NSLog(@"%@",productName1);
    
    _bsrNameTitel.text=productName1;
    
    
    [super viewDidLoad];
    dbh=[[DBHandler alloc]init];
    
    self.NotifactionArray=[[NSMutableArray alloc]init];
    self.NotificationTime=[[NSMutableArray alloc]init];
    
    self.arrayPush=[[NSMutableArray alloc]init];
    NSLog(@"%@",BID);
    
    self.arrayPush=[dbh selectPush:BID];
    [messageTableView reloadData];
    NSLog(@"%@",self.arrayPush);
    for (int j=0; j<[self.arrayPush count]; j++)
    {
        NSString *string=[NSString stringWithFormat:@"%@",[self.arrayPush objectAtIndex:j]];
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        string = [[string componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        NSMutableArray *TBArr=[[NSMutableArray alloc]initWithArray:[string componentsSeparatedByString:@","]];
        
        NSLog(@"%@",TBArr);
        
        
        
        
        NSMutableDictionary *m = [[NSMutableDictionary alloc] init];
		[m setObject:[TBArr objectAtIndex:2] forKey:@"msg"];
        
        
        
        NSString *checkMsgSt=[NSString stringWithFormat:@"%@",[TBArr objectAtIndex:3]];
        NSCharacterSet *doNotWantagain = [NSCharacterSet characterSetWithCharactersInString:@"\n "];
        checkMsgSt = [[checkMsgSt componentsSeparatedByCharactersInSet: doNotWantagain] componentsJoinedByString: @""];
        NSLog(@"%@",checkMsgSt);
        
        if([checkMsgSt isEqualToString:@"Send"])
        {
            
            [m setObject:@"Send" forKey:@"sender"];
        }
        else
        {
            [m setObject:@"Recieve" forKey:@"sender"];
        }
		[m setObject:[TBArr objectAtIndex:4] forKey:@"time"];
		
        
		[messages addObject:m];

    }
    NSLog(@"%@",messages);
    NSString *str=@"unread";
    NSArray *arrcount=[dbh selectPushCount:str];
    
    
    NSLog(@"%@",arrcount);
    NSString *strCount=[NSString stringWithFormat:@"%@",arrcount];
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
    strCount = [[strCount componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    _CountFromPushMsg.text=strCount;
    NSLog(@"%@\n%@",strCount,_CountFromPushMsg.text);
    
    [messageTableView reloadData];
    
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [_messageTableView reloadData];
    
    int lastRowNumber = [_messageTableView numberOfRowsInSection:0] - 1;
    NSIndexPath* ip = [NSIndexPath indexPathForRow:lastRowNumber inSection:0];
    [_messageTableView scrollToRowAtIndexPath:ip atScrollPosition:UITableViewScrollPositionTop animated:NO];
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)backButtonMethod:(id)sender{
    //[self dismissViewControllerAnimated:YES completion:nil];
    //[self.view removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)MyOrderMethod:(id)sender {
    
    
    
    objMapViewController=[[MapViewController  alloc]initWithNibName:@"MapViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objMapViewController animated:YES];
    
    
    
    
}

- (IBAction)MainScreenMethod:(id)sender {
    
    
    objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objRLSampleViewController animated:YES];
    
    
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.arrayPush count];
    //return [self.NotifactionArray count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	
    
	NSDictionary *dict = (NSDictionary *)[messages objectAtIndex:indexPath.row];
    
	NSString *msg = [dict objectForKey:@"msg"];
	
	CGSize  textSize = { 260.0, 10000.0 };
	CGSize size = [msg sizeWithFont:[UIFont boldSystemFontOfSize:13]
				  constrainedToSize:textSize
					  lineBreakMode:UILineBreakModeWordWrap];
	
	size.height += padding*2;
	
	CGFloat height = size.height < 65 ? 65 : size.height;
	return height;
	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    
    NSDictionary *s = (NSDictionary *) [messages objectAtIndex:indexPath.row];
	
    NSLog(@"%@",messages);
    static  NSString *cellIdentifier=@"PushMessagesCustomCell";
    
    PushMessagesCustomCell *cell = (PushMessagesCustomCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
  
	if (cell == nil) {
		cell = [[PushMessagesCustomCell alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier];
	}
    
	NSString *sender = [s objectForKey:@"sender"];
	NSString *message = [s objectForKey:@"msg"];
	NSString *time = [s objectForKey:@"time"];
	
	CGSize  textSize = { 260.0, 10000.0 };
	CGSize size = [message sizeWithFont:[UIFont boldSystemFontOfSize:13]
					  constrainedToSize:textSize
						  lineBreakMode:UILineBreakModeWordWrap];
    
	
	size.width += (padding/2);
	
	
	cell.messageContentView.text = message;
	cell.accessoryType = UITableViewCellAccessoryNone;
	cell.userInteractionEnabled = NO;
	
    
	UIImage *bgImage = nil;
	
    NSLog(@"%@",sender);
	if (![sender isEqualToString:@"Send"]) { // left aligned
        
		bgImage = [[UIImage imageNamed:@"orange.png"] stretchableImageWithLeftCapWidth:24  topCapHeight:15];
		
		[cell.messageContentView setFrame:CGRectMake(padding, padding*2, size.width, size.height)];
		
		[cell.bgImageView setFrame:CGRectMake( cell.messageContentView.frame.origin.x - padding/2,
											  cell.messageContentView.frame.origin.y - padding/2,
											  size.width+padding,
											  size.height+padding)];
        
	} else {
        
		bgImage = [[UIImage imageNamed:@"aqua.png"] stretchableImageWithLeftCapWidth:24  topCapHeight:15];
		
		[cell.messageContentView setFrame:CGRectMake(320 - size.width - padding,
													 padding*2,
													 size.width,
													 size.height)];
		
		[cell.bgImageView setFrame:CGRectMake(cell.messageContentView.frame.origin.x - padding/2,
											  cell.messageContentView.frame.origin.y - padding/2,
											  size.width+padding,
											  size.height+padding)];
		
	}
	
	cell.bgImageView.image = bgImage;
    [cell.senderAndTimeLabel setBackgroundColor:[UIColor clearColor]];
	cell.senderAndTimeLabel.text = [NSString stringWithFormat:@"%@", time];
	
	return cell;
	

    
    

    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PushMessagesCustomCell *cell = (PushMessagesCustomCell*)[tableView cellForRowAtIndexPath:indexPath];
    NSLog(@"%d",indexPath.row);
    NSLog(@"%@",cell.idPushMsg.text);
    
    NSArray *arrPush=[[NSArray alloc]initWithObjects:@"read",[NSString stringWithFormat:@"%@",cell.idPushMsg.text], nil];
    NSLog(@"%@",arrPush);
    cell.cellImage.image = [UIImage imageNamed:@"readM.png"];
    [dbh UpadetePush:arrPush];
    self.arrayPush=[dbh selectPush];
    NSLog(@"%@",self.arrayPush);
    NSString *str=@"unread";
    NSArray *arrcount=[dbh selectPushCount:str];
    NSLog(@"%@",arrcount);
    NSString *strCount=[NSString stringWithFormat:@"%@",arrcount];
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
    strCount = [[strCount componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    _CountFromPushMsg.text=strCount;
    NSLog(@"%@\n%@",strCount,_CountFromPushMsg.text);
    
    [_messageTableView reloadData];
    
    
       
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // No editing style if not editing or the index path is nil.
 //if (self.editing == NO || !indexPath) return UITableViewCellEditingStyleNone;
 // Determine the editing style based on whether the cell is a placeholder for adding content or already
 // existing content. Existing content can be deleted.
 if (self.editing && indexPath.row == ([self.arrayPush count]))
 {
 return UITableViewCellEditingStyleInsert;
 } else
 {
 return UITableViewCellEditingStyleDelete;
 }
 return UITableViewCellEditingStyleNone;
 }

// Update the data model according to edit actions delete or insert.
- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    
}



- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    return YES;
}


- (IBAction)sendMessage:(id)sender {
    
    NSString *msg=sendMessageTextView.text;
    
        
    msg = [msg stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    NSLog(@"After = %@",msg);
    NSLog(@"%@",BID);
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CustomerApi/randomMsg?zoneId=1&msg=%@&orderId=%@",msg,BID];
    NSLog(@"%@",myurl);
    url = [[NSURL alloc] initWithString:myurl];
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [messageTableView reloadData];
    [conn release];
    
    NSDateFormatter *formatter;
    NSString        *dateString;
    
    formatter = [[NSDateFormatter alloc] init];
    // [formatter setDateFormat:@"HH:mm a"];
    
    [formatter setDateFormat:@"MMM/dd/yyyy/hh:mm a"];
    
    dateString = [formatter stringFromDate:[NSDate date]];
    NSLog(@"%@",dateString);
    [formatter release];
    
    NSLog(@"barid-->%@",Barid);
    
    
    msg = [msg stringByReplacingOccurrencesOfString:@"%20" withString:@" "];
    
    NSLog(@"After = %@",msg);
    
    
    
    NSArray *arr=[[NSArray alloc]initWithObjects:productName1,[NSString stringWithFormat:@"%d",i],msg,@"Send",dateString,@"6",BID, nil];
    NSLog(@"%@",arr);
    
    [dbh insertPush:arr];
    
    
    
    dbh=[[DBHandler alloc]init];
    
    self.arrayPush=[dbh selectPush:BID];
    
   // [self.messageTableView reloadData];
    
    
    
    
    
    NSString *messageStr =sendMessageTextView.text;
	NSLog(@"%@",messageStr);
    
    if([messageStr length] > 0) {
		
        
        NSMutableDictionary *m = [[NSMutableDictionary alloc] init];
		[m setObject:messageStr forKey:@"msg"];
		[m setObject:@"Send" forKey:@"sender"];
        [m setObject:dateString forKey:@"time"];
        
		
        
		[messages addObject:m];
		
        
    }
	
	NSIndexPath *topIndexPath = [NSIndexPath indexPathForRow:messages.count-1
												   inSection:0];
    [self.messageTableView reloadData];
    
    
    
    
    
      CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    if (568 == screenBounds.size.height)
    {
        
        
        [_mainScroll setFrame:CGRectMake(0,52,320,497)];
    }else{
        
        [_mainScroll setFrame:CGRectMake(0,30,320,480)];
        
    }

    
    
    [sendMessageTextView resignFirstResponder];
    sendMessageTextView.text=@"";
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
      CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if([text isEqualToString:@"\n"]) {
        //  self.view.frame = CGRectMake(0,0,320,500);
        if (568 == screenBounds.size.height)
        {
            
        
               [_mainScroll setFrame:CGRectMake(0,52,320,497)];
        }else{
            
            [_mainScroll setFrame:CGRectMake(0,30,320,480)];

        }
      
                         
          [sendMessageTextView resignFirstResponder];     
        
        return NO;
    }
    
    return YES;
}




- (void)textViewDidBeginEditing:(UITextView *)textView
{
   
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
    
    
    _mainScroll.frame=CGRectMake(0,-190, 320,517);
    
    }else{
        
         _mainScroll.frame=CGRectMake(0,-190, 320,460);
    }
    
    
    
    
}


- (void)dealloc {
    [_CountFromPushMsg release];
    [sendMessageTextView release];
    [_mainScroll release];
    [_bsrNameTitel release];
    [super dealloc];
}

@end
