//
//  AddPoductViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "AddPoductViewController.h"
#import "XMLParser.h"
#import "AddPoductViewController.h"
#import "MainOrderViewController.h"
#import "ViewController.h"
#import "PushMessagesViewController.h"
#import "AppDelegate.h"
@interface AddPoductViewController ()
{
    
}

+ (void) setBackgroundColor:(UIColor *) background
            withStrokeColor:(UIColor *) stroke;
@end


@implementation AddPoductViewController
@synthesize TitleStr,DiscriptionStr,books,brandstring,ProDuctID,TitleStr1;
@synthesize totalAmount1,MyUrlID;
@synthesize  CouterForBottle,forValidation1,forValidation,donotaddagainsoda,
donotaddagainDCoke,
donotaddagainIce,
donotaddagainLemonde,
donotaddagaincoke,
donotaddagainsDistilWater,bgImageView,headerImageView;



XMLParser *objXMLParser;
ViewController *objRLSampleViewController;
MainOrderViewController *objMainOrderViewController;
PushMessagesViewController *objPushMessagesViewController;

AppDelegate *objRLSampleAppDelegate;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        appDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    mstr=[[NSMutableString alloc]init];
    AddonIds=[[NSMutableString alloc]init];
    btnarray = [[NSMutableArray alloc]init];
    btn=[[NSMutableArray alloc]init];;
}
- (void)viewDidLoad
{
    temp1=0;
    _alertView.hidden=YES;
    _DescriptionView.hidden=YES;
   
    AddonArray =[[NSMutableArray alloc]init];
    TempAddons=[[NSMutableString alloc]init];
    
    [_SubItemForAddLbl setNumberOfLines:3];
    [_Activity startAnimating];
    
    _decLabel.text=TitleStr1;
    
    NSLog(@"%@",AddonArray);
    
    
    UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(94,14,130,35)];
    
    NSString *string=[NSString stringWithFormat:@"http://%@",objRLSampleAppDelegate.logoString];
    
    
    
    UIImage *img=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:string]]];
    
    [imgview setImage:img];
    
    [self.view addSubview:imgview];
    
    //sleep(2);
    Btni=0;
    extraforAddonPrice=[[NSMutableArray alloc]init];
    //NSString *MyUrlID1=[[NSString alloc]init];
    //NSLog(@"%@",self.MyUrlID);
    
    NSString *MyUrlID1=[NSString stringWithFormat:@"%@",self.MyUrlID];
    //NSLog(@"%@",MyUrlID1);
    
    
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n  "];
    MyUrlID1 = [[MyUrlID1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    
    
    //NSLog(@"%@",MyUrlID1);
    
    
    
    url=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/ProductItemApi/getProductItemAddon?product_id=%@",MyUrlID1];
    
    
    NSLog(@"%@",url);
    
    
    NSString *u=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/ProductItemApi/getProductItemAddon?product_id=%@&action=customer",MyUrlID1];
    NSURL *myurl1=[NSURL URLWithString:u];
    
    //NSURL *url = [[NSURL alloc] initWithString:@"http://10.1.1.17/ordavia/index.php/ProductItemApi/getProductItemAddon?product_id=1"];
	NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:myurl1];
	
	XMLParser *parser = [[XMLParser alloc] initXMLParser];
	
	
	[xmlParser setDelegate:parser];
	
	//Start parsing the XML file.
	BOOL success = [xmlParser parse];
	
	if(success)
		NSLog(@"No Errors");
	else
		NSLog(@"Error Error Error!!!");
    
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //NSLog(@"uday: %@",appDelegate.books);
    
    //url = [[NSURL alloc] initWithString:@"http://10.1.1.17/ordavia/index.php/ProductItemApi/getProductItemAddon?product_id=1"];
    
    url1=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/ProductItemApi/getProductItemSize?product_id=%@",MyUrlID1];
    NSString *u1=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/ProductItemApi/getProductItemSize?product_id=%@",MyUrlID1];
    NSURL *myurl2=[NSURL URLWithString:u1];
    
    
    //url1 = [[NSURL alloc] initWithString:@"http://10.1.1.17/ordavia/index.php/ProductItemApi/getProductItemSize?product_id=1"];
    
    
    
    req1=[NSURLRequest requestWithURL:myurl2];
    
    conn1=[[NSURLConnection alloc]initWithRequest:req1 delegate:self];
    
    xmldata=[[NSMutableData alloc]init];
    [conn1 release];
    
    
    
    
    forValidation=0;
    forValidation1=0;
    
    dbh=[[DBHandler alloc]init];
    mstr=[[NSMutableString alloc]init];
    
    CouterForBottle = 1;
    donotaddagainsoda=0;
    donotaddagainDCoke=0;
    donotaddagainIce=0;
    donotaddagainLemonde=0;
    donotaddagaincoke=0;
    donotaddagainsDistilWater=0;
    [_MainScrollView setScrollEnabled:YES];
    [_MainScrollView setContentSize:CGSizeMake(320, 420)];
    [_SubFirstScorll setScrollEnabled:YES];
    [_SubFirstScorll setShowsHorizontalScrollIndicator:YES];
    [_SubFirstScorll setContentSize:CGSizeMake(600, 68)];
    //[self.view addSubview:_SubFirstScorll];
    [_SubSecondScroll setScrollEnabled:YES];
    [_SubSecondScroll setContentSize:CGSizeMake(600, 125)];
    
    
    
    
    
    
    
    NSString *Brand=[NSString stringWithFormat:@"%@",brandstring];
    
    
    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    Brand = [[Brand componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
    NSLog(@"%@",Brand);
    Main = [Brand substringWithRange:NSMakeRange(4, [Brand length]-4)];
    
    
    
    _BrandLbl.text=Main;
    MyBrand=[NSString stringWithFormat:@"%@",Main];
    
    
    _ProductTitle.text=TitleStr;
    
    _ProductDiscription.text=DiscriptionStr;
    
    
    _BrandLbl.text=TitleStr1;
    
    NSLog(@"%@",TitleStr1);
    
    //    _TitleLabel.text=TitleStr;
    //    _DiscriptionLabel.text=DiscriptionStr;
    _SubFirstScorll.delegate=self;
    [_SubFirstScorll setShowsVerticalScrollIndicator:NO];
    
    
    /*
     
     */
    [super viewDidLoad];
    
    if ([objRLSampleAppDelegate.themeString isEqualToString:@"1"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"001-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"001-header.png"]];
    }
    
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"2"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"002-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"002-header.png"]];
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"3"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"003-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"003-header.png"]];
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"4"])
    {
        
        [bgImageView setImage:[UIImage imageNamed:@"004-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"004-header.png"]];
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"5"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"005-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"005-header.png"]];
    }
    
    else{
        
        [headerImageView setImage:[UIImage imageNamed:@"BG.png"]];
        
    }        NSLog(@"%@",objRLSampleAppDelegate.themeString);
    
    
    
//    NSString *myArrayString = [appDelegate.addonID description];
//    NSLog(@"%@",myArrayString);
//    
//    if ([myArrayString isEqualToString:@""]) {
//        NSLog(@"nil");
//        
//    }else{
//        
//        NSLog(@"%@",appDelegate.addonName);
//    
//    NSString *orderveiw=[appDelegate.addonName objectAtIndex:0];
//    NSLog(@"%@",orderveiw);
//    
//    
//   
//    NSLog(@"%@",orderveiw);
//    NSCharacterSet *doNotWant2 = [NSCharacterSet characterSetWithCharactersInString:@"  ()\"\n"];
//    NSString *str2=[NSString stringWithFormat:@"%@",orderveiw];
//    
//    str2 = [[str2 componentsSeparatedByCharactersInSet:doNotWant2] componentsJoinedByString: @" "];
//    NSLog(@"%@",str2);
//    
//
//    if([str2 isEqualToString:@""]){
//        
//        _ourerOrderView.hidden=NO;
//    }else{
//        _ourerOrderView.hidden=YES;
//    }
//    
//    }
    // Do any additional setup after loading the view from its nib.
}


/////xml


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    [xml_parser release];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
}



- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    currentElementValue=nil;
    CurrentText=nil;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict {
	
	if([elementName isEqualToString:@"xml"]) {
		output=[[NSMutableString alloc]init];
        productItemId=[[NSMutableArray alloc]init];
        ProductId=[[NSMutableArray alloc]init];
        price=[[NSMutableArray alloc]init];
        ProductSize=[[NSMutableArray alloc]init];
        ProductImage=[[NSMutableArray alloc]init];
        
        
        
		
	}
	else if([elementName isEqualToString:@"product_item_id"]||[elementName isEqualToString:@"product_id"] || [elementName isEqualToString:@"price"]|| [elementName isEqualToString:@"size_name"] || [elementName isEqualToString:@"CONCATwww.bevond.comordaviasize_master.size_image"])
    {
		
        
		currentElementValue=elementName;
        CurrentText=[[NSMutableString alloc]init];
		//NSLog(@"Reading id value :%i", aBook.bookID);
	}
	NSLog(@"Processing Element: %@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	
	if(!CurrentText)
		CurrentText = [[NSMutableString alloc] initWithString:string];
	else
		[CurrentText appendString:string];
	
	NSLog(@"Processing Value: %@", CurrentText);
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	if([elementName isEqualToString:@"xml"])
    {
        
    }
    if([elementName isEqualToString:@"CONCATwww.bevond.comordaviasize_master.size_image"]) {
        
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [ProductImage addObject:arr];
        [output appendString:CurrentText];
        
        NSLog(@"%@",output);
		//[appDelegate.books addObject:aBook];
		
		
	}
    else if([elementName isEqualToString:@"product_item_id"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [productItemId addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"product_id"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [ProductId addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"price"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [price addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"size_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [ProductSize addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    
    
    
   	
	[CurrentText release];
	CurrentText=nil;
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    if ([output isEqualToString:@""]) {
//        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Sorry,Product is Not Available."delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
//        [alt show];
//        [alt release];
//        [self dismissViewControllerAnimated:YES completion:nil];
//        
//
        
        _alertView.hidden=NO;
        
    }
    else
    {
        
        
        [self DynamicInit];
        [self SizeButtonAndLabel];
        [_Activity stopAnimating];
        [_Activity setHidden:YES];
        
    }
    
    //    NSLog(@"%@",ProductImage);
    //    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:output delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
    //    [alt show];
    //    [alt release];
    
    ///Set Image
    
    
}

-(void)ButtonSizeAction:(id*)sender
{
    buttonsize = (UIButton *)sender;
    
    int BtnZi=0;
    
    
    while(BtnZi<[ProductSize count])
    {
        //NSLog(@"%d",buttonsize.tag);
        if(buttonsize.tag==BtnZi)
        {
            
            
            
            NSLog(@"%@",mstr);
            
            /////////////button///////
            //[button removeFromSuperview];
            //[self ButtonReload];
            
            //_SubItemForAddLbl.text=mstr;
            
            // _TitleLabel.text=TitleStr;
            //  _DiscriptionLabel.text=_BrandLbl.text;
            
            
            
            
            
            NSString *two=@"   ";
            NSLog(@"%@",_TitleLabel.text);
            
            NSLog(@"bra%@",_BrandLbl.text);
            
            
            NSString *Tea= [NSString stringWithFormat:@"%@%@%@", TitleStr,two,_BrandLbl.text];
            
            NSLog(@"bra%@",Tea);
            
            _TitleLabel.text=Tea;
            
            
           // _decLabel.text=Tea;
            
           
            
            
            
            
            donotaddagainsoda=0;
            donotaddagainDCoke=0;
            donotaddagainIce=0;
            donotaddagainLemonde=0;
            donotaddagaincoke=0;
            donotaddagainsDistilWater=0;
            
            //_SubItemForAddLbl.text=nil;
            
            //_CurrencySign.text=@"£";
            //float totalAmout=[BottlePriceLbl.text floatValue];
            //NSLog(@"%@",[price objectAtIndex:buttonsize.tag]);
            
            NSString *str1=[NSString stringWithFormat:@"%@",[price objectAtIndex:buttonsize.tag]];
            NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
            str1 = [[str1 componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
            NSLog(@"%@",str1);
            
            float finalamount=[ str1 floatValue];
            
            
            NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
            [numberFormatter setPositiveFormat:@"###0.##"];
            
            // NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalamount]];
            //NSLog(@"formattedNumberString: %@", formattedNumberString);
            
                        NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalamount];
            NSLog(@"%@",formattedNumber);
             NSLog(@"%f",temp1);
            float myTotal=[_TotalAmount.text floatValue]+finalamount-temp1;
            
            formattedNumber = [NSString stringWithFormat:@"%.02f", myTotal];
            
            _TotalAmount.text=[NSString stringWithFormat:@"%@",formattedNumber];
            
          
            [numberFormatter release];
            
            
            
             temp1=finalamount;
            NSLog(@"%f",temp1);
            NSLog(@"%f",totalAmount1);
            

            totalAmount1=[_TotalAmount.text floatValue];
            
          
            
            NSString *str2=[NSString stringWithFormat:@"%@",[ProductSize objectAtIndex:buttonsize.tag]];
            proSizeId=[NSString stringWithFormat:@"%@",[productItemId objectAtIndex:buttonsize.tag]];
            NSLog(@"%@",proSizeId);
            proSizeId=[[proSizeId componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
            
            productSizeID=proSizeId;
            
            productSizeID = [proSizeId substringWithRange:NSMakeRange(4, [proSizeId length]-4)];
            
            appDelegate.ProductItemId=productSizeID;
            NSLog(@"%@",proSizeId);
            NSLog(@"%@",productSizeID);
            NSCharacterSet *doNotWant3 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
            str2 = [[str2 componentsSeparatedByCharactersInSet: doNotWant3] componentsJoinedByString: @""];
            //NSLog(@"%@",str2);
            
            NSString *Main4 = [str2 substringWithRange:NSMakeRange(4, [str2 length]-4)];
            /////
            _ProductLabel.text=[NSString stringWithFormat:@"%@",Main4];
            
            forValidation1=0;
            _With.text=@"With";
            
            
            
            //mstr=[[NSMutableString alloc]init];
            //AddonIds=[[NSMutableString alloc]init];
            
            _SubItemForAddLbl.text=mstr;
            
            int sBtni=0;
            //NSLog(@"%d",buttonsize.tag);
            int j=buttonsize.tag;
            while (sBtni<[btnarray count])
            {
                UIButton *tempbtn = [btnarray objectAtIndex:sBtni];
                tempbtn.tag=sBtni;
                if(tempbtn.tag==j)
                {
                    
                    //NSLog(@"%d",tempbtn.tag);
                  //  [tempbtn setBackgroundImage:[UIImage imageNamed:@"PressButton Effect.png"] forState:UIControlStateNormal];
                    
                    
                       [tempbtn setBackgroundImage:[UIImage imageNamed:@"RedBox.png"] forState:UIControlStateNormal];
                }
                else
                    
                {
                    
                    //NSLog(@"%d",tempbtn.tag);
                    [tempbtn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                    
                }
                sBtni++;
                
            }
            buttonsize.tag=j;
            
            _CurrencySign.text=@"£";
            
            forValidation=1;
        }
        
        BtnZi++;
    }
}
-(void)AgainSizeBtnLoad
{
    int bfw=10;
    int blabel=36;
    int blabel1=32;
    
    NSLog(@"button:%d",[AddonId count]);
    
    for(int i=0;i<[ProductId count];i++)
    {
        
        
        
        
        UILabel *buttonLabel=[[UILabel alloc] initWithFrame: CGRectMake(blabel,39,62,51)];
        UILabel *buttoncurrencyLabel=[[UILabel alloc] initWithFrame: CGRectMake(blabel1,69,30,21)];
        
        [buttonLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttonsize= [UIButton buttonWithType:UIButtonTypeCustom];;
        [buttonsize addTarget:self action:@selector(ButtonSizeAction:) forControlEvents:UIControlEventTouchUpInside];
        
        
        
        
       // [buttonsize setBackgroundImage:[UIImage imageNamed:@"Button.png"] forState:UIControlStateNormal];
        buttonsize.tag = i;
        
        buttonsize.backgroundColor = [UIColor clearColor];
        buttonsize.frame = CGRectMake(bfw, 35, 40, 40);
        [btnarray addObject:buttonsize];
        
               
        
        NSString *buttonlabelstr=[price objectAtIndex:i];
        
        NSString *buttonlabelstr1=[NSString stringWithFormat:@"%@",buttonlabelstr];
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        buttonlabelstr1 = [[buttonlabelstr1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        
        NSString *MainbtnLabel=[NSString stringWithFormat:@"%@",buttonlabelstr1];
        
        
        
        NSString *Mainbtn = [MainbtnLabel substringWithRange:NSMakeRange(4, [MainbtnLabel length]-4)];
        
        
        
        [buttonLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttonLabel.text = [NSString stringWithFormat:@"%@",Mainbtn];
        buttonLabel.textAlignment=NSTextAlignmentCenter;
        buttonLabel.tag=i;
        buttonLabel.backgroundColor=[UIColor clearColor];
        
        
        [buttoncurrencyLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttoncurrencyLabel.text = @"£";
        buttoncurrencyLabel.textAlignment=NSTextAlignmentLeft;
        buttoncurrencyLabel.tag=i;
        buttoncurrencyLabel.backgroundColor=[UIColor clearColor];
        
        //[extraforAddonPrice insertObject:buttonLabel.text atIndex:i];
        [self.SubSecondScroll addSubview:buttonsize];
        
        [self.SubSecondScroll addSubview:buttonLabel];
        [self.SubSecondScroll addSubview:buttoncurrencyLabel];
        bfw=bfw+120;
        blabel=blabel+120;
        blabel1=blabel1+120;
        
    }
}

-(void)SizeButtonAndLabel
{
    /// product Button------->
    
    int bfw=10;
    
    int blabel=36;
    int blabel1=30;
    float iw=31;
    float iw1=110;
    int lbl=23;
    NSLog(@"button:%d",[AddonId count]);
    
    
    for(int i=0;i<[ProductId count];i++)
    {
        UILabel *buttonLabel=[[UILabel alloc] initWithFrame: CGRectMake(blabel,100,42,21)];
        UILabel *buttoncurrencyLabel=[[UILabel alloc] initWithFrame: CGRectMake(blabel1,100,30,21)];
        
        buttonLabel.textColor=[UIColor whiteColor];
        
         buttoncurrencyLabel.textColor=[UIColor whiteColor];
       
        
        buttonsize= [UIButton buttonWithType:UIButtonTypeCustom];
        
        imageButton=[UIButton buttonWithType:UIButtonTypeCustom];
        
        
        
        [buttonsize addTarget:self action:@selector(ButtonSizeAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [imageButton addTarget:self action:@selector(ButtonSizeAction:) forControlEvents:UIControlEventTouchUpInside];
        
        
       // [buttonsize setBackgroundImage:[UIImage imageNamed:@"Button.png"] forState:UIControlStateNormal];
        
        
        buttonsize.tag = i;
        imageButton.tag=i;
        
        buttonsize.backgroundColor = [UIColor clearColor];
        
        
        buttonsize.frame = CGRectMake(bfw,30, 80,95);
        
        
        //imageButton.frame=CGRectMake(bfw, 1, 90,90);
        
        
        [btnarray addObject:buttonsize];
        // [btnarray addObject:imageButton];
        
        NSString *buttonlabelstr=[price objectAtIndex:i];
        
        NSString *buttonlabelstr1=[NSString stringWithFormat:@"%@",buttonlabelstr];
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        buttonlabelstr1 = [[buttonlabelstr1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        
        NSString *MainbtnLabel=[NSString stringWithFormat:@"%@",buttonlabelstr1];
        
        
        
        
        NSString *Mainbtn = [MainbtnLabel substringWithRange:NSMakeRange(4, [MainbtnLabel length]-4)];
        
        [buttonLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttonLabel.text = [NSString stringWithFormat:@"%@",Mainbtn];
        buttonLabel.textAlignment=NSTextAlignmentCenter;
        buttonLabel.tag=i;
        buttonLabel.backgroundColor=[UIColor clearColor];
        
        
        [buttoncurrencyLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttoncurrencyLabel.text = @"£";
        buttoncurrencyLabel.textAlignment=NSTextAlignmentLeft;
        buttoncurrencyLabel.tag=i;
        buttoncurrencyLabel.backgroundColor=[UIColor clearColor];
        
        //[extraforAddonPrice insertObject:buttonLabel.text atIndex:i];
        
        UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(iw, 40, 40, 50) ];
        
        
        NSString *str=[ProductImage objectAtIndex:i];
        
        NSString *str1=[NSString stringWithFormat:@"%@",str];
        NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        str1 = [[str1 componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
                
        NSString *strDiscription=[NSString stringWithFormat:@"%@",str1];
                
        NSString *newStr = [strDiscription substringWithRange:NSMakeRange(4, [strDiscription length]-4)];
        
        NSString *string=[NSString stringWithFormat:@"http://%@",newStr];
        
        UIImage *img=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:string]]];
        
        [imgview setImage:img];
        
        
        [self.SubSecondScroll addSubview:imgview];
        //[self.SubFirstScorll addSubview:label];
        iw=iw+119;
        
        
        
        UIImageView *imgview1=[[UIImageView alloc]initWithFrame:CGRectMake(iw1, 0, 2, 140)];
        
        
        [imgview1 setImage:[UIImage imageNamed:@"Line_01.png"]];
        
        
        [self.SubSecondScroll addSubview:imgview1];
        //[self.SubFirstScorll addSubview:label];
        iw1=iw1+118;
        
        
        
        
        [self.SubSecondScroll addSubview:buttonsize];
        [self.SubSecondScroll addSubview:imageButton];
        
        [self.SubSecondScroll addSubview:buttonLabel];
        [self.SubSecondScroll addSubview:buttoncurrencyLabel];
        bfw=bfw+120;
        blabel=blabel+120;
        blabel1=blabel1+120;
        
                
        
        UILabel *label =  [[UILabel alloc] initWithFrame: CGRectMake(lbl,-9,70,40)];
        
        label.textColor=[UIColor whiteColor];
        
        NSString *Labelstr=[ProductSize objectAtIndex:i];
        
        
        NSString *LAbelStr1=[NSString stringWithFormat:@"%@",Labelstr];
        NSCharacterSet *doNotWant2 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        LAbelStr1 = [[LAbelStr1 componentsSeparatedByCharactersInSet: doNotWant2] componentsJoinedByString: @""];
        
       
        NSString *MainLabel=[NSString stringWithFormat:@"%@",LAbelStr1];
        
        
        NSString *Main1 = [MainLabel substringWithRange:NSMakeRange(4, [MainLabel length]-4)];
        
        
        [label setFont:[UIFont systemFontOfSize:13]];
      
        
        
        label.text = [NSString stringWithFormat:@"%@",Main1];
        label.textAlignment=NSTextAlignmentCenter;
        label.backgroundColor=[UIColor clearColor];
        [label setNumberOfLines:2];
        
        [self.SubSecondScroll addSubview:label];
            lbl=lbl+118;
        
        [label release];
        
      
        
        
    }
    
    
}



-(void)DynamicInit
{
    int index=0;
    while(index<[ProductSize count])
    {
        NSString *myimage=[ProductSize objectAtIndex:index];
        
        //NSLog(@"%@",myimage);
        NSString *myImgStr=[NSString stringWithFormat:@"%@",myimage];
        
        NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        myImgStr = [[myImgStr componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
        //NSLog(@"%@",myImgStr);
        
        NSString *newStr1 = [myImgStr substringWithRange:NSMakeRange(4, [myImgStr length]-4)];
        
        
        //NSLog(@"%@",newStr1);
        
        if([newStr1 isEqualToString:@"Half"])
        {
            
            
        }
        else if([newStr1 isEqualToString:@"Pint"])
        {
            
            
        }
        else if([newStr1 isEqualToString:@"60ml"])
        {
            
            
            
        }
        else if([newStr1 isEqualToString:@"20ml"])
        {
            
            
        }
        else if([newStr1 isEqualToString:@"Bottle"])
        {
            
        }
        else if([newStr1 isEqualToString:@"Short Glass"])
        {
            
            
            
        }
        else
        {
            
        }
        index++;
    }
    
    
    
    //NSLog(@"%@",appDelegate.addonID);
    AddonId=[NSMutableArray arrayWithArray:appDelegate.addonID];
    //NSLog(@"%@",AddonId);
    
    //NSLog(@"%@",appDelegate.addonName);
    AddOnName=[NSMutableArray arrayWithArray:appDelegate.addonName];
    NSLog(@"%@",AddOnName);
    
    NSLog(@"%@",appDelegate.addonPrice);
    AddOnPrice=[NSMutableArray arrayWithArray:appDelegate.addonPrice];
    NSLog(@"%@",AddOnPrice);
    
    int w=68;
    int h=40;
    int fw=25;
    int fh=5;
    int iw=128;
    int bfw=20;
    int blabel=43;
    int blabel1=30;
    NSLog(@"button:%d",[AddonId count]);
    
    
    for(int i=0;i<[AddonId count];i++)
    {
        
        //addon 1 time...>
        
        
        
        UILabel *buttonLabel=[[UILabel alloc] initWithFrame: CGRectMake(blabel,35,42,23)];
        
        UILabel *buttoncurrencyLbl=[[UILabel alloc] initWithFrame: CGRectMake(blabel1,35,42,23)];
        
        buttonLabel.textColor=[UIColor whiteColor];
        buttoncurrencyLbl.textColor=[UIColor whiteColor];
        
        button= [UIButton buttonWithType:UIButtonTypeCustom];
        [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [button setBackgroundImage:[UIImage imageNamed:@"REDinvisible.png"] forState:UIControlStateNormal];
        button.tag = i;
        //NSLog(@"%d",button.tag);
        
        button.backgroundColor = [UIColor clearColor];
        
        button.frame = CGRectMake(bfw,10, 80,50);
        [btn addObject:button];
        
        
        NSString *buttonlabelstr=[AddOnPrice objectAtIndex:i];
        
        NSLog(@"@%",AddOnPrice);
        NSString *buttonlabelstr1=[NSString stringWithFormat:@"%@",buttonlabelstr];
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        buttonlabelstr1 = [[buttonlabelstr1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        //NSLog(@"%@",buttonlabelstr1);
        
        
        NSString *MainbtnLabel=[NSString stringWithFormat:@"%@",buttonlabelstr1];
        
        
        
        NSString *Mainbtn = [MainbtnLabel substringWithRange:NSMakeRange(4, [MainbtnLabel length]-4)];
        
        
        //NSLog(@"%@",Mainbtn);
        
        
        [buttonLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttonLabel.text = [NSString stringWithFormat:@"%@",Mainbtn];
        buttonLabel.textAlignment=NSTextAlignmentCenter;
        buttonLabel.tag=i;
        buttonLabel.backgroundColor=[UIColor clearColor];
        
        
        
        
        [buttoncurrencyLbl setFont:[UIFont systemFontOfSize:15]];
        
        buttoncurrencyLbl.text = @"£";
        buttoncurrencyLbl.textAlignment=NSTextAlignmentCenter;
        buttoncurrencyLbl.tag=i;
        buttoncurrencyLbl.backgroundColor=[UIColor clearColor];
        
        [extraforAddonPrice insertObject:buttonLabel.text atIndex:i];
        
        NSLog(@"%@",extraforAddonPrice);
        
        
        [self.SubFirstScorll addSubview:button];
        
        [self.SubFirstScorll addSubview:buttonLabel];
        
        
        [self.SubFirstScorll addSubview:buttoncurrencyLbl];
        
        
        
        UILabel *label =  [[UILabel alloc] initWithFrame: CGRectMake(fw,fh,w,h)];
        
        label.textColor=[UIColor whiteColor];
        
        [label setFont:[UIFont systemFontOfSize:14]];
        
        bfw=bfw+120;
        blabel=blabel+120;
        blabel1=blabel1+120;
        fw=fw+120;
        
        NSString *Labelstr=[AddOnName objectAtIndex:i];
        
        NSString *LAbelStr1=[NSString stringWithFormat:@"%@",Labelstr];
        NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        LAbelStr1 = [[LAbelStr1 componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
        //NSLog(@"%@",LAbelStr1);
        
        
        NSString *MainLabel=[NSString stringWithFormat:@"%@",LAbelStr1];
        
        
        
        NSString *Main1 = [MainLabel substringWithRange:NSMakeRange(4, [MainLabel length]-4)];
        
        
        //NSLog(@"%@",Main1);
        
        
        [label setFont: [UIFont fontWithName:@"Arial" size:14]];
        
        
        label.text = [NSString stringWithFormat:@"%@",Main1];
        label.textAlignment=NSTextAlignmentCenter;
        
        label.tag=i;
        
        label.backgroundColor=[UIColor clearColor];
        [label setNumberOfLines:2];
        
        
        
        UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(iw,-3,-2,98)];
        
        //UIImage *img=[UIImage imageNamed:@"Line_01.png"];
        //[imgview addSubview:img];
        [imgview setImage:[UIImage imageNamed:@"Line_01.png"]];
        
        
        [self.SubFirstScorll addSubview:imgview];
        [self.SubFirstScorll addSubview:label];
        iw=iw+118;
        //[imgview release];
        //[img release];
        [label release];
        [buttonLabel release];
    }
    
    
}


-(void)ButtonReload
{
    /// Button Reload----->
    
    
    AddonId=[NSMutableArray arrayWithArray:appDelegate.addonID];
    
    AddOnName=[NSMutableArray arrayWithArray:appDelegate.addonName];
    
    
    AddOnPrice=[NSMutableArray arrayWithArray:appDelegate.addonPrice];
    
    int bfw=25;
    int blabel=43;
    int blabel1=30;
    
    for(int i=0;i<[AddonId count];i++)
    {
        UILabel *buttonLabel=[[UILabel alloc] initWithFrame: CGRectMake(blabel,60,42,23)];
        UILabel *buttoncurrencyLbl=[[UILabel alloc] initWithFrame: CGRectMake(blabel1,60,42,23)];
        
        button= [UIButton buttonWithType:UIButtonTypeCustom];;
        [button addTarget:self action:@selector(ButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [button setBackgroundImage:[UIImage imageNamed:@"REDinvisible.png"] forState:UIControlStateNormal];
        button.tag = i;
        //NSLog(@"%d",button.tag);
        button.backgroundColor = [UIColor clearColor];
        
        button.frame = CGRectMake(bfw,55, 80,30);
        
        
        [btn addObject:button];
        NSString *buttonlabelstr=[AddOnPrice objectAtIndex:i];
        
        NSString *buttonlabelstr1=[NSString stringWithFormat:@"%@",buttonlabelstr];
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        buttonlabelstr1 = [[buttonlabelstr1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        
        
        NSString *MainbtnLabel=[NSString stringWithFormat:@"%@",buttonlabelstr1];
        
        
        
        NSString *Mainbtn = [MainbtnLabel substringWithRange:NSMakeRange(4, [MainbtnLabel length]-4)];
        
        
        
        
        // [buttonLabel setFont: [UIFont fontWithName:@"Courier-Bold" size:15]];
        [buttonLabel setFont:[UIFont systemFontOfSize:15]];
        
        buttonLabel.text = [NSString stringWithFormat:@"%@",Mainbtn];
        buttonLabel.textAlignment=NSTextAlignmentCenter;
        buttonLabel.tag=i;
        buttonLabel.backgroundColor=[UIColor clearColor];
        
        //[buttoncurrencyLbl setFont: [UIFont fontWithName:@"Courier-Bold" size:12]];
        [buttoncurrencyLbl setFont:[UIFont systemFontOfSize:15]];
        
        
        
        buttoncurrencyLbl.text = @"£";
        buttoncurrencyLbl.textAlignment=NSTextAlignmentCenter;
        buttoncurrencyLbl.tag=i;
        buttoncurrencyLbl.backgroundColor=[UIColor clearColor];
        
        [extraforAddonPrice insertObject:buttonLabel.text atIndex:i];
        
        
        
        
        [self.SubFirstScorll addSubview:button];
        
        
        [self.SubFirstScorll addSubview:buttonLabel];
        [self.SubFirstScorll addSubview:buttoncurrencyLbl];
        bfw=bfw+120;
        blabel=blabel+120;
        blabel1=blabel1+120;
        
    }
    
    
}

-(void)ButtonAction:(id*)sender
{
    
    if(forValidation==1)
    {
        
        button = (UIButton *)sender;
        
        
        Btni=0;
        
        
        //NSLog(@"%d",Btni);
        //NSLog(@"%d",[appDelegate.addonID count] );
        
        while(Btni<[appDelegate.addonID count])
        {
            //NSLog(@"%d",button.tag);
            if(button.tag==Btni)
            {
                
                
                
                NSString *addOn=[NSString stringWithFormat:@"%@",[appDelegate.addonName objectAtIndex:button.tag]];
                NSString *addID=[NSString stringWithFormat:@"%@",[appDelegate.addonID objectAtIndex:button.tag]];
                NSString *addpri=[NSString stringWithFormat:@"%@",[appDelegate.addonPrice objectAtIndex:button.tag]];
                
                NSLog(@"%@",addpri);
                
                
                
                NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
                addOn = [[addOn componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
                addID=[[addID componentsSeparatedByCharactersInSet:doNotWant1]componentsJoinedByString:@""];
                
                NSLog(@"%@",addOn);
                
                
                
                
                NSCharacterSet *doNotWant2 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
                addpri = [[addpri componentsSeparatedByCharactersInSet: doNotWant2] componentsJoinedByString: @""];
                
                
                NSLog(@"%@",addOn);

                                
                
                
                NSString *Main11 = [addOn substringWithRange:NSMakeRange(4, [addOn length]-4)];
                NSString *MainID = [addID substringWithRange:NSMakeRange(4, [addID length]-4)];
                
                
                //NSLog(@"%@",Main11);
                
                
                NSString *mainComm=[NSString stringWithFormat:@",%@",Main11];
                NSString *myID=[NSString stringWithFormat:@"%@,",MainID];
                
                if([mainComm length] > 0 && [myID length]>0)
                {
                    if ([mstr rangeOfString:mainComm].location == NSNotFound && [AddonIds rangeOfString:myID].location==NSNotFound)
                    {
                        NSLog(@"string does not contain ");
                        [mstr appendString:mainComm];
                        [AddonIds appendString:myID];
                        NSLog(@"%@",[extraforAddonPrice objectAtIndex:button.tag]);
                        float finalamount=[_TotalAmount.text floatValue]+[[extraforAddonPrice objectAtIndex:button.tag] floatValue];
                        
                        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
                        [numberFormatter setPositiveFormat:@"###0.##"];
                        
                        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalamount]];
                        //NSLog(@"formattedNumberString: %@", formattedNumberString);
                        
                        
                        NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalamount];
                        
                        NSLog(@"%@",formattedNumber);
                        
                        
                        _TotalAmount.text=formattedNumber;
                        
                        totalAmount1=[formattedNumberString floatValue];
                        [numberFormatter release];
                        
                        
                        
                        
                        
                    }
                    else
                    {
                        NSLog(@"string contains!");
                        [mstr setString:[ NSString stringWithFormat:@"%@",[mstr stringByReplacingOccurrencesOfString:mainComm withString:@""]]];
                        [AddonIds setString:[NSString stringWithFormat:@"%@",[AddonIds stringByReplacingOccurrencesOfString:myID withString:@""]]];
                        NSLog(@"%@",AddonIds);
                        float finalamount=[_TotalAmount.text floatValue]-[[extraforAddonPrice objectAtIndex:button.tag] floatValue];
                        
                        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
                        [numberFormatter setPositiveFormat:@"###0.##"];
                        
                        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalamount]];
                        //NSLog(@"formattedNumberString: %@", formattedNumberString);
                        
                        
                         NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalamount];
                        
                        _TotalAmount.text=formattedNumber;
                        totalAmount1=[formattedNumberString floatValue];
                        [numberFormatter release];
                        
                    }
                    
                }
                
                
                NSLog(@"%@",AddonIds);
                
                _SubItemForAddLbl.text=mstr;
                
                
                
                
                if(button.imageView.image!=[UIImage imageNamed:@"RedBox.png"])
                {
                    [button setImage:[UIImage imageNamed:@"RedBox.png"] forState:UIControlStateNormal];
                }
                else
                {
                    [button setImage:[UIImage imageNamed:@"REDinvisible.png"] forState:UIControlStateNormal];
                }
                
                /*[btn addObject:button];
                 
                 int sBtni=0;
                 NSLog(@"%d",button.tag);
                 int j=button.tag;
                 while (sBtni<[btn count])
                 {
                 UIButton *tempbtn = [btn objectAtIndex:sBtni];
                 tempbtn.tag=sBtni;
                 NSLog(@"%d",tempbtn.tag);
                 
                 if(tempbtn.imageView.image==[UIImage imageNamed:@"PressButton Effect.png"])
                 
                 {
                 
                 
                 
                 
                 }
                 
                 sBtni++;
                 
                 }*/
                
                
                
                
                //[button setImage:[UIImage imageNamed:@"PressButton Effect"] forState:UIControlStateNormal];
                _CurrencySign.text=@"£";
                forValidation1=1;
                
                
                
                
                
                
            }
            Btni++;
        }
        
        
    }
    else
    {
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Warning" message:@"Sorry,Pls First Select the size."delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
        [alt show];
        [alt release];
        
    }// here using the tag value i want to get the button and change the background image….
    // for example i want to change the background for tag values 1,3,6,7 ,8…
}


//[myWebView.scrollView setShowsVerticalScrollIndicator:NO];
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_MainScrollView release];
    [_SubFirstScorll release];
    //[_SubSecondScroll release];
    [_ProductTitle release];
    [_ProductDiscription release];
    
    [_SubSecondScroll release];
    
    
    [_TitleLabel release];
    [_DiscriptionLabel release];
    [_ProductLabel release];
    
    [_With release];
    
    [_CounterLbLForBottleQnty release];
    [_SubItemForAddLbl release];
    [_TotalAmount release];
    
    [_CurrencySign release];
    
    
    
    
    [_BrandLbl release];
    
    [_Activity release];
    [_DescriptionView release];
    [_alertView release];
    [_ourerOrderView release];
    [_decLabel release];
    [super dealloc];
}
- (IBAction)BackMethod:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)orderToAddMethod:(id)sender{
    NSLog(@"%d",forValidation);
    if(forValidation==0 )
    {
        
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"You have to select any one Product Item!" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alt show];
        [alt release];
        
    }
    else
    {
        NSLog(@"%@",ProDuctID);
        
        NSLog(@"%@", appDelegate.ProductItemId);
        
        NSLog(@"addon:%@",AddonIds);
        if([AddonIds isEqualToString:@""])
        {
            AddonIds=@"0,";
            
            
        }
        
        NSLog(@"addon:%@",AddonIds);
        
        //        [AddonArray addObject:AddonIds];
        //        NSLog(@"%@",AddonArray);
        //        NSString *TempAddons:@"%@",AddonArray];
        
        NSString *string=[[NSString alloc]initWithFormat:@"%@",AddonIds];
        
        if ( [string length] > 0)
            string = [string substringToIndex:[string length] - 1];
        
        NSLog(@"%@",string);
        NSLog(@"%@",appDelegate.deviceToken);
        
        if ([AddonIds length] > 0)
            AddonIds = [AddonIds substringToIndex:[AddonIds length] - 1];
        NSLog(@"%@",AddonIds);
        
        objMainOrderViewController=[[MainOrderViewController  alloc]initWithNibName:@"MainOrderViewController"bundle:nil];
    
        
        
        NSMutableArray *myItems=[[NSMutableArray alloc]initWithObjects:[NSString stringWithFormat:@"%d",appDelegate.OD_id],ProDuctID,_TitleLabel.text,_BrandLbl.text,appDelegate.ProductItemId,_ProductLabel.text,AddonIds,_SubItemForAddLbl.text,_TotalAmount.text,@"1", nil];
        
        
        NSMutableArray *myPriceItem=[[NSMutableArray alloc]initWithObjects:[NSString stringWithFormat:@"%d",appDelegate.OD_id],_TotalAmount.text, nil];
        
        
        
        int k=1;
        appDelegate.OD_id++;
        
        [dbh insert:myItems];
        [dbh insertPrice:myPriceItem];
        objMainOrderViewController.product=[NSMutableString stringWithFormat:@"%@,",appDelegate.ProductItemId];
        objMainOrderViewController.addon=[NSMutableString stringWithFormat:@"%@",string];
        objMainOrderViewController.i=k;
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
        
        
        
        [self.navigationController pushViewController:objMainOrderViewController animated:YES];
        
        }
        else{
            
         MainOrderViewController *objMainOrderViewController4=[[MainOrderViewController  alloc]initWithNibName:@"MainOrderViewController4"bundle:nil];
            
             [self.navigationController pushViewController:objMainOrderViewController4 animated:YES];
        }
        
        
        mstr=[[NSMutableString alloc]init];
        _ProductLabel.text=nil;
        _SubItemForAddLbl.text=nil;
        
        _TotalAmount.text=nil;
    [button setImage:[UIImage imageNamed:@"REDinvisible.png"] forState:UIControlStateNormal];
        

        
    }
}

- (IBAction)MyOrderMethod:(id)sender {
    
    objMainOrderViewController=[[MainOrderViewController  alloc]initWithNibName:@"MainOrderViewController"bundle:nil];
    
    [self presentViewController:objMainOrderViewController animated:YES completion:nil];
    
    
    
    
    mstr=[[NSMutableString alloc]init];
    _ProductLabel.text=nil;
    _SubItemForAddLbl.text=nil;
    //_CounterLbLForBottleQnty.text=nil;
    _TotalAmount.text=nil;
    
    
}
- (IBAction)ResetOrderMethod:(id)sender {
    _ProductLabel.text=@"";
    _SubItemForAddLbl.text=@"";
    _TotalAmount.text=@"";
    _TitleLabel.text=@"";
    _CurrencySign.text=@"";
    //_DiscriptionLabel.text=@"":
    _With.text=@"";
    _DiscriptionLabel.text=@"";
    [buttonsize setBackgroundImage:[UIImage imageNamed:@"REDinvisible.png"] forState:UIControlStateNormal];
    //[imageButton setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    forValidation=0;
    forValidation1=0;
    CouterForBottle = 1;
    donotaddagainsoda=0;
    donotaddagainDCoke=0;
    donotaddagainIce=0;
    donotaddagainLemonde=0;
    donotaddagaincoke=0;
    donotaddagainsDistilWater=0;
    mstr=[[NSMutableString alloc]init];
    AddonIds=[[NSMutableString alloc]init];
    [self ButtonReload];
    //[self AgainSizeBtnLoad];
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)MYOrderMethod:(id)sender {
    objMainOrderViewController=[[MainOrderViewController  alloc]initWithNibName:@"MainOrderViewController"bundle:nil];
    
    [self presentViewController:objMainOrderViewController animated:YES completion:nil];
    
    
}

- (IBAction)MSG_Method:(id)sender {
    objPushMessagesViewController=[[PushMessagesViewController  alloc]initWithNibName:@"PushMessagesViewController"bundle:nil];
    
    [self presentViewController:objPushMessagesViewController animated:YES completion:nil];
}

- (IBAction)MainScreenMethod:(id)sender {
    
    
    
    objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
    
   
    [self.view addSubview:objRLSampleViewController.view];
    [self.view removeFromSuperview];
    
}
- (IBAction)ShowDiscriptionMethod:(id)sender {
    
    
    _descriptionLebal.text=DiscriptionStr;
    
    _DescriptionView.hidden=NO;
    
    
   
    
}

- (IBAction)popOk:(id)sender{
    _DescriptionView.hidden=YES;
    
}


- (void)viewDidUnload {
    [self setDescriptionView:nil];
    [self setAlertView:nil];
    [self setOurerOrderView:nil];
    [self setDecLabel:nil];
    [super viewDidUnload];
}
- (IBAction)alteProctOk:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
 
}
- (IBAction)closeMethod:(id)sender {
    
     _DescriptionView.hidden=YES;
}

- (IBAction)popClose:(id)sender{
   
    _alertView.hidden=YES;
     [self.navigationController popViewControllerAnimated:YES];
    
}

@end
