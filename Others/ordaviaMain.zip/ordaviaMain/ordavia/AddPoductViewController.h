//
//  AddPoductViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler.h"
#import "AppDelegate.h"
@class AppDelegate;

@interface AddPoductViewController : UIViewController<UIScrollViewDelegate>{
    NSMutableArray *AddonArray;
    NSMutableString *TempAddons;
    int Btni;
    NSString *productSizeID;
    NSString *proSizeId;
    NSString *brandstring;
    DBHandler *dbh;
    float temp;
    int donotaddagainsoda,donotaddagaincoke,donotaddagainDCoke,donotaddagainIce,donotaddagainsDistilWater,donotaddagainLemonde;
    int CouterForBottle,forValidation,forValidation1;
    float totalAmount1;
    NSMutableString *mstr;
    NSMutableString *AddonIds;
    float temp1;
    ///xml
    
	AppDelegate *appDelegate;
    
    NSString *currentElementValue;
	NSMutableString *CurrentText;
	
    NSMutableArray *AddOnName,*AddonId,*AddOnPrice,*productItemId,*ProductId,*price,*ProductSize,*ProductImage;
    NSMutableString *output,*output1;
    NSXMLParser *xml_parser,*xml_parser1;
    NSMutableData *xmldata,*xmldata1;
    NSURLRequest *req,*req1;
    NSURLConnection *conn,*conn1;
    NSMutableDictionary *dics,*dics1;
    NSURL *url,*url1;
    
    NSString *arrString;
    NSString *ProDuctID;
    NSString *MyUrlID;
    NSMutableArray *books;
    NSString *Main;
    NSString *MyBrand;
    UIButton *button;
    UIButton *buttonsize;
    IBOutlet  UIButton *imageButton;
    NSMutableArray *btnarray;
    NSMutableArray *btn;
    NSMutableArray *extraforAddonPrice;
}
@property (retain, nonatomic) IBOutlet UILabel *decLabel;
- (IBAction)closeMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *DescriptionView;
@property (retain, nonatomic) IBOutlet UIView *yourOrderView;
- (IBAction)alteProctOk:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *ourerOrderView;

@property (retain, nonatomic) IBOutlet UIView *alertView;
@property (retain, nonatomic) IBOutlet UILabel *descriptionLebal;
- (IBAction)popOk:(id)sender;
- (IBAction)popClose:(id)sender;
- (IBAction)MYOrderMethod:(id)sender;
- (IBAction)MSG_Method:(id)sender;
- (IBAction)MainScreenMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Activity;
-(void)DynamicInit;
-(void)ButtonReload;
-(void)SizeButtonAndLabel;
-(void)AgainSizeBtnLoad;

@property (retain, nonatomic) IBOutlet UILabel *BrandLbl;
@property (retain, nonatomic)IBOutlet  UIButton *imageButton;
@property (retain, nonatomic) NSString *brandstring;
-(void)ButtonAction:(id*)sender;
-(void)ButtonSizeAction:(id*)sender;

- (IBAction)ShowDiscriptionMethod:(id)sender;
@property (nonatomic, retain) NSMutableArray *books;



@property (retain, nonatomic) IBOutlet UILabel *CurrencySign;
- (IBAction)ResetOrderMethod:(id)sender;
- (IBAction)MainScreenMethod:(id)sender;
@property(nonatomic)int forValidation,forValidation1;
- (IBAction)MyOrderMethod:(id)sender;

@property(nonatomic)int CouterForBottle,donotaddagainsoda,
donotaddagainDCoke,
donotaddagainIce,
donotaddagainLemonde,
donotaddagaincoke,
donotaddagainsDistilWater;

-(IBAction)orderToAddMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIImageView *bgImageView;
@property (retain, nonatomic) IBOutlet UIImageView *headerImageView;


@property (retain, nonatomic) IBOutlet UILabel *CounterLbLForBottleQnty;
@property (retain, nonatomic) IBOutlet UILabel *TotalAmount;

@property (retain, nonatomic) IBOutlet UILabel *TitleLabel;
@property (retain, nonatomic) IBOutlet UILabel *DiscriptionLabel;
@property (retain, nonatomic) IBOutlet UILabel *With;
@property (retain, nonatomic) IBOutlet UILabel *ProductLabel;
@property(nonatomic)float totalAmount1;
@property (retain, nonatomic) IBOutlet UIScrollView *MainScrollView;
@property (retain, nonatomic) IBOutlet UIScrollView *SubFirstScorll;
@property (retain, nonatomic) IBOutlet UILabel *ProductTitle;
@property (retain, nonatomic) IBOutlet UIScrollView *SubSecondScroll;


@property (retain, nonatomic) IBOutlet UILabel *ProductDiscription;
@property (retain, nonatomic) NSString *TitleStr;
@property (retain, nonatomic) NSString *TitleStr1;


@property (retain, nonatomic) NSString *DiscriptionStr;
@property (retain, nonatomic) NSString *halfStr;
@property (retain, nonatomic) NSString *PintStr;
@property (retain, nonatomic) NSString *MyUrlID;
@property (retain, nonatomic) NSString *BottleStr;
- (IBAction)BackMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *SubItemForAddLbl;
@property (retain, nonatomic) IBOutlet UILabel *newDetailLebal;
@property (retain, nonatomic) IBOutlet UILabel *newProduLabel;
@property (retain, nonatomic) IBOutlet UILabel *newSubDaital;
@property (retain, nonatomic) IBOutlet UILabel *newTotalLabel;

@property (retain, nonatomic) IBOutlet UILabel *newWith;
@property (retain, nonatomic) NSString *ProDuctID;


@end
