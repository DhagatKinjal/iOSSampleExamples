//
//  subXMLParser.m
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "subXMLParser.h"

@implementation subXMLParser
- (subXMLParser *) initXMLParser {
	[super init];
	
	subappDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	
	return self;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
	attributes:(NSDictionary *)attributeDict {
	
	if([elementName isEqualToString:@"root"]) {
		//Initialize the array.
		subappDelegate.subbooks = [[NSMutableArray alloc] init];
	}
	else if([elementName isEqualToString:@"category"]) {
		
		//Initialize the book.
		subaBook = [[subBook alloc] init];
		
		//Extract the attribute here.
		subaBook.subbookID = [[attributeDict objectForKey:@"id"] integerValue];
        subaBook.subname=[attributeDict objectForKey:@"name"];
		
		NSLog(@"Reading id value :%i", subaBook.subbookID);
	}
	
	NSLog(@"Processing Element: %@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	
	if(!currentElementValue)
		currentElementValue = [[NSMutableString alloc] initWithString:string];
	else
		[currentElementValue appendString:string];
	
	NSLog(@"Processing Value: %@", currentElementValue);
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	if([elementName isEqualToString:@"root"])
		return;
	
	if([elementName isEqualToString:@"category"]) {
		[subappDelegate.subbooks addObject:subaBook];
		
		[subaBook release];
		subaBook = nil;
	}
	else
		[subaBook setValue:currentElementValue forKey:elementName];
	
	[currentElementValue release];
	currentElementValue = nil;
}

- (void) dealloc {
	
	[subaBook release];
	[currentElementValue release];
    [subappDelegate release];
	[super dealloc];
}
@end
