//
//  productViewController.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface productViewController : UIViewController<NSXMLParserDelegate,UITableViewDelegate,UITableViewDataSource>{
    NSXMLParser *xml_parser;
    NSString *xml_file_path;
    NSMutableData *xmldata;
    NSMutableArray *catID,*ProductID,*ProductName,*ProductDiscription,*bname;
    NSMutableString *output;
    NSString *cur_ele;
    NSMutableString *cur_txt;
    NSURL *url;
    NSURLRequest *req;
    NSURLConnection *conn;
    NSMutableDictionary *dics,*dict;
    NSMutableArray *proName;
    NSString *p_Id;
    NSString *p_name;
    NSInteger *proid;
    NSString *name;
    NSMutableArray *arrdata;
    int i,k,p;
    NSMutableArray *list;
    
    IBOutlet UIButton *viewOkButton;
    IBOutlet UIView *productView;
    IBOutlet UIButton *backButton;
    
    IBOutlet UIButton *plusBtn;
    IBOutlet UIButton *subBtn;
    IBOutlet UIButton *closeBtn;
    IBOutlet UILabel *counLabel;
    IBOutlet UIView *subViewProduct;
    IBOutlet UIButton *popCancelButton;
    NSString *brandstring;
    IBOutlet UILabel *lblText;;
    NSArray *arr1;
    NSString *productLabelString;
    IBOutlet UILabel *titLabel;
    NSString *titString;
    
    NSString *MyUrlId;
    AppDelegate *appDelegate;
    
    NSString *productName1;
   
}
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Action_indicator;
- (IBAction)MSG_Method:(id)sender;
@property (retain, nonatomic) NSString *productName1;

@property (retain, nonatomic) IBOutlet UILabel *ProductName;
- (IBAction)MyOrderMethod:(id)sender;
- (IBAction)MoveToHome:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *ProductTitle;

- (IBAction)viewOkButtonMethod:(id)sender;
- (IBAction)closeButton:(id)sender;

@property (retain, nonatomic)NSString *MyUrlId;
@property (retain, nonatomic) IBOutlet UILabel *l1;
@property (retain, nonatomic) IBOutlet UITableView *tblxmldata;
@property (retain, nonatomic) IBOutlet UITableView *tbl1;
@property (retain, nonatomic) IBOutlet UIButton *backButton;
@property(retain,nonatomic)IBOutlet UIButton *plusBtn;
@property(retain,nonatomic) IBOutlet UIButton *subBtn;
@property(retain,nonatomic)    IBOutlet UIButton *closeBtn;

@property(retain,nonatomic)   IBOutlet UILabel *counLabel;
@property(retain,nonatomic) IBOutlet UIView *subViewProduct;
@property(retain,nonatomic)  IBOutlet UIButton *popcancelButton;
@property(retain,nonatomic) NSString *productLabelString;
@property(retain,nonatomic) IBOutlet UILabel *lblText;
@property(nonatomic,retain)IBOutlet UIImageView *bgImageView;
@property(nonatomic,retain)IBOutlet UIImageView *headerImageView;
@property(retain,nonatomic)IBOutlet UILabel *titLabel;


@property(retain,nonatomic)NSString *titString;
-(IBAction)backButtonMethod:(id)sender;
-(IBAction)cancelButtonMethod:(id)sender;
@end
