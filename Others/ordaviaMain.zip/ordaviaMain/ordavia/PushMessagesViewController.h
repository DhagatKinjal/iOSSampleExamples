//
//  PushMessagesViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler.h"

@interface PushMessagesViewController : UIViewController{
    int i;
    IBOutlet UITableView *messageTableView;
    NSMutableArray *NotifactionArray;
    IBOutlet UITextView *sendMessageTextView;
    DBHandler *dbh;
    NSMutableArray *arrayPush;
    
    NSURL *url;
    NSURLRequest *req;
    NSURLConnection *conn;
    NSMutableData *xmldata;
    
    NSString *productName1;
    NSString *Barid;
    NSString *orid;
    NSString *bhid;
    
    NSMutableArray *msgArray;
NSMutableArray	*messages;
}
@property (retain, nonatomic) IBOutlet UITextField *messtextfield;
@property (retain, nonatomic) IBOutlet UITextView *textview;
- (IBAction)sendMessage:(id)sender;
-(IBAction)MainScreenMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *bsrNameTitel;
@property (retain, nonatomic)NSString *Barid;
@property (retain, nonatomic) NSString *bhid;
@property (retain, nonatomic) NSString *productName1;
@property (retain, nonatomic) IBOutlet UIScrollView *mainScroll;
@property (nonatomic,retain)IBOutlet UIButton *backButton;
@property (retain, nonatomic) IBOutlet UILabel *CountFromPushMsg;

@property (nonatomic,retain)IBOutlet UITableView *messageTableView;
@property (nonatomic,retain)NSMutableArray *NotifactionArray;
@property (nonatomic,retain)NSMutableArray *NotificationTime;
@property (nonatomic,retain)NSMutableArray *arrayPush;
@property (nonatomic,retain)NSString *BID;

@property (nonatomic,retain)NSString *orid;

-(IBAction)backButtonMethod:(id)sender;
- (IBAction)MyOrderMethod:(id)sender;
@end
