//
//  productViewController.m
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "productViewController.h"
#import "AddPoductViewController.h"
#import "ProductViewCell.h"
#import "ViewController.h"
#import "MainOrderViewController.h"
#import "subMenuViewController.h"
#import "PushMessagesViewController.h"
#import "AppDelegate.h"
#import "MapViewController.h"
#import "messageInboxViewController.h"
@interface productViewController ()

@end

@implementation productViewController

@synthesize backButton,subBtn,closeBtn,plusBtn;
@synthesize counLabel,subViewProduct,productLabelString,lblText,MyUrlId,titString,titLabel,productName1;
@synthesize bgImageView,headerImageView;
PushMessagesViewController *objPushMessagesViewController;
 ViewController *objRLSampleViewController;
MainOrderViewController *objMainOrderViewController;

AddPoductViewController *objAddPoductViewController;
//subMenuViewController *objsubMenuViewController;
 AppDelegate *objRLSampleAppDelegate;
MapViewController *objMapViewController;
messageInboxViewController *objmessageInboxViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        objRLSampleAppDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];    }
    return self;
}
- (void)viewDidLoad
{
    
    //product --->view
    [_Action_indicator startAnimating];
    
    
    productView.hidden=YES;
    
    UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(94,20,130,35)];
    
    NSString *string=[NSString stringWithFormat:@"http://%@",objRLSampleAppDelegate.logoString];
    
    
    
    UIImage *img=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:string]]];
    
    [imgview setImage:img];
    
    [self.view addSubview:imgview];
    
    
    
    i=0;
    k=0;
    p=3;
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if([appDelegate.SubMenuId isEqualToString:@""] || [appDelegate.SubMenuId isEqualToString:@"(null)"] )
    {
        _ProductName.text=productName1;
        //NSString *MyUrlID1=[[NSString alloc]init];
        NSLog(@"%@",self.MyUrlId);
        
        NSString *MyUrlID1=[NSString stringWithFormat:@"%@",self.MyUrlId];
        NSLog(@"%@",MyUrlID1);
        
        
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n  "];
        MyUrlID1 = [[MyUrlID1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        
        NSLog(@"%@",MyUrlID1);
        
        
        
        NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/ProductApi/getProduct?cat_id=%@&action=customer",MyUrlID1];
        NSLog(@"%@",myurl);
        url = [[NSURL alloc] initWithString:myurl];
        
        req=[NSURLRequest requestWithURL:url];
        conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
        xmldata=[[NSMutableData alloc]init];
        [conn release];
        [_tbl1 setHidden:YES];
        //self.tblxmldata.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"B_G_480x640.png"]];
        
        //self.tbl1.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"popupBG.png"]];
        
        [super viewDidLoad];
        // Do any additional setup after loading the view, typically from a nib.
        
        // self.tbl1.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Menu_bg.png"]];
        // self.tblxmldata.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Menu_bg.png"]];
        
        counLabel.text=productLabelString;
        titLabel.text=titString;
        
        NSLog(@"lbl Text--->%@",productLabelString);
        
        if ([objRLSampleAppDelegate.themeString isEqualToString:@"1"])
        {
            [bgImageView setImage:[UIImage imageNamed:@"001-bg.png"]];
            [headerImageView setImage:[UIImage imageNamed:@"001-header.png"]];
        }
        
        else if ([objRLSampleAppDelegate.themeString isEqualToString:@"2"])
        {
            
            [bgImageView setImage:[UIImage imageNamed:@"002-bg.png"]];
            [headerImageView setImage:[UIImage imageNamed:@"002-header.png"]];
        }
        
        
        else if ([objRLSampleAppDelegate.themeString isEqualToString:@"3"])
        {
            [bgImageView setImage:[UIImage imageNamed:@"003-bg.png"]];
            [headerImageView setImage:[UIImage imageNamed:@"003-header.png"]];
        }
        
        else if ([objRLSampleAppDelegate.themeString isEqualToString:@"4"])
        {
            
            [bgImageView setImage:[UIImage imageNamed:@"004-bg.png"]];
            [headerImageView setImage:[UIImage imageNamed:@"004-header.png"]];
        }
        
        else if ([objRLSampleAppDelegate.themeString isEqualToString:@"5"])
        {
            
            [bgImageView setImage:[UIImage imageNamed:@"005-bg.png"]];
            [headerImageView setImage:[UIImage imageNamed:@"005-header.png"]];
        }
        
        
        
        else{
            [bgImageView setImage:[UIImage imageNamed:@"BG.png"]];
            
        }        NSLog(@"%@",objRLSampleAppDelegate.themeString);
        
        
        
        
    }
    else
    {
        _ProductName.text=productName1;
        //NSString *MyUrlID1=[[NSString alloc]init];
        NSLog(@"%@",self.MyUrlId);
        
        NSString *MyUrlID1=[NSString stringWithFormat:@"%@",self.MyUrlId];
        NSLog(@"%@",MyUrlID1);
        
        
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n  "];
        MyUrlID1 = [[MyUrlID1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        
        NSLog(@"%@",MyUrlID1);
        
        
        
        NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/ProductApi/getProduct?cat_id=%@",appDelegate.SubMenuId];
        NSLog(@"%@",myurl);
        url = [[NSURL alloc] initWithString:myurl];
        
        req=[NSURLRequest requestWithURL:url];
        conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
        xmldata=[[NSMutableData alloc]init];
        [conn release];
        [_tbl1 setHidden:YES];
        //self.tblxmldata.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"B_G_480x640.png"]];
        
        //self.tbl1.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"popupBG.png"]];
        
        [super viewDidLoad];
        // Do any additional setup after loading the view, typically from a nib.
        
        // self.tbl1.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Menu_bg.png"]];
        // self.tblxmldata.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Menu_bg.png"]];
        
        counLabel.text=productLabelString;
        titLabel.text=titString;
        appDelegate.SubMenuId=@"";
        NSLog(@"%@",appDelegate.SubMenuId);
        NSLog(@"lbl Text--->%@",productLabelString);
        
    }
    
    
    
}




- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    [xml_parser release];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
}



- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    cur_ele=nil;
    cur_txt=nil;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict;
{
    
      
    if([elementName isEqualToString:@"xml"])
    {
        dics=[[NSMutableDictionary alloc]init];
        catID=[[NSMutableArray alloc]init];
        ProductID=[[NSMutableArray alloc]init];
        ProductName=[[NSMutableArray alloc]init];
        ProductDiscription=[[NSMutableArray alloc]init];
        arrdata=[[NSMutableArray alloc]init];
         bname=[[NSMutableArray alloc]init];
        
        output=[[NSMutableString alloc]init];
        proName=[[NSMutableArray alloc]init];
    }
    
    else if([elementName isEqualToString:@"brand_name"] || [elementName isEqualToString:@"product_id"] || [elementName isEqualToString:@"product_name"] || [elementName isEqualToString:@"product_desc"])
    {
        cur_ele=elementName;
        cur_txt=[[NSMutableString alloc]init];
        
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [cur_txt appendString:string];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
   
    if([elementName isEqualToString:@"product_id"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [ProductID addObject:arr];
        [output appendString:cur_txt];
        
        brandstring=[[NSString alloc]init];
        NSLog(@"----%@",brandstring);
        
    }
    else if([elementName isEqualToString:@"product_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [ProductName addObject:arr];
        [output appendString:cur_txt];
    }
    else if([elementName isEqualToString:@"product_desc"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [ProductDiscription addObject:arr];
        [output appendString:cur_txt];
        
    }
    
     else if([elementName isEqualToString:@"brand_name"])
    {
        NSArray *arr1=[NSArray arrayWithObjects:cur_txt, nil];
        [bname addObject:arr1];
        [output appendString:cur_txt];
        
        NSLog(@"--%@",bname);
               
        [dics setValue:cur_txt forKey:cur_ele];
        
         NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        
        [catID addObject:arr];
        [output appendString:cur_txt];
        
        NSLog(@"---->%@",arr);
        
        
    }
    
    
    
    else if ([elementName isEqualToString:@"xml"])
    {
        
    }
    [cur_txt release];
    cur_txt=nil;
}

// sent when the parser begins parsing of the document.
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"%@",output);
    if ([output isEqualToString:@""]) {
//        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Sorry,Product is Not Available."delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
//        [alt show];
//        
//        [alt release];
//        
        
        
        
       // [self dismissViewControllerAnimated:YES completion:nil];
        
        productView.hidden=NO;
        
        
    }
    else
    {
       
    }
    [_Action_indicator stopAnimating];
    [_Action_indicator setHidden:YES];
    [_tblxmldata reloadData];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [ProductName count];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView.tag==0)
    {
        return 1;
    }
    else
    {
        return [list count];
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    static  NSString *cellIdentifier=@"ProductViewCell";
    
    ProductViewCell *cell = (ProductViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    
    if(tableView.tag==0)
    {
        
        if(cell==nil)
        {
            
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ProductViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            
            
        }
               
        NSArray *arr=[ProductName objectAtIndex:indexPath.section];
        NSArray *arr1=[bname objectAtIndex:indexPath.section];

        
        cell.ProductLabel.text=[arr objectAtIndex:indexPath.row];
        NSLog(@"%@",[bname objectAtIndex:indexPath.row ]);
        
        cell.DetailLabel.text=[arr1 objectAtIndex:indexPath.row ];
        
        NSLog(@"%@",[arr1 objectAtIndex:indexPath.row ]);
        
        cell.textLabel.textColor=[UIColor whiteColor];
      
        self.tblxmldata.opaque = NO;
        self.tblxmldata.backgroundView = nil;
        //cell.selectionStyle=UITableViewCellSelectionStyleGray;
        
        return cell;
        
        
        
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 47;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    ProductViewCell *cell = (ProductViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    if ( ( [ProductName count] > 0 ) && ( [indexPath length] > 0 ) )
    {
               
     
        objAddPoductViewController=[[AddPoductViewController  alloc]initWithNibName:@"AddPoductViewController5"bundle:nil];
        
   AddPoductViewController *objAddPoductViewController4=[[AddPoductViewController  alloc]initWithNibName:@"AddPoductViewController4"bundle:nil];
        
        NSLog(@"%@",[ProductID objectAtIndex:indexPath.section]);
        
        
        objAddPoductViewController.MyUrlID=[ProductID objectAtIndex:indexPath.section];
         objAddPoductViewController4.MyUrlID=[ProductID objectAtIndex:indexPath.section];
             
        NSString *Discription=[[NSString alloc]initWithFormat:@"%@",[ProductDiscription objectAtIndex:indexPath.row]];
        NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        Discription = [[Discription componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
        
        objAddPoductViewController.TitleStr=cell.ProductLabel.text;
        objAddPoductViewController4.TitleStr=cell.ProductLabel.text;
        
        
        objAddPoductViewController.TitleStr1=cell.DetailLabel.text;
        objAddPoductViewController4.TitleStr1=cell.DetailLabel.text;
        
        
        objAddPoductViewController.brandstring=[catID objectAtIndex:indexPath.row];
     
        objAddPoductViewController4.brandstring=[catID objectAtIndex:indexPath.row];
        
        NSLog(@"%@",[catID objectAtIndex:indexPath.row]);
              
        
        NSString *strDiscription=[NSString stringWithFormat:@"%@",Discription];
        
        
        
        NSString *newStr = [strDiscription substringWithRange:NSMakeRange(4, [strDiscription length]-4)];
        
        
        objAddPoductViewController.DiscriptionStr=newStr;
        objAddPoductViewController4.DiscriptionStr=newStr;
        
        NSString *ProId1=[NSString stringWithFormat:@"%@",[ProductID objectAtIndex:indexPath.section]];
        ProId1 = [[ProId1 componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
        
        
        
        objAddPoductViewController.ProDuctID=ProId1;
        objAddPoductViewController4.ProDuctID=ProId1;
        
        NSLog(@"%@",ProId1);
        NSLog(@"%@",newStr);
        NSLog(@"%@",cell.textLabel.text);
        
     
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
        
         
    [self.navigationController pushViewController:objAddPoductViewController animated:YES];
        }
        else{
          [self.navigationController pushViewController:objAddPoductViewController4 animated:YES];
            
        }
    
    
}
}

-(IBAction)cancelButtonMethod:(id)sender{
    
    subViewProduct.hidden=YES;
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft
                           forView:[self view]
                             cache:YES];
    [self view];
    [UIView commitAnimations];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_tblxmldata release];
    [_l1 release];
    [_tbl1 release];
    [_ProductTitle release];
    [_ProductName release];
    [_Action_indicator release];
    [productView release];
    [viewOkButton release];
    [super dealloc];
}
-(IBAction)backButtonMethod:(id)sender{
    

    
    [self.navigationController popViewControllerAnimated:YES];
    
    
 
   
}
- (IBAction)MyOrderMethod:(id)sender {
   
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
    
 MapViewController  *objMapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objMapViewController4 animated:YES];
    }
    
    
}

- (IBAction)MoveToHome:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
        ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
}
- (IBAction)MSG_Method:(id)sender {
    
    
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];


}

- (void)viewDidUnload {
    [productView release];
    productView = nil;
    [viewOkButton release];
    viewOkButton = nil;
    [super viewDidUnload];
}
- (IBAction)viewOkButtonMethod:(id)sender {
    productView.hidden=YES;
  
}

- (IBAction)closeButton:(id)sender {
      productView.hidden=YES;
    
    [self.navigationController popViewControllerAnimated:YES];
        
    [self.view removeFromSuperview];
}
@end
