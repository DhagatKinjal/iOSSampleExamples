//
//  messageInboxViewController.m
//  ordavia
//
//  Created by mac on 6/20/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "messageInboxViewController.h"
#import "messageInboxCustomcellCell.h"
#import "PushMessagesViewController.h"
#import "MapViewController.h"
#import "ViewController.h"

@interface messageInboxViewController ()

@end

@implementation messageInboxViewController
@synthesize pushMsgarr;
int flag;
PushMessagesViewController *objPushMessagesViewController;
MapViewController *objMapViewController;
ViewController *objViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{   flag=1;
    tempArrayID=[[NSMutableArray alloc] init];
    [tempArrayID addObject:@"@@@!@@@"];
    dbh=[[DBHandler alloc]init];
    self.pushMsgarr=[[NSMutableArray alloc]init];
    self.pushMsgarr=[dbh selectNewPushAll];
    
//      NSLog(@"arrays=> %@",self.pushMsgarr);
//    NSLog(@"first=> %@",[self.pushMsgarr objectAtIndex:0]);
//    NSLog(@"first ID=> %@ %@",[[self.pushMsgarr objectAtIndex:0] objectAtIndex:6],[[dbh tempID] objectAtIndex:0]);
    
//
//   NSMutableArray *array2=[[NSMutableArray alloc]init];
//    for (id obj in self.pushMsgarr)
//    {
//        if (![array2 containsObject:obj])
//        {
//            [array2 addObject: obj];
//        }
//    }
//    NSLog(@"new array is %@",array2);
    
    
    

   

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [_inboxTableview reloadData];
    
   
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  
    return [self.pushMsgarr count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 61;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static  NSString *cellIdentifier=@"messageInboxCustomcellCell";
    
    messageInboxCustomcellCell *cell = (messageInboxCustomcellCell *)[_inboxTableview dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell==nil)
    {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"messageInboxCustomcellCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    
    
    [cell setFont:[UIFont fontWithName:@"Times New Roman" size:18.0]];
    
    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
    NSString *str1=[[NSString alloc]initWithFormat:@"%@",[self.pushMsgarr objectAtIndex:indexPath.row]];
    
    str1= [[str1 componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
    
    NSMutableArray *PushMsgArr1=[[NSMutableArray alloc]initWithArray:[str1 componentsSeparatedByString:@","]];
    
    NSLog(@"%@,%d",PushMsgArr1,[PushMsgArr1 count]);
   
            cell.TimeLbl.text=[PushMsgArr1 objectAtIndex:4];
            
            cell.MSGDiscLBL.text=[PushMsgArr1 objectAtIndex:2];
            
            cell.BarNameLBL.text=[PushMsgArr1 objectAtIndex:0];
            cell.B_id.text=[PushMsgArr1 objectAtIndex:5];
            
            cell.orderid.text=[PushMsgArr1 objectAtIndex:6];

        oid=[PushMsgArr1 objectAtIndex:6];
    NSLog(@"%@ ",oid);

    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    messageInboxCustomcellCell *cell = (messageInboxCustomcellCell *)[_inboxTableview cellForRowAtIndexPath:indexPath];
    
    objPushMessagesViewController=[[PushMessagesViewController  alloc]initWithNibName:@"PushMessagesViewController"bundle:nil];
    
   PushMessagesViewController  *objPushMessagesViewController5=[[PushMessagesViewController  alloc]initWithNibName:@"PushMessagesViewController5"bundle:nil];
    
    
    objPushMessagesViewController.BID=cell.orderid.text;
    
    objPushMessagesViewController.productName1=cell.BarNameLBL.text;
        
    objPushMessagesViewController.Barid=cell.B_id.text;
    
    objPushMessagesViewController.bhid=cell.B_id.text;
    
    
    
    NSLog(@"%@", objPushMessagesViewController.productName1);
    
    NSLog(@"%@", objPushMessagesViewController.bhid);
    
     objPushMessagesViewController5.BID=cell.orderid.text;
    
    
  //  objPushMessagesViewController5.BID=cell.B_id.text;
    
    
    
    objPushMessagesViewController5.productName1=cell.BarNameLBL.text;
    
    objPushMessagesViewController5.Barid=cell.B_id.text;
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
    
      
    [self.navigationController pushViewController:objPushMessagesViewController5 animated:YES];
    }
    else
        [self.navigationController pushViewController:objPushMessagesViewController animated:YES];
    
    
    
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // No editing style if not editing or the index path is nil.
    //if (self.editing == NO || !indexPath) return UITableViewCellEditingStyleNone;
    // Determine the editing style based on whether the cell is a placeholder for adding content or already
    // existing content. Existing content can be deleted.
    if (self.pushMsgarr && indexPath.row == ([pushMsgarr count]))
	{
		return UITableViewCellEditingStyleInsert;
	} else
	{
		return UITableViewCellEditingStyleDelete;
	}
    return UITableViewCellEditingStyleNone;
}




- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
        NSLog(@"%@",oid);
        
        [self.pushMsgarr removeObjectAtIndex:indexPath.row];
        [dbh deletepush:oid];
        
                
        [_inboxTableview reloadData];
        

    }

}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
//- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
//forRowAtIndexPath:(NSIndexPath *)indexPath {
//    // If row is deleted, remove it from the list.
//    if (editingStyle == UITableViewCellEditingStyleDelete) {
//        NSInteger row = [indexPath row];
//         messageInboxCustomcellCell *cell = (messageInboxCustomcellCell*)[tableView cellForRowAtIndexPath:indexPath];
//        
//        [self.pushMsgarr removeObjectAtIndex:row];
//        
//        [_inboxTableview reloadData];
//    }
//}




- (void)dealloc {
    [_inboxTableview release];
    [super dealloc];
}
- (IBAction)backButtonMethod:(id)sender {
    
      [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)homeSreenMethod:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objViewController animated:YES];
        
        
    }else{
        ViewController *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
    
    
}

- (IBAction)VenuesSreccMethod:(id)sender {
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
    
   MapViewController *objMapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objMapViewController4 animated:YES];
    
    }
    
}
@end
