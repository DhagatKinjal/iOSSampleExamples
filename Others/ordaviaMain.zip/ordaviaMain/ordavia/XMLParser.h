//
//  XMLParser.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>
@class AppDelegate, Book; 
@interface XMLParser : NSObject
{
    
	AppDelegate *appDelegate;
	Book *aBook;
    
    
    NSString *currentElementValue;
	NSMutableString *CurrentText;
	
    NSMutableArray *AddOnName,*AddonId,*AddOnPrice;
    NSMutableString *output;
    NSXMLParser *xml_parser;
    NSMutableData *xmldata;
    NSURLRequest *req,*req1;
    NSURLConnection *conn;
    NSMutableDictionary *dics;
    NSURL *url;
    
    NSString *arrString;
    
}
@property(retain, nonatomic)NSMutableArray *AddOnName,*AddonId,*AddOnPrice;
- (XMLParser *) initXMLParser;
@end
