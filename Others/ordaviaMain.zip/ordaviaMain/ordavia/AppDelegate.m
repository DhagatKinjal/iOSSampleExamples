//
//  AppDelegate.m
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"
#import "AddPoductViewController.h"
#import "XMLParser.h"
#import "subXMLParser.h"

//#import "proXMLParser.h"
#import "DBHandler.h"
//#import "RLSampleViewController.h"

@implementation AppDelegate
@synthesize window,SubMenuId;
@synthesize viewController,ProductItemId;
@synthesize navigationController,subbooks1, books,subbooks,probooks,addonID,addonName,addonPrice,deviceToken,dbpath1,dbpath,time,alertView,alert,NotificationMessage,ForAddonIds,ForProduct,dev,Cancel,OD_id,timeNotification,MainOrderTotal,dbpath2,dbpath3,myAdonIds,ProId,BarCode;
DBHandler *dbh;
@synthesize appLongString,appLatString,CategoryId,CategoryName,Themeid,themeString,logoString;


- (void)dealloc
{
    [viewController release];
    [window release];
    [books release];
	[navigationController release];
    [super dealloc];
}

-(void)checkDB
{
    NSArray *arrdir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path=[arrdir objectAtIndex:0];
    
    self.dbpath=[path stringByAppendingString:@"/OrdiviaOrderDB.sqlite"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:self.dbpath])
    {
        NSError *err;
        NSString *searchpath=[[NSBundle mainBundle]pathForResource:@"OrdiviaOrderDB" ofType:@"sqlite"];
        [[NSFileManager defaultManager]copyItemAtPath:searchpath toPath:self.dbpath error:&err];
    }
}
-(void)checkDB1
{
    NSArray *arrdir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path=[arrdir objectAtIndex:0];
    
    self.dbpath1=[path stringByAppendingString:@"/MyOrderTimeDB"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:self.dbpath1])
    {
        NSError *err;
        NSString *searchpath=[[NSBundle mainBundle]pathForResource:@"MyOrderTimeDB" ofType:@"sqlite"];
        [[NSFileManager defaultManager]copyItemAtPath:searchpath toPath:self.dbpath1 error:&err];
    }
}
-(void)checkDB2
{
    NSArray *arrdir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path=[arrdir objectAtIndex:0];
    
    self.dbpath2=[path stringByAppendingString:@"/PushDB1.sqlite"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:self.dbpath2])
    {
        NSError *err;
        NSString *searchpath=[[NSBundle mainBundle]pathForResource:@"PushDB1" ofType:@"sqlite"];
        [[NSFileManager defaultManager]copyItemAtPath:searchpath toPath:self.dbpath2 error:&err];
    }
}
-(void)checkDB3
{
    NSArray *arrdir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path=[arrdir objectAtIndex:0];
    
    self.dbpath3=[path stringByAppendingString:@"/OrdiviaOrderPriceDB.sqlite"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:self.dbpath3])
    {
        NSError *err;
        NSString *searchpath=[[NSBundle mainBundle]pathForResource:@"OrdiviaOrderPriceDB" ofType:@"sqlite"];
        [[NSFileManager defaultManager]copyItemAtPath:searchpath toPath:self.dbpath3 error:&err];
    }
}

-(void)FirstTimeDateTimeStoreinDB
{
    /*dbh=[[DBHandler alloc]init];
     
     NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
     [dateFormatter1 setDateFormat:@"hh:mm.a"];
     NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
     [dateFormatter2 setDateFormat:@"dd-MM-yyyy"];
     
     NSString *todayDate=[dateFormatter2 stringFromDate:[NSDate date]];
     NSString *todayString = [dateFormatter1 stringFromDate:[NSDate date]];
     
     NSLog(@"Time:%@",todayString);
     NSLog(@"Date:%@",todayDate);
     
     NSString *str = [NSString stringWithFormat:@"%@",todayString];
     
     NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
     
     [dateFormatter setDateFormat:@"hh:mm.a"];// here give the format which you get in TimeStart
     
     NSDate *date = [dateFormatter dateFromString: str];
     
     dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
     
     [dateFormatter setDateFormat:@"mm:ss:SS"];
     
     NSString *convertedString = [dateFormatter stringFromDate:date];
     
     
     NSLog(@"Converted String : %@",convertedString);
     
     
     NSArray *arrtime=[[NSArray alloc]initWithObjects:convertedString,todayDate, nil];
     //[dbh deleteTime];
     
     [dbh insertTimeDate:arrtime];
     
     
     NSArray *arrdate=[[NSArray alloc]init];
     arrdate=[dbh selecttime];
     
     
     NSLog(@"%@",arrdate);*/
    Time=0;
    
    
    
}




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    
    
//    userMessageCounter = @"0";
//    postType = 0;
//    joinedStreamChecker = 0;
//    OwnerValue = 0;
//    pushValue = 1;
//    badgeValue =0;
//    
    
    
    [self checkDB];
    [self checkDB1];
    [self checkDB2];
    [self checkDB3];
    
    [self FirstTimeDateTimeStoreinDB];
    self.OD_id=0;
    i=0;
    self.CategoryName=[[NSMutableArray alloc]init];
    self.CategoryId=[[NSMutableArray alloc]init];
    self.Themeid=[[NSMutableArray alloc]init];
    self.ProId=[[NSMutableArray alloc]init];
    
    self.myAdonIds=[[NSMutableArray alloc]init];
    dbh=[[DBHandler alloc]init];
    self.BarCode=[[NSDictionary alloc]init];
    
    self.MainOrderTotal=[[NSString alloc]init];
    self.NotificationMessage=[[NSMutableString alloc]init];
    self.timeNotification=[[NSMutableString alloc]init];
    self.ForAddonIds=[[NSMutableString alloc]init];
    self.ForProduct=[[NSMutableString alloc]init];
    self.appLatString=[[NSString alloc]init];
    self.appLongString =[[NSString alloc]init];
    self.themeString=[[NSString alloc]init];
    self.logoString=[[NSString alloc]init];
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert|UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeNone)];
    
    
    
	[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackOpaque];
    deviceToken=nil;
    
    
    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
     
        self.viewController = [[[ViewController alloc] initWithNibName:@"ViewController" bundle:nil] autorelease];
        
    }else{
      self.viewController = [[[ViewController alloc] initWithNibName:@"ViewController4" bundle:nil] autorelease];  
    }

    
   
    self.window.rootViewController = self.viewController;
    
    
    
    
      self.navigationController = [[[UINavigationController alloc] initWithRootViewController:viewController] autorelease];
    self.window.rootViewController = self.navigationController;
       
        
    
    [self.window makeKeyAndVisible];

    if (launchOptions != nil)
    {
        NSDictionary* dictionary = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if (dictionary != nil)
        {
            NSLog(@"Launched from push notification: %@", dictionary);
            
            [self clearNotifications];
        }
    }

    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    
    return YES;
    
    
    
    
}



-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken {
    
    NSString *deviceTokenString=[NSString stringWithFormat:@"%@",devToken ];
    NSLog(@"%@",deviceTokenString);
    
    deviceToken=[NSString stringWithFormat:@"%@",deviceTokenString];
    
    deviceToken = [devToken retain];
    
    
    
    dev = [[NSMutableString alloc] init];
    
    NSRange r;
    r.length = 1;
    unsigned char c;
    
    for (int i = 0; i < [deviceToken length]; i++)
    {
        r.location = i;
        [deviceToken getBytes:&c range:r];
        
        if (c < 10) {
            [dev appendFormat:@"0%x", c];
        }
        else {
            [dev appendFormat:@"%x", c];
        }
        
    }
    
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    
    [def setObject:dev forKey:@"DeviceToken"];
    
    [def synchronize];
    
    NSLog(@"Registered for APNS %@\n%@", deviceToken, dev);
    
    [dev release];
    
    
    
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    
    NSString *str = [NSString stringWithFormat: @"Error: %@", err];
    NSLog(@"%@",str);
    deviceToken = nil;
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
   
    
    NSLog(@"Recieved Remote Notification %@", userInfo);
    
    NSDictionary *aps = [userInfo objectForKey:@"aps"];
    
    NSLog(@"%@",aps);
    NSString *alertMessage = [aps objectForKey:@"alert"];
    
  
    
    NSLog(@"%@",alertMessage);
    
    self.NotificationMessage=[NSString stringWithString:alertMessage];
    
    NSDateFormatter *formatter;
    NSString        *dateString;
    
    formatter = [[NSDateFormatter alloc] init];
   // [formatter setDateFormat:@"HH:mm a"];
    
  [formatter setDateFormat:@"MMM/dd/yyyy/hh:mm a"];
    
    dateString = [formatter stringFromDate:[NSDate date]];
    NSLog(@"%@",dateString);
    [formatter release];
    self.timeNotification=[NSString stringWithString:dateString];
    
    NSLog(@"array: %@", alertMessage);
    NSMutableArray *PushMsgArr=[[NSMutableArray alloc]initWithArray:[alertMessage componentsSeparatedByString:@":"]];
    [PushMsgArr objectAtIndex:0];
    [PushMsgArr objectAtIndex:1];
    [PushMsgArr objectAtIndex:2];
    [PushMsgArr objectAtIndex:3];
    
    NSLog(@"array: %@", self.timeNotification);
    NSLog(@"array: %@", self.NotificationMessage);
    
    NSArray *arr=[[NSArray alloc]initWithObjects:[PushMsgArr objectAtIndex:1],[NSString stringWithFormat:@"%d",i],[PushMsgArr objectAtIndex:3],@"Recieve",self.timeNotification,[PushMsgArr objectAtIndex:0],[PushMsgArr objectAtIndex:2], nil];
    NSLog(@"%@",arr);
    [dbh insertPush:arr];
    
    NSMutableArray *array=[dbh selectNewPush:[NSString stringWithFormat:@"%@",[arr objectAtIndex:5]]];
    NSLog(@"%@",array);
    NSString *ValidateStr=[NSString stringWithFormat:@"%@",array];
    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n, "];
    ValidateStr = [[ValidateStr componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
    NSLog(@"%@",ValidateStr);
    if([ValidateStr isEqualToString:@""])
    {
        //[dbh deleteOnePush:[NSString stringW`ithFormat:@"%@",[arr objectAtIndex:5]]];
        [dbh insertNewPush:arr];
    }
    else
        
    {
        [dbh deleteOnePush:[NSString stringWithFormat:@"%@",[arr objectAtIndex:5]]];
        [dbh insertNewPush:arr];
    }
    
    i++;
    
    NSString *alertMsg;
    NSString *badge;
    NSString *sound;
    
    
    if( [[userInfo objectForKey:@"aps"] objectForKey:@"alert"] != NULL)
    {
        alertMsg = [[userInfo objectForKey:@"aps"] objectForKey:@"alert"];
    }
    else
    {    alertMsg = @"{no alert message in dictionary}";
    }
    
    if( [[userInfo objectForKey:@"aps"] objectForKey:@"badge"] != NULL)
    {
        badge = [[userInfo objectForKey:@"aps"] objectForKey:@"badge"];
    }
    else
    {    badge = @"{no badge number in dictionary}";
    }
    
    if( [[userInfo objectForKey:@"aps"] objectForKey:@"sound"] != NULL)
    {
        sound = [[userInfo objectForKey:@"aps"] objectForKey:@"sound"];
    }
    else
    {    sound = @"{no sound in dictionary}";
    }
        
    NSLog(@"%@",alertMsg);
    
//    alertMsg = [alertMsg substringWithRange:NSMakeRange(10, [alertMessage length]-10)];
//    
//    NSLog(@"%@",alertMsg);
//    
//
//    NSString* alert_msg = [NSString stringWithFormat:@"%@", alertMsg];
//    
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
//                                                    message:alert_msg
//                                                   delegate:nil
//                                          cancelButtonTitle:@"OK"
//                                          otherButtonTitles:nil];
//    [alert show];
//    [alert release];
    
    
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive) {
        // do stuff when app is active
        
    }else{
        // do stuff when app is in background
        [UIApplication sharedApplication].applicationIconBadgeNumber =
        [UIApplication sharedApplication].applicationIconBadgeNumber-1;
        /* to increment icon badge number */
        
        
            }
}


- (void) clearNotifications {
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
