//
//  CheckXMLParser.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>
@class AppDelegate, Book;
@interface CheckXMLParser : NSObject
{

//NSMutableString *currentElementValue;
int i;
AppDelegate *appDelegate;
Book *aBook;


NSString *currentElementValue;
NSMutableString *CurrentText;

NSMutableArray *CurrentParentId,*CurrentName,*CurrentProductId,*ProductId,*ProductName;
NSMutableString *output;
NSXMLParser *xml_parser;
NSMutableData *xmldata;
NSURLRequest *req;
NSURLConnection *conn;
NSMutableDictionary *dics;
NSURL *url;

NSString *MyUrlID;

NSString *subMenuLabelString;
// NSString *currentElementValue;
//NSMutableString *CurrentText;

//NSMutableArray *AddOnName,*AddonId,*AddOnPrice;
// NSMutableString *output;
//NSXMLParser *xml_parser;
//NSMutableData *xmldata;
//NSURLRequest *req,*req1;
// NSURLConnection *conn;
// NSMutableDictionary *dics;
// NSURL *url;

NSString *arrString;

NSURL *myurl1;
NSString *myid;
}
@property (nonatomic)int i;
@property (retain, nonatomic)NSURL *myurl1;
@property (retain, nonatomic)NSString *myid;
@property(retain, nonatomic)NSMutableArray *AddOnName,*AddonId,*AddOnPrice;
- (CheckXMLParser *) initXMLParser;
@end
