//
//  Place.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
@interface Place : NSObject
{
    NSString* name;
    NSString* description;
    double latitude;
    double longitude;
    CLLocation *location2;
    CLLocation *location1 ;
}
@property (nonatomic, retain) NSString* name;
@property (nonatomic, retain) NSString* description;
@property (nonatomic) double latitude;
@property (nonatomic) double longitude;
@property (nonatomic, retain)CLLocation *location1;
@property (nonatomic, retain)CLLocation *location2;
@end
