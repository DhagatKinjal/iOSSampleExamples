//
//  PushMessagesCustomCell.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PushMessagesCustomCell : UITableViewCell
{
    UILabel	*senderAndTimeLabel;
	UITextView *messageContentView;
	UIImageView *bgImageView;
}



@property (nonatomic,retain) UILabel *senderAndTimeLabel;
@property (nonatomic,retain) UITextView *messageContentView;
@property (nonatomic,retain) UIImageView *bgImageView;




@property (retain, nonatomic) IBOutlet UILabel *ProductLabel;
@property (retain, nonatomic) IBOutlet UIImageView *cellImage;
@property (retain, nonatomic) IBOutlet UILabel *idPushMsg;
@property (retain, nonatomic) IBOutlet UILabel *productSecond;
@property (retain, nonatomic) IBOutlet UILabel *dateSecond;

@property (retain, nonatomic) IBOutlet UIImageView *secondImage;
@property (retain, nonatomic) IBOutlet UILabel *DateTimeLbl;
@end
