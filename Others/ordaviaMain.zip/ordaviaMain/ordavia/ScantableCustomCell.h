//
//  ScantableCustomCell.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScantableCustomCell : UITableViewCell
@property(nonatomic,retain)IBOutlet UILabel *menuItemsLabel;
@end
