//
//  subMenuViewController.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AppDelegate;
@interface subMenuViewController : UIViewController
{
NSString *MenuName;

IBOutlet UITableView *tableview;
IBOutlet UIButton *backButton;
AppDelegate *subappDelegate;
IBOutlet UILabel *lblText;
NSString *selectedCountry;
//BarcodePickerController *pickerController;




NSString *currentElementValue;
NSMutableString *CurrentText;

NSMutableArray *CurrentParentId,*CurrentName,*CurrentProductId,*ProductId,*ProductName;
NSMutableString *output;
NSXMLParser *xml_parser;
NSMutableData *xmldata;
NSURLRequest *req;
NSURLConnection *conn;
NSMutableDictionary *dics;
NSURL *url;

NSString *MyUrlID;

NSString *subMenuLabelString;
}
//@property (retain, nonatomic) IBOutlet UILabel *SubMenuTitle;
- (IBAction)Msg_Method:(id)sender;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Action_indicator;

@property (retain, nonatomic) NSString *MenuName;
@property (retain, nonatomic) IBOutlet UILabel *SubMenuTitle;
- (IBAction)MyOrderMethod:(id)sender;

@property(nonatomic,retain)IBOutlet UITableView *tableview;
@property(nonatomic,retain)IBOutlet UIButton *backButton;
@property(nonatomic,retain) IBOutlet UILabel *lblText;
@property(nonatomic,retain)NSString *selectedCountry;

@property(nonatomic,retain)IBOutlet UIButton *checkInButton;
@property(nonatomic,retain)IBOutlet UIButton *venuesButton;
@property(nonatomic,retain)IBOutlet UIButton *mainSrceenButton;


@property(nonatomic,retain)NSString *subMenuLabelString;
@property(nonatomic,retain)NSString *MyUrlID;
@property(nonatomic,retain)IBOutlet UIImageView *bgImageView;
@property(nonatomic,retain)IBOutlet UIImageView *headerImageView;
-(IBAction)backButtonMethod:(id)sender;

-(IBAction)menuButtonMethod:(id)sender;
-(IBAction)venuesButtonMethod:(id)sender;
-(IBAction)mainSrceenButton:(id)sender;



@end
