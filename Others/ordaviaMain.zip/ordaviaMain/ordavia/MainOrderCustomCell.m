//
//  MainOrderCustomCell.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "MainOrderCustomCell.h"
#import "AddPoductViewController.h"
#import "MainOrderViewController.h"

@implementation MainOrderCustomCell
AddPoductViewController *objAddPoductViewController;
MainOrderViewController *objMainOrderViewController;

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    temp=[_TotalPriceLbl.text floatValue];
    //NSString *str=[NSString stringWithFormat:@"%d",[_BottleQutntityLbl.text intValue]];
    
    bottleQnty=[_BottleQutntityLbl.text intValue];
    
    
    //temp1=[objMainOrderViewController.TotalLbl.text floatValue];
    
    
    
    [super setSelected:selected animated:animated];
    
    // bottleQnty=[_TotalPriceLbl.text intValue];
    //[super viewDidLoad];
    
}


- (void)dealloc {
    
    [_TitleLbl release];
    [_DiscriptionLbl release];
    [_QuntityLbl release];
    [_SubItemLbl release];
    
    [_TotalPriceLbl release];
    [_BottleQutntityLbl release];
    [_OD_Id release];
    [_withLabel release];
    [_prizeL release];
    [super dealloc];
}
- (IBAction)IncreamentBottleQnty:(id)sender {
    
    
    
    bottleQnty++;
    
    float finalTotal1=[objMainOrderViewController.TotalLbl.text floatValue]+temp;
    NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
    [numberFormatter1 setPositiveFormat:@"###0.##"];
    
    NSString *formattedNumberString1 = [numberFormatter1 stringFromNumber:[NSNumber numberWithFloat:finalTotal1]];
    NSLog(@"formattedNumberString: %@", formattedNumberString1);
    ////
    
    objMainOrderViewController.TotalLbl.text=formattedNumberString1;
    [numberFormatter1 release];
    //[NSString stringWithFormat:@"%f",[objMainOrderViewController.TotalLbl.text floatValue]+temp];
    
    str =[NSString stringWithFormat:@"%d",[objMainOrderViewController.ItemLbl.text intValue]+1];
    objMainOrderViewController.ItemLbl.text=str;
    
    _BottleQutntityLbl.text=[NSString stringWithFormat:@"%d",bottleQnty];
    
    
    
    float finalTotal=[_TotalPriceLbl.text floatValue]+temp;
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setPositiveFormat:@"###0.##"];
    
    NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalTotal]];
    NSLog(@"formattedNumberString: %@", formattedNumberString);
    
    
    NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalTotal];
    
    NSLog(@"%@",formattedNumber);
    
    
   // _TotalPriceLbl.text=formattedNumber;
    
    [numberFormatter release];
    
    
}

- (IBAction)DecreamentBottleOnty:(id)sender {
    bottleQnty=[_BottleQutntityLbl.text intValue];
    if(bottleQnty==0)
    {
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"status" message:@"Pls Select the bottle quantity" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alt show];
        [alt release];
    }
    else
    {
                
        bottleQnty--;
        float finalTotal1=[objMainOrderViewController.TotalLbl.text floatValue]-temp;
       
        
        NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
        [numberFormatter1 setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString1 = [numberFormatter1 stringFromNumber:[NSNumber numberWithFloat:finalTotal1]];
        NSLog(@"formattedNumberString: %@", formattedNumberString1);
        ////
        
        objMainOrderViewController.TotalLbl.text=formattedNumberString1;
        [numberFormatter1 release];
        //objMainOrderViewController.TotalLbl.text=[NSString stringWithFormat:@"%f",[objMainOrderViewController.TotalLbl.text floatValue]-temp];
        float finalTotal=[_TotalPriceLbl.text floatValue]-temp;
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalTotal]];
        NSLog(@"formattedNumberString: %@", formattedNumberString);
        str =[NSString stringWithFormat:@"%d",[objMainOrderViewController.ItemLbl.text intValue]-1];
        objMainOrderViewController.ItemLbl.text=str;
        
          NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalTotal];
        
     //   _TotalPriceLbl.text=formattedNumber;
        
        [numberFormatter release];
        //bjMainOrderViewController.TotalLbl.text=formattedNumberString;
        _BottleQutntityLbl.text=[NSString stringWithFormat:@"%d",bottleQnty];
    }
    
}
-(void)UpdateTable
{
    [objMainOrderViewController.mainOrderTable reloadData];
}
@end
