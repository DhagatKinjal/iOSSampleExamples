//
//  MainOrderCustomCell.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddPoductViewController.h"
@interface MainOrderCustomCell : UITableViewCell
{
    int bottleQnty;
    float temp,temp1,temp2;
    NSString *str;
}
@property (retain, nonatomic) IBOutlet UILabel *prizeL;
@property (retain, nonatomic) IBOutlet UILabel *BottleQutntityLbl;
@property (retain, nonatomic) IBOutlet UILabel *TotalPriceLbl;
@property (retain, nonatomic) IBOutlet UILabel *TitleLbl;
@property (retain, nonatomic) IBOutlet UILabel *DiscriptionLbl;
@property (retain, nonatomic) IBOutlet UILabel *QuntityLbl;
@property (retain, nonatomic) IBOutlet UILabel *SubItemLbl;
@property (retain, nonatomic) IBOutlet UILabel *OD_Id;
@property (retain, nonatomic) IBOutlet UILabel *withLabel;

- (IBAction)IncreamentBottleQnty:(id)sender;
- (IBAction)DecreamentBottleOnty:(id)sender;



@end
