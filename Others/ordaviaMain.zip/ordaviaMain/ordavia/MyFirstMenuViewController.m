 //
//  MyFirstMenuViewController.m
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "MyFirstMenuViewController.h"
#import "ViewController.h"

#import "mapViewController.h"
#import "AppDelegate.h"

#import "productViewController.h"
#import "subMenuViewController.h"
#import "ScantableCustomCell.h"
#import "MainOrderViewController.h"
#import "PushMessagesViewController.h"
#import "MyFirstMenuViewController.h"
#import "ScantableCustomCell.h"
#import "MapViewController.h"
#import "messageInboxViewController.h"

@interface MyFirstMenuViewController ()

@end

@implementation MyFirstMenuViewController
@synthesize bgImageView,Action_Indicator,headerImageView,logoimgview;
//productViewController *objproductViewController;
productViewController *objproductViewController5;
productViewController *objproductViewController4;

PushMessagesViewController *objPushMessagesViewController;
MainOrderViewController *objMainOrderViewController;
MapViewController *objmapViewController;
//subMenuViewController *objsubMenuViewController;
ViewController *objRLSampleViewController;
AppDelegate *appDelegate;
MapViewController *objMapViewController;
messageInboxViewController *objmessageInboxViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)viewDidLoad
{
       
    _singOutView.hidden=YES;
    
    [_Active startAnimating];
    
    [_Active2 setHidden:YES];
    dbh=[[DBHandler alloc]init];
    
       
     url = [[NSURL alloc] initWithString:@"http://www.bevond.com/ordavia/index.php/CategoryApi/GetCategory?zone_id=1&bar_id=1&lat=52.813507&long=-1.638649&action=customer"];
         req=[NSURLRequest requestWithURL:url];
     conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
     xmldata=[[NSMutableData alloc]init];
    [_scanHistoryTable reloadData];
     [conn release];
              
    [super viewDidLoad];
   
}


 - (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
 {
     
 [xmldata appendData:data];
     
    str = [[NSString alloc] initWithData:xmldata encoding:NSUTF8StringEncoding];
     
     NSLog(@"%@",str);
     if([str isEqualToString:@"Failed"])
     {
         NSLog(@"Failed");
         
     }
     
     
     
 }
 
 - (void)connectionDidFinishLoading:(NSURLConnection *)connection
 {
 xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
 [xml_parser setDelegate:self];
 [xml_parser parse];
 [xml_parser release];
 
     
     if([str isEqualToString:@"Failed"])
     {
         NSLog(@"Failed");
         
     }

     
     
 }
 
 - (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
 {
 UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
 [alt show];
 [alt release];
 }
 
 
 
 - (void)parserDidStartDocument:(NSXMLParser *)parser
 {
 currentElementValue=nil;
 CurrentText=nil;
 }
 
 
 - (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict {
 
 if([elementName isEqualToString:@"xml"]) {
 //Initialize the array.
 CategoryName=[[NSMutableArray alloc]init];
 CategoryId=[[NSMutableArray alloc]init];
 Themeid=[[NSMutableArray alloc]init];
     logoId=[[NSMutableArray alloc]init];
     statsid=[[NSMutableArray alloc]init];
     
 output=[[NSMutableString alloc]init];
    lstring=[[NSMutableString alloc]init];
 
 //appDelegate.books = [[NSMutableArray alloc] init];
 }
 else if([elementName isEqualToString:@"cat_id"]||[elementName isEqualToString:@"cat_name"]||[elementName isEqualToString:@"status"]) {
 
 //Initialize the book.
 //aBook = [[Book alloc] init];
 
 //Extract the attribute here.
 //aBook.bookID = [[attributeDict objectForKey:@"id"] integerValue];
 //aBook.name=[attributeDict objectForKey:@"name"];
 currentElementValue=elementName;
 CurrentText=[[NSMutableString alloc]init];
 //NSLog(@"Reading id value :%i", aBook.bookID);
 }
 
 NSLog(@"Processing Element: %@", elementName);
 }
 
 - (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
 
 if(!CurrentText)
 CurrentText = [[NSMutableString alloc] initWithString:string];
 else
 [CurrentText appendString:string];
 
 NSLog(@"Processing Value: %@", CurrentText);
 
 }
 
 - (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
 namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
 
 if([elementName isEqualToString:@"xml"])
 {
 
 }
 
 if([elementName isEqualToString:@"cat_name"]) {
 
 NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
 
 [CategoryName addObject:arr];
 [output appendString:CurrentText];
 
 
 
 
 }
 else if([elementName isEqualToString:@"cat_id"])
 {
 NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
 [CategoryId addObject:arr];
 [output appendString:CurrentText];
 
 
 }
     
 else if([elementName isEqualToString:@"CONCATwww.bevond.comordaviavenue.bar_logo"])
 {
     NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
     [logoId addObject:arr];
     [lstring appendString:CurrentText];
    
     
 }
 else if([elementName isEqualToString:@"status"])
 {
     NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
     [statsid addObject:arr];
     [output appendString:CurrentText];
     NSLog(@"%@",output);
     NSLog(@"%@",statsid);
     
     
     
     
     
 } 
     
     
 else if([elementName isEqualToString:@"theme_id"])
 {
 NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
 [Themeid addObject:arr];
 [output appendString:CurrentText];
 
 NSLog(@"arr %@",Themeid);
     
     NSLog(@"arr %@",arr);
 
     
     
     
     
 }
     
     if([output isEqualToString:@"Failed"])
     {
         
         UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"We have stopped taking order by scanning please talk to the venues manager sorry for the inconvenience" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
         
         [alt show];
         [alt release];
         
         [self.navigationController popViewControllerAnimated:YES];
         
         
     }else{
         
     
     
 NSLog(@"Bar_Name:%@",[Themeid objectAtIndex:0]);
 
 [CurrentText release];
 CurrentText=nil;
     }
 }
 - (void)parserDidEndDocument:(NSXMLParser *)parser
 {
 

 [_scanHistoryTable reloadData];
 
    /*
     NSLog(@"Bar_Name:%@",[Themeid objectAtIndex:1]);
     
     appDelegate.themeString=[Themeid objectAtIndex:1];
     
     NSString *themid1=[NSString stringWithFormat:@"%@",appDelegate.themeString];
     
     NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n\"\\n  "];
     themid1= [[themid1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
     
     NSLog(@"%@",themid1);
     
     appDelegate.themeString=themid1;
     
   */
     
     
     
     
     if([output isEqualToString:@"Failed"])
     {
         
         UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"We have stopped taking order by scanning please talk to the venues manager sorry for the inconvenience" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
         
         [alt show];
         [alt release];
         
         [self.navigationController popViewControllerAnimated:YES];
         
         
     }else{
         
     
     
     
     
     
     NSLog(@"Bar_Name:%@",[logoId objectAtIndex:1]);
     
     appDelegate.logoString=[logoId objectAtIndex:1];
     
     NSString *themid2=[NSString stringWithFormat:@"%@",appDelegate.logoString];
     
     NSCharacterSet *doNotWant2= [NSCharacterSet characterSetWithCharactersInString:@"() \" "  ];
     themid2= [[themid2 componentsSeparatedByCharactersInSet: doNotWant2] componentsJoinedByString: @""];
     
    

     NSString *address =[ NSString stringWithFormat:@"%@",themid2];
     address = [address stringByReplacingOccurrencesOfString:@"\n" withString:@""];
     address = [address stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
     
     NSLog(@"%@",address);
     
     
     NSString *address1 =[ NSString stringWithFormat:@"%@",address];
     address1 = [address1 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
     address1 = [address1 stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
       address1 = [address1 substringWithRange:NSMakeRange(2, [address1 length]-2)];
     
     NSLog(@"%@",address1);
     
     appDelegate.logoString=address1;
     
     
    // logoimgview=[[UIImageView alloc]initWithFrame:cgrect;
     
      UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(94,20,130,35)];
     
     NSString *string=[NSString stringWithFormat:@"http://%@",address1];
     
  
     
     UIImage *img=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:string]]];
     
     [imgview setImage:img];
     
     [self.view addSubview:imgview];
     
     
   
     
     
     
 [_Active stopAnimating];
 [_Active setHidden:YES];
     }
 }


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSLog(@"%@",CategoryName,CategoryId);
    return [CategoryName count];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    
    static  NSString *cellIdentifier=@"ScantableCustomCell";
    
    ScantableCustomCell *cell = (ScantableCustomCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    
    if(cell == nil)
    {
        
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ScantableCustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    //Book *aBook = [data1 objectAtIndex:indexPath.row];
    //NSLog(aBook.name);
    
    NSArray *arr=[CategoryName objectAtIndex:indexPath.section];
    
    cell.menuItemsLabel.text=[arr objectAtIndex:indexPath.row];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
   // cell.textLabel.highlightedTextColor = [UIColor redColor];
    
    cell.textColor = [UIColor redColor];
    //theCell.textLabel.textColor = [UIColor redColor];
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    
        return cell;
    
    
    
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UINavigationController *navigationController= [[UINavigationController alloc]init];
        ScantableCustomCell *cell = (ScantableCustomCell *)[tableView cellForRowAtIndexPath:indexPath] ;
    
    
    
     [_Active2 setHidden:NO];
    [_Active2 startAnimating];
    
      
    if ( ( [CategoryName count] > 0 ) && ( [indexPath length] > 0 ) )
    {
        
      
        
       subMenuViewController  *objsubMenuViewController=[[subMenuViewController  alloc]initWithNibName:@"subMenuViewController5"bundle:nil];
        
        
         subMenuViewController  *objsubMenuViewController4=[[subMenuViewController  alloc]initWithNibName:@"subMenuViewController4"bundle:nil];
        
        
        
        
        NSLog(@"%@",[CategoryId objectAtIndex:indexPath.section]);
        
        objsubMenuViewController.MyUrlID=[CategoryId objectAtIndex:indexPath.section];
        
          objsubMenuViewController4.MyUrlID=[CategoryId objectAtIndex:indexPath.section];
    
        
        self.MyUrlID1=[NSString stringWithFormat:@"%@",[CategoryId objectAtIndex:indexPath.section]];
        
        NSLog(@"%@",self.MyUrlID1);
        
      
        
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n  "];
        self.MyUrlID1 = [[self.MyUrlID1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        
        NSLog(@"%@",self.MyUrlID1);
        
        
        NSURL *url1=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CategoryApi/GetSubCategory?cat_id=%@&action=customer",self.MyUrlID1];
                
        NSLog(@"%@",url1);
        
        
        NSString *u=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CategoryApi/GetSubCategory?cat_id=%@&action=customer",self.MyUrlID1];
        
        
        
        
        
        
        //http://www.bevond.com/ordavia/index.php/CategoryApi/GetSubCategory?cat_id=%@",MyUrlID1];
        
        url11=[NSURL URLWithString:u];
        
        NSLog(@"%@",url11);
        
        
        // check=[[CheckXMLParser alloc]initXMLParser];
        
        
        NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithContentsOfURL:url11];
        
        CheckXMLParser *parser = [[CheckXMLParser alloc] initXMLParser];
        
        
        
        [xmlParser setDelegate:parser];
        
        
        //Start parsing the XML file.
        BOOL success = [xmlParser parse];
        
        if(success)
            NSLog(@"No Errors");
        else
            NSLog(@"Error Error Error!!!");
        
        
        
        NSLog(@"%d",parser.i);
        
        NSLog(@"%@",cell.menuItemsLabel.text);
        

        
        if(parser.i==0)
        {
          
          
            objsubMenuViewController.MenuName=cell.menuItemsLabel.text;
         
             objsubMenuViewController4.MenuName=cell.menuItemsLabel.text;
            
            CGRect screenBounds = [[UIScreen mainScreen] bounds];
            if (568 == screenBounds.size.height)
            {
            
            
                [self.navigationController pushViewController:objsubMenuViewController animated:YES];              
      
            }else{
                
                
                
                [self.navigationController pushViewController:objsubMenuViewController4 animated:YES];
                
            }
            
          
            
            
        }
        else
        {

            
             objproductViewController5.productName1=cell.menuItemsLabel.text;
            
             objproductViewController4.productName1=cell.menuItemsLabel.text;
            
            NSLog(@"%@",cell.menuItemsLabel.text);
          
            
            
            appDelegate.SubMenuId=self.MyUrlID1;
            
            NSLog(@"%@",self.MyUrlID1);
            NSLog(@"%@",appDelegate.SubMenuId);
            
            
          
                productViewController  *objproductViewController5=[[productViewController  alloc]initWithNibName:@"productViewController5"bundle:nil];

            
            
            CGRect screenBounds = [[UIScreen mainScreen] bounds];
            if (568 == screenBounds.size.height)
            {
                
                [self.navigationController pushViewController:objproductViewController5 animated:YES];
            
            }else{
               [self.navigationController pushViewController:objproductViewController4 animated:YES];
            }
            
            
            
            
        }
        
    }

    
}



-(void)tableView:(UITableView*)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath {
}




- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_scanHistoryTable release];
    [_TabView release];
    
    [Action_Indicator release];
    [_Active release];
    [_LogoImgView release];
    [_singOutView release];
    [_Active2 release];
    [super dealloc];
}
- (IBAction)BackButton:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
   // [self.view removeFromSuperview];
    
}
- (IBAction)singoutOkButtonMethod:(id)sender {
  
    [dbh deleteTime];
    [dbh deletealll];
    [dbh deleteallPrice];
  
      
    appDelegate.time=0;

    
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
        
    {
        
        ViewController  *objRLSampleViewController5=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController5 animated:YES];
               
        
    }else{
        
        
          ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
        
        
        
    }
   
    appDelegate.time=0;

    
   
}
- (IBAction)singOutCancelMethod:(id)sender {
    
    _singOutView.hidden=YES;
}

- (IBAction)SignOut:(id)sender {
 
    
    
    _singOutView.hidden=NO;
   }




- (IBAction)MyOrderMethod:(id)sender {
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
        
        MapViewController  *objmapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
        
        
        [self.navigationController pushViewController:objmapViewController4 animated:YES];
    }}

- (IBAction)MSG_Method:(id)sender {
    
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
}

- (IBAction)MainScreenMethod:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
        ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    

    
    
       
  
}

- (void)viewDidUnload {
    [self setLogoImgView:nil];
    [self setSingOutView:nil];
    [self setActive2:nil];
    [super viewDidUnload];
}
@end
