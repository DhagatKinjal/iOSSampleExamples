//
//  AppDelegate.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    int i;
    int Time;
    int Cancel;
    int OD_id;
    
//    NSString *userMessageCounter;
//    int postType;
//    int joinedStreamChecker;
//    int OwnerValue;
//    int  pushValue ;
//    int badgeValue;
    
    
    NSString *SubMenuId;
    NSString *ProductItemId;
    UIWindow *window;
    NSMutableArray *myAdonIds;
    ViewController *viewController;
    //NSMutableArray *NotificationMessage;
    //MainOrderViewController *objMainOrderViewController;
    
    UINavigationController *navigationController;
    NSString *dbPath;
    NSString *dbPath1;
    NSString *dbPath2;
    NSString *dbPath3;
    NSMutableArray *books;
    NSMutableArray *subbooks;
    NSMutableArray *subbooks1;
    NSMutableArray *probooks;
    
    NSArray *addonID,*addonName,*addonPrice;
    NSString *deviceToken;
    NSMutableArray *alertView;
    NSDictionary *alert;
    NSMutableString *ForAddonIds;
    NSMutableString *ForProduct;
    NSMutableString *dev;
    NSMutableArray *ProId;
    NSMutableArray *CategoryName,*CategoryId,*Themeid;
    
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;
@property (retain, nonatomic) NSMutableArray *CategoryName,*CategoryId,*Themeid;

@property (nonatomic, retain) NSDictionary *BarCode;
@property (nonatomic, retain) NSMutableArray *ProId;
@property (nonatomic, retain) NSMutableArray *myAdonIds;
@property (nonatomic, retain) NSString *MainOrderTotal;
@property (nonatomic, strong)NSMutableString *dev;
@property (nonatomic, strong) UITabBarController *tabBarController;
@property (nonatomic, retain) NSArray *addonID,*addonName,*addonPrice;
@property (nonatomic, retain) NSString *SubMenuId;
@property (nonatomic, retain) NSString *ProductItemId;
@property (nonatomic, retain) NSString *deviceToken;
@property (nonatomic, retain) NSMutableString *ForAddonIds;
@property (nonatomic, retain) NSMutableString *ForProduct;
-(void)checkDB;
@property (strong, nonatomic)NSString *dbpath;
@property (strong, nonatomic)NSString *dbpath1;
@property (strong, nonatomic)NSString *dbpath2;
@property (strong, nonatomic)NSString *dbpath3;
@property ( nonatomic)int time;
@property ( nonatomic)int Cancel,OD_id;

//@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ViewController *objviewController;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@property (nonatomic, retain) NSMutableArray *books;
@property(nonatomic,retain) NSMutableArray *subbooks;
@property(nonatomic,retain) NSMutableArray *subbooks1;
@property(nonatomic,retain) NSMutableArray *alertView;
@property(nonatomic,retain) NSMutableArray *probooks;
@property(nonatomic,retain) NSDictionary *alert;
@property(nonatomic,retain)NSMutableString *NotificationMessage,*timeNotification;

@property (nonatomic, retain) NSString *appLatString;
@property (nonatomic, retain) NSString *appLongString;

@property (nonatomic, retain) NSString *themeString;
@property (nonatomic, retain) NSString *logoString;
@end
