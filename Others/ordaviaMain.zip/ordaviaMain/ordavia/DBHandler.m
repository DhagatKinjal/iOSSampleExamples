//
//  DBHandler.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "DBHandler.h"

@implementation DBHandler
@synthesize field1,qtyPost,tempID;
int flag;
NSString *oid,*nid;
-(id)init{
    if(self==[super init])
    {
        appdel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        flag=1;
        dataPath=[[NSString alloc]initWithString:appdel.dbpath];
        dataPath1=[[NSString alloc]initWithString:appdel.dbpath1];
        dataPath2=[[NSString alloc]initWithString:appdel.dbpath2];
        dataPath3=[[NSString alloc]initWithString:appdel.dbpath3];
        tempID=[[NSMutableArray alloc] init];
        [tempID addObject:@"@@aID@@"];
        
        
    }
    return  self;
}


-(NSString *)selectCount
{
    NSMutableString *data=[[NSMutableString alloc]init];
    NSString *query=@"select sum(qty) from OrderList";
    //SELECT COUNT(*) FROM table_name
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableString *Row=[NSMutableString stringWithString:@""];
                
                int sum=sqlite3_column_int(stm, 0);
                if(sum>0)
                {
                    [Row appendString:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                    
                }
                
                //                Row=[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)];
                NSLog(@"The Count:  %@ ", Row);
                [data appendString:Row];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    
    return data;
    
}

-(BOOL)deleteOne:(NSString*)str
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from OrderList where order_id='%@'",str];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
//            UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Order Deleted" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//            
//            [alt show];
//            [alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}


-(BOOL)deletepush:(NSString*)str
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from PushMsgNew where order_number='%@'",str];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
//                       UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@" Deleted" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//            
//                        [alt show];
//                       [alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}



-(NSMutableArray *)SelectProItem
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    //NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select Product_Size_Id from OrderList";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                [data addObject:Row];
                [Row release];
                
                
                
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    
    return data;
}

-(NSMutableArray *)SelectAddItemID
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    //NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select Product_AddItem_Id from OrderList";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                [data addObject:Row];
                [Row release];
                
                
                
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    
    return data;
}

-(NSMutableArray *)SelectQty
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    //NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select qty from OrderList";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                [data addObject:Row];
                [Row release];
                
                
                
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    
    return data;
}


-(NSString *)SelectSUM
{
    
    //NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select sum(Price_of_product)as Total from OrderList";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                self.field1 =  sqlite3_column_int(stm, 0);
                NSLog(@"The sum is  %f ", self.field1);
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    NSString *str=[NSString stringWithFormat:@"%f",self.field1 ];
    return str;
}
-(BOOL)insert:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"insert into OrderList values('%@','%@','%@','%@','%@','%@','%@','%@',%lf,'%@')",[arr objectAtIndex:0],[arr objectAtIndex:1],[arr objectAtIndex:2],[arr objectAtIndex:3],[arr objectAtIndex:4],[arr objectAtIndex:5],[arr objectAtIndex:6],[arr objectAtIndex:7],[[arr objectAtIndex:8]floatValue],[arr objectAtIndex:9]];
    
    
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            /* UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Product Add In my Order" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
             
             [alt show];
             [alt release];*/
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}

-(void)deleteall
{
    // BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from OrderList"];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            //isok=YES;
//            UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"All Order Canceled" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//            
//            [alt show];
//            [alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    //return isok;
}
-(void)deletealll
{
    //BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from OrderList"];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            //isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    //return isok;
}



-(NSMutableArray*)selectinfo
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select * from OrderList";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 1)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 2)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 3)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 4)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 5)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 6)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 7)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 8)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 9)]];
                [data addObject:Row];
                [Row release];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    return data;
}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

//create table time(myOrderTime varchar(20),myOrderDate varchar(20));
-(BOOL)UpadateTable:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"UPDATE OrderList SET qty='%@',Price_of_product='%@' WHERE order_id='%@'",[arr objectAtIndex:0],[arr objectAtIndex:1],[arr objectAtIndex:2]];
    //NSString *query = [NSString stringWithFormat:@"UPDATE rf_detail SET rf_comment = '%@' WHERE rf_id='%@'",_txt_comment.text,_ref_id_str];
    
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            //UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Time/DAte Added" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            //[alt show];
            //[alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
    
    
}
-(bool)insertTimeDate:(NSArray *)arr{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"insert into TimeCheck values('%@')",[arr objectAtIndex:0]];
    
    
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            //UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Time/DAte Added" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            //[alt show];
            //[alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
    
}


-(NSMutableArray *)selecttime
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select * from TimeCheck";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                
                //[Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 8)]];
                [data addObject:Row];
                [Row release];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    return data;
    
}


-(void)deleteTime
{
    //BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from TimeCheck"];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            //isok=YES;
            //UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Your Order is Sent" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            //[alt show];
            //[alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
}


-(bool)insertPush:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"insert into PushMsg values('%@','%@','%@','%@','%@','%@','%@')",[arr objectAtIndex:0],[arr objectAtIndex:1],[arr objectAtIndex:2],[arr objectAtIndex:3],[arr objectAtIndex:4],[arr objectAtIndex:5],[arr objectAtIndex:6]];
    
    
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
       
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
     
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
    
}
-(bool)insertNewPush:(NSArray *)arr
{
    BOOL isok=NO;
    
    NSString *query ,*idSelect;
    query=[NSString stringWithFormat:@"insert into PushMsgNew values('%@','%@','%@','%@','%@','%@','%@')",[arr objectAtIndex:0],[arr objectAtIndex:1],[arr objectAtIndex:2],[arr objectAtIndex:3],[arr objectAtIndex:4],[arr objectAtIndex:5],[arr objectAtIndex:6]];
    
    idSelect=[NSString stringWithFormat:@"select * from PushMsgNew where order_number='%@' ",[arr objectAtIndex:6]];
    NSLog(@"%@",[arr objectAtIndex:6]);
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [idSelect UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            NSLog(@"%s",sqlite3_column_text(stm, 6));
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
               NSString *str=[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 6)];
                NSLog(@"%s",sqlite3_column_text(stm, 6));
                query=[NSString stringWithFormat:@"update PushMsgNew set msg_disc='%@' where order_number='%@'",[arr objectAtIndex:2],[arr objectAtIndex:6]];
//                if ([str isEqual:[arr objectAtIndex:6]]) {
//                    break;
//                }
             }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    NSLog(query);
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
            
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
    
}



-(NSMutableArray *)selectPush:(NSString*)str
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSLog(@"%@",str);
    NSString *query=[NSString stringWithFormat:@"select * from PushMsg where order_number='%@'",str];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 1)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 2)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 3)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 4)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 5)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 6)]];
                
                //[Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 8)]];
                [data addObject:Row];
                [Row release];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    return data;
    
}

-(NSMutableArray *)selectNewPush:(NSString *)str
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=[NSString stringWithFormat:@"select * from PushMsgNew where order_number='%@'",str];
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 1)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 2)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 3)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 4)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 5)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 6)]];
                
                
                
                //[Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 8)]];
                [data addObject:Row];
                [Row release];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    return data;
    
}
-(NSMutableArray *)selectNewPushAll
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    
    NSString *query=@"select * from PushMsgNew ";
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 1)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 2)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 3)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 4)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 5)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 6)]];
                NSLog(@"%s",sqlite3_column_text(stm, 6));
                
                //[Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 8)]];
                [data addObject:Row];
                [Row release];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    return data;
    
}

-(BOOL)UpadetePush:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"UPDATE notification SET MessageStatus='%@' WHERE PushId='%@'",[arr objectAtIndex:0],[arr objectAtIndex:1]];
    //NSString *query = [NSString stringWithFormat:@"UPDATE rf_detail SET rf_comment = '%@' WHERE rf_id='%@'",_txt_comment.text,_ref_id_str];
    
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath2 UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            //UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Time/DAte Added" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            //[alt show];
            //[alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
    
    
}
-(NSMutableArray *)selectPushCount:(NSString*)string{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    //NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=[NSString stringWithFormat:@"select count(*) from notification where MessageStatus='%@'",string];
    
    if(sqlite3_open([dataPath2 UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                [data addObject:Row];
                [Row release];
                
                
                
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    
    return data;
    
}


// create table OrderPriceList(order_id varchar(40),Price_of_product varchar(10));

-(BOOL)insertPrice:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"insert into OrderPriceList values('%@','%@')",[arr objectAtIndex:0],[arr objectAtIndex:1]];
    
    
    NSLog(@"%@",arr);
    if(sqlite3_open([dataPath3 UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            //UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Product Add In my Order" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            //[alt show];
            //[alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}

-(BOOL)deleteOnePrice:(NSString*)str
{
    BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from OrderPriceList where order_id='%@'",str];
    
    if(sqlite3_open([dataPath3 UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            //UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Order Deleted" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            //[alt show];
            //[alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}

-(NSMutableArray *)SelectPrice:(NSString *)str
{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    //NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=[NSString stringWithFormat:@"select Price_of_product from OrderPriceList where order_id='%@'",str];
    
    if(sqlite3_open([dataPath3 UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                
                [data addObject:Row];
                [Row release];
                
                
                
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    
    return data;
    
}




-(BOOL)deleteOnePush:(NSString*)str
{
    BOOL isok=NO;
    /////
    NSString *query=[NSString stringWithFormat:@"Delete from PushMsgNew where bar_id='%@'",str];
    /////
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
//         /   UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Push Message Deleted" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//            
//            [alt show];
//            [alt release];
//            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}
-(void)deleteallPrice
{
    //BOOL isok=NO;
    NSString *query=[NSString stringWithFormat:@"Delete from OrderPriceList"];
    
    if(sqlite3_open([dataPath3 UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            //isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    
}

@end
