//
//  MapViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "MapViewController.h"
#import "DisplayMap.h"
#import "VenuesViewController.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "infoViewController.h"
#import "MapViewController.h"
#import "PushMessagesViewController.h"

@interface MapViewController ()

@end

@implementation MapViewController

@synthesize mapView,infoButton,backButton;

@synthesize reports;
//@synthesize nxtDetailsVCtr;
@synthesize mapTableView;
@synthesize kmLabel,distance,km,pin;



VenuesViewController *objVenuesViewController;
ViewController *objRLSampleViewController;
infoViewController *objinfoViewController;
PushMessagesViewController *objPushMessagesViewController;
messageInboxViewController *objmessageInboxViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    
    return self;
}

- (void)viewDidLoad
{
    pinn=0;
    count=0;
    [super viewDidLoad];
    pinDrop=[[NSMutableArray alloc]init];
    
    
    
    distance=[[NSMutableArray alloc]init];
    
    mapView.showsUserLocation = YES;
    listOfItems=[[NSMutableArray alloc]init];
//    self.mapTableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BG_02.png"]];
    
    [mapView setMapType:MKMapTypeStandard];
	[mapView setZoomEnabled:YES];
	[mapView setScrollEnabled:YES];
    
    NSLog(@"%f",mapView.userLocation.coordinate.latitude);
    
    
    
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/VenueApi/GetVenue?bar_lat=52.813507&bar_long=-1.638649"];
    
    url = [[NSURL alloc] initWithString:myurl];
    
    NSLog(@"%@",myurl);
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata=[[NSMutableData alloc]init];
    //[mapTableView reloadData];
    [conn release];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    [xml_parser release];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"status" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
}



- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    cur_ele=nil;
    cur_txt=nil;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict;
{
    
    
    if([elementName isEqualToString:@"xml"])
    {
        dics=[[NSMutableDictionary alloc]init];
        data1=[[NSMutableArray alloc]init];
        data2=[[NSMutableArray alloc]init];
        data3=[[NSMutableArray alloc]init];
        data4=[[NSMutableArray alloc]init];
        data5=[[NSMutableArray alloc]init];
        data6=[[NSMutableArray alloc]init];
        data7=[[NSMutableArray alloc]init];
        arrdata=[[NSMutableArray alloc]init];
        
        output=[[NSMutableString alloc]init];
        proName=[[NSMutableArray alloc]init];
    }
    else if([elementName isEqualToString:@"bar"]) {
        
        
        
        [arrdata insertObject:name atIndex:i];
        i++;
        NSLog(@"ud: %@",name);
    }
    else if([elementName isEqualToString:@"bar_id"] || [elementName isEqualToString:@"bar_name"] || [elementName isEqualToString:@"bar_latitude"] || [elementName isEqualToString:@"bar_longitude"] || [elementName isEqualToString:@"distance"] )
    {
        cur_ele=elementName;
        cur_txt=[[NSMutableString alloc]init];
        
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [cur_txt appendString:string];
    
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
    if([elementName isEqualToString:@"bar_id"])
    {
        
        
        [dics setValue:cur_txt forKey:cur_ele];
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [data1 addObject:arr];
        [output appendString:cur_txt];
        
        
        
        
    }
    else if([elementName isEqualToString:@"bar_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [data2 addObject:arr];
        [output appendString:cur_txt];
    }
    else if([elementName isEqualToString:@"bar_latitude"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [data3 addObject:arr];
        [output appendString:cur_txt];
    }
    else if([elementName isEqualToString:@"bar_longitude"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [data4 addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"distance"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [data5 addObject:arr];
        NSLog(@"%@",data5);
        [output appendString:cur_txt];
    }
    
    else if ([elementName isEqualToString:@"xml"])
    {
        
    }
    [cur_txt release];
    cur_txt=nil;
}

// sent when the parser begins parsing of the document.
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    /*UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:output delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
     [alt show];
     [alt release];*/
    
    // [mapTableView reloadData];
    //[_tblxmldata reloadData];
    self.mapView.delegate=self;
    MKUserLocation *user;
    [self mapView:mapView didUpdateUserLocation:user];
    [mapTableView reloadData];
    [self MyMapAnnoatation];
    
    ////mapview code///
    
    
}




-(IBAction)backButtonMethod:(id)sender{
   
    [self.navigationController popViewControllerAnimated:YES];

   }
-(IBAction)infoButtonMethod:(id)sender{
    
      
    objinfoViewController=[[infoViewController  alloc]initWithNibName:@"infoViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objinfoViewController animated:YES];
    

    
    
}

- (IBAction)msgMethod:(id)sender {
    
    
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    

    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 37;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [data2 count];
}
- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section {
    
    
    return 1;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    
    MapViewCustomCell *cell = (MapViewCustomCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    
    
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MapViewCustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    
    //cell.accessoryType =  UITableViewCellAccessoryDisclosureIndicator;
    
    NSArray *arr=[data2 objectAtIndex:indexPath.section];
    cell.BarNameLabel.text = [arr objectAtIndex:indexPath.row];
    NSString *KMLBL=[NSString stringWithFormat:@"%@ KM",[data5 objectAtIndex:indexPath.section]];
    NSCharacterSet *doNotWant3 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    KMLBL = [[KMLBL componentsSeparatedByCharactersInSet: doNotWant3] componentsJoinedByString: @""];
    NSLog(@"%@",KMLBL);
    
    NSString *Main4 = [KMLBL substringWithRange:NSMakeRange(4, [KMLBL length]-4)];
    NSLog(@"%@ ",Main4);
    NSLog(@"%@",data5);
    
    
    NSLog(@"%@-->%@",data5,data2);
    cell.DistanceInKmLabel.text=Main4;
    
    
  
    
    self.mapTableView.opaque = NO;
    self.mapTableView.backgroundView = nil;
    
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
   
    
    
    if ( ( [data1 count] > 0 ) && ( [indexPath length] > 0 ) )
    {
        
        objVenuesViewController=[[VenuesViewController  alloc]initWithNibName:@"VenuesViewController"bundle:nil];
        VenuesViewController *objVenuesViewController4=[[VenuesViewController  alloc]initWithNibName:@"VenuesViewController4"bundle:nil];
        
        NSLog(@"%@",[data1 objectAtIndex:indexPath.section]);
        objVenuesViewController.myID=[data1 objectAtIndex:indexPath.section];
         objVenuesViewController4.myID=[data1 objectAtIndex:indexPath.section];
        
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
        
        
        
        
        [self.navigationController pushViewController:objVenuesViewController animated:YES];
      
        }
        else{
           
            
            
            [self.navigationController pushViewController:objVenuesViewController4 animated:YES];
            
        }
    }
    
    
    
}


- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    int degrees = newLocation.coordinate.latitude;
    double decimal = fabs(newLocation.coordinate.latitude - degrees);
    int minutes = decimal * 60;
    double seconds = decimal * 3600 - minutes * 60;
    NSString *lat = [NSString stringWithFormat:@"%d° %d' %1.4f\"",
                     degrees, minutes, seconds];
    latLabel.text = lat;
    degrees = newLocation.coordinate.longitude;
    decimal = fabs(newLocation.coordinate.longitude - degrees);
    minutes = decimal * 60;
    seconds = decimal * 3600 - minutes * 60;
    NSString *longt = [NSString stringWithFormat:@"%d° %d' %1.4f\"",
                       degrees, minutes, seconds];
    longLabel.text = longt;
}


- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    //sleep(10);
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];
    [locationManager stopUpdatingLocation];
    CLLocation *location = [locationManager location];
    // Configure the new event with information from the location
    
    ulongitude=location.coordinate.longitude;
    ulatitude=location.coordinate.latitude;
    
    
    NSLog(@"dLongitude : %f", ulongitude);
    NSLog(@"dLatitude : %f", ulatitude);
    
}


-(void)MyMapAnnoatation
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
    [locationManager startUpdatingLocation];
    
    
       self.reports=[NSArray arrayWithObjects:data2,nil ];//d2,d3,d4,nil];
    
	// code to add pins on map
	for(int h=0;h<[data5 count];h++)
    {
        NSString *latitudestr=[NSString stringWithFormat:@"%@",[data3 objectAtIndex:h]];
        NSCharacterSet *doNotWant3 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        latitudestr = [[latitudestr componentsSeparatedByCharactersInSet: doNotWant3] componentsJoinedByString: @""];
        NSLog(@"%@",latitudestr);
        
        myLat = [latitudestr substringWithRange:NSMakeRange(4, [latitudestr length]-4)];
        NSLog(@"%@",myLat);
        
        NSString *landitudestr=[NSString stringWithFormat:@"%@",[data4 objectAtIndex:h]];
        NSCharacterSet *doNotWant4 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        landitudestr = [[landitudestr componentsSeparatedByCharactersInSet: doNotWant4] componentsJoinedByString: @""];
        NSLog(@"%@",landitudestr);
        
        myLan = [landitudestr substringWithRange:NSMakeRange(4, [landitudestr length]-4)];
        NSLog(@"%@",myLan);
        
        
        float latitude=[myLat floatValue];
		float longitude=[myLan floatValue];
        
        NSLog(@"%f",latitude);
        Place* home = [[[Place alloc] init] autorelease];
        
        NSString *namastr=[NSString stringWithFormat:@"%@",[data2 objectAtIndex:h]];
        NSCharacterSet *doNotWant5 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        namastr = [[namastr componentsSeparatedByCharactersInSet: doNotWant5] componentsJoinedByString: @""];
        NSLog(@"%@",namastr);
        
        NSString *barname = [namastr substringWithRange:NSMakeRange(4, [namastr length]-4)];
        NSLog(@"%@",barname);
        
		home.name = [NSString stringWithFormat:@"%@",barname];
        
		home.latitude = latitude;
		home.longitude = longitude;
        PlaceMark *from = [[[PlaceMark alloc] initWithPlace:home] autorelease];
		[mapView addAnnotation:from];
        
        
        NSLog(@"%f",mapView.userLocation.coordinate.latitude);
        NSLog(@"%f",mapView.userLocation.coordinate.longitude);
        
        
    }
        
    
	NSLog(@"%@",distance);
	[self centerMap];
    
}



-(void) centerMap

{
	MKCoordinateRegion region;
	CLLocationDegrees maxLat = -90;
	CLLocationDegrees maxLon = -90;
	CLLocationDegrees minLat = 120;
	CLLocationDegrees minLon = 120;
	NSMutableArray *temp=[NSArray arrayWithArray:self.reports];
	NSLog(@"%@",temp);
    int ii;
	for (ii=0; ii<[data3 count];ii++) {
        
        
        NSString *latitudestr=[NSString stringWithFormat:@"%@",[data3 objectAtIndex:ii]];
        NSCharacterSet *doNotWant3 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        latitudestr = [[latitudestr componentsSeparatedByCharactersInSet: doNotWant3] componentsJoinedByString: @""];
        NSLog(@"%@",latitudestr);
        
        NSString *myLat1 = [latitudestr substringWithRange:NSMakeRange(4, [latitudestr length]-4)];
        NSLog(@"%@",myLat1);
        
        NSString *landitudestr=[NSString stringWithFormat:@"%@",[data4 objectAtIndex:ii]];
        NSCharacterSet *doNotWant4 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
        landitudestr = [[landitudestr componentsSeparatedByCharactersInSet: doNotWant4] componentsJoinedByString: @""];
        NSLog(@"%@",landitudestr);
        
        NSString *myLan1 = [landitudestr substringWithRange:NSMakeRange(4, [landitudestr length]-4)];
        NSLog(@"%@",myLan1);
        
        
        
        
		Place* home = [[[Place alloc] init] autorelease];
        //		home.latitude = [[[temp objectAtIndex:ii] valueForKey:@"latitude"]floatValue];
        //
        //		home.longitude =[[[temp objectAtIndex:ii] valueForKey:@"longitude"]floatValue];
		home.latitude = [myLat1 floatValue];
        
		home.longitude =[myLan1 floatValue];
		
        PlaceMark* from = [[[PlaceMark alloc] initWithPlace:home] autorelease];
		
		CLLocation* currentLocation = (CLLocation*)from ;
		if(currentLocation.coordinate.latitude > maxLat)
			maxLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.latitude < minLat)
			minLat = currentLocation.coordinate.latitude;
		if(currentLocation.coordinate.longitude > maxLon)
			maxLon = currentLocation.coordinate.longitude;
		if(currentLocation.coordinate.longitude < minLon)
			minLon = currentLocation.coordinate.longitude;
		
		region.center.latitude     = (maxLat + minLat) / 2;
		region.center.longitude    = (maxLon + minLon) / 2;
		region.span.latitudeDelta  =  maxLat - minLat;
		region.span.longitudeDelta = maxLon - minLon;
	}
	[mapView setRegion:region animated:YES];
	
}

- (MKAnnotationView *)mapView:(MKMapView *)map viewForAnnotation:(id <MKAnnotation>)annotation
{
	NSLog(@"Controll comes here");
	
	if (annotation == mapView.userLocation)
		return nil;
	
	pin = (MKPinAnnotationView *) [mapView dequeueReusableAnnotationViewWithIdentifier: @"asdf"];
	
	if (pin == nil)
		pin = [[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier: @"asdf"] autorelease];
	else
		pin.annotation = annotation;
	pin.userInteractionEnabled = YES;
	UIButton *disclosureButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
	[disclosureButton setFrame:CGRectMake(0, 0, 30, 30)];
	pin.tag=pinn;
    [pinDrop addObject:[NSString stringWithFormat:@"%d",pin.tag]];
    //[pinDrop addObject:pin];
    
    NSLog(@"%d",pin.tag);
    
    
	pin.rightCalloutAccessoryView = disclosureButton;
	//pin.pinColor = MKPinAnnotationColorGreen;
    
    pin.image = [UIImage imageNamed:@"push_pin.png"];
	pin.animatesDrop = YES;
	[pin setEnabled:YES];
	[pin setCanShowCallout:YES];
    pinn++;
	return pin;

 
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
    
	NSString *strTitle = [NSString stringWithFormat:@"%@",[view.annotation title]];
    strTitle = [[strTitle componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    
    NSLog(@"%@",strTitle);
    
	
	
	for (int ii = 0; ii<[data2 count]; ii++)
	{
        NSLog(@"%d",[data2 count]);
		NSLog(@"%@",[data2 objectAtIndex:ii]);
        
		NSString *strAddress = [NSString stringWithFormat:@"%@",[data2 objectAtIndex:ii]];
        
        strAddress = [[strAddress componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        NSLog(@"%@",strAddress);
        NSLog(@"%@",strTitle);
        
		if([strAddress isEqualToString:strTitle])
        {
            objVenuesViewController=[[VenuesViewController  alloc]initWithNibName:@"VenuesViewController"bundle:nil];
            
        VenuesViewController *objVenuesViewController4=[[VenuesViewController  alloc]initWithNibName:@"VenuesViewController4"bundle:nil];
            
            NSLog(@"%@",[data1 objectAtIndex:ii]);
            
            objVenuesViewController.myID=[data1 objectAtIndex:ii];
             objVenuesViewController4.myID=[data1 objectAtIndex:ii];
            
            
            
            CGRect screenBounds = [[UIScreen mainScreen] bounds];
            if (568 == screenBounds.size.height)
                
            {

                      
             [self.navigationController pushViewController:objVenuesViewController animated:YES];
            }
            else{
                 [self.navigationController pushViewController:objVenuesViewController4 animated:YES];
            }
		}
		
		
	}
}


-(void)dealloc{
    [objVenuesViewController release];
    [objRLSampleViewController release];
    [backButton release];
    [infoButton release];
    [objinfoViewController release];
   // [nxtDetailsVCtr release];
    [reports release];
    [mapTableView release];
    [mapView release];
    [listOfItems release];
    [locationManager release];
    [latLabel release];
    [longLabel release];
    [kmLabel release];
    [backButton release];
    [infoButton release];
    
    
    [super dealloc];
}

- (IBAction)homeSrcreenMethod:(id)sender {
      
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
       ViewController *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
    
    
    
    
    

}
@end
