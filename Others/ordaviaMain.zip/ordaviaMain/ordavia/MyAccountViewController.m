//
//  MyAccountViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "MyAccountViewController.h"
#import "ViewController.h"
#import "PushMessagesViewController.h"
#import "MapViewController.h"
#import "messageInboxViewController.h"
@interface MyAccountViewController ()

@end

@implementation MyAccountViewController
 ViewController *objRLSampleViewController;
PushMessagesViewController *objPushMessagesViewController;
MapViewController *objMapViewController;
messageInboxViewController *objmessageInboxViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    _newEditView.hidden=YES;
     
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
    [_mainScroll setFrame:CGRectMake(0,85,320,420)];
        
    }else{
     [_mainScroll setFrame:CGRectMake(0,97,320,412)];
    }
    
    
    
        NSLog(@"%@",appDelegate.deviceToken);
    
    NSString *MYDeviceToken=[NSString stringWithFormat:@"%@",appDelegate.deviceToken];
    
    NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
    MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
    NSLog(@"%@",MYDeviceToken);
    
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CustomerApi/customerDetail?customer_device_token=%@",MYDeviceToken];
    NSLog(@"%@",myurl);
    url = [[NSURL alloc] initWithString:myurl];
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata=[[NSMutableData alloc]init];
    //[scanHistoryTable reloadData];
    [conn release];
    
    
    // Do any additional setup after loading the view from its nib.
}






-(void)keyboardWillShow:(NSNotification*)notification {
    
        
    NSDictionary* keyboardInfo = [notification userInfo];
    NSValue* keyboardFrameBegin = [keyboardInfo valueForKey:UIKeyboardFrameBeginUserInfoKey];
    CGRect keyboardFrameBeginRect = [keyboardFrameBegin CGRectValue];
    
    NSLog(@"%@", NSStringFromCGRect(keyboardFrameBeginRect));
}



- (void)viewWillAppear:(BOOL)animated {
    
    
    
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text isEqualToString:@"\n"]) {
      //  self.view.frame = CGRectMake(0,0,320,500);
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
        
        [_mainScroll setFrame:CGRectMake(0,75,320,412)];
        
        }else{
             [_mainScroll setFrame:CGRectMake(0,97,320,412)];
        }
        
        
        
        
        [_addresstextView resignFirstResponder];
        [_emailTextView resignFirstResponder];
        
        
        return NO;
    }
    
    return YES;
}




- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    currentElementValue=nil;
    CurrentText=nil;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict {
	
	if([elementName isEqualToString:@"xml"]) {
		//Initialize the array.
        fNameMutableArray=[[NSMutableArray alloc]init];
        lNameMutableArray=[[NSMutableArray alloc]init];
        addressMutableArray=[[NSMutableArray alloc]init];
        emailMutableArray=[[NSMutableArray alloc]init];
        
        output=[[NSMutableString alloc]init];
        
		//appDelegate.books = [[NSMutableArray alloc] init];
	}
	else if([elementName isEqualToString:@"first_name"]||[elementName isEqualToString:@""]) {
		
		//Initialize the book.
		//aBook = [[Book alloc] init];
		
		//Extract the attribute here.
		//aBook.bookID = [[attributeDict objectForKey:@"id"] integerValue];
        //aBook.name=[attributeDict objectForKey:@"name"];
		currentElementValue=elementName;
        CurrentText=[[NSMutableString alloc]init];
		//NSLog(@"Reading id value :%i", aBook.bookID);
	}
	
	NSLog(@"Processing Element: %@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	
	if(!CurrentText)
		CurrentText = [[NSMutableString alloc] initWithString:string];
	else
		[CurrentText appendString:string];
	
	NSLog(@"Processing Value: %@", CurrentText);
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	if([elementName isEqualToString:@"xml"])
    {
        
    }
	
	if([elementName isEqualToString:@"first_name"]) {
        
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [fNameMutableArray addObject:arr];
        [output appendString:CurrentText];
        _nameTextField.text=output;
		
	}
    
    else if([elementName isEqualToString:@"address"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [addressMutableArray addObject:arr];
        [output appendString:CurrentText];
        
		
    }
    
    else if([elementName isEqualToString:@"customer_username"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [emailMutableArray addObject:arr];
        [output appendString:CurrentText];
        
		
    }
    else if([elementName isEqualToString:@"last_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [lNameMutableArray addObject:arr];
        [output appendString:CurrentText];
        
		
    }
	[CurrentText release];
	CurrentText=nil;
    
    }
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"%@",fNameMutableArray);
    
    
    
    
    
    if([output isEqualToString:@""]){
      
             
        UIButton *theButton = [[UIButton buttonWithType:UIButtonTypeRoundedRect]retain];
        
        
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
            theButton.frame = CGRectMake(100,347,110, 30);
            
        }else{
         theButton.frame = CGRectMake(112,285,100, 40);
        }
        
        
        
        //[theButton setTitle:@"SUBMIT" forState:UIControlStateNormal];
        
        [theButton addTarget:self action:@selector(submitButtonMethod:) forControlEvents:UIControlEventTouchUpInside];
        [theButton setBackgroundImage:[UIImage imageNamed:@"SUBMIT.png"] forState:UIControlStateNormal];
       
        
       [_mainScroll addSubview:theButton];
        
        
        
    
    }
else{
    
    
    
        
    NSString *strname=[fNameMutableArray objectAtIndex:0];
    
  
    
    
    
    NSLog(@"%@",strname);
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"   ()\"\n"];
    NSString *str1=[NSString stringWithFormat:@"%@",strname];
    
    str1 = [[str1 componentsSeparatedByCharactersInSet:doNotWant1] componentsJoinedByString: @" "];
    NSLog(@"%@",str1);
        
    
    NSString *strlastname=[lNameMutableArray objectAtIndex:0];
    NSLog(@"%@",strlastname);
    NSCharacterSet *doNotWant2 = [NSCharacterSet characterSetWithCharactersInString:@"  ()\"\n"];
    NSString *str2=[NSString stringWithFormat:@"%@",strlastname];
    
    str2 = [[str2 componentsSeparatedByCharactersInSet:doNotWant2] componentsJoinedByString: @" "];
    NSLog(@"%@",str2);
    
    
    NSString *straddress=[addressMutableArray objectAtIndex:0];
    NSCharacterSet *doNotWant3 = [NSCharacterSet characterSetWithCharactersInString:@"  ()\"\n"];
    NSString *str3=[NSString stringWithFormat:@"%@",straddress];
    
    str3 = [[str3 componentsSeparatedByCharactersInSet: doNotWant3] componentsJoinedByString: @" "];
    
    
    
    
     str1 = [str1 substringWithRange:NSMakeRange(2, [str1 length]-2)];
    NSString *stremail=[emailMutableArray objectAtIndex:0];
    NSCharacterSet *doNotWant4 = [NSCharacterSet characterSetWithCharactersInString:@" ()\"\n"];
    NSString *str4=[NSString stringWithFormat:@"%@",stremail];
    
    str4 = [[str4 componentsSeparatedByCharactersInSet: doNotWant4] componentsJoinedByString: @""];
    
    str4 = [str4 substringWithRange:NSMakeRange(2, [str4 length]-2)];
    str2 = [str2 substringWithRange:NSMakeRange(13, [str2 length]-13)];
    str3 = [str3 substringWithRange:NSMakeRange(13, [str3 length]-13)];
    
    
     
    
        NSLog(@"%@",str1);
        NSLog(@"%@",str2);
        NSLog(@"%@",str3);
        NSLog(@"%@",str4);
    
    
    NSCharacterSet *doNotWantM = [NSCharacterSet characterSetWithCharactersInString:@" ()\"\n"];
    NSString *strM=[NSString stringWithFormat:@"%@",str1];
    
    strM = [[strM componentsSeparatedByCharactersInSet:doNotWantM] componentsJoinedByString: @""];
    NSLog(@"%@",strM);
    
    _nameTextField.text=strM;
    
    NSCharacterSet *doNotWantM2 = [NSCharacterSet characterSetWithCharactersInString:@" ()\"\n"];
    NSString *strM2=[NSString stringWithFormat:@"%@",str2];
    
    strM2 = [[strM2 componentsSeparatedByCharactersInSet:doNotWantM2] componentsJoinedByString: @""];
    NSLog(@"%@",strM2);
    
    
    
    
    NSCharacterSet *doNotWantM3 = [NSCharacterSet characterSetWithCharactersInString:@" ()\"\n"];
    NSString *strM3=[NSString stringWithFormat:@"%@",str3];
    
    strM3 = [[strM3 componentsSeparatedByCharactersInSet:doNotWantM3] componentsJoinedByString: @""];
    NSLog(@"%@",strM3);
    
    
    
    NSCharacterSet *doNotWantM4 = [NSCharacterSet characterSetWithCharactersInString:@" ()\"\n"];
    NSString *strM4=[NSString stringWithFormat:@"%@",str4];
    
    strM4 = [[strM4 componentsSeparatedByCharactersInSet:doNotWantM4] componentsJoinedByString: @""];
    NSLog(@"%@",strM4);
    
    
    
    
    
    
    
    
    _lastNameTextField.text=strM2;
    
    _lastTextView.text=strM2;
    _addresstextView.text=strM3;
    _emailTextView.text=strM4;
    
   
    }
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)backButtonMethod:(id)sender {
    
[self.navigationController popViewControllerAnimated:YES];
    
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
   
    //[UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationDuration:0.25];
  //  self.view.frame = CGRectMake(0,-160,320,500);
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
    
    _mainScroll.frame=CGRectMake(0,-60,320,412);
    
    }else
    
    {
        _mainScroll.frame=CGRectMake(0,-80, 320,412);
    }
  
    
    //[UIView commitAnimations];
        
}

- (BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    
    
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    return !([newString length] > 10);
         
}




- (BOOL) textFieldShouldReturn:(UITextField *)theTextField
{
    NSLog(@"textFieldShouldReturn Fired :)");
    [_nameTextField resignFirstResponder];
        
    [_lastNameTextField resignFirstResponder];
  
    [_lastTextView resignFirstResponder];
    
        return YES;
}


- (void)dealloc {
  
    
    [objRLSampleViewController release];
    [objPushMessagesViewController release];
    [objMapViewController release];
    [_emailTextView release];
    [_nameTextField release];
    [_lastNameTextField release];
    [_emailidTextField release];
    [_addressTextfield release];
    [_addresstextView release];
    
    [_submit release];
    [_mainScroll release];
    [_editView release];
    [_editView release];
    [_newEditView release];
    [_youraccountLabel release];
    [_lastTextView release];
    [super dealloc];
}
- (IBAction)submitButtonMethod:(id)sender {
    
    nameString=_nameTextField.text;
    lastNameString=_lastNameTextField.text;
    emailidString=_emailTextView.text;
    addressString=_addresstextView.text;
    
    NSLog(@"%@",nameString);
    NSLog(@"%@",lastNameString);
    NSLog(@"%@",emailidString);
    NSLog(@"%@",addressString);
    
    
    
     NSLog(@"%@",appDelegate.deviceToken);
    
    NSString *MYDeviceToken=[NSString stringWithFormat:@"%@",appDelegate.deviceToken];
    
    NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
    MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
    NSLog(@"%@",MYDeviceToken);
    
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CustomerApi/insertCustomer?fname=%@&lname=%@&customer_user_name=%@&address=%@&customer_device_token=%@&device_os_type=2",nameString,lastNameString,emailidString,addressString,MYDeviceToken];
    
    
    NSLog(@"%@",myurl);
    
    url = [[NSURL alloc] initWithString:myurl];
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata1=[[NSMutableData alloc]init];
    //[scanHistoryTable reloadData];
    [conn release];
    
    
}

- (IBAction)msgScreenMethod:(id)sender {
    
    
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
    
}

- (IBAction)venuesScreenMethod:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
    MapViewController *objMapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objMapViewController4 animated:YES];
    }
}

- (IBAction)homScreenMethod:(id)sender {
        
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
     ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
    
    
    
    

}

- (IBAction)updateMethod:(id)sender {
   
    
    [_addresstextView resignFirstResponder];
    [_emailTextView resignFirstResponder];
    [_nameTextField resignFirstResponder];
    [_lastNameTextField resignFirstResponder];
    [_lastTextView resignFirstResponder];
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    
    if ([emailTest evaluateWithObject:_emailTextView.text] == NO) {
        
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Please Enter Valid Email Address." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//        [alert show];
//        [alert release];
        
        
        
        
        //return;
        _newEditView.hidden=NO;
        _youraccountLabel.hidden=YES;
        
    }else{
    
   nameString= _nameTextField.text;
   lastNameString=_lastTextView.text;
    addressString=_addresstextView.text;
    emailidString=_emailTextView.text;
    
    
  //  NSString *strlastname=[lNameMutableArray objectAtIndex:0];
    NSLog(@"%@",nameString);
    NSCharacterSet *doNotWant2 = [NSCharacterSet characterSetWithCharactersInString:@"  ()\"\n"];
    NSString *str2=[NSString stringWithFormat:@"%@",nameString];    
    str2 = [[str2 componentsSeparatedByCharactersInSet:doNotWant2] componentsJoinedByString: @" "];
    NSLog(@"%@",str2);
    
    
    NSLog(@"%@",nameString);
    NSLog(@"%@",lastNameString);
    NSLog(@"%@",addressString);
    NSLog(@"%@",emailidString);
    NSLog(@"%@",appDelegate.deviceToken);
    
    NSString *MYDeviceToken=[NSString stringWithFormat:@"%@",appDelegate.deviceToken];
    
    NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
    MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
    NSLog(@"%@",MYDeviceToken);
    
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CustomerApi/updateCustomer?fname=%@&lname=%@&customer_user_name=%@&address=%@&customer_device_token=%@&device_os_type=2",nameString,lastNameString,emailidString,addressString,MYDeviceToken];
    
    
    NSLog(@"%@",myurl);
    
    url = [[NSURL alloc] initWithString:myurl];
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata1=[[NSMutableData alloc]init];
    
    
    [conn release];
   
    }
    
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata1 appendData:data];
    
    NSLog(@"%@",xmldata1);
    
    [xmldata appendData:data];
    
    NSLog(@"%@",xmldata);
    
    str = [[NSString alloc] initWithData:xmldata1 encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    
    [xml_parser parse];
    [xml_parser release];
  //  _newEditView.hidden= NO;

    if([str isEqualToString:@"Successfull"])
    {
        
        [_addresstextView resignFirstResponder];
        [_emailTextView resignFirstResponder];
        [_nameTextField resignFirstResponder];
        [_lastNameTextField resignFirstResponder];
        [_lastTextView resignFirstResponder];
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
            
            [_mainScroll setFrame:CGRectMake(0,85,320,412)];
            
        }else{
            [_mainScroll setFrame:CGRectMake(0,97,320,412)];
        }
        
        
        
        
        
        _newEditView.hidden= NO;
        

        
    }
    //[self viewDidLoad];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
     
    
//    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Your Account Not-Update" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//    [alt show];
//    [alt release];
    
    [_addresstextView resignFirstResponder];
    [_emailTextView resignFirstResponder];
    [_nameTextField resignFirstResponder];
    [_lastNameTextField resignFirstResponder];
    
     [self viewDidLoad];
}


- (void)viewDidUnload {
    [self setNameTextField:nil];
    [self setLastNameTextField:nil];
    [self setEmailidTextField:nil];
    [self setAddressTextfield:nil];
    [self setAddresstextView:nil];
  //  [self set_emailTextView:nil];
    [self setSubmit:nil];
    [self setMainScroll:nil];
    [self setEditView:nil];
    [self setEditView:nil];
    [self setNewEditView:nil];
    [self setYouraccountLabel:nil];
    [self setLastTextView:nil];
    [super viewDidUnload];
}

- (IBAction)editYesMethod:(id)sender {
    
    _nameTextField.text=@"";
    _lastNameTextField.text=@"";
    
    _lastTextView.text=@"";
    _emailTextView.text=@"";
    _addresstextView.text=@"";
    
    _newEditView.hidden=YES;

}

- (IBAction)editButtonMethod:(id)sender {
    _newEditView.hidden=YES;
    [self viewDidLoad];
   
}

- (IBAction)editNoMethhod:(id)sender {
      _newEditView.hidden=YES;
    }
@end
