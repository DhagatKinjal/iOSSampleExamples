
//  subMenuViewController.m
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//
#import "subMenuViewController.h"
#import "subBook.h"
#import "AppDelegate.h"
#import "productViewController.h"
#import "ViewController.h"
#import "MapViewController.h"

//#import "OverlayController.h"
#import "subMenuCustomCell.h"
#import "MainOrderViewController.h"
#import "PushMessagesViewController.h"
#import "MyFirstMenuViewController.h"
#import "subMenuViewController.h"
#import "messageInboxViewController.h"

@interface subMenuViewController ()

@end

@implementation subMenuViewController
@synthesize tableview,lblText;
@synthesize selectedCountry,subMenuLabelString,MenuName;
@synthesize MyUrlID;
@synthesize venuesButton ;
@synthesize  checkInButton,mainSrceenButton,bgImageView,headerImageView;
PushMessagesViewController *objPushMessagesViewController;
MainOrderViewController *objMainOrderViewController;
productViewController *objproductViewController;
MapViewController *objMapViewController;
ViewController *objRLSampleViewController;

AppDelegate *objRLSampleAppDelegate;
messageInboxViewController *objmessageInboxViewController;
MyFirstMenuViewController *objMyFirstMenuViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        objRLSampleAppDelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
                
    }
    return self;
}


///111111subcat



- (void)viewDidLoad {
    [super viewDidLoad];
    [_Action_indicator startAnimating];
    
    
    NSLog(@"%@",objRLSampleAppDelegate.logoString);
    
    UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(94,20,130,35)];
    
    NSString *string=[NSString stringWithFormat:@"http://%@",objRLSampleAppDelegate.logoString];
    
   
    
   UIImage *img=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:string]]];
    
    [imgview setImage:img];
    
    [self.view addSubview:imgview];
    
    
    NSLog(@"%@",self.MenuName);
    
    _SubMenuTitle.text=MenuName;
    //NSString *MyUrlID1=[[NSString alloc]init];
    NSLog(@"%@",self.MyUrlID);
    
    NSString *MyUrlID1=[NSString stringWithFormat:@"%@",self.MyUrlID];
    NSLog(@"%@",MyUrlID1);
    
    
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n  "];
    MyUrlID1 = [[MyUrlID1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    
    
    NSLog(@"%@",MyUrlID1);
    //http://10.1.1.17/ordavia/index.php/CategoryApi/GetSubCategory?cat_id=1
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/CategoryApi/GetSubCategory?cat_id=%@",MyUrlID1];
    NSLog(@"%@",myurl);
    url = [[NSURL alloc] initWithString:myurl];
    
    
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata=[[NSMutableData alloc]init];
    //[scanHistoryTable reloadData];
    [conn release];
    
    
    
    lblText.text = subMenuLabelString;
   	
	subappDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	
    NSLog(@"%@",objRLSampleAppDelegate.themeString);
    
    if ([objRLSampleAppDelegate.themeString isEqualToString:@"1"])
    {
        
        [bgImageView setImage:[UIImage imageNamed:@"001-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"001-header.png"]];
    }
    
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"2"])
    {
        
        
        [bgImageView setImage:[UIImage imageNamed:@"002-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"002-header.png"]];
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"3"])
    {
        
        [bgImageView setImage:[UIImage imageNamed:@"003-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"003-header.png"]];
        
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"4"])
    {
        
        
        [bgImageView setImage:[UIImage imageNamed:@"004-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"004-header.png"]];
        
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"5"])
    {
        
        
        [bgImageView setImage:[UIImage imageNamed:@"005-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"005-header.png"]];
        
    }
    
    
    else{
        [bgImageView setImage:[UIImage imageNamed:@"BG.png"]];
        
        
    }        NSLog(@"%@",objRLSampleAppDelegate.themeString);
    
    
    
	
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [CurrentName count];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static  NSString *cellIdentifier=@"subMenuCustomCell";
    
    subMenuCustomCell *cell = (subMenuCustomCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    
    if(cell == nil)
    {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"subMenuCustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    
    NSArray *arr=[CurrentName objectAtIndex:indexPath.section];
    cell.subMenuItemsLabel.text=[arr objectAtIndex:indexPath.row];
    //cell.selectionStyle=UITableViewCellSelectionStyleGray;
    return cell;
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 42;
    ;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    subMenuCustomCell *cell = (subMenuCustomCell *)[tableView cellForRowAtIndexPath:indexPath];
    if ( ( [CurrentName count] > 0 ) && ( [indexPath length] > 0 ) )
    {
        [_Action_indicator startAnimating];
        
        
        
        productViewController *objproductViewController=[[productViewController  alloc]initWithNibName:@"productViewController5"bundle:nil];
        
        
        
        productViewController *objproductViewController4=[[productViewController  alloc]initWithNibName:@"productViewController4"bundle:nil];
        
        
                NSLog(@"%@",[CurrentProductId objectAtIndex:indexPath.section]);
        
        objproductViewController.MyUrlId=[CurrentProductId objectAtIndex:indexPath.section];
        
         objproductViewController4.MyUrlId=[CurrentProductId objectAtIndex:indexPath.section];
        
      
        
        objproductViewController.productName1=cell.subMenuItemsLabel.text;
        
     objproductViewController4.productName1=cell.subMenuItemsLabel.text;
        
        NSLog(@"%@-->",objproductViewController.productName1);
        
        
        
        
        CGRect screenBounds = [[UIScreen mainScreen] bounds];
        if (568 == screenBounds.size.height)
        {
        
        
        [self.navigationController pushViewController:objproductViewController animated:YES];
        }else{
            
            
              [self.navigationController pushViewController:objproductViewController4 animated:YES];
        }
        
        
        
        
    }else{
        
        
        
        
    }
    
    
	
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    [xml_parser release];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
}



- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    currentElementValue=nil;
    CurrentText=nil;
}


- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict {
	
	if([elementName isEqualToString:@"xml"]) {
		//Initialize the array.
        CurrentParentId=[[NSMutableArray alloc]init];
        CurrentName=[[NSMutableArray alloc]init];
        CurrentProductId=[[NSMutableArray alloc]init];
        ProductId=[[NSMutableArray alloc]init];
        ProductName=[[NSMutableArray alloc]init];
        output=[[NSMutableString alloc]init];
        
		
	}
	else if([elementName isEqualToString:@"parent_cat_id"] || [elementName isEqualToString:@"cat_id"]||[elementName isEqualToString:@"cat_name"] || [elementName isEqualToString:@"product_id"] || [elementName isEqualToString:@"product_name"])
    {
		
		//Initialize the book.
		//aBook = [[Book alloc] init];
		
		//Extract the attribute here.
		//aBook.bookID = [[attributeDict objectForKey:@"id"] integerValue];
        //aBook.name=[attributeDict objectForKey:@"name"];
		currentElementValue=elementName;
        CurrentText=[[NSMutableString alloc]init];
		//NSLog(@"Reading id value :%i", aBook.bookID);
	}
	
	NSLog(@"Processing Element: %@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	
	if(!CurrentText)
		CurrentText = [[NSMutableString alloc] initWithString:string];
	else
		[CurrentText appendString:string];
	
	NSLog(@"Processing Value: %@", CurrentText);
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	if([elementName isEqualToString:@"xml"])
    {
        
    }
	
	if([elementName isEqualToString:@"parent_cat_id"]) {
        
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [CurrentParentId addObject:arr];
        [output appendString:CurrentText];
        
		//[appDelegate.books addObject:aBook];
		
		
	}
    else if([elementName isEqualToString:@"cat_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [CurrentName addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"cat_id"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [CurrentProductId addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"product_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [ProductName addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"product_id"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [ProductId addObject:arr];
        [output appendString:CurrentText];
        
        
        
        //[self presentViewController:objproductViewController animated:YES completion:nil];
        
        
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    
    
    
    
   	
	[CurrentText release];
	CurrentText=nil;
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    
    //    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:output delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
    //    [alt show];
    //    [alt release];
    
    [tableview reloadData];
    
    NSLog(@"%@",ProductId);
    
    NSString *ProductId1=[NSString stringWithFormat:@"%@",ProductId];
    NSLog(@"%@",ProductId1);
    
    
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\n  "];
    ProductId1 = [[ProductId1 componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    
    NSLog(@"ud:%@",ProductId1);
    
    subappDelegate.SubMenuId=@"";
    
    if(![ProductId1 isEqualToString:@""])
    {
       productViewController *objproductViewController5=[[productViewController  alloc]initWithNibName:@"productViewController"bundle:nil];
        
        
        NSLog(@"%@",self.MyUrlID);
        objproductViewController.MyUrlId=self.MyUrlID;
       
        [self.navigationController pushViewController:objproductViewController5 animated:YES];
        
        
        
    }
    [_Action_indicator setHidden:YES];
    
    [_Action_indicator stopAnimating];
}


-(IBAction)menuButtonMethod:(id)sender{
    
    
    
}
-(IBAction)venuesButtonMethod:(id)sender{
   
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
        
        MapViewController  *objmapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
        
        
        [self.navigationController pushViewController:objmapViewController4 animated:YES];
    }
}
-(IBAction)mainSrceenButton:(id)sender{
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
        ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
    
    
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}
-(IBAction)backButtonMethod:(id)sender{
      
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)dealloc {
	//[bdvController release];
	[subappDelegate release];
    [tableview release];
    [backButton release];
    [lblText release];
    [selectedCountry release];
    [venuesButton release];
    [checkInButton release];
    [mainSrceenButton release];
    [subMenuLabelString release];
    [objproductViewController release];
    [objRLSampleViewController release];
    [objMapViewController release];
    
    
    [_SubMenuTitle release];
    [_SubMenuTitle release];
    [_Action_indicator release];
    [super dealloc];
}


- (IBAction)MyOrderMethod:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
        
        MapViewController  *objmapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
        
        
        [self.navigationController pushViewController:objmapViewController4 animated:YES];
    }
   
    
}
- (IBAction)Msg_Method:(id)sender {
        
    
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
    
}

@end
