//
//  subBook.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface subBook : NSObject{
NSInteger subbookID;
NSString *subname;
}
@property (nonatomic, readwrite) NSInteger subbookID;
@property (nonatomic, retain) NSString *subname;
@end
