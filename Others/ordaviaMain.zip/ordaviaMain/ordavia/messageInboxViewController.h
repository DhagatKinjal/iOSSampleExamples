//
//  messageInboxViewController.h
//  ordavia
//
//  Created by mac on 6/20/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler.h"

@interface messageInboxViewController : UIViewController
{
    DBHandler *dbh;
    NSMutableArray *pushMsgarr;
    NSString *oid,*nid;
    NSMutableArray *tempArrayID;
    
}
@property (retain, nonatomic) NSMutableArray *pushMsgarr;
@property (retain, nonatomic) IBOutlet UITableView *inboxTableview;
@property (retain, nonatomic) NSString *oid;
- (IBAction)backButtonMethod:(id)sender;
- (IBAction)homeSreenMethod:(id)sender;
- (IBAction)VenuesSreccMethod:(id)sender;

@end
