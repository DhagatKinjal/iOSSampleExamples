//
//  XMLParser.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "XMLParser.h"
#import "AppDelegate.h"

@implementation XMLParser
@synthesize AddOnName,AddonId,AddOnPrice;
- (XMLParser *) initXMLParser {
	
	[super init];
	
	appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.addonID=[NSArray arrayWithArray:AddonId];
    appDelegate.addonName=[NSArray arrayWithArray:AddOnName];
    appDelegate.addonPrice=[NSArray arrayWithArray:AddOnPrice];
	
	return self;
}
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    currentElementValue=nil;
    CurrentText=nil;
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
	attributes:(NSDictionary *)attributeDict {
	
	if([elementName isEqualToString:@"xml"]) {
		//Initialize the array.
		appDelegate.books = [[NSMutableArray alloc] init];
        AddonId=[[NSMutableArray alloc]init];
        AddOnName=[[NSMutableArray alloc]init];
        AddOnPrice=[[NSMutableArray alloc]init];
        output=[[NSMutableString alloc]init];
	}
	else if([elementName isEqualToString:@"addon_id"] || [elementName isEqualToString:@"addon_name"] || [elementName isEqualToString:@"addon_price"]) {
        
        currentElementValue=elementName;
        CurrentText=[[NSMutableString alloc]init];
    }
    
    //Initialize the book.
    
	
	NSLog(@"Processing Element: %@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	
	if(!CurrentText)
		CurrentText = [[NSMutableString alloc] initWithString:string];
	else
		[CurrentText appendString:string];
	
	NSLog(@"Processing Value: %@", CurrentText);
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
	if([elementName isEqualToString:@"xml"])
    {
        
    }
	
	if([elementName isEqualToString:@"addon_id"]) {
        
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [AddonId addObject:arr];
        [output appendString:CurrentText];
        
		//[appDelegate.books addObject:aBook];
		
		
	}
    else if([elementName isEqualToString:@"addon_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        [AddOnName addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    else if([elementName isEqualToString:@"addon_price"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [AddOnPrice addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    
    
    
   	
	[CurrentText release];
	CurrentText=nil;
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    
    //    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:output delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
    //    [alt show];
    //    [alt release];
    
    //[scanHistoryTable reloadData];
    appDelegate.addonID=[NSArray arrayWithArray:AddonId];
    appDelegate.addonName=[NSArray arrayWithArray:AddOnName];
    appDelegate.addonPrice=[NSArray arrayWithArray:AddOnPrice];
    
  //  NSString *addon=[AddOnName objectAtIndex:0];
    
    
    
    
}

- (void) dealloc {
	
	[aBook release];
	[currentElementValue release];
	[super dealloc];
}

@end
