//
//  VenuesViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VenuesViewController : UIViewController{
    

IBOutlet UILabel *lblText;
NSString *selectedCountry;
NSString *myID;



////xml////
NSXMLParser *xml_parser;
NSString *xml_file_path;
NSMutableData *xmldata;
NSMutableArray *bar_id,*company_id,*bar_name,*bar_address1,*bar_address2,*bar_city,*bar_state,*bar_country,*bar_zipcode,*bar_phone1,*bar_phone2,*bar_latitude,*bar_longitude;
NSMutableString *output;
NSString *cur_ele;
NSMutableString *cur_txt;
NSURL *url;
NSURLRequest *req;
NSURLConnection *conn;
NSMutableDictionary *dics,*dict;
NSMutableArray *proName;
NSString *p_Id;
NSString *p_name;
NSInteger *proid;
NSString *name;
NSMutableArray *arrdata;
    NSString *Phone1;

}
- (IBAction)callingButtonMethod:(id)sender;
- (IBAction)webSit:(id)sender;
@property(nonatomic,retain)UIButton *backButton;
@property(nonatomic,retain)UIButton *infoButton;
@property (nonatomic, retain) NSString *selectedCountry;
@property (nonatomic, retain) NSString *myID;
@property (retain, nonatomic) IBOutlet UILabel *VAddress;
@property (retain, nonatomic) IBOutlet UILabel *VDiscription;

@property (retain, nonatomic) IBOutlet UILabel *BarName;
@property (retain, nonatomic) IBOutlet UILabel *BarAddress;
@property (retain, nonatomic) IBOutlet UILabel *PhoneNumber;
@property (retain, nonatomic) IBOutlet UILabel *BarDiscription;
- (IBAction)homTapButtonMethod:(id)sender;

- (IBAction)msgTapMethod:(id)sender;


-(IBAction)backButtonMethod:(id)sender;
-(IBAction)infoButtonMethod:(id)sender;

@end
