//
//  infoViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface infoViewController : UIViewController
@property (retain, nonatomic) IBOutlet UIWebView *WebView;

@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Action_Ind;
@property(nonatomic,retain)IBOutlet UIButton *backButton;
- (IBAction)homeTabButtonMethod:(id)sender;
- (IBAction)venuesTapButtonMethod:(id)sender;
- (IBAction)msgTapButtonMethod:(id)sender;

-(IBAction)backButtonMethod:(id)sender;
@end
