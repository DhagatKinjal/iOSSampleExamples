//
//  MapViewCustomCell.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapViewCustomCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *BarNameLabel;
@property (retain, nonatomic) IBOutlet UILabel *DistanceInKmLabel;

@end
