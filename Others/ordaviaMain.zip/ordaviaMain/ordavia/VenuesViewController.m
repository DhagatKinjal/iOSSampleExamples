//
//  VenuesViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "VenuesViewController.h"
#import "MapViewController.h"
#import "ViewController.h"
#import "infoViewController.h"
//#import "webSiteViewController.h"
#import "messageInboxViewController.h"
#import "ViewController.h"

@interface VenuesViewController ()

@end

@implementation VenuesViewController

@synthesize backButton,infoButton;
@synthesize selectedCountry,myID;

MapViewController *objmapViewController;
ViewController *objRLSampleViewController;
infoViewController *objinfoViewController;
//webSiteViewController *objwebSiteViewController;
ViewController *objViewController;
messageInboxViewController *objmessageInboxViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)dealloc{
    [infoButton release];
    [backButton release];
    [objinfoViewController release];
    [objmapViewController release];
    [objRLSampleViewController release];
    [selectedCountry release];
    
    [lblText release];
    [objinfoViewController release];
    [_VAddress release];
    [_VDiscription release];
    [_BarName release];
    [_BarAddress release];
    [_PhoneNumber release];
    [_BarDiscription release];
    [super dealloc];
    
}
- (void)viewDidLoad
{
    NSLog(@"%@",self.myID);
    NSString *idmy=[NSString stringWithFormat:@"%@",self.myID];
    NSString *barid=[NSString stringWithString:idmy];
    NSCharacterSet *doNotWant4 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    
    barid = [[barid componentsSeparatedByCharactersInSet: doNotWant4] componentsJoinedByString: @""];
    NSLog(@"%@",barid);
    
    NSString *BarID1 = [barid substringWithRange:NSMakeRange(4, [barid length]-4)];
    NSLog(@"%@",BarID1);
    
    
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/VenueApi/GetVenueDetails?bar_id=%@",BarID1];
    
    url = [[NSURL alloc] initWithString:myurl];
    
    NSLog(@"%@",myurl);
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata=[[NSMutableData alloc]init];
    //[mapTableView reloadData];
    [conn release];
    
    
    //    _VAddress.text=vanueAdd;
    //    _VDiscription.text=vanueAdd;
    //
    //    NSArray *arrData=[[NSMutableArray alloc]initWithArray:[vanueAdd componentsSeparatedByString:@","]];
    //    NSLog(@"%@",[arrData objectAtIndex:0]);
    //
    //    NSString *s=[[NSString alloc]initWithFormat:@"%@",[arrData objectAtIndex:0]];
    //    NSLog(@"%@",s);
    //    NSArray *arrData1=[[NSMutableArray alloc]initWithArray:[s componentsSeparatedByString:@"("]];
    //    NSLog(@"%@",[arrData1 objectAtIndex:1]);
    //
    //
    //    NSString *s1=[[NSString alloc]initWithFormat:@"%@",[arrData1 objectAtIndex:1]];
    //    NSArray *arrData2=[[NSMutableArray alloc]initWithArray:[s1 componentsSeparatedByString:@")"]];
    //    NSLog(@"%@",[arrData2 objectAtIndex:0]);
    //
    //    NSString *add=[arrData2 objectAtIndex:0];
    //    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"()\" (), \n "];
    //    add = [[add componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""];
    //
    //    _VAddress.text=  add;
    //
    //
    //     NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\" (), \n "];
    //     vanueAdd = [[vanueAdd componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    //     [super viewDidLoad];
    //
    //
    //     _VDiscription.text=vanueAdd;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    // lblText.text = selectedCountry;
}



- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    [xml_parser release];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"status" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
}



- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    cur_ele=nil;
    cur_txt=nil;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict;
{
    
    
    if([elementName isEqualToString:@"xml"])
    {
        dics=[[NSMutableDictionary alloc]init];
        bar_id=[[NSMutableArray alloc]init];
        company_id=[[NSMutableArray alloc]init];
        bar_name=[[NSMutableArray alloc]init];
        bar_address1=[[NSMutableArray alloc]init];
        bar_address2=[[NSMutableArray alloc]init];
        bar_city=[[NSMutableArray alloc]init];
        bar_state=[[NSMutableArray alloc]init];
        bar_country=[[NSMutableArray alloc]init];
        bar_zipcode=[[NSMutableArray alloc]init];
        bar_phone1=[[NSMutableArray alloc]init];
        bar_phone2=[[NSMutableArray alloc]init];
        bar_latitude=[[NSMutableArray alloc]init];
        bar_longitude=[[NSMutableArray alloc]init];
        
        
        
        output=[[NSMutableString alloc]init];
        proName=[[NSMutableArray alloc]init];
    }
    
    else if([elementName isEqualToString:@"bar_id"] || [elementName isEqualToString:@"bar_name"] || [elementName isEqualToString:@"company_id"] ||  [elementName isEqualToString:@"bar_latitude"]  || [elementName isEqualToString:@"bar_longitude"] || [elementName isEqualToString:@"bar_address1"] || [elementName isEqualToString:@"bar_address2"] || [elementName isEqualToString:@"bar_city"] || [elementName isEqualToString:@"bar_state"] || [elementName isEqualToString:@"bar_country"] || [elementName isEqualToString:@"bar_zipcode"] || [elementName isEqualToString:@"bar_phone1"] || [elementName isEqualToString:@"bar_phone2"] )
    {
        cur_ele=elementName;
        cur_txt=[[NSMutableString alloc]init];
        
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [cur_txt appendString:string];
    
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
    if([elementName isEqualToString:@"bar_id"])
    {
        [dics setValue:cur_txt forKey:cur_ele];
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_id addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_name addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_latitude"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_latitude addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_longitude"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_longitude addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_address1"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_address1 addObject:arr];
        NSLog(@"%@",bar_address1);
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_address2"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_address2 addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_city"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_city addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_state"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_state addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_country"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_country addObject:arr];
        NSLog(@"%@",bar_address1);
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_zipcode"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_zipcode addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_phone1"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_phone1 addObject:arr];
        [output appendString:cur_txt];
    }
    
    else if([elementName isEqualToString:@"bar_phone2"])
    {
        NSArray *arr=[NSArray arrayWithObjects:cur_txt, nil];
        [bar_phone2 addObject:arr];
        NSLog(@"%@",bar_phone2);
        [output appendString:cur_txt];
    }
    
    
    else if ([elementName isEqualToString:@"xml"])
    {
        
    }
    [cur_txt release];
    cur_txt=nil;
}

// sent when the parser begins parsing of the document.
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    
    NSString *barname=[NSString stringWithFormat:@"%@",[bar_name objectAtIndex:0]];
    
    NSString *bname=[NSString stringWithString:barname];
    NSCharacterSet *doNotWant4 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    
    bname = [[bname componentsSeparatedByCharactersInSet: doNotWant4] componentsJoinedByString: @""];
    NSLog(@"%@",bname);
    
    NSString *BarNAme1 = [bname substringWithRange:NSMakeRange(4, [bname length]-4)];
    NSLog(@"%@",BarNAme1);
    _BarName.text=BarNAme1;
    
    
    NSString *baradd=[NSString stringWithFormat:@"%@",[bar_address1 objectAtIndex:0]];
    
    NSString *baradd1=[NSString stringWithString:baradd];
    NSCharacterSet *doNotWant5 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    
    baradd1 = [[baradd1 componentsSeparatedByCharactersInSet: doNotWant5] componentsJoinedByString: @""];
    NSLog(@"%@",baradd1);
    
    NSString *BarAddress = [baradd1 substringWithRange:NSMakeRange(4, [baradd1 length]-4)];
    NSLog(@"%@",BarAddress);
    _BarName.text=BarNAme1;
    
    
    
    
    NSString *baradd2=[NSString stringWithFormat:@"%@",[bar_address2 objectAtIndex:0]];
    
    NSString *baradd11=[NSString stringWithString:baradd2];
    NSCharacterSet *doNotWant2 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    
    baradd11 = [[baradd11 componentsSeparatedByCharactersInSet: doNotWant2] componentsJoinedByString: @""];
    NSLog(@"%@",baradd11);
    
    NSString *BarAddress2 = [baradd11 substringWithRange:NSMakeRange(4, [baradd11 length]-4)];
    NSLog(@"%@",BarAddress2);
    _BarName.text=BarNAme1;
    
    
    
    NSString *barcity=[NSString stringWithFormat:@"%@",[bar_city objectAtIndex:0]];
    
    NSString *barcity1=[NSString stringWithString:barcity];
    NSCharacterSet *doNotWant6 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    
    barcity1 = [[barcity1 componentsSeparatedByCharactersInSet: doNotWant6] componentsJoinedByString: @""];
    NSLog(@"%@",barcity1);
    
    NSString *BarCity = [barcity1 substringWithRange:NSMakeRange(4, [barcity1 length]-4)];
    NSLog(@"%@",BarCity);
    _BarName.text=BarNAme1;
    
    _BarAddress.text=[NSString stringWithFormat:@"%@, %@, %@",BarAddress,BarAddress2,BarCity];
    
    
    
    
    NSString *phone=[NSString stringWithFormat:@"%@",[bar_phone1 objectAtIndex:0]];
    
    NSString *phone1=[NSString stringWithString:phone];
    NSCharacterSet *doNotWant7 = [NSCharacterSet characterSetWithCharactersInString:@",()\"\n"];
    
    phone1 = [[phone1 componentsSeparatedByCharactersInSet: doNotWant7] componentsJoinedByString: @""];
    NSLog(@"%@",phone1);
    
   Phone1 = [phone1 substringWithRange:NSMakeRange(4, [phone1 length]-4)];
    NSLog(@"%@",Phone1);
    
    
    
    NSString *pphone=[NSString stringWithFormat:@"%@",[bar_phone2 objectAtIndex:0]];
    
    NSString *phone2=[NSString stringWithString:pphone];
    NSCharacterSet *doNotWant8 = [NSCharacterSet characterSetWithCharactersInString:@",()\"\n"];
    
    phone2 = [[phone2 componentsSeparatedByCharactersInSet: doNotWant8] componentsJoinedByString: @""];
    NSLog(@"%@",phone2);
    
    NSString *Phone2 = [phone2 substringWithRange:NSMakeRange(4, [phone2 length]-4)];
    NSLog(@"%@",Phone2);
    
    _PhoneNumber.text=[NSString stringWithFormat:@"%@ %@",Phone1,Phone2];
    // [mapTableView reloadData];
    //[_tblxmldata reloadData];
    
    
    ////mapview code///
    
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)homTapButtonMethod:(id)sender {
    
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
        ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }

    
    
}

- (IBAction)msgTapMethod:(id)sender {
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
}

-(IBAction)backButtonMethod:(id)sender{
    
   [self.navigationController popViewControllerAnimated:YES];

}
-(IBAction)infoButtonMethod:(id)sender{
//    objinfoViewController=[[infoViewController  alloc]initWithNibName:@"infoViewController"bundle:nil];
//    
//    [self.view addSubview:objinfoViewController.view];
//    
    
    objinfoViewController=[[infoViewController  alloc]initWithNibName:@"infoViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objinfoViewController animated:YES];
    
    
    
}


- (void)viewDidUnload {
    //[self setVanueAddress:nil];
    //[self setVanueDiscription:nil];
    [self setVAddress:nil];
    [self setVDiscription:nil];
    [super viewDidUnload];
}
- (IBAction)callingButtonMethod:(id)sender {
    
    
   [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel:07405047707"]];}
   
    
    



@end
