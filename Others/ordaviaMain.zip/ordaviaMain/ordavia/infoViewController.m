//
//  infoViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "infoViewController.h"
#import "MapViewController.h"
#import "messageInboxViewController.h"
#import "ViewController.h"

@interface infoViewController ()

@end

@implementation infoViewController
@synthesize backButton;
MapViewController *objMapViewController;
messageInboxViewController *objmessageInboxViewController;
ViewController *objViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    [_Action_Ind startAnimating];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    NSString *fullURL = @"http://www.bevond.com/ordavia/index.php/TermsAndConditions";
    NSURL *url = [NSURL URLWithString:fullURL];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [_WebView loadRequest:requestObj];
    
    //
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [_Action_Ind setHidden:YES];
    
    [_Action_Ind stopAnimating];
    // Dispose of any resources that can be recreated.
}

- (IBAction)homeTabButtonMethod:(id)sender {
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objViewController animated:YES];
        
        
    }else{
        ViewController *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
}

- (IBAction)venuesTapButtonMethod:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
        
        MapViewController *objMapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objMapViewController4 animated:YES];
        
    }

    
}

- (IBAction)msgTapButtonMethod:(id)sender {
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
}

-(IBAction)backButtonMethod:(id)sender{
    
       [self.navigationController popViewControllerAnimated:YES];
}
-(void)dealloc{
    [backButton release];
    [_WebView release];
    
    
    [_Action_Ind release];
    [super dealloc];
}


@end
