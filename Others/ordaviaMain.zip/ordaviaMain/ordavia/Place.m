//
//  Place.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "Place.h"

@implementation Place
@synthesize name;
@synthesize description;
@synthesize latitude;
@synthesize longitude;
@synthesize location1,location2;
- (void) dealloc
{
	[name release];
	[description release];
    [name release];
    [location1 release];
    [location2 release];
	[super dealloc];
}
@end
