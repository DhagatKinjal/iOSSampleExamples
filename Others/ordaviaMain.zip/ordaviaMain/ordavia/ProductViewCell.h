//
//  ProductViewCell.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *ProductLabel;
@property (retain, nonatomic) IBOutlet UILabel *DetailLabel;
@end
