//
//  MapViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MKFoundation.h>
#import <MapKit/MKAnnotation.h>
#import <MapKit/MKAnnotationView.h>
#import <MapKit/MKDirectionsRequest.h>
#import <MapKit/MKGeometry.h>
#import <MapKit/MKMapItem.h>
#import <MapKit/MKMapView.h>
#import <MapKit/MKPinAnnotationView.h>
#import <MapKit/MKPlacemark.h>
#import <MapKit/MKReverseGeocoder.h>
#import <MapKit/MKUserLocation.h>
#import <MapKit/MKTypes.h>
#import <MapKit/MKOverlay.h>
#import <MapKit/MKShape.h>
#import <MapKit/MKPointAnnotation.h>
#import <MapKit/MKMultiPoint.h>
#import <MapKit/MKPolyline.h>
#import <MapKit/MKPolygon.h>
#import <MapKit/MKCircle.h>
#import <MapKit/MKOverlayView.h>
#import <MapKit/MKOverlayPathView.h>
#import <MapKit/MKPolygonView.h>
#import <MapKit/MKPolylineView.h>
#import <MapKit/MKCircleView.h>
#import <MapKit/MKUserTrackingBarButtonItem.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

#import "MapViewCustomCell.h"

#import "Place.h"
#import "PlaceMark.h"
//#import "DetailVCtr.h"
#import "messageInboxViewController.h"

@interface MapViewController : UIViewController<MKMapViewDelegate,UITableViewDataSource, UITableViewDelegate,CLLocationManagerDelegate,NSXMLParserDelegate>
{
    IBOutlet MKMapView *mapView;
    NSMutableArray *listOfItems;
    CLLocationManager *locationManager;
    IBOutlet UILabel *latLabel;
    IBOutlet UILabel *longLabel;
    
    NSMutableArray *reports;
	//DetailVCtr *nxtDetailsVCtr;
    
    NSString *myLat;
    NSString *myLan;
    NSMutableArray *pinDrop;
    float ulongitude;
    float ulatitude;
    int pinn;
    int count;
    IBOutlet UITableView *mapTableView;
    //////xml/////
    NSXMLParser *xml_parser;
    NSString *xml_file_path;
    NSMutableData *xmldata;
    NSMutableArray *data1,*data2,*data3,*data4,*data5,*data6,*data7;
    NSMutableString *output;
    NSString *cur_ele;
    NSMutableString *cur_txt;
    NSURL *url;
    NSURLRequest *req;
    NSURLConnection *conn;
    NSMutableDictionary *dics,*dict;
    NSMutableArray *proName;
    NSString *p_Id;
    NSString *p_name;
    NSInteger *proid;
    NSString *name;
    NSMutableArray *arrdata;
    int i,k,p;
    NSMutableArray *list;
    NSMutableArray *arr1;
    NSMutableArray *distance;
    IBOutlet UILabel *kmLabel;
    int kmIndex;
    float km;
    
    
}
@property(nonatomic,retain) MKPinAnnotationView *pin;
@property(nonatomic,retain)NSMutableArray *reports,*distance;
//@property (nonatomic, retain) IBOutlet DetailVCtr *nxtDetailsVCtr;
@property (nonatomic, retain)IBOutlet UITableView *mapTableView;
@property(nonatomic)float km;


@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, retain) IBOutlet UILabel *kmLabel;

@property(nonatomic,retain)IBOutlet UIButton *backButton;
- (IBAction)homeSrcreenMethod:(id)sender;
@property(nonatomic,retain)IBOutlet UIButton *infoButton;
-(IBAction)backButtonMethod:(id)sender;
-(IBAction)infoButtonMethod:(id)sender;
- (IBAction)msgMethod:(id)sender;
-(void) centerMap;
-(void) MyMapAnnoatation;

@end
