//
//  ViewController.m
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "ViewController.h"

#import "mapViewController.h"
#import "AppDelegate.h"
#import "productViewController.h"
#import "subMenuViewController.h"
#import "ScantableCustomCell.h"
#import "MainOrderViewController.h"
#import "MyFirstMenuViewController.h"
#import "PushMessagesViewController.h"
#import "infoViewController.h"
#import "MyAccountViewController.h"
//#import "FeedBackViewController.h"
#import "messageInboxViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import "MainOrderViewController.h"
#import "infoViewController.h"


@interface ViewController ()

@end

@implementation ViewController
messageInboxViewController *objmessageInboxViewController;

MyFirstMenuViewController *objMyFirstMenuViewController;
productViewController *objproductViewController;
MainOrderViewController *objMainOrderViewController;
MapViewController *objmapViewController;
subMenuViewController *objsubMenuViewController;
PushMessagesViewController *objPushMessagesViewController;
infoViewController *objinfoViewController;
 AppDelegate *appdelegate;
MyAccountViewController *objMyAccountViewController;
//FeedBackViewController *objFeedBackViewController;
infoViewController *objinfoViewController;
@synthesize scanHistoryTable,venuesLable,MyUrlID1,messageButton,timeDate,lat,longt;
- (id) initWithCoder:(NSCoder *)decoder
{
	if (self = [super initWithCoder:decoder])
	{
              
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appBecameActive:)
                                                     name:UIApplicationDidBecomeActiveNotification object:nil];
	}
	
	return self;
}


- (IBAction)scanMethod:(id)sender {
  
////    
//    MyFirstMenuViewController  *objMyFirstMenuViewController5=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController5" bundle:nil];
//    
//    MyFirstMenuViewController  *objMyFirstMenuViewController4=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController4" bundle:nil];
//  CGRect screenBounds = [[UIScreen mainScreen] bounds];
//    if (568 == screenBounds.size.height)
//    {
//        
//        [self.navigationController pushViewController:objMyFirstMenuViewController5 animated:YES];
//        
//    }else{
//        [self.navigationController pushViewController:objMyFirstMenuViewController4 animated:YES];
//    }

//    
//    
    if(appDelegate.time==0)
    {
       
        NSLog(@"Scanning..");
        ZBarReaderViewController *codeReader = [ZBarReaderViewController new];
        codeReader.readerDelegate=self;
        codeReader.supportedOrientationsMask = ZBarOrientationMaskAll;
        
        ZBarImageScanner *scanner = codeReader.scanner;
        [scanner setSymbology: ZBAR_I25 config: ZBAR_CFG_ENABLE to: 0];
        [dbh deleteTime];
        [dbh deletealll];
        [dbh deleteallPrice];
        [self presentViewController:codeReader animated:YES completion:nil];

    }
    else
    {
    NSLog(@"Scanning..");
        
#pragma mark - Reoder Method
     
                       
    self.timeDate=[dbh selecttime];
    NSLog(@"%@",self.timeDate);
    //resultTextView.text = @"Scanning..";
   
      
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
    [dateFormatter2 setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
    
    NSString *todayTime1=[dateFormatter2 stringFromDate:[NSDate date]];
    NSLog(@"%@",todayTime1);
        NSLog(@"%@",self.timeDate);
        
        
    NSString *ODTime=[NSString stringWithFormat:@"%@",[self.timeDate objectAtIndex:0]];
      
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n"];
    ODTime = [[ODTime componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    NSLog(@"Cell Time:%@",ODTime);
    NSLog(@"Cell Time:%@",todayTime1);  
    NSDate* firstDate = [dateFormatter2 dateFromString:todayTime1];
    NSDate* secondDate = [dateFormatter2 dateFromString:ODTime];      //@"2013-06-11 12:16:00"];
    
    NSTimeInterval timeDifference = [firstDate timeIntervalSinceDate:secondDate];
    NSLog(@"%f",timeDifference);
    if(timeDifference<3600)
    {
        
        _reorderView.hidden=NO;

               
        
    }
    else
    {
        
        appDelegate.ForProduct=[[NSMutableString alloc]init];
        appDelegate.ForAddonIds=[[NSMutableString alloc]init];
        
        
        [_CheckInLabel setTextColor:[UIColor redColor]];
        ZBarReaderViewController *codeReader = [ZBarReaderViewController new];
        codeReader.readerDelegate=self;
        codeReader.supportedOrientationsMask = ZBarOrientationMaskAll;
        
        ZBarImageScanner *scanner = codeReader.scanner;
        [scanner setSymbology: ZBAR_I25 config: ZBAR_CFG_ENABLE to: 0];
        
        [self presentViewController:codeReader animated:YES completion:nil];

                       
    }

    
    }
    
}


#pragma mark - ZBar's Delegate method

- (void) imagePickerController: (UIImagePickerController*) reader didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    //  get the decode results
    id<NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // just grab the first barcode
        break;
    NSLog(@"%@",symbol.data);
    
    NSString *myString=[NSString stringWithFormat:@"%@",symbol.data];
    NSLog(@"%@",myString);
    NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@""];
    myString = [[myString componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @"="];
    NSMutableArray *TBArr=[[NSMutableArray alloc]initWithArray:[myString   componentsSeparatedByString:@"\n"]];
    
    NSLog(@"%@",TBArr);
    
    
    NSDictionary *dict = (NSDictionary *)[TBArr objectAtIndex:0];
    for (int j=0; j<[TBArr count]; j++)
    {
        NSString *str=[NSString stringWithFormat:@"%@",[TBArr objectAtIndex:j]];
        NSMutableArray *Arr=[[NSMutableArray alloc]initWithArray:[str   componentsSeparatedByString:@"="]];
        NSLog(@"%@",Arr);
        [ChkDetailArr addObject:[Arr objectAtIndex:1]];
        
    }
    NSLog(@"%@",ChkDetailArr);
    
    
    NSMutableDictionary *ChkDetailDict = [[NSMutableDictionary alloc] init];
   
    [ChkDetailDict setObject:[ChkDetailArr objectAtIndex:0] forKey:@"BarID"];
    [ChkDetailDict setObject:[ChkDetailArr objectAtIndex:1] forKey:@"BarName"];
    [ChkDetailDict setObject:[ChkDetailArr objectAtIndex:2] forKey:@"Address"];
    [ChkDetailDict setObject:[ChkDetailArr objectAtIndex:3] forKey:@"TableNo"];
    //[ChkDetailDict setObject:[ChkDetailArr objectAtIndex:5] forKey:@"U"];
    
   
    NSString *BaridStr = [ChkDetailDict objectForKey:@"BarID"];
    NSString *BarNameStr = [ChkDetailDict objectForKey:@"BarName"];
    NSString *AddressStr = [ChkDetailDict objectForKey:@"Address"];
    NSString *TBStr = [ChkDetailDict objectForKey:@"TableNo"];
   // NSString *UrlStr=[ChkDetailDict objectForKey:@"U"];
    
    //NSLog(@"%@",UrlStr);
    NSLog(@"%@",BaridStr);
    NSLog(@"%@",BarNameStr);
    NSLog(@"%@",AddressStr);
    NSLog(@"%@",TBStr);
    
    [reader dismissViewControllerAnimated:YES completion:nil];

    
    
    
    
           
      MyFirstMenuViewController  *objMyFirstMenuViewController5=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController5" bundle:nil];
    
    MyFirstMenuViewController  *objMyFirstMenuViewController4=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController4" bundle:nil];

    
    
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        
       [self.navigationController pushViewController:objMyFirstMenuViewController5 animated:YES];
        
    }else{
        [self.navigationController pushViewController:objMyFirstMenuViewController4 animated:YES];
    }
    
    
        
       
        
        
}




- (void) dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    
	
	//[pickerController release];
	[scanHistoryTable release];
	[firstTimeView release];
    
	[appNameAndVersionLabel release];
    [_CheckInLabel release];
    [myAccountButton release];
    [reoderAlterView release];
    [_CheckinMethod release];
    [_BtterButtonMethod release];
    [_feedBackView release];
    [_feedbackCommentView release];
    [_feedbackTextView release];
    [_reorderView release];
    [_newOrderButtonMethod release];
	[super dealloc];
}

- (void) viewDidLoad
{
  
    
    
    ChkDetailArr =[[NSMutableArray alloc]init];
    
    _reorderView.hidden=YES;
    reoderAlterView.hidden=YES;
    _feedbackCommentView.hidden=YES;
    _feedBackView.hidden=YES;
    
    UINavigationController *navController = [[UINavigationController alloc] init];
    [navController setNavigationBarHidden:YES animated:YES];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
    [locationManager startUpdatingLocation];
    
      
    self.timeDate=[[NSArray alloc]init];
    dbh=[[DBHandler alloc]init];
    
       
//	[pickerController prepareToScan];
	[firstTimeView setHidden:[scanHistory count] != 0];
    
    // Uncomment the following line to add the Edit button to the navigation bar.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
	
	appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
	//self.scanHistoryTable.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"BG.png"]];
    
	//self.title = @"Data";
    [super viewDidLoad];
}

/////xml


- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    int degrees = newLocation.coordinate.latitude;
    double decimal = fabs(newLocation.coordinate.latitude - degrees);
    int minutes = decimal * 60;
    double seconds = decimal * 3600 - minutes * 60;
    lat = [NSString stringWithFormat:@"%d° %d' %1.4f\"",
           degrees, minutes, seconds];
    latLabel.text = lat;
    degrees = newLocation.coordinate.longitude;
    decimal = fabs(newLocation.coordinate.longitude - degrees);
    minutes = decimal * 60;
    seconds = decimal * 3600 - minutes * 60;
    longt = [NSString stringWithFormat:@"%d° %d' %1.4f\"",
             degrees, minutes, seconds];
    longLabel.text = longt;
    
    NSLog(@"Lat%@",lat);
    NSLog(@"Lat%@",longt);
    
    appDelegate.appLatString=[NSString stringWithFormat:@"%@",lat];
    appDelegate.appLongString=[NSString stringWithFormat:@"%@",longt];
    NSLog(@"%@--->",appDelegate.appLatString);
    NSLog(@"%@--->",appDelegate.appLongString);
}


- (void) viewDidUnload
{
    _reorderView.hidden=YES;
    
    [scanHistoryTable release];
	scanHistoryTable = nil;
	[firstTimeView release];
	firstTimeView = nil;
	[appNameAndVersionLabel release];
	appNameAndVersionLabel = nil;
    [reoderAlterView release];
    reoderAlterView = nil;
    [self setCheckinMethod:nil];
    [self setBtterButtonMethod:nil];
    [self setFeedBackView:nil];
    [self setFeedbackCommentView:nil];
    [self setFeedbackTextView:nil];
    [self setReorderView:nil];
    [self setNewOrderButtonMethod:nil];
	[super viewDidUnload];
}


// When the app launches or is foregrounded, this will get called via NSNotification
// to warm up the camera.
- (void) appBecameActive:(NSNotification *) notification
{
	//[pickerController prepareToScan];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}
- (IBAction)infoButtonMethod:(id)sender {
    
     objinfoViewController=[[infoViewController  alloc]initWithNibName:@"infoViewController"bundle:nil];
    [self.navigationController pushViewController:objinfoViewController animated:YES];
}

- (IBAction) optionsButtonPressed:(id)sender
{
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
      MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
    
  MapViewController  *objmapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
    
        
     [self.navigationController pushViewController:objmapViewController4 animated:YES];
    }
}

// This button initiates a scan session to scan a single barcode. The session will exit
// as soon as something is found.


#pragma mark - UITableViewDataSource


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (IBAction)MyOrderMethod:(id)sender {
    objMainOrderViewController=[[MainOrderViewController  alloc]initWithNibName:@"MainOrderViewController"bundle:nil];
    //[self.view addSubview:objMainOrderViewController.view];
    //[self.view removeFromSuperview];
    [self presentViewController:objMainOrderViewController animated:YES completion:nil];
}

- (IBAction)myAccountMethod:(id)sender {
    
        
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MyAccountViewController  *objMyAccountViewController5=[[MyAccountViewController  alloc]initWithNibName:@"MyAccountViewController5"bundle:nil];
        
        [self.navigationController pushViewController:objMyAccountViewController5 animated:YES];
    }
    else{
        
        
        MyAccountViewController  *objMyAccountViewController4=[[MyAccountViewController  alloc]initWithNibName:@"MyAccountViewController4"bundle:nil];
        
        [self.navigationController pushViewController:objMyAccountViewController4 animated:YES];
    }
       
    
}

    
 
    


-(IBAction)messageButtonMethod:(id)sender
{
    objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    
//  messageInboxViewController   *objmessageInboxViewController5=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController5"bundle:nil];
//   
//    CGRect screenBounds = [[UIScreen mainScreen] bounds];
//    if (568 == screenBounds.size.height)
//    {
//        
//        [self.navigationController pushViewController:objmessageInboxViewController5 animated:YES];
//        
//    }else
//    
 
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
}

- (IBAction)feedBackMethod:(id)sender {
    

     _feedBackView.hidden=NO;
}

- (IBAction)loveButtonMethod:(id)sender {
    
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://itunes.apple.com/in/app/simple-reflect/id670247429?mt=8"]];
     _feedBackView.hidden=YES;
    
}

- (IBAction)closeButtonMethod:(id)sender {
     _feedBackView.hidden=YES;
    _feedbackCommentView.hidden=YES;
    _reorderView.hidden=YES;
    _feedbackTextView.text=@"";
    [_feedbackTextView resignFirstResponder];
    

}
- (IBAction)butterButtonAction:(id)sender {
    _feedBackView.hidden=YES;
    _feedbackCommentView.hidden=NO;
    
    [_feedbackTextView becomeFirstResponder];
    
    
}
- (IBAction)feedbackSubmitButton:(id)sender {
        [_feedbackTextView resignFirstResponder];    
    NSLog(@"%@",appDelegate.deviceToken);
    
    NSString *MYDeviceToken=[NSString stringWithFormat:@"%@",appDelegate.deviceToken];
    
    NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
    MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
    NSLog(@"%@",MYDeviceToken);
    
    
    NSString *msg=_feedbackTextView.text;
    
    NSLog(@"feedBack--->%@",msg);
    
    NSString *myurl=[NSString stringWithFormat:@"http://www.bevond.com/ordavia/index.php/FeedbackApi/insertFeedback?cust_id=1&device_token=%@&feedback_msg=%@",MYDeviceToken,msg];
    NSLog(@"%@",myurl);
    
    url = [[NSURL alloc] initWithString:myurl];
    
    req=[NSURLRequest requestWithURL:url];
    conn=[[NSURLConnection alloc]initWithRequest:req delegate:self];
    xmldata=[[NSMutableData alloc]init];
    //[scanHistoryTable reloadData];
    [conn release];
    _feedBackView.hidden=YES;
    _feedbackCommentView.hidden=YES;

    _feedbackTextView.text=@"";
    
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text isEqualToString:@"\n"]) {
        
          [_feedbackTextView resignFirstResponder];
                
        return NO;
    }
    
    return YES;
}


- (IBAction)reoderderButtonMethod:(id)sender {
    
      
   
 
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        
        
        MainOrderViewController *objMainOrderViewController=[[MainOrderViewController alloc]initWithNibName:@"MainOrderViewController" bundle:nil];
        [self.view removeFromSuperview];
        
        [self.navigationController pushViewController:objMainOrderViewController animated:YES];
    }
    else{
        
        MainOrderViewController *objMainOrderViewController4=[[MainOrderViewController alloc]initWithNibName:@"MainOrderViewController4" bundle:nil];
        [self.view removeFromSuperview];
        
        [self.navigationController pushViewController:objMainOrderViewController4 animated:YES];
        
        
    }
    
    
    
    
    
    _reorderView.hidden=YES;
    
}
- (IBAction)chechInButtonMethoc:(id)sender {
    
    [dbh deleteTime];
    [dbh deletealll];
    [dbh deleteallPrice];
    appDelegate.time=0;
    NSLog(@"Scanning..");
    ZBarReaderViewController *codeReader = [ZBarReaderViewController new];
    codeReader.readerDelegate=self;
    codeReader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = codeReader.scanner;
    [scanner setSymbology: ZBAR_I25 config: ZBAR_CFG_ENABLE to: 0];
    
    [self presentViewController:codeReader animated:YES completion:nil];
    [self.view removeFromSuperview];
    _reorderView.hidden=YES;
}

- (IBAction)newOrderMethod:(id)sender {
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        [dbh deleteTime];
        [dbh deletealll];
        [dbh deleteallPrice];
        appDelegate.time=0;
        
        
        MyFirstMenuViewController  *objMyFirstMenuViewController5=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController5" bundle:nil  ];
        
        [self.navigationController pushViewController:objMyFirstMenuViewController5 animated:YES];
        
        
        
    }
    else{
        
        [dbh deleteTime];
        [dbh deletealll];
        [dbh deleteallPrice];
        appDelegate.time=0;
        
       MyFirstMenuViewController *objMyFirstMenuViewController4=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController4" bundle:nil];
        
        [self.navigationController pushViewController:objMyFirstMenuViewController4 animated:YES ];
        
        
        
    }
    
    
    _reorderView.hidden=YES;
}
@end
