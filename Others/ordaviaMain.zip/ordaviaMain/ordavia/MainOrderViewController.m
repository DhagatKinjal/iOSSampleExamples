//
//  MainOrderViewController.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "MainOrderViewController.h"
#import "ViewController.h"
#import "subMenuViewController.h"
#import "AddPoductViewController.h"
#import "productViewController.h"
#import "PushMessagesViewController.h"
#import "MyFirstMenuViewController.h"
#import "MainOrderCustomCell.h"
#import "AppDelegate.h"
#import "MapViewController.h"
#import "messageInboxViewController.h"


@interface MainOrderViewController ()

@end

@implementation MainOrderViewController
@synthesize mainOrderTable,backButton,mainScrollView,marrSqlite,product,addon,i,Reorder,bgImageView,headerImageView;
PushMessagesViewController *objPushMessagesViewController;
productViewController *objproductViewController;
ViewController *objRLSampleViewController;
MainOrderCustomCell *mcell;
subMenuViewController *objsubMenuViewController;
AddPoductViewController *objAddPoductViewController;
MyFirstMenuViewController *objMyFirstMenuViewController;
MainOrderCustomCell *objMainOrderCustomCell;
AppDelegate *objRLSampleAppDelegate;
MapViewController *objMapViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)tabBar:(UITabBar *)theTabBar didSelectItem:(UITabBarItem *)item {
    NSUInteger indexOfTab = [[_TabBar items] indexOfObject:item];
    NSLog(@"Tab index = %u", indexOfTab);
    if(indexOfTab==0)
    {
        NSLog(@"UD");
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        
        [self presentViewController:objRLSampleViewController animated:YES completion:nil];
    }
    if(indexOfTab==1)
    {
        NSLog(@"UJ");
        objsubMenuViewController=[[subMenuViewController  alloc]initWithNibName:@"subMenuViewController"bundle:nil];
        
        [self presentViewController:objsubMenuViewController animated:YES completion:nil];
    }
}

- (void)viewDidLoad

{
    _addview.hidden=YES;
    _orderSendView.hidden=YES;
     _commentView.hidden=YES;
    

//    UIImageView *imgview=[[UIImageView alloc]initWithFrame:CGRectMake(94,14,130,35)];
//    
//    NSString *string=[NSString stringWithFormat:@"http://%@",objRLSampleAppDelegate.logoString];
//    
//    
//    
//    UIImage *img=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:string]]];
//    
//    [imgview setImage:img];
//    
//    [self.view addSubview:imgview];
    
    
    if ([objRLSampleAppDelegate.themeString isEqualToString:@"1"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"001-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"001-header.png"]];    }
    
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"2"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"002-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"002-header.png"]];
    }
    
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"3"])
    {
        
        [bgImageView setImage:[UIImage imageNamed:@"003-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"003-header.png"]];
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"4"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"004-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"004-header.png"]];
    }
    else if ([objRLSampleAppDelegate.themeString isEqualToString:@"5"])
    {
        [bgImageView setImage:[UIImage imageNamed:@"005-bg.png"]];
        [headerImageView setImage:[UIImage imageNamed:@"005-header.png"]];
    }
    
    
    
    else{
        [bgImageView setImage:[UIImage imageNamed:@"BG.png"]];
        
    }        NSLog(@"%@",objRLSampleAppDelegate.themeString);
    
    
    
    
    
    additem=[[NSMutableString alloc]init];
    
    [_Action_Indicator setHidden:YES];
    
    appDelegate.ProId=[dbh SelectProItem];
    appDelegate.myAdonIds=[dbh SelectAddItemID];
    
    
    [_TableMainScrollView setScrollEnabled:YES];
    arrQty=[[NSMutableArray alloc]init];
    
    
    [_TableMainScrollView setContentSize:CGSizeMake(320, 2200)];
    if(i==1)
    {
        forAddon=[[NSMutableString alloc]init];
        
        [forAddon appendFormat:@";%@",addon];
        [appDelegate.myAdonIds addObject:forAddon];
        NSLog(@"%@",appDelegate.myAdonIds);
        
        [appDelegate.ForAddonIds appendString:forAddon];
        [appDelegate.ForProduct appendString:product];
        NSLog(@"%@\n%@",appDelegate.ForAddonIds,appDelegate.ForProduct);
    }
    else{}
    
   
    
    
    mcell=[[[MainOrderCustomCell alloc]init]autorelease];
    
    [_MainScroll setScrollEnabled:YES];
    [_MainScroll setContentSize:CGSizeMake(320, 300)];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    DBDictionary=[[NSMutableDictionary alloc]init];
    marrSqlite=[[NSMutableArray alloc]init];
    dbh =[[DBHandler alloc]init];
    marrSqlite=[dbh selectinfo];
    float total=[[dbh SelectSUM]floatValue];
    //DBDictionary=[dbh selectinfo];
    NSLog(@"%@",marrSqlite);
    NSString *countOD=[dbh selectCount];
    _ItemLbl.text=[NSString stringWithFormat:@"%@",countOD];
    //_ItemLbl.text=[NSString stringWithFormat:@"%d",[marrSqlite count]];
    NSLog(@"%f",total);
    
    
    
    NSNumberFormatter *numberFormatter = [[[NSNumberFormatter alloc] init]autorelease];
    [numberFormatter setPositiveFormat:@"###0.##"];
    
    NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:total]];
    NSLog(@"formattedNumberString: %@", formattedNumberString);
    
     NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", total];
    
    
    
    _TotalLbl.text=formattedNumber;
    
    
    
    //[ mainScrollView:YES];
    [mainScrollView setContentSize:CGSizeMake(320, 200)];
    [mainOrderTable reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSLog(@"%@",marrSqlite);
    _TotalLbl.text=@"0";
    return [marrSqlite count];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 79;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static  NSString *cellIdentifier=@"MainOrderCustomCell";
    
    MainOrderCustomCell *cell = (MainOrderCustomCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell==nil)
    {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MainOrderCustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
        
    accessory = [UIButton buttonWithType:UIButtonTypeCustom];
    [accessory addTarget:self action:@selector(onCustomAccessoryPlusTapped:) forControlEvents:UIControlEventTouchUpInside];
    CGRect frame = CGRectMake(280 ,5, 40, 70);
   //[accessory setBackgroundImage:[UIImage imageNamed:@"+box.png"] forState:UIControlStateNormal];
    
    accessory.frame = frame;
    accessory.tag=indexPath.section;
    //cell.accessoryView = accessory;
    [cell addSubview:accessory];
    
    
    accessory1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [accessory1 addTarget:self action:@selector(onCustomAccessoryMinusTapped:) forControlEvents:UIControlEventTouchUpInside];
    CGRect frame1 = CGRectMake(220, 5,40, 70 );
    //[accessory1 setBackgroundImage:[UIImage imageNamed:@"-Box.png"] forState:UIControlStateNormal];
    
    accessory1.frame = frame1;
    accessory1.tag=indexPath.section;
    //cell.accessoryView = accessory1;
    [cell addSubview:accessory1];
    ////////////////
    [cell setFont:[UIFont fontWithName:@"Times New Roman" size:18.0]];
    NSArray *arr=[marrSqlite objectAtIndex:indexPath.section];
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    
    
    cell.OD_Id.text=[arr objectAtIndex:0];
    cell.TitleLbl.text=[arr objectAtIndex:2];
    cell.DiscriptionLbl.text=[arr objectAtIndex:3];
    cell.QuntityLbl.text=[arr objectAtIndex:5];
    cell.SubItemLbl.text=[arr objectAtIndex:7];
    cell.BottleQutntityLbl.text=[arr objectAtIndex:9];
   
    cell.TotalPriceLbl.text=[arr objectAtIndex:8];
    
   
    float f1=[cell.BottleQutntityLbl.text floatValue];
    float f2=[cell.TotalPriceLbl.text floatValue];
    myTotal=f1*f2+myTotal;
    
    
    NSLog(@"%@",[arr objectAtIndex:0]);
    
    
    NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
    [numberFormatter1 setPositiveFormat:@"###0.##"];
    
    NSString *formattedNumberString1 = [numberFormatter1 stringFromNumber:[NSNumber numberWithFloat:myTotal]];
    NSString* formattedNumberM = [NSString stringWithFormat:@"%.02f", myTotal];
    
    NSLog(@"formattedNumberString: %@", formattedNumberM);
    ////
    
 
    
    _TotalLbl.text=formattedNumberM;
    
    

    NSString *pri=[arr objectAtIndex:8];
    float finalamountp=[ pri floatValue];
    
    
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setPositiveFormat:@"###0.##"];
       
    NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalamountp];
    
    
    cell.TotalPriceLbl.text=formattedNumber;
    
    [cell.OD_Id setHidden:YES];
    
    NSLog(@"%@",[arr objectAtIndex:7]);
    
    if([[arr objectAtIndex:7] isEqualToString:@""]){
        
   
    }else
    {
     
        
        cell.withLabel.text=@"With";
    }
    
    
    return cell;
    
    
}


- (void)onCustomAccessoryPlusTapped:(UIButton *)sender {
    
    
    MainOrderCustomCell *cell = (MainOrderCustomCell *)sender.superview;
    
    
    
    //UITableViewCell *cell = (UITableViewCell *)sender.superview;
    NSIndexPath *indexPath = [mainOrderTable indexPathForCell:cell];
    
    // Now you can do the following
    [self tableView:mainOrderTable accessoryButtonTappedForRowWithIndexPath:indexPath];
    NSLog(@"%d",indexPath.section);
    NSLog(@"%@",cell.OD_Id.text);
    
    NSMutableArray *arr=[dbh SelectPrice:[NSString stringWithFormat:@"%@",cell.OD_Id.text]];
    NSLog(@"%@",arr);
    
    NSString *strPrice=[NSString stringWithFormat:@"%@",[arr objectAtIndex:0]];
    
    NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
    strPrice = [[strPrice componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
    
    temp=[strPrice floatValue];
    NSLog(@"%f",temp);
    
    // Or you can do something else here to handle the action
    bottleQnty=[cell.BottleQutntityLbl.text intValue];
    //temp=[cell.TotalPriceLbl.text floatValue];
    bottleQnty++;
    
    float finalTotal1=[_TotalLbl.text floatValue]+temp;
    
    NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
    [numberFormatter1 setPositiveFormat:@"###0.##"];
    
    NSString *formattedNumberString1 = [numberFormatter1 stringFromNumber:[NSNumber numberWithFloat:finalTotal1]];
     NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalTotal1];
    
    NSLog(@"formattedNumberString: %@", formattedNumberString1);
    ////
    
    _TotalLbl.text=formattedNumber;
    //[NSString stringWithFormat:@"%f",[objMainOrderViewController.TotalLbl.text floatValue]+temp];
    
    
    NSLog(@"%d",bottleQnty);
    cell.BottleQutntityLbl.text=[NSString stringWithFormat:@"%d",bottleQnty];
    NSLog(@"%@",cell.BottleQutntityLbl);
    
    NSLog(@"%@",cell.TotalPriceLbl);
    NSString *totalPrice=[NSString stringWithFormat:@"%@",cell.TotalPriceLbl.text];
    NSLog(@"%@",totalPrice);
    float finalTotal=[totalPrice floatValue]+temp;
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setPositiveFormat:@"###0.##"];
    
    NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalTotal]];
    NSLog(@"formattedNumberString: %@", formattedNumberString);
    
    
    
    //cell.TotalPriceLbl.text=formattedNumberString;
    
    
    NSLog(@"%@",cell.TotalPriceLbl.text);
    
    
    
    NSLog(@"%@",cell.BottleQutntityLbl.text);
    NSString *qty=[NSString stringWithFormat:@"%@",cell.BottleQutntityLbl.text];
    NSString *ind=[NSString stringWithFormat:@"%@",cell.OD_Id.text];
    
    arrQty=[[NSMutableArray alloc]initWithObjects:qty,cell.TotalPriceLbl.text,ind, nil];
    NSLog(@"%@",arrQty);
    appDelegate.MainOrderTotal=_TotalLbl.text;
    NSLog(@"%@",appDelegate.MainOrderTotal);
    [dbh UpadateTable:arrQty];
    
    
    marrSqlite=[dbh selectinfo];
    NSString *countOD=[dbh selectCount];
    _ItemLbl.text=[NSString stringWithFormat:@"%@",countOD];
    
    //[mainOrderTable reloadData];
    
    
}

- (void)onCustomAccessoryMinusTapped:(UIButton *)sender {
    
    MainOrderCustomCell *cell = (MainOrderCustomCell *)sender.superview;
    
    //UITableViewCell *cell = (UITableViewCell *)sender.superview;
    NSIndexPath *indexPath = [mainOrderTable indexPathForCell:cell];
    
    // Now you can do the following
    [self tableView:mainOrderTable accessoryButtonTappedForRowWithIndexPath:indexPath];
    NSLog(@"%d",indexPath.section);
    
    //temp=[cell.TotalPriceLbl.text floatValue];
    
    // Or you can do something else here to handle the action
    bottleQnty=[cell.BottleQutntityLbl.text intValue];
    
    if(bottleQnty==1)
    {
//        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"status" message:@"You have to select any one" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//        [alt show];
//        [alt release];
    }
    else
    {
                
        MainOrderCustomCell *cell = (MainOrderCustomCell *)sender.superview;
        
        
        
        //UITableViewCell *cell = (UITableViewCell *)sender.superview;
        NSIndexPath *indexPath = [mainOrderTable indexPathForCell:cell];
        
        // Now you can do the following
        [self tableView:mainOrderTable accessoryButtonTappedForRowWithIndexPath:indexPath];
        NSLog(@"%d",indexPath.section);
        NSLog(@"%@",cell.OD_Id.text);
        
        NSMutableArray *arr=[dbh SelectPrice:[NSString stringWithFormat:@"%@",cell.OD_Id.text]];
        NSLog(@"%@",arr);
        
        NSString *strPrice=[NSString stringWithFormat:@"%@",[arr objectAtIndex:0]];
        
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
        strPrice = [[strPrice componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        temp=[strPrice floatValue];
        NSLog(@"%f",temp);
        
        // Or you can do something else here to handle the action
        bottleQnty=[cell.BottleQutntityLbl.text intValue];
        //temp=[cell.TotalPriceLbl.text floatValue];
        bottleQnty--;
        
        float finalTotal1=[_TotalLbl.text floatValue]-temp;
        NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
        [numberFormatter1 setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString1 = [numberFormatter1 stringFromNumber:[NSNumber numberWithFloat:finalTotal1]];
        
        NSLog(@"formattedNumberString: %@", formattedNumberString1);
        ////
        myTotal=0;
        
        NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalTotal1];

        _TotalLbl.text=formattedNumber;
        //[NSString stringWithFormat:@"%f",[objMainOrderViewController.TotalLbl.text floatValue]+temp];
        
        
        NSLog(@"%d",bottleQnty);
        cell.BottleQutntityLbl.text=[NSString stringWithFormat:@"%d",bottleQnty];
        NSLog(@"%@",cell.BottleQutntityLbl);
        
        NSLog(@"%@",cell.TotalPriceLbl);
        NSString *totalPrice=[NSString stringWithFormat:@"%@",cell.TotalPriceLbl.text];
        NSLog(@"%@",totalPrice);
        float finalTotal=[totalPrice floatValue]-temp;
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalTotal]];
        NSLog(@"formattedNumberString: %@", formattedNumberString);
        
        
        NSLog(@"%@",cell.TotalPriceLbl.text);
     
        
        NSLog(@"%@",cell.BottleQutntityLbl.text);
        NSString *qty=[NSString stringWithFormat:@"%@",cell.BottleQutntityLbl.text];
        //      NSString *ind=[NSString stringWithFormat:@"%d",indexPath.section];
        NSString *ind=[NSString stringWithFormat:@"%@",cell.OD_Id.text];
        arrQty=[[NSMutableArray alloc]initWithObjects:qty,cell.TotalPriceLbl.text,ind, nil];
        NSLog(@"%@",arrQty);
        appDelegate.MainOrderTotal=_TotalLbl.text;
        NSLog(@"%@",appDelegate.MainOrderTotal);
        [dbh UpadateTable:arrQty];
        
        
        marrSqlite=[dbh selectinfo];
        [mainOrderTable reloadData];
        NSString *countOD=[dbh selectCount];
        _ItemLbl.text=[NSString stringWithFormat:@"%@",countOD];
        
    }
}

- (IBAction)IncreamentBottleQnty:(id)sender {
    
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Action" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{    
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
  
    
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // No editing style if not editing or the index path is nil.
    //if (self.editing == NO || !indexPath) return UITableViewCellEditingStyleNone;
    // Determine the editing style based on whether the cell is a placeholder for adding content or already
    // existing content. Existing content can be deleted.
    if (self.editing && indexPath.row == ([marrSqlite count]))
	{
		return UITableViewCellEditingStyleInsert;
	} else
	{
		return UITableViewCellEditingStyleDelete;
	}
    return UITableViewCellEditingStyleNone;
}

// Update the data model according to edit actions delete or insert.
- (void)tableView:(UITableView *)aTableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath
{
    MainOrderCustomCell *cell = (MainOrderCustomCell *)[mainOrderTable cellForRowAtIndexPath:indexPath];
    
    
    myTotal=0;
    
    if (editingStyle == UITableViewCellEditingStyleDelete)
	{
        
        [appDelegate.myAdonIds removeObjectAtIndex:indexPath.section];
        [appDelegate.ProId removeObjectAtIndex:indexPath.section];
        NSLog(@"%@",appDelegate.myAdonIds);
      
        [marrSqlite removeObjectAtIndex:indexPath.section];
        NSLog(@"%d",indexPath.section);
        NSLog(@"%@",cell.OD_Id.text);
        
        [dbh deleteOne:[NSString stringWithFormat:@"%@",cell.OD_Id.text]];
        [dbh deleteOnePrice:[NSString stringWithFormat:@"%@",cell.OD_Id.text]];
        
        float to=[_TotalLbl.text floatValue]-[cell.TotalPriceLbl.text floatValue];
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:to]];
        NSLog(@"formattedNumberString: %@", formattedNumberString);
        
        
          NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", to];
        
        _TotalLbl.text=[NSString stringWithFormat:@"%@",formattedNumber];
        NSString *countOD=[dbh selectCount];
        _ItemLbl.text=[NSString stringWithFormat:@"%@",countOD];
		[mainOrderTable reloadData];
    }
    else if (editingStyle == UITableViewCellEditingStyleInsert)
	{
        [marrSqlite insertObject:@"New Row" atIndex:[marrSqlite count]];
		[mainOrderTable reloadData];
    }
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)MSG_Method:(id)sender {
    
 messageInboxViewController  *objmessageInboxViewController=[[messageInboxViewController  alloc]initWithNibName:@"messageInboxViewController"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objmessageInboxViewController animated:YES];
    
    
}

-(IBAction)backButtonMethod:(id)sender{
    
   
    
    objAddPoductViewController.forValidation=0;
    objAddPoductViewController.forValidation1=0;
    
    
 MyFirstMenuViewController   *objMyFirstMenuViewController5  =[[MyFirstMenuViewController  alloc]initWithNibName:@"MyFirstMenuViewController5"bundle:nil];
    
     MyFirstMenuViewController   *objMyFirstMenuViewController4  =[[MyFirstMenuViewController  alloc]initWithNibName:@"MyFirstMenuViewController4"bundle:nil];
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
    
    
    [self.navigationController pushViewController:objMyFirstMenuViewController5 animated:YES];
    
    }else{
         [self.navigationController pushViewController:objMyFirstMenuViewController4 animated:YES];
        
    }
    
    
       objAddPoductViewController.TitleLabel.text=@"";
    objAddPoductViewController.CurrencySign.text=@"";
    //_DiscriptionLabel.text=@"":
    objAddPoductViewController.With.text=@"";
    objAddPoductViewController.DiscriptionLabel.text=@"";
    
    [objAddPoductViewController.self ButtonReload];
    [objAddPoductViewController.self AgainSizeBtnLoad];
    
    //Buttonproduct.png
    [self.view removeFromSuperview];
    
    
    
}

-(IBAction)mainScreenMethod:(id)sender
{
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
        ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
}

- (IBAction)CancelBackMethod:(id)sender {
    objAddPoductViewController.forValidation=0;
    appDelegate.OD_id=0;
    appDelegate.ForProduct=[[NSMutableString alloc]init];
    appDelegate.ForAddonIds=[[NSMutableString alloc]init];
    
    //[self dismissViewControllerAnimated:YES completion:nil];
    [dbh deleteall];
    [dbh deleteallPrice];
    //  marrSqlite=[dbh selectinfo];
    // [mainOrderTable reloadData];
    _TotalLbl.text=0;
    _ItemLbl.text=0;
    
    objAddPoductViewController.With.text=@"";
    objAddPoductViewController.DiscriptionLabel.text=@"";
    objAddPoductViewController.forValidation1=0;
    objAddPoductViewController.TitleLabel.text=@"";
    objAddPoductViewController.CurrencySign.text=@"";
    [objAddPoductViewController.self ButtonReload];
    [objAddPoductViewController.self AgainSizeBtnLoad];
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        objRLSampleViewController=[[ViewController  alloc]initWithNibName:@"ViewController"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController animated:YES];
        
        
    }else{
        
        ViewController  *objRLSampleViewController4=[[ViewController  alloc]initWithNibName:@"ViewController4"bundle:nil];
        [self.view removeFromSuperview];
        [self.navigationController pushViewController:objRLSampleViewController4 animated:YES];
        
    }
    
    
   
}


- (void)dealloc
{
    [_ItemLbl release];
    [_TotalLbl release];
    [_commentTextView release];
    [_MainScroll release];
    [_commentTextView release];
    [_TabImageView release];
    
    //[_mainOrderTable release];
    [_imgview1 release];
    
    [_TabBar release];
    
    [_TableScrollView release];
    
    [_TableMainScrollView release];
    [_HomeBtn release];
    [_MessageBtn release];
    [_Action_Indicator release];
    [_commentView release];
    [_orderSendView release];
    [_addview release];
    [_comfButton release];
    [super dealloc];
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text isEqualToString:@"\n"]) {
        [_commentTextView resignFirstResponder];
      //  [UIView beginAnimations:nil context:NULL];
        //[UIView setAnimationDuration:0.25];
        //self.view.frame = CGRectMake(0,20,320,548);
        //_TabImageView.frame=CGRectMake(0, 497, 320, 50);
        //[self.view addSubview:_TabImageView];
        //[_MainScroll setFrame:CGRectMake(0, 302, 320, 100)];
       // mainScrollView.frame=CGRectMake(0, 245, 320, 165);
        //_TableMainScrollView.frame=CGRectMake(0,110, 320, 195);
       // [mainOrderTable setHidden:NO];
        //[self.view addSubview:mainScrollView];
        
        
       // [UIView commitAnimations];
        
        return NO;
    }
    
    return YES;
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    //[UIView beginAnimations:nil context:NULL];
    //[UIView setAnimationDuration:0.25];
    //self.view.frame = CGRectMake(0,-278,320,548);
   // mainScrollView.frame=CGRectMake(0, 81, 320, 220);
    //_TabImageView.frame=CGRectMake(0, 200, 320, 44);
    //_TableMainScrollView.frame=CGRectMake(0, -50, 320, 195);
  //  [mainOrderTable setHidden:YES];
    
   /// [UIView commitAnimations];
    
}

- (IBAction)ConfirmOrderMethod:(id)sender {
    
   
    
    [_Action_Indicator setHidden:NO];
    [_Action_Indicator startAnimating];
    
    appDelegate.ProId=[dbh SelectProItem];
    NSLog(@"%@",appDelegate.ProId);
    NSString *proID=[NSString stringWithFormat:@"%@",appDelegate.ProId];
    NSCharacterSet *doNotWant11 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
    // NSString *strAddon=[NSString stringWithFormat:@"%@",[appDelegate.myAdonIds objectAtIndex:j]];
    proID = [[proID componentsSeparatedByCharactersInSet: doNotWant11] componentsJoinedByString: @""];
    NSLog(@"%@",proID);
    
    
    
    appDelegate.myAdonIds=[dbh SelectAddItemID];
    NSLog(@"%@",appDelegate.myAdonIds);
    for(int j=0;j<[appDelegate.myAdonIds count];j++)
    {
        NSCharacterSet *doNotWant1 = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
        NSString *strAddon=[NSString stringWithFormat:@"%@",[appDelegate.myAdonIds objectAtIndex:j]];
        strAddon = [[strAddon componentsSeparatedByCharactersInSet: doNotWant1] componentsJoinedByString: @""];
        
        [additem appendFormat:@";%@",strAddon];
        NSLog(@"%@",additem);
        
    }
    
    NSString *Pro=[NSString stringWithFormat:@"%@",appDelegate.ForProduct];
    NSString *ADDon=[NSString stringWithFormat:@"%@",appDelegate.ForAddonIds];
    
    if ([Pro length] > 0)
        Pro = [Pro substringToIndex:[Pro length] - 1];
    NSLog(@"%@",Pro);
    
    
    if(![additem isEqualToString:@""])
    {
        
        
        i=0;
        additem= [additem substringWithRange:NSMakeRange(1, [additem length]-1)];
        
        /////For Time Interval/////
        
        
        appDelegate.time=1;
        
        
      
        NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc] init];
        [dateFormatter2 setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
        
        NSString *todayTime1=[dateFormatter2 stringFromDate:[NSDate date]];
        NSLog(@"%@",todayTime1);
        
        NSArray *arrtime=[[NSArray alloc]initWithObjects:todayTime1, nil];
        [dbh deleteTime];
        
        [dbh insertTimeDate:arrtime];
        
        
        NSArray *arrdate=[[NSArray alloc]init];
        arrdate=[dbh selecttime];
        
        NSLog(@"%@",arrdate);
        NSLog(@"%@",[arrtime objectAtIndex:0]);
        
              
        
        
        NSLog(@"%@",ADDon);
        NSLog(@"%@",appDelegate.deviceToken);
        NSLog(@"%@",_commentTextView.text);
        NSLog(@"%@",_TotalLbl.text);
        NSLog(@"%@",_ItemLbl.text);
        NSString *MYDeviceToken=[NSString stringWithFormat:@"%@",appDelegate.deviceToken];
        
        NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
        MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
        NSLog(@"%@",MYDeviceToken);
        
        NSString *Product_id=[NSString stringWithFormat:@"%@",proID];
        NSString *addon_id=[NSString stringWithFormat:@"%@",additem];
        NSString *bar_id=@"6";
        NSString *zone_id=@"1";
        NSString *table_id=@"5";
        NSString *customer_name=@"Risk iOS";
        NSString *comment=[NSString stringWithFormat:@"%@",_commentTextView.text];
        NSString *total_price=[NSString stringWithFormat:@"%@",_TotalLbl.text];
        NSString *cust_device_type=@"2";
        NSString *cust_device_token=[NSString stringWithFormat:@"%@",MYDeviceToken];
        NSString *api_key=@"0";
        NSString *qty=[NSString stringWithFormat:@"%@",_ItemLbl.text];
        
        
        NSArray *qtyForpost=[[NSMutableArray alloc]init];
        qtyForpost=[dbh SelectQty];
        NSLog(@"%@",qtyForpost);
        
        NSString *strQty=[NSString stringWithFormat:@"%@",qtyForpost];
        NSCharacterSet *DoNot = [NSCharacterSet characterSetWithCharactersInString:@"()\"\n "];
        strQty = [[strQty componentsSeparatedByCharactersInSet: DoNot] componentsJoinedByString: @""];
        NSLog(@"%@",strQty);
        
        NSDictionary *mydict=[NSDictionary dictionaryWithObjectsAndKeys:Product_id,@"product_item_id",addon_id,@"addon_id",customer_name,@"customer_name",bar_id,@"bar_id",table_id,@"table_id",zone_id,@"zone_id",comment,@"comment",total_price,@"total_price",cust_device_type,@"cust_device_type",cust_device_token,@"cust_device_token",api_key,@"api_key",qty,@"qty", nil];
        
        NSLog(@"%@",mydict);
        
        NSString *MyRequest=[NSString stringWithFormat:@"product_item_id=%@&addon_id=%@&customer_name=%@&bar_id=%@&table_id=%@&zone_id=%@&comment=%@&total_price=%@&cust_device_type=%@&cust_device_token=%@&api_key=%@&qty=%@",Product_id,addon_id,customer_name,bar_id,table_id,zone_id,comment,total_price,cust_device_type,cust_device_token,api_key,strQty];
        
        
        NSLog(@"\n\nRequest: %@",MyRequest);
        
        
        NSURL *url = [NSURL URLWithString:@"http://www.bevond.com/ordavia/index.php/OrderDetailApi/insertOrder?"];
        
        NSLog(@"%@",url);
        //NSURL *url = [NSURL URLWithString:@"http://www.bevond.com/ordavia/index.php/OrderDetailApi/insertOrder?"];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:[MyRequest dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
        
        xmldata=[[NSMutableData alloc]init];
        [connection start];
        //[dbh deletealll];
        //marrSqlite=[dbh selectinfo];
        //[mainOrderTable reloadData];
        //_ItemLbl.text=@"";
        //_TotalLbl.text=@"";
        
        //appDelegate.ForProduct=[[NSMutableString alloc]init];
        //appDelegate.ForAddonIds=[[NSMutableString alloc]init];
        // [self.view removeFromSuperview];
        _orderSendView.hidden=NO; 
        
    }
    else{
          _comfButton.hidden=YES;
//       UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"We have stopped taking order by scanning please talk to the venues manager sorry for the inconvenience" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//       [alt show];
//      [alt release];
     
//      //  _addview.hidden=NO;
       // _comfButton.hidden=YES;
        
        [_Action_Indicator setHidden:YES];
        
    }
}




- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata1 appendData:data];
    
    NSLog(@"%@",xmldata1);
    
    [xmldata appendData:data];
    
    NSLog(@"%@",xmldata);
    
    str = [[NSString alloc] initWithData:xmldata1 encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
//    if([str isEqualToString:@"Successfull"])
//    {
    
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    
    [xml_parser parse];
    [xml_parser release];
    
   

    
    [_Action_Indicator stopAnimating];
    [_Action_Indicator setHidden:YES];
    
    
    objMyFirstMenuViewController=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController5" bundle:nil];
    
     MyFirstMenuViewController *objMyFirstMenuViewController4=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController4" bundle:nil];
    
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        [self.navigationController pushViewController:objMyFirstMenuViewController animated:YES];
        
         [self.view removeFromSuperview];

    }else{
        [self.navigationController pushViewController:objMyFirstMenuViewController4 animated:YES];
        
        [self.view removeFromSuperview];
    }
    
//    }else{
//        
//    }
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
    [alt release];
}


//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
//    if(alertView.tag==1)
//    {
//        
//        switch (buttonIndex) {
//                
//            case 0:
//                
//                objMyFirstMenuViewController=[[MyFirstMenuViewController alloc]initWithNibName:@"MyFirstMenuViewController" bundle:nil];
//                                [self.navigationController pushViewController:objMyFirstMenuViewController animated:YES];
//                
//           
//                
//                
//                break;
//                
//                
//            default:
//                
//                break;
//        }
//    }
//    
//}
- (IBAction)venuesMethod:(id)sender {
   
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        MapViewController *objmapViewController5=[[MapViewController  alloc]initWithNibName:@"MapViewController5"bundle:nil];
        [self.navigationController pushViewController:objmapViewController5 animated:YES];
        
        
    }
    else{
    
   MapViewController *objMapViewController4=[[MapViewController  alloc]initWithNibName:@"MapViewController4"bundle:nil];
    [self.view removeFromSuperview];
    [self.navigationController pushViewController:objMapViewController4 animated:YES];
        
    }
}

- (void)viewDidUnload {
    [self setCommentView:nil];
    [self setOrderSendView:nil];
    [self setAddview:nil];
    [self setComfButton:nil];
    [super viewDidUnload];
}

- (IBAction)upButtonMethod:(id)sender {

    _commentView.hidden=NO;
    [_commentTextView becomeFirstResponder];
   // [_commentTextView resignFirstResponder];
}

- (IBAction)downButtonMethod:(id)sender {
    
   [_commentTextView resignFirstResponder];
     _commentView.hidden=YES;
    
}
- (IBAction)okSendMethod:(id)sender {
    
    objAddPoductViewController.forValidation=0;
    objAddPoductViewController.forValidation1=0;
    
    
    MyFirstMenuViewController   *objMyFirstMenuViewController5  =[[MyFirstMenuViewController  alloc]initWithNibName:@"MyFirstMenuViewController5"bundle:nil];
    
    MyFirstMenuViewController   *objMyFirstMenuViewController4  =[[MyFirstMenuViewController  alloc]initWithNibName:@"MyFirstMenuViewController4"bundle:nil];
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    if (568 == screenBounds.size.height)
    {
        
        
        [self.navigationController pushViewController:objMyFirstMenuViewController5 animated:YES];
        
    }else{
        [self.navigationController pushViewController:objMyFirstMenuViewController4 animated:YES];
        
    }
    
    
    objAddPoductViewController.TitleLabel.text=@"";
    objAddPoductViewController.CurrencySign.text=@"";
    //_DiscriptionLabel.text=@"":
    objAddPoductViewController.With.text=@"";
    objAddPoductViewController.DiscriptionLabel.text=@"";
    
    [objAddPoductViewController.self ButtonReload];
    [objAddPoductViewController.self AgainSizeBtnLoad];
    
    //Buttonproduct.png
    [self.view removeFromSuperview];
    
}
-(IBAction)newbackMethod:(id)sender;
{
    [self.navigationController popViewControllerAnimated:YES];

}


@end
