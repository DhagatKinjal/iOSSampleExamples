//
//  messageInboxCustomcellCell.h
//  ordavia
//
//  Created by mac on 6/20/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface messageInboxCustomcellCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UILabel *BarNameLBL;
@property (retain, nonatomic) IBOutlet UILabel *MSGDiscLBL;
@property (retain, nonatomic) IBOutlet UILabel *TimeLbl;
@property (retain, nonatomic) IBOutlet UILabel *B_id;
@property(retain ,nonatomic)IBOutlet UILabel *orderid;
@end
