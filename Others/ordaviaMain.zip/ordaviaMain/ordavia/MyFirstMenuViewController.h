//
//  MyFirstMenuViewController.h
//  ordavia
//
//  Created by mac on 6/17/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler.h"
#import "AppDelegate.h"
@interface MyFirstMenuViewController : UIViewController
{
    NSString *MyUrlID1;
    NSString *currentElementValue;
	NSMutableString *CurrentText;
    NSString *str;
    AppDelegate *appDelegate;
    DBHandler *dbh;
    NSMutableArray *CategoryName,*CategoryId,*Themeid,*logoId;
    NSMutableString *output;
    NSMutableString *lstring;
    NSXMLParser *xml_parser;
    NSMutableData *xmldata;
    NSMutableArray *statsid;
    NSURLRequest *req;
    NSURLConnection *conn;
    NSMutableDictionary *dics;
    NSURL *url;
    NSURL *url11;
    NSString *arrString;
   
}
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Active2;
@property (retain, nonatomic) IBOutlet UIImageView *LogoImgView;
@property (retain, nonatomic) IBOutlet UIView *singOutView;
- (IBAction)singoutOkButtonMethod:(id)sender;
- (IBAction)singOutCancelMethod:(id)sender;

- (IBAction)SignOut:(id)sender;
- (IBAction)MyOrderMethod:(id)sender;
- (IBAction)MSG_Method:(id)sender;
- (IBAction)MainScreenMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Active;
@property (retain, nonatomic) IBOutlet UIImageView *TabView;
- (IBAction)BackButton:(id)sender;
@property (retain, nonatomic) NSString *MyUrlID1;
@property (retain, nonatomic) IBOutlet UITableView *scanHistoryTable;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Action_Indicator;
@property(nonatomic,retain)IBOutlet UIImageView *bgImageView;
@property(nonatomic,retain)IBOutlet UIImageView *headerImageView;
@property(nonatomic,retain)IBOutlet UIImageView *logoimgview;

@end
