//
//  MainOrderViewController.h
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler.h"
#import "AppDelegate.h"
@interface MainOrderViewController : UIViewController<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate,UITextViewDelegate,UITextFieldDelegate,UITabBarDelegate,NSXMLParserDelegate,UIAlertViewDelegate>{
    
    float myTotal;
    NSString *str;
    float temp;
    int bottleQnty;
    int Reorder;
    NSMutableString *additem;
    UIButton *accessory ;
    UIButton *accessory1 ;
    AppDelegate *appDelegate;
    DBHandler *dbh;
    NSMutableArray *marrSqlite;
    NSMutableDictionary *DBDictionary;
    NSXMLParser *xml_parser,*xml_parser1;
    NSMutableData *xmldata,*xmldata1;
    
    NSMutableString *addon;
    NSMutableString *product;
    NSMutableString *forAddon;
    NSMutableArray *Array;
    NSMutableArray *arrQty;
    UIButton *Cellbutton;
}
- (IBAction)okSendMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *orderSendView;
- (IBAction)upButtonMethod:(id)sender;
- (IBAction)downButtonMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UIView *commentView;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *Action_Indicator;
@property (retain, nonatomic) IBOutlet UIButton *HomeBtn;
@property (retain, nonatomic) IBOutlet UIView *addview;
@property (retain, nonatomic) IBOutlet UIButton *MessageBtn;
@property(retain,nonatomic) IBOutlet UIImageView *bgImageView;
@property(retain,nonatomic) IBOutlet UIImageView *headerImageView;

@property(retain, nonatomic) NSMutableString *addon;
@property(retain, nonatomic) NSMutableString *product;
@property(nonatomic)int i;
@property(nonatomic)int Reorder;
@property (retain, nonatomic) IBOutlet UIScrollView *TableMainScrollView;

- (IBAction)IncreamentBottleQnty:(id)sender;

@property (retain, nonatomic) IBOutlet UIScrollView *TableScrollView;

- (IBAction)ConfirmOrderMethod:(id)sender;
- (IBAction)venuesMethod:(id)sender;

@property (retain, nonatomic) IBOutlet UITabBar *TabBar;
@property (retain, nonatomic) IBOutlet UIImageView *img1;
@property (retain, nonatomic) IBOutlet UIScrollView *CommentScrollView;
@property (retain, nonatomic) IBOutlet UIButton *comfButton;
@property (retain, nonatomic) NSMutableArray *marrSqlite;
@property (retain, nonatomic) IBOutlet UIImageView *TabImageView;
@property (retain, nonatomic) IBOutlet UITextView *commentTextView;
@property (retain, nonatomic) IBOutlet UIScrollView *MainScroll;

- (IBAction)MenuMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *ItemLbl;
- (IBAction)CancelBackMethod:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *TotalLbl;

@property(nonatomic,retain)IBOutlet UITableView *mainOrderTable;
@property(nonatomic,retain)IBOutlet UIButton *backButton;
@property(nonatomic,retain)IBOutlet UIButton *cancelButton;
@property (retain, nonatomic) IBOutlet UIImageView *imgview1;

@property(nonatomic,retain)IBOutlet UIScrollView *mainScrollView;
- (IBAction)MSG_Method:(id)sender;

-(IBAction)backButtonMethod:(id)sender;
-(IBAction)mainScreenMethod:(id)sender;
-(IBAction)menuSreenMethod:(id)sender;
-(IBAction)newbackMethod:(id)sender;
@end
