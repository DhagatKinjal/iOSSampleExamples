//
//  DisplayMap.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "DisplayMap.h"

@implementation DisplayMap
@synthesize coordinate,title,subtitle;


-(void)dealloc{
	[title release];
    [subtitle release];
	[super dealloc];
}
@end
