//
//  CheckXMLParser.m
//  ordavia
//
//  Created by mac on 6/18/13.
//  Copyright (c) 2013 Credencys. All rights reserved.
//

#import "CheckXMLParser.h"
#import "productViewController.h"
#import "ViewController.h"
//@implementation CheckXMLParser

//@end
///


#import "AppDelegate.h"
//#import "Book.h"

@implementation CheckXMLParser
@synthesize AddOnName,AddonId,AddOnPrice,myid,myurl1,i;
ViewController *objRLSampleViewController;

- (CheckXMLParser *) initXMLParser {
	
	[super init];
	
	appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.addonID=[NSArray arrayWithArray:AddonId];
    appDelegate.addonName=[NSArray arrayWithArray:AddOnName];
    appDelegate.addonPrice=[NSArray arrayWithArray:AddOnPrice];
    
    
    
    
    //NSURL *url = [[NSURL alloc] initWithString:@"http://10.1.1.17/ordavia/index.php/ProductItemApi/getProductItemAddon?product_id=1"];
	
    
	
	return self;
}
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    currentElementValue=nil;
    CurrentText=nil;
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
	attributes:(NSDictionary *)attributeDict {
    
	if([elementName isEqualToString:@"xml"]) {
		//Initialize the array.
        CurrentParentId=[[NSMutableArray alloc]init];
        CurrentName=[[NSMutableArray alloc]init];
        CurrentProductId=[[NSMutableArray alloc]init];
        ProductId=[[NSMutableArray alloc]init];
        ProductName=[[NSMutableArray alloc]init];
        output=[[NSMutableString alloc]init];
        
		
	}
	else if([elementName isEqualToString:@"parent_cat_id"] || [elementName isEqualToString:@"cat_id"]||[elementName isEqualToString:@"cat_name"])
    {
		
		//Initialize the book.
		//aBook = [[Book alloc] init];
		
		//Extract the attribute here.
		//aBook.bookID = [[attributeDict objectForKey:@"id"] integerValue];
        //aBook.name=[attributeDict objectForKey:@"name"];
		currentElementValue=elementName;
        CurrentText=[[NSMutableString alloc]init];
		//NSLog(@"Reading id value :%i", aBook.bookID);
	}
	
	NSLog(@"Processing Element: %@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	
    
	if(!CurrentText)
		CurrentText = [[NSMutableString alloc] initWithString:string];
	else
		[CurrentText appendString:string];
	
	NSLog(@"Processing Value: %@", CurrentText);
    
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
	
    if([elementName isEqualToString:@"xml"])
    {
        
    }
	
	if([elementName isEqualToString:@"parent_cat_id"]) {
        
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [CurrentParentId addObject:arr];
        [output appendString:CurrentText];
        
		//[appDelegate.books addObject:aBook];
		
		
	}
    else if([elementName isEqualToString:@"cat_name"])
    {
        NSArray *arr=[NSArray arrayWithObjects:CurrentText, nil];
        
        [CurrentName addObject:arr];
        [output appendString:CurrentText];
        //[appDelegate.subbooks1 addObject:aBook];
		
    }
    //    else if([elementName isEqualToString:@"cat_id"])
    //    {
    //        NSArray *arr=[[NSArray alloc]initWithObjects:CurrentText, nil];
    //        [CurrentProductId addObject:arr];
    //        [output appendString:CurrentText];
    //        //[appDelegate.subbooks1 addObject:aBook];
    //
    //    }
    //    else if([elementName isEqualToString:@"product_name"])
    //    {
    //        NSArray *arr=[[NSArray alloc]initWithObjects:CurrentText, nil];
    //        [ProductName addObject:arr];
    //        [output appendString:CurrentText];
    //        //[appDelegate.subbooks1 addObject:aBook];
    //
    //    }
    //    else if([elementName isEqualToString:@"product_id"])
    //    {
    //        NSArray *arr=[[NSArray alloc]initWithObjects:CurrentText, nil];
    //        [ProductId addObject:arr];
    //        [output appendString:CurrentText];
    //
    //
    //
    //        //[self presentViewController:objproductViewController animated:YES completion:nil];
    //
    //
    //        //[appDelegate.subbooks1 addObject:aBook];
    //
    //    }
    //
    
    
    
   	
	[CurrentText release];
	CurrentText=nil;
}
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    
    //        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:output delegate:self cancelButtonTitle:@"OK..!" otherButtonTitles: nil];
    //        [alt show];
    //        [alt release];
    
    
    if([output isEqualToString:@""])
    {
        
        i=1;
        
        
    }
    
    
}

- (void) dealloc {
	
	[aBook release];
	[currentElementValue release];
	[super dealloc];
}

@end
