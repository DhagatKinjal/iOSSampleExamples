//
//  AppDelegate.h
//  admobDemo
//
//  Created by sxt on 12-1-7.
//  Copyright (c) 2012年 Jinlong Wei. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
