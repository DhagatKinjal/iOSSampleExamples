//
//  ViewController.h
//  admobDemo
//
//  Created by sxt on 12-1-7.
//  Copyright (c) 2012年 Jinlong Wei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GADBannerView.h"

@interface ViewController : UIViewController{
    GADBannerView *bannerView_;//实例变量 bannerView_是一个view
}

@end
