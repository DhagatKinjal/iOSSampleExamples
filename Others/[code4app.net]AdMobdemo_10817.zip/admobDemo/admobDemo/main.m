//
//  main.m
//  admobDemo
//
//  Created by sxt on 12-1-7.
//  Copyright (c) 2012年 Jinlong Wei. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
