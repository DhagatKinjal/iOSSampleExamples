RecipeSegmentControlDemo
========================

A demo project that demonstrates how to create a Jamie's Recipes style segment control.

You can find out more about this project on my blog at: http://iappexperience.com/post/24152562752/segment.

![picture](http://cl.ly/141N322V3l0w1I1M2B39/SegmentControlInAction.png)
