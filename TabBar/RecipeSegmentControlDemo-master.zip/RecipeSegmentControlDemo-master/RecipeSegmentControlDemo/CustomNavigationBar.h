//
//  CustomNavigationBar.h
//  RecipeSegmentControlDemo
//
//  Created by Derek Yang on 05/31/12.
//  Copyright (c) 2012 Derek Yang. All rights reserved.
//



@interface CustomNavigationBar : UINavigationBar

@end
