//
//  UIViewController+CMTabBarController.h
//
//  Created by Constantine Mureev on 3/15/12.
//  Copyright (c) 2012 Team Force LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CMTabBarController.h"

@interface UIViewController (CMTabBarController)

@property (readonly) CMTabBarController*    customTbBarController;

@end
