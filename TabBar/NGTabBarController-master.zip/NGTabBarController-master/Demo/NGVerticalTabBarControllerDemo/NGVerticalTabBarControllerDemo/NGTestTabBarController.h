//
//  NGTestTabBarController.h
//  NGVerticalTabBarControllerDemo
//
//  Created by Tretter Matthias on 24.04.12.
//  Copyright (c) 2012 NOUS Wissensmanagement GmbH. All rights reserved.
//

#import "NGTabBarController.h"

@interface NGTestTabBarController : NGTabBarController

@end
