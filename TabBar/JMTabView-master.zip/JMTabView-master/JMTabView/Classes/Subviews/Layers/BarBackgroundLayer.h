//  Created by Jason Morrissey

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface BarBackgroundLayer : CALayer

@end
