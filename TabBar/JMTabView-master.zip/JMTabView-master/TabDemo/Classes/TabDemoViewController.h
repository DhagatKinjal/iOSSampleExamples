//  Created by Jason Morrissey

#import <Foundation/Foundation.h>
#import <JMTabView/JMTabView.h>

@interface TabDemoViewController : UIViewController <JMTabViewDelegate>

@end
