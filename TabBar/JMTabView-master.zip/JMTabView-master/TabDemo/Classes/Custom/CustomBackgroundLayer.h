//  Created by Jason Morrissey

#import <QuartzCore/QuartzCore.h>
#import <Foundation/Foundation.h>

@interface CustomBackgroundLayer : CALayer {
    
}

@end
