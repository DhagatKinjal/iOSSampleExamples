//  Created by Jason Morrissey

#import <JMTabView/JMTabView.h>

@interface CustomSelectionView : JMSelectionView

+ (CustomSelectionView *) createSelectionView;

@end
