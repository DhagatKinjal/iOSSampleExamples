//
//  MKHorizMenuDemoAppDelegate.h
//  MKHorizMenuDemo
//
//  Created by Mugunth on 26/04/11.
//  Copyright 2011 Steinlogic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKHorizMenuDemoAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end
