//
//  UIView+CulturedInspiration.h
//  concierge
//
//  Created by Brendan Dixon on 2/20/11.
//  Copyright 2011 cultured inspiration. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface UIView(CulturedInspiration)

- (void)removeSubviews;

@end
