//
//  LSMultiTabDemoViewController_Notifications.m
//  LSTabs
//
//  Created by Marco Mussini on 26/6/12.
//  Copyright (c) 2011 Lucky Software. All rights reserved.
//

#import "LSMultiTabDemoViewController_Notifications.h"


NSString *const LSMultiTabViewDidUnloadNotification  = @"LSMultiTabViewDidUnloadNotification";
NSString *const LSMultiTabViewWillAppearNotification = @"LSMultiTabViewWillAppearNotification";
