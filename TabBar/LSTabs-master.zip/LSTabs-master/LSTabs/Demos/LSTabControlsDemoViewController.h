//
//  LSTabControlsDemoViewController.h
//  LSTabs
//
//  Created by Marco Mussini on 6/18/12.
//  Copyright (c) 2012 Lucky Software. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DemoViewControllerProtocol.h"


@interface LSTabControlsDemoViewController : UIViewController <DemoViewControllerProtocol>

@end
