//
//  InnerTabControl.h
//  LSTab
//
//  Created by Marco Mussini on 26/6/12.
//  Copyright (c) 2012 Lucky Software. All rights reserved.
//

#import "MultiTabControl.h"


/**
 * It is basically the same as CustomTabControl but uses different textcolor
 */
@interface InnerTabControl : MultiTabControl

@end
