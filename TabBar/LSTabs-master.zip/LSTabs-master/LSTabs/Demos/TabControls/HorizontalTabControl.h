//
//  HorizontalTab.h
//  LSTabs
//
//  Created by Marco Mussini on 22/6/12.
//  Copyright (c) 2012 Lucky Software. All rights reserved.
//

#import "LSTabControl.h"


@interface HorizontalTabControl : LSTabControl

@end
