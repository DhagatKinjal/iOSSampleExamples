//
//  ColorPickerBackgroundView.h
//  LSTabs
//
//  Created by Marco Mussini on 18/06/12.
//  Copyright (c) 2012 Lucky Software. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ColorPickerBackgroundView : UIView

@end
