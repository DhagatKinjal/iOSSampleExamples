//
//  DemoViewControllerProtocol.h
//  LSTabs
//
//  Created by Marco Mussini on 1/8/13.
//  Copyright (c) 2013 Lucky Software. All rights reserved.
//

@protocol DemoViewControllerProtocol <NSObject>

@required
+ (NSString *)viewTitle;

@end