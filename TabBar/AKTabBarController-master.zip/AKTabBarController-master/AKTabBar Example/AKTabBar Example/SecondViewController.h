//
//  SecondViewController.h
//  AKTabBar Example
//
//  Created by Ali KARAGOZ on 04/05/12.
//  Copyright (c) 2012 Ali Karagoz. All rights reserved.
//

#import "ContentViewController.h"

@interface SecondViewController : ContentViewController

@end
