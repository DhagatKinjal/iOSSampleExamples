![](https://github.com/fictorial/BHTabBar/raw/master/Docs/screenshot.png)
