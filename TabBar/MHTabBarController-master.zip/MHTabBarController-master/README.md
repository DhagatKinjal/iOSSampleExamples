# MHTabBarController

This is a custom container view controller for iOS 5 that works just like a regular UITabBarController, except the tabs are at the top and look different.

![Screenshot](https://github.com/hollance/MHTabBarController/raw/master/Screenshot.png)
 
To customize the tab bar's appearance you currently have to mess around in the code a bit.
 
The MHTabBarController source code is copyright 2011-2012 Matthijs Hollemans and is licensed under the terms of the MIT license.
