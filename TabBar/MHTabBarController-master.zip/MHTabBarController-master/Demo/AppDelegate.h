
#import "MHTabBarController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, MHTabBarControllerDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
