***NOTICE: I do not have time to support this project nor do I have time to help you with it. Sorry!***

***Please feel feee to update this project and submit a pull request! I am glad to review any changes and keep this alive. Alas, I do not have enough time to support it.***

TBTabBar
=============
Based off of the custom UITabBar from TweetBot by TapBots

![](http://i.imgur.com/qYzEr.png)
