//
//  RootViewController.h
//  FlickTabControlDemo
//
//  Created by Shaun Harrison on 2/11/09.
//  Copyright enormego 2009. All rights reserved.
//

#import "FlickTabControl.h"

@interface RootViewController : FlickTableViewController {
}

@end
