//
//  SecondViewController.h
//  LeveyTabBarDemo
//
//  Created by zhang on 12-10-10.
//  Copyright (c) 2012年 jclt. All rights reserved.
//
//

#import <UIKit/UIKit.h>


@interface SecondViewController : UIViewController {

}

@end
