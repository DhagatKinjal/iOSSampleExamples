#### [iDevRecipes](http://idevrecipes.com/)
iOS developers sometimes look at iPhone and iPad apps and wonder: _How did they do that?_

This is the source for the iDevRecipes blog where we re-create interesting features and user interfaces of iOS apps
