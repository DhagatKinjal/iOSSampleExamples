BrowserTabView

The BrowserTabView is a browser-style tabview controller looks like the Dolphin Browser,you can add or remove tab dynamically,and it also support panning and dragging  ,you can exchange tab positions.It gives you a overlapping-look tabview and displays the tabs by rendering images, so if you want to do some custom, simply replace these images.  
I also want to thanks Denis Lebedev(https://github.com/garnett) for his great work and idea, added ARC surport ,bug fixed,and possibility to rename tabs after long press, etc.

License

MIT. Copyright 2012 xiao haibo.
 

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

ScreenShot

<img src="https://raw.github.com/xxhp/BrowserTabViewDemo/master/screen2.png">
