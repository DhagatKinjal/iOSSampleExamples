//
//  ChinaViewController.m
//  NotificationDemo
//
//  Created by 王松 on 12-7-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//	EMail：342528568@qq.com
//	Tel:18761642621

#import "ChinaViewController.h"
#import "HubeiViewController.h"

@interface ChinaViewController ()

@end

@implementation ChinaViewController


- (IBAction)btPressed:(id)sender{
	//向通知中心发送消息
	[[NSNotificationCenter defaultCenter] postNotificationName:@"wangsong" object:nil];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	//设置通知中心
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(test:) 
												 name:@"wangsong" object:nil];
	
	//在navigationBar右方加上一个button
	UIBarButtonItem *navRightButton = [[UIBarButtonItem alloc] initWithTitle:@"下一页" style:UIBarButtonItemStylePlain target:self action:@selector(nextPage:)];
	
	[self.navigationItem setRightBarButtonItem:navRightButton];
	
	[self.navigationItem setTitle:@"首页"];
	
}

//进入下一个视图
- (void)nextPage:(id)sender{
	
	HubeiViewController *hubeiViewController = [[HubeiViewController alloc] init];
	[self.navigationController pushViewController:hubeiViewController animated:YES];
}

//通知中心接受到消息后，响应该方法
- (void)test:(NSNotification*)notify{
	
	NSString *testString = @"Test Notification!";
	
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"NotificationCentre" 
														message:testString 
													   delegate:nil 
											  cancelButtonTitle:@"OK"
											  otherButtonTitles:nil];
	[alertView show];
	
	
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
