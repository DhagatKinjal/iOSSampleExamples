//
//  AppDelegate.h
//  NotificationDemo
//
//  Created by 王松 on 12-7-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//	EMail：342528568@qq.com
//	Tel:18761642621

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
	
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (strong, nonatomic) UITabBarController *tabBarController;

@end
