//
//  ViewController.m
//  NotificationDemo
//
//  Created by 王松 on 12-7-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "HubeiViewController.h"
#import "ChinaViewController.h"
@interface ViewController ()

@end

@implementation ViewController
@synthesize tabBar;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(test) 
												 name:@"wangsong" object:nil];	

	
    tabBar = [[UITabBarController alloc] init];
	
//    tabBar.delegate = self;
	
	HubeiViewController *hubeiViewController = [[HubeiViewController alloc] init];
	
    ChinaViewController *chinaViewController = [[ChinaViewController alloc] init];  
	
    NSArray *viewControllerArray = [NSArray arrayWithObjects:chinaViewController,hubeiViewController,nil];
	
    tabBar.viewControllers = viewControllerArray;  
	
    tabBar.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
	
    [self.view addSubview:tabBar.view]; 
	
    [viewControllerArray release];  
}

- (void)test{
	
	NSLog(@"Test Notification!");
	
}

- (IBAction)btPressed{
	
	[[NSNotificationCenter defaultCenter] postNotificationName:@"wangsong" object:nil];
	
}

- (IBAction)hubeiPressed:(id)sender{
	UIViewController *hubeiViewController = [[[HubeiViewController alloc] initWithNibName:
											  @"HubeiViewController" bundle:nil]autorelease];
	[self presentModalViewController:hubeiViewController animated:YES];
}

- (void)tabBar:(UITabBar *)tabbar didSelectItem:(UITabBarItem *)item{
	
	if (0 == item.tag) {
		UIViewController *chinaViewController = [[[ChinaViewController alloc] initWithNibName:
												  @"ChinaViewController" bundle:nil]autorelease];
		[self presentModalViewController:chinaViewController animated:YES];
	}
	else if (1 == item.tag) {
		UIViewController *hubeiViewController = [[[HubeiViewController alloc] initWithNibName:
												  @"HubeiViewController" bundle:nil]autorelease];
		[self presentModalViewController:hubeiViewController animated:YES];
	}
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
	self.tabBar = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
