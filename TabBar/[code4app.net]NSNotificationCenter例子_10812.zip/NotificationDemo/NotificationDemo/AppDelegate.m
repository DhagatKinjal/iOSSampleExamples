//
//  AppDelegate.m
//  NotificationDemo
//
//  Created by 王松 on 12-7-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//	EMail：342528568@qq.com
//	Tel:18761642621

#import "AppDelegate.h"

#import "ViewController.h"
#import "HubeiViewController.h"
#import "ChinaViewController.h"

@implementation AppDelegate

@synthesize window = _window;
@synthesize viewController = _viewController;
@synthesize tabBarController;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	
	
	tabBarController = [[UITabBarController alloc] init];

	ChinaViewController* vc1 = [[ChinaViewController alloc] init];	
	
	HubeiViewController* vc2 = [[HubeiViewController alloc] init];
	
	//每一个tabBarItem添加一个navigation
	UINavigationController *navController1 = [[UINavigationController alloc] initWithRootViewController:vc1];
	
	navController1.navigationBar.tintColor = [UIColor redColor];
	
	UINavigationController *navController2 = [[UINavigationController alloc] initWithRootViewController:vc2];
	
	navController2.navigationBar.tintColor = [UIColor blueColor];
	
	//tabBar设置标签名	
	UITabBarItem *customItem1 = [[UITabBarItem alloc] initWithTitle:@"学习" image:nil tag:0];
	
	UITabBarItem *customItem2 = [[UITabBarItem alloc] initWithTitle:@"书签" image:nil tag:1];
	
	customItem1.badgeValue = @"550";
	
	navController1.tabBarItem = customItem1;
	
	navController2.tabBarItem = customItem2;
	
	//将navigation添加到tabBar中	
	NSArray* controllers = [NSArray arrayWithObjects:navController1, navController2, nil];
	
	tabBarController.viewControllers = controllers;
	
	
	[self.window addSubview:tabBarController.view];
	
	[self.window makeKeyAndVisible];
	
	
	return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
