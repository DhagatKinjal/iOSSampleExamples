//
//  ViewController.h
//  NotificationDemo
//
//  Created by 王松 on 12-7-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITabBarDelegate>{
	
	UITabBarController *tabBar;

}

@property(nonatomic, strong) IBOutlet UITabBarController *tabBar;

- (IBAction)btPressed;
- (IBAction)hubeiPressed:(id)sender;

@end
