//
//  HubeiViewController.m
//  NotificationDemo
//
//  Created by 王松 on 12-7-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//	EMail：342528568@qq.com
//	Tel:18761642621

#import "HubeiViewController.h"

@interface HubeiViewController ()

@end

@implementation HubeiViewController

- (IBAction)btPressed{
	//向通知中心发送消息，因为注册中心是全局的，所以可以向其他类发送注册消息
	[[NSNotificationCenter defaultCenter] postNotificationName:@"wangsong" object:nil];
	
}

//也可以通过实现init方式来改变tabBar的item
//-(id)init {  
//	if ([super init] != nil) {  
//		UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:@"Hubei" image:nil tag:1];  
//		self.tabBarItem = item;  
//		[item release];  
//	}  
//	return self;  
//}  

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
