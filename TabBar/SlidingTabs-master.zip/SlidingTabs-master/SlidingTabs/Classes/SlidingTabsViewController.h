//
//  SlidingTabsViewController.h
//  SlidingTabs
//
//  Created by Mathew Piccinato on 5/12/11.
//  Copyright 2011 Constructt. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingTabsControl.h"

@interface SlidingTabsViewController : UIViewController <SlidingTabsControlDelegate> {
    
}

@end
