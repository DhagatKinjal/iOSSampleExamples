# A simple example of sliding tabs for the iPhone

Was inspired to make this after using the Gowalla iPhone app.

Initial code base came from iDevRecipes Custom Segmented Control.


