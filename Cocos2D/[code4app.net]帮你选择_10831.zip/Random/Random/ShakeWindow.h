//
//  ShakeWindow.h
//  Random
//
//  Created by quentin on 12-12-14.
//
//

#import <UIKit/UIKit.h>

@interface ShakeWindow : UIWindow

@end
