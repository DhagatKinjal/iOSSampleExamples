//
//  ShakeLayer.h
//  Random
//
//  Created by quentin on 12-12-14.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"



@interface ShakeLayer : CCLayer{
    
}
+(CCScene *)scene;
@end
