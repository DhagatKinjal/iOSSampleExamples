//
//  BulletSpirte.m
//  specialBullet
//
//  Created by jiangyu on 13-1-10.
//  Copyright 2013年 __MyCompanyName__. All rights reserved.
//

#import "BulletSpirte.h"


@implementation BulletSpirte

static inline CGFloat bezierat( float a, float b, float c, float d, ccTime t )
{
	return (powf(1-t,3) * a +
			3*t*(powf(1-t,2))*b +
			3*powf(t,2)*(1-t)*c +
			powf(t,3)*d );
}


-(void)update:(ccTime)delta{
        CGFloat xa = 0;
        CGFloat xb = config_. controlPoint_1.x;
        CGFloat xc = config_.controlPoint_2.x;
        CGFloat xd = config_.endPosition.x;
    
    
        CGFloat ya = 0;
        CGFloat yb = config_.controlPoint_1.y;
        CGFloat yc = config_.controlPoint_2.y;
        CGFloat yd = config_.endPosition.y;
    
        CGFloat x = bezierat(xa, xb, xc, xd, 1);
        CGFloat y = bezierat(ya, yb, yc, yd, 1);
        
        [self setPosition: ccpAdd(self.position, ccpMult( ccpNormalize( ccp(x,y)),12))];
//
    if (self.position.y>=480) {
        [self removeFromParentAndCleanup:YES];
    }
}

+(id)initWithBezierConfig:(ccBezierConfig)config StartPos:(CGPoint)startPosT{
    return [[[self alloc]initWithBezierConfig:config StartPos:startPosT]autorelease];
}

-(id)initWithBezierConfig:(ccBezierConfig)config StartPos:(CGPoint)startPosT{
    
    self  = [super initWithFile:@"dl_pe_a_071.png"];
    if (self) {
        self.position = startPosT;
        startPos = startPosT;
        config_ = config;
        
        config_.controlPoint_1 = ccpSub(config_.controlPoint_1, startPos);
        config_.controlPoint_2 = ccpSub(config_.controlPoint_2, startPos);
        
        config_.endPosition = ccpSub(config_.endPosition, startPos);
    }
    return self;
}

-(id)initWithFile:(NSString *)filename{
    self  = [super initWithFile:@"dl_pe_a_071.png"];
    if (self) {
        
    }
    return self;
}

-(void)onEnter{
    [super onEnter];
    [self scheduleUpdate];
}

@end
