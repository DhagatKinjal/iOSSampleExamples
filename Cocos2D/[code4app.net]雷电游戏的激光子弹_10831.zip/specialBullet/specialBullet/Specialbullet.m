//
//  Specialbullet.m
//  specialBullet
//
//  Created by jiangyu on 12-12-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "Specialbullet.h"


@implementation Specialbullet

-(void) update:(ccTime)delta{
    intervial +=delta;
    if (intervial>0.3 && !streak.visible) {
        streak.visible = YES;
    }else{
    sprite.position = ccpAdd(sprite.position, ccpMult(velocity,8));
//    if (!CGRectContainsPoint(screenRect, sprite.position)) {
//        CGPoint veloc = ccpSub(sprite.position, startPos);
//        velocity = ccpNormalize(veloc);
//        if (self.position.x<=0 || sprite.position.x>=screenRect.size.width) {
//            velocity = ccp(velocity.x*-1, velocity.y);
//        }
//        if (sprite.position.y<=0 || sprite.position.y>=screenRect.size.height) {
//            velocity = ccp(velocity.x, velocity.y*-1);
//        }
//        startPos = sprite.position;
//    }
//    streak.position = sprite.position;
    if (!CGRectContainsPoint(screenRect, sprite.position)) {
        CGPoint veloc = ccpSub(sprite.position, startPos);
        velocity = ccpNormalize(veloc);
        if (sprite.position.x<=0 || sprite.position.x>=screenRect.size.width) {
            velocity = ccp(velocity.x*-1, velocity.y);
        }
        if (sprite.position.y<=0 || sprite.position.y>=screenRect.size.height) {
            velocity = ccp(velocity.x, velocity.y*-1);
        }
        startPos = sprite.position;
    }
        streak.position = sprite.position;
    }
}

-(void)setVelocity:(CGPoint)veloc withSpritePos:(CGPoint)pos{
    velocity = veloc;
    startPos = pos;
    sprite.position = pos;
    [self scheduleUpdate];
}

- (id)init
{
    self = [super init];
    if (self) {
        CGSize size = [[CCDirector sharedDirector]winSize];
        screenRect = CGRectMake(0, 0, size.width, size.height);
        sprite = [CCSprite spriteWithFile:@"01.png"];
        [self addChild:sprite];
        streak = [CCMotionStreak streakWithFade:0.3 minSeg:1  width:5 color:ccWHITE textureFilename:@"special.png"];
        [self addChild:streak];
//        streak.position = sprite.position;
        streak.visible = NO;
        velocity = ccp(0, 0);
    }
    return self;
}

-(void)onEnter{
    [super onEnter];
}

@end
