//
//  Specialbullet.h
//  specialBullet
//
//  Created by jiangyu on 12-12-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Specialbullet : CCSprite {
    CCSprite * sprite;
    CCMotionStreak * streak;
    CGPoint velocity;
    CGPoint startPos;
    CGRect screenRect;
    CGFloat intervial;
}
-(void)setVelocity:(CGPoint)veloc withSpritePos:(CGPoint)pos;
@end
