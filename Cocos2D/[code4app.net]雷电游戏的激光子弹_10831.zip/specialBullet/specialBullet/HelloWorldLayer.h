//
//  HelloWorldLayer.h
//  specialBullet
//
//  Created by jiangyu on 12-12-28.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//


#import <GameKit/GameKit.h>

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer <GKAchievementViewControllerDelegate, GKLeaderboardViewControllerDelegate>
{
    CGSize size ;
    CGPoint veloc1;
    CGPoint veloc2;
    CCSprite * sprite;
    CCSprite * sprite2;
    CCSprite * sprite3;
    CCSprite * spriteTouch;
    CCSpriteBatchNode * node;
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
