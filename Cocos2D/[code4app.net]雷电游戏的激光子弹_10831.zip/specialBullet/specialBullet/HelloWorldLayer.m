//
//  HelloWorldLayer.m
//  specialBullet
//
//  Created by jiangyu on 12-12-28.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"
#import "Specialbullet.h"
#import "BulletSpirte.h"
#pragma mark - HelloWorldLayer

// HelloWorldLayer implementation
@implementation HelloWorldLayer

// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	if( (self=[super init]) ) {
        size = [[CCDirector sharedDirector]winSize];

        spriteTouch = [CCSprite spriteWithFile:@"01.png"];
        spriteTouch.position = ccp(0, 0);
        [self addChild:spriteTouch];
        
        sprite  = [CCSprite spriteWithFile:@"01.png"];
        sprite.position = ccp(spriteTouch.position.x, size.height);
        [self addChild:sprite];
        sprite2  = [CCSprite spriteWithFile:@"01.png"];
        sprite2.position = ccp(spriteTouch.position.x, size.height/3);
        [self addChild:sprite2];
        sprite3  = [CCSprite spriteWithFile:@"01.png"];
        sprite3.position = ccp(spriteTouch.position.x, size.height/3*2);
        [self addChild:sprite3];
        
        veloc1 = ccp(0, 0);
        veloc2 = ccp(0, 0);
        node  = [CCSpriteBatchNode batchNodeWithFile:@"dl_pe_a_071.png"];
        [self addChild:node];
        for (int i =0; i<80; i++) {
            CCSprite * testBullet = [CCSprite spriteWithFile:@"dl_pe_a_071.png"];
            [node addChild:testBullet];
        }
        
        [self scheduleUpdate];
    }
	return self;
}

-(void)onEnter{
    [super onEnter];
    [[[CCDirector sharedDirector]touchDispatcher]addTargetedDelegate:self priority:1 swallowsTouches:YES];
}

-(void) update:(ccTime)delta{
    
    CGPoint origin =ccp(spriteTouch.position.x, spriteTouch.position.y);
    CGPoint destination = ccp(sprite.position.x, sprite.position.y);
    CGPoint control1 = ccp(spriteTouch.position.x, spriteTouch.position.y+(sprite.position.y - spriteTouch.position.y)/3);
    CGPoint control2 = ccp(spriteTouch.position.x, spriteTouch.position.y+(sprite.position.y - spriteTouch.position.y)/3*2);//ccp(sprite3.position.x, sprite3.position.y);
    NSInteger segments = 80;
    ccVertex2F vertices[segments + 1];
    
	float t = 0;
//    CCArray * array = node.children;
    CCNode * n;
	for(NSUInteger i = 0; i < segments; i++)
	{
        n = [node.children objectAtIndex:i];
		vertices[i].x = powf(1 - t, 3) * origin.x + 3.0f * powf(1 - t, 2) * t * control1.x + 3.0f * (1 - t) * t * t * control2.x + t * t * t * destination.x;
		vertices[i].y = powf(1 - t, 3) * origin.y + 3.0f * powf(1 - t, 2) * t * control1.y + 3.0f * (1 - t) * t * t * control2.y + t * t * t * destination.y;
		t += 1.0f / segments;
        if (n) {
            n.position = ccp(vertices[i].x, vertices[i].y);
        }
	}
	vertices[segments] = (ccVertex2F) {destination.x, destination.y};
    
    CGPoint pos = ccp(spriteTouch.position.x,size.height);
    
    if (ccpDistance(pos, sprite.position)>=1) {
        sprite.position = ccpAdd(sprite.position, veloc1);
    }
}

-(BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{
    return YES;
}

-(void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event{
    CGPoint location = [self convertTouchToNodeSpace:touch];
    spriteTouch.position = ccp(location.x, 0);
    veloc1 = ccpSub(ccp(spriteTouch.position.x, size.height), sprite.position);
    veloc1 = ccpNormalize(veloc1);
    veloc2 = ccpMult(veloc1, 0.5);
}

-(void)draw{
    [super draw];
    CGPoint origin =ccp(spriteTouch.position.x, spriteTouch.position.y);
    CGPoint control1 = ccp(spriteTouch.position.x, spriteTouch.position.y+(sprite.position.y - spriteTouch.position.y)/3);
    CGPoint control2 = ccp(spriteTouch.position.x, spriteTouch.position.y+(sprite.position.y - spriteTouch.position.y)/3*2);//ccp(sprite3.position.x, sprite3.position.y);
    CGPoint destination = ccp(sprite.position.x, sprite.position.y);
    NSInteger segments = 8;
    
    ccDrawCubicBezier(origin, control1, control2, destination, segments);
}
// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
    [[[CCDirector sharedDirector]touchDispatcher] removeDelegate:self];
	[super dealloc];
}

#pragma mark GameKit delegate

-(void) achievementViewControllerDidFinish:(GKAchievementViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}

-(void) leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}
@end
