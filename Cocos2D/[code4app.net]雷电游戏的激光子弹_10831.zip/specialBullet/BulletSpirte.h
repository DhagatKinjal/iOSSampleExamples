//
//  BulletSpirte.h
//  specialBullet
//
//  Created by jiangyu on 13-1-10.
//  Copyright 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface BulletSpirte : CCSprite {
    CGPoint startPos;
    ccBezierConfig config_;
}
+(id) initWithBezierConfig:(ccBezierConfig) config StartPos:(CGPoint)startPosT;
-(id) initWithBezierConfig:(ccBezierConfig) config StartPos:(CGPoint)startPosT;
@end
