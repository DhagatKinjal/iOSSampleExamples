//
//  GameSetting.h
//  BmberMan
//
//  Created by  on 12-9-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#define TileWidth 32
#define TileHeight 32
#define WinWidth 480
#define winHeight 320
#define EnemyNum 6
#define Nandu   1//难度系数