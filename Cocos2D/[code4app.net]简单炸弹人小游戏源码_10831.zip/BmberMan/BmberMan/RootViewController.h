//
//  RootViewController.h
//  BmberMan
//
//  Created by  on 12-9-17.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
