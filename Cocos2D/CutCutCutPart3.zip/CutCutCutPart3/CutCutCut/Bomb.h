//
//  Bomb.h
//  CutCutCut
//
//  Created by Allen Benson G Tan on 5/18/12.
//  Copyright 2012 WhiteWidget Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "PolygonSprite.h"

@interface Bomb : PolygonSprite {
    
}

@end
