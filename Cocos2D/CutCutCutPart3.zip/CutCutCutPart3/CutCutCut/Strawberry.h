//
//  Strawberry.h
//  CutCutCut
//
//  Created by Allen Benson G Tan on 5/16/12.
//  Copyright 2012 WhiteWidget Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "PolygonSprite.h"

@interface Strawberry : PolygonSprite {
    
}

@end
