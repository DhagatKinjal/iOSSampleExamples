//
//  WinScene.h
//  BattleCity
//
//  Created by 喆 肖 on 12-8-13.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface WinScene : CCScene {
    
}

+(id)scene;

@end
