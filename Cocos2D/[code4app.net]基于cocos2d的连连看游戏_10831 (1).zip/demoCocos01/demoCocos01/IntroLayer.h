//
//  IntroLayer.h
//  demoCocos01
//
//  Created by huande on 12-8-30.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//

#import "cocos2d.h"

@interface IntroLayer : CCLayer
{
}

+(CCScene *) scene;

@end
