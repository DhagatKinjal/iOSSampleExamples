//
//  BDAppDelegate.h
//  BDMultiDownloader
//
//  Created by Nor Oh on 6/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BDViewController;

@interface BDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
