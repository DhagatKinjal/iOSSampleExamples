//
//  FlickrTableViewController.h
//  MKNetworkKit-iOS-Demo
//
//  Created by Mugunth Kumar on 22/1/12.
//  Copyright (c) 2012 Steinlogic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlickrTableViewController : UITableViewController

@property (strong, nonatomic) NSMutableArray *flickrImages;
@end
