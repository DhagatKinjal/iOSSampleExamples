//
//  testViewController.h
//  test
//
//  Created by Cao Canfu on 02/05/2012.
//  Copyright 2012 Maxitech Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "testAppDelegate.h"
@interface testViewController :UIViewController<UITableViewDataSource,UITableViewDelegate,NSXMLParserDelegate>

{
    UITableView*tablev;
    NSMutableArray*parserObjects;
    NSMutableDictionary*dataDict;
    NSString*m_strCurrentElement;
    NSMutableString*tempString;
    NSArray*NewsTitle;
    NSArray*NewsId;
    NSArray*NewsUser;
    NSArray*NewsDate;
    NSArray*NewsContent;
    NSString* item;
    NSString* item2;
    NSString* item3;
    NSString* item4;
    UIView*iview;
      NSMutableDictionary*dic;
    
}
@property(nonatomic,retain)    NSString*m_strCurrentElement;
@property(nonatomic,retain)  NSMutableString*tempString;
@end
