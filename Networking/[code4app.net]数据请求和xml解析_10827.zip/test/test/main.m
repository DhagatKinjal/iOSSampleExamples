//
//  main.m
//  test
//
//  Created by Cao Canfu on 02/05/2012.
//  Copyright 2012 Maxitech Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
