//
//  testAppDelegate.h
//  test
//
//  Created by Cao Canfu on 02/05/2012.
//  Copyright 2012 Maxitech Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class testViewController;

@interface testAppDelegate : NSObject <UIApplicationDelegate> {
    
}

@property (nonatomic, retain) IBOutlet UIWindow *window;


@property (nonatomic, retain) IBOutlet testViewController *viewController;


@end
