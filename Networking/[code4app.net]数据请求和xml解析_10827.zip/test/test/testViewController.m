//
//  testViewController.m
//  test
//
//  Created by Cao Canfu on 02/05/2012.
//  Copyright 2012 Maxitech Ltd. All rights reserved.
//

#import "testViewController.h"

#import "ASIHTTPRequest.h"
@interface testViewController ()

@end

@implementation testViewController
@synthesize m_strCurrentElement;
@synthesize tempString;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)dealloc
{
    [super dealloc];
}

- (void)ASIHttpRequestFailed:(ASIHTTPRequest *)request{
    
    if (request) {
        [request release];
    }
    NSError *error = [request error];
	NSLog(@"the error is %@",error);
}
//
- (void)ASIHttpRequestSuceed:(ASIHTTPRequest *)request{
    
    //成功  这里怎么写
    
    NSData *responseData = [request responseData];
    
    NSXMLParser *m_parser = [[NSXMLParser alloc] initWithData:responseData];
    [m_parser setDelegate:self];  //设置代理为本地
    BOOL flag = [m_parser parse]; //开始解析
    if(flag) {
        NSLog(@"ok");
    }else{
        NSLog(@"获取指定路径的xml文件失败");
    }
    [m_parser release];
}



- (void)parserDidStartDocument:(NSXMLParser *)parser {
    parserObjects = [[NSMutableArray alloc] init];  //每一组信息都用数组来存，最后得到的数据即在此数组中
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict {
    
    NSArray *elementArray = [[NSArray alloc] initWithObjects:@"NewsId",@"NewsTitle",@"NewsUser",@"NewsContent",@"NewsDate",nil];
    
    if ([elementName isEqualToString:@"News"]) {  //开始解析News节点
        [dataDict release];
        dataDict = [[NSMutableDictionary alloc] initWithCapacity:0];  //每一条信息都用字典来存储
        NSLog(@"%@",dataDict);
    }else {   //开始解析子节点
        for (NSString *e in elementArray) {
            if ([e isEqualToString:elementName]) {
                self.m_strCurrentElement = elementName;
                self.tempString = [NSMutableString string];
                break;
            }
        }
    }
    
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    //填充string
    if (m_strCurrentElement) {
        [self.tempString appendString:string];
        [dataDict setObject:string forKey:m_strCurrentElement];
        
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    //填充dic
    if (m_strCurrentElement) {
        [dataDict setObject:self.tempString forKey:m_strCurrentElement];
        
        self.m_strCurrentElement = nil;
        self.tempString = nil;
    }
    
    //结束解析News节点
    if ([elementName isEqualToString:@"News"]) {
        if (dataDict) {
            [parserObjects addObject:dataDict];
        }
    }
    
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    [tablev reloadData];

  
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL *url = [NSURL URLWithString:@"http://www.vc111.cn/LSXH/GETNEWS2.ASP"];
	ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    [request setValidatesSecureCertificate:NO];
    [request setDelegate:self];
    [request setDidFailSelector:@selector(ASIHttpRequestFailed:)];
    [request setDidFinishSelector:@selector(ASIHttpRequestSuceed:)];
    [request startAsynchronous];
    
    [request setDefaultResponseEncoding:NSUTF8StringEncoding];
    tablev=[[UITableView alloc]initWithFrame:CGRectMake(200, 100, 400, 400) style:UITableViewStylePlain];
    tablev.delegate=self;
    tablev.dataSource=self;
    [self.view addSubview:tablev];
    [tablev release];
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{  
    return [parserObjects count];  
    NSLog(@"num:%d",[parserObjects count]);
    
}  

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{  
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle 
                                       reuseIdentifier:CellIdentifier] autorelease];
    }
    if ([parserObjects count]!=0) {
    
   
   	NSUInteger row = [indexPath row];
  
    dic = [parserObjects objectAtIndex:row];
        UILabel*lab=[[UILabel alloc]init];
        lab.frame=CGRectMake(0, 0, 350, 40);
        lab.text=[dic objectForKey:@"NewsTitle"];
        [cell addSubview:lab];
        UILabel*label=[[UILabel alloc]initWithFrame:CGRectMake(300, 20, 100, 20)];
        label.text=[dic objectForKey:@"NewsDate"];
        [cell addSubview:label];
        [lab release];
        [label release];
//        cell.textLabel.text =  [dic objectForKey:@"NewsTitle"];

    }
  
    return cell;  
} 



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath{  
    NSUInteger row = [indexPath row];
    dic = [parserObjects objectAtIndex:row];
    iview=[[UIView alloc]initWithFrame:tablev.frame];
    [self.view addSubview:iview];
    iview.backgroundColor=[UIColor whiteColor];
    UILabel*lab1=[[UILabel alloc]initWithFrame:CGRectMake(100, 20, 200, 50)];
    lab1.text=[dic objectForKey:@"NewsTitle"];
    
    UITextView*tview=[[UITextView alloc]initWithFrame:CGRectMake(20, 100, 360, 400)];
    tview.text=[dic objectForKey:@"NewsContent"];
    [iview addSubview:tview];
    [iview addSubview:lab1];
}  





@end
