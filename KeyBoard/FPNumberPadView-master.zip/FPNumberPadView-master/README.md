FPNumberPadView
===============

A simple but highly customisable numeric keyboard  for iPhone.
Uses ARC. Currently does not support rotation, you are welcome to implement it.
Includes some input checks to allow only 2 decimal digits, but you can easily change 
those checks to allow whatever input suits your app.

![Screenshot](https://raw.github.com/fprosper/FPNumberPadView/master/screenshot.png "FPNumberPadView")
