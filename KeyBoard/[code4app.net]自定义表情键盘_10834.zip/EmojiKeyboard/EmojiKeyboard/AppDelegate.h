//
//  AppDelegate.h
//  EmojiKeyboard
//
//  Created by wangjianle on 13-3-8.
//  Copyright (c) 2013年 wangjianle. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
