//
//  ViewController.h
//  EmojiKeyboard
//
//  Created by wangjianle on 13-3-8.
//  Copyright (c) 2013年 wangjianle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FaceToolBar.h"
@interface ViewController : UIViewController<FaceToolBarDelegate>

@end
