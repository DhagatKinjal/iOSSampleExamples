//
//  AppDelegate.h
//  ZenKeyboard
//
//  Created by Kevin Nick on 2012-11-19.
//  Copyright (c) 2012年 com.zen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
