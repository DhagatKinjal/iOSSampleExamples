//
//  AppDelegate.h
//  Test
//
//  Created by royasoft on 12-12-4.
//  Copyright (c) 2012年 royasoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
