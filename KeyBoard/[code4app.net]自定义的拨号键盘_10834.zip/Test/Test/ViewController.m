//
//  ViewController.m
//  Test
//
//  Created by royasoft on 12-12-4.
//  Copyright (c) 2012年 royasoft. All rights reserved.
//

#import "ViewController.h"
#import "RoyaDialView.h"
@interface ViewController ()

@end

@implementation ViewController
@synthesize royaDialView;
- (void)viewDidLoad
{
   
    [super viewDidLoad];
  
    
    royaDialView = [[RoyaDialView alloc]init];
    
    [self.btn setTitle:@"hello\nWorld" forState:UIControlStateNormal];
    [self.btn.titleLabel setLineBreakMode:NSLineBreakByWordWrapping];
    [royaDialView showInView:self.view];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
   
}

@end
