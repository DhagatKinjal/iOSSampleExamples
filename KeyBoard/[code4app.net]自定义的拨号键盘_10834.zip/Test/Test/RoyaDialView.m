//
//  RoyaDialView.m
//  Test
//
//  Created by royasoft on 12-12-5.
//  Copyright (c) 2012年 royasoft. All rights reserved.
//

#import "RoyaDialView.h"
#import "RoyaDialViewDelegate.h"

#define CONFIGURE_BUTTON(BTN,X,Y,TITLE,TAG) {\
                                    self.BTN = [UIButton buttonWithType:UIButtonTypeCustom];\
                                    [self.BTN setFrame:CGRectMake(X, Y, widthOfButton, heightOfButton)];\
                                    [self.BTN setShowsTouchWhenHighlighted:YES];\
                                    [self.BTN setTintColor:[UIColor whiteColor]];\
                                    [self.BTN setBackgroundColor:[UIColor darkGrayColor]];\
                                    [self.BTN setTag:TAG];\
                                    [self.BTN addTarget:self action:@selector(onKeyPressed:) \
                                                forControlEvents:UIControlEventTouchUpInside];\
                                    [self addSubview:self.BTN];\
                                   }

#define PULL_DOWN_OFFSET 5.0

#define TAG_KEY_DIAL     111

#define TAG_KEY_UNDO     444



//private
@interface RoyaDialView(private)

-(void)setLayOn:(BOOL) isLayOn;

-(void)handleCall:(NSString *) phoneNum;

@end

@implementation RoyaDialView(private)

-(void)setLayOn:(BOOL)isLayOn
{
    CGFloat adjustOffset = (self.frame.size.height - self.txtNumber.frame.size.height)/2.0 + PULL_DOWN_OFFSET;
    if (isLayOn == YES) {
        adjustOffset *= -1;
    }
   
    CGPoint center = self.center;
    center.y += adjustOffset;
    self.center = center;
}


-(void)handleCall:(NSString *) phoneNum
{
    if(phoneNum.length){
        if ([self.delegate  respondsToSelector:@selector(onDialView:makePhoneCall:)]) {
            [self.delegate onDialView:self makePhoneCall:phoneNum];
        }else{
                NSString *num = [[NSString alloc] initWithFormat:@"telprompt://%@",phoneNum];
                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:num]];
                [num release];
              }
    }
}

@end

//public
@implementation RoyaDialView

-(id)init
{
    CGRect frame = [[UIScreen mainScreen]applicationFrame];
    frame.size.height /= 1.2;
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        CGFloat heightOfTextField = 30.0;
        CGFloat widthOfButtonOnOff = 50.0;
        self.btnOffOn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.btnOffOn setFrame:CGRectMake(0, 0, widthOfButtonOnOff, heightOfTextField)];
        [self.btnOffOn setShowsTouchWhenHighlighted:YES];
        [self.btnOffOn setImage:[UIImage imageNamed:@"up.png"] forState:UIControlStateNormal];
        [self.btnOffOn addTarget:self
                       action:@selector(onButtonOnOffPressed:)
                       forControlEvents:UIControlEventTouchUpInside];
        self.btnOffOn.imageEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
        [self addSubview:self.btnOffOn]; 
        
        self.txtNumber = [[UITextField alloc]initWithFrame:CGRectMake(self.btnOffOn.frame.size.width + 10,
                                                                      0,
                                                                      frame.size.width - self.btnOffOn.frame.size.width-10,
                                                                      heightOfTextField)];
        [self.txtNumber setBorderStyle:UITextBorderStyleRoundedRect];
        [self.txtNumber setEnabled:NO];
        [self.txtNumber setPlaceholder:@"号码:"];
        self.txtNumber.text = @"";
        self.txtNumber.delegate = self;
        [self addSubview:self.txtNumber];
        
        CGFloat heightOfButton = frame.size.height / 5.0 - heightOfTextField;
        CGFloat widthOfButton = frame.size.width / 3.0;
        
        //configure the number key
        CONFIGURE_BUTTON(btn1, 0, heightOfTextField, @"1",1);
        [self.btn1 setBackgroundImage:[UIImage imageNamed:@"dial_num_1_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn2, widthOfButton , heightOfTextField, @"2",2);
        [self.btn2 setBackgroundImage:[UIImage imageNamed:@"dial_num_2_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn3, widthOfButton*2, heightOfTextField, @"3",3);
        [self.btn3 setBackgroundImage:[UIImage imageNamed:@"dial_num_3_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn4, 0, heightOfButton + heightOfTextField, @"4",4);
        [self.btn4 setBackgroundImage:[UIImage imageNamed:@"dial_num_4_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn5, widthOfButton, heightOfButton + heightOfTextField, @"5",5);
        [self.btn5 setBackgroundImage:[UIImage imageNamed:@"dial_num_5_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn6, widthOfButton*2, heightOfButton + heightOfTextField, @"6",6);
        [self.btn6 setBackgroundImage:[UIImage imageNamed:@"dial_num_6_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn7, 0, heightOfButton*2 + heightOfTextField, @"7",7);
        [self.btn7 setBackgroundImage:[UIImage imageNamed:@"dial_num_7_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn8, widthOfButton, heightOfButton*2 + heightOfTextField, @"8",8);
        [self.btn8 setBackgroundImage:[UIImage imageNamed:@"dial_num_8_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn9, widthOfButton*2, heightOfButton*2 + heightOfTextField, @"9",9);
        [self.btn9 setBackgroundImage:[UIImage imageNamed:@"dial_num_9_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btn0, widthOfButton, heightOfButton*3 + heightOfTextField, @"0",0);
        [self.btn0 setBackgroundImage:[UIImage imageNamed:@"dial_num_11_normal.png"]
                             forState:UIControlStateNormal];
        
         //configure the funcion key
        CONFIGURE_BUTTON(btnDial,0,heightOfButton*3 + heightOfTextField, @"Dial",TAG_KEY_DIAL);
        [self.btnDial setBackgroundImage:[UIImage imageNamed:@"dial_num_10_normal.png"]
                             forState:UIControlStateNormal];
        
        CONFIGURE_BUTTON(btnUndo, widthOfButton*2, heightOfButton*3 + heightOfTextField, @"Undo",TAG_KEY_UNDO);
        [self.btnUndo setBackgroundImage:[UIImage imageNamed:@"dial_num_12_normal.png"]
                             forState:UIControlStateNormal];
        
        mIsLayOn = NO;
        [self setLayOn:mIsLayOn];
        self.backgroundColor = [UIColor darkGrayColor];
    }
    return self;

}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)onKeyPressed:(id)sender
{
   NSInteger tag = [sender tag];
    NSString *text = self.txtNumber.text;
    switch (tag) {
       case TAG_KEY_DIAL:
            [self handleCall:text];
            break;
       case TAG_KEY_UNDO:
            if (text.length) {
                 self.txtNumber.text = [text stringByReplacingCharactersInRange:NSMakeRange(text.length-1, 1)
                                                                     withString:@""];
            }
            break;
       default:
            self.txtNumber.text = [NSString stringWithFormat:@"%@%d",text,tag];
            break;
    }
    if ([self.delegate respondsToSelector:@selector(onDialView:dialNumber:withKey:)]) {
        [self.delegate onDialView:self dialNumber:text withKey:tag];
    }
    
}

-(void)onButtonOnOffPressed:(id)sender
{
    UIImage *image = [UIImage imageNamed:@"down.png"];
    if (mIsLayOn) {
        image = [UIImage imageNamed:@"up.png"];
    }
    mIsLayOn ? (mIsLayOn = NO) : (mIsLayOn = YES);
    [self.btnOffOn setImage:image forState:UIControlStateNormal];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [self setLayOn:mIsLayOn];
    [UIView commitAnimations];
    self.txtNumber.text = @"";
}

-(void)dealloc
{
    [self.btn0 release];
    [self.btn1 release];
    [self.btn2 release];
    [self.btn3 release];
    [self.btn4 release];
    [self.btn5 release];
    [self.btn6 release];
    [self.btn7 release];
    [self.btn8 release];
    [self.btn9 release];
    [self.btnDial release];
    [self.btnUndo release];
    [super dealloc];
}

-(void)showInView:(UIView *)view
{
    CGPoint center = self.center;
    center.y += view.frame.size.height * 0.4;
    self.center = center;
    [view addSubview:self];
}

#pragma Delegate

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    mIsLayOn ? (mIsLayOn = NO) : (mIsLayOn = YES);
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    [self setLayOn:mIsLayOn];
    [UIView commitAnimations];
    self.txtNumber.text = @"";
}









@end