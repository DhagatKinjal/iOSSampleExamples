//
//  ViewController.h
//  Test
//
//  Created by royasoft on 12-12-4.
//  Copyright (c) 2012年 royasoft. All rights reserved.
//

#import <UIKit/UIKit.h>
@class RoyaDialView;
@interface ViewController : UIViewController<UIActionSheetDelegate>

@property(retain,nonatomic) RoyaDialView *royaDialView;

@property(retain,nonatomic) IBOutlet UIButton *btn;

@end
