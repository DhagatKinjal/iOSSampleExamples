//
//  main.m
//  KOKeyboard
//
//  Created by Adam Horacek on 03.08.12.
//  Copyright (c) 2012 Adam Horacek. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KOAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([KOAppDelegate class]));
	}
}
