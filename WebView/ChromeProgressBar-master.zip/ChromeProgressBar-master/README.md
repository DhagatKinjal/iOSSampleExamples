ChromeProgressBar
=================

A custom progress bar with Google Chrome style. 

1) Copy entire 'ChromeProgressBar' folder into your project

2) See usage in 'SampleViewController'

NOTE: The sample uses private UIWebView methods. Therefore, it is not 100% AppStore safe.