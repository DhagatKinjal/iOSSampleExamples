//
//  main.m
//  ChromeProgressBarSample
//
//  Created by Mario Nguyen on 01/12/11.
//  Copyright (c) 2012 Mario Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SampleAppDelegate class]));
    }
}
