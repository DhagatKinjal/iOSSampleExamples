//
//  AppDelegate.h
//  poptoolbar
//
//  Created by zzvcom on 12-8-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class webViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    webViewController * webviewcontroller;
}
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,retain) webViewController * webviewcontroller;
@end
