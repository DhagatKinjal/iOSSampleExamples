//
//  main.m
//  CIALBrowserAsModal
//
//  Created by Ito Katsuyoshi on 12/03/19.
//  Copyright (c) 2012年 ITO SOFT DESIGN Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
