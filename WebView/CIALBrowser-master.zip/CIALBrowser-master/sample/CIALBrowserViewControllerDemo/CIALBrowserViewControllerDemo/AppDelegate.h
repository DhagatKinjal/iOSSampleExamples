//
//  AppDelegate.h
//  CIALBrowserViewControllerDemo
//
//  Created by Sylver Bruneau on 01/09/10.
//  Copyright 2011 CodeIsALie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
    UIWindow * window;
    UIViewController *_mainViewController;
}

@property (nonatomic, retain) UIWindow *window;

@end
