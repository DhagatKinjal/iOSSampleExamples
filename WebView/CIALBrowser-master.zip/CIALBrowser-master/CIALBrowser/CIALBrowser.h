//
//  CIALBrowser.h
//  CIALBrowser
//
//  Created by Sylver Bruneau on 28/03/12.
//  Copyright 2012 CodeIsALie. All rights reserved.
//

NSString * CIALBrowserLocalizedString(NSString* key, ...);
