
//  Created by Yang Meyer on 30.01.12.
//  Copyright (c) 2012 compeople. All rights reserved.

#import <UIKit/UIKit.h>

/** Demo modal/presented controller */
@interface CPChildViewController : UIViewController
@property (unsafe_unretained, nonatomic) IBOutlet UIView* shakeFeedbackOverlay;
@end
