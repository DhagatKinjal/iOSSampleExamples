
//  Created by Yang Meyer on 30.01.12.
//  Copyright (c) 2012 compeople. All rights reserved.

#import <UIKit/UIKit.h>

/** Demo parent/presenting controller */
@interface CPViewController : UIViewController
@end
