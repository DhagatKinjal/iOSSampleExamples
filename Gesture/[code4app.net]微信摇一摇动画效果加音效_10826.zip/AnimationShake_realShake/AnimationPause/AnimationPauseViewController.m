//
//  AnimationPauseViewController.m
//  AnimationPause
//
//  Created by gamy on 12-1-5.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "AnimationPauseViewController.h"


@implementation AnimationPauseViewController
@synthesize controlButton;
//添加
@synthesize imgUp;
@synthesize imgDown;


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

//添加
#pragma mark - 摇一摇动画效果
- (void)addAnimations
{
    
    AudioServicesPlaySystemSound (soundID);
    
    //让imgup上下移动
    CABasicAnimation *translation2 = [CABasicAnimation animationWithKeyPath:@"position"];
    translation2.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    translation2.fromValue = [NSValue valueWithCGPoint:CGPointMake(160, 115)];
    translation2.toValue = [NSValue valueWithCGPoint:CGPointMake(160, 40)];
    translation2.duration = 0.4;
    translation2.repeatCount = 1;
    translation2.autoreverses = YES;
    
    //让imagdown上下移动
    CABasicAnimation *translation = [CABasicAnimation animationWithKeyPath:@"position"];
    translation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    translation.fromValue = [NSValue valueWithCGPoint:CGPointMake(160, 345)];
    translation.toValue = [NSValue valueWithCGPoint:CGPointMake(160, 420)];
    translation.duration = 0.4;
    translation.repeatCount = 1;
    translation.autoreverses = YES;
    
    [imgDown.layer addAnimation:translation forKey:@"translation"];
    [imgUp.layer addAnimation:translation2 forKey:@"translation2"];
    
//    [aiLoad stopAnimating];
//    aiLoad.hidden=YES;
    
}

//#pragma mark - 摇一摇
//
//
//-(void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event
//{
//    if(motion==UIEventSubtypeMotionShake)
//    {
//        NSLog(@"shake begin ....");
//        aiLoad.hidden=NO;
//        [aiLoad startAnimating];
//    }
//}
//
//
//-(void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event{
//
//
//    if(motion==UIEventSubtypeMotionShake)
//    {
//        
//    //添加
//    [self addAnimations];
//    //添加
//    AudioServicesPlaySystemSound (soundID);	
//        
//    }
//    
//    
//  
//
//}

//添加
-(void)dealloc{
    
    [controlButton release];
    [imgDown release];
    [imgUp release];
    [super dealloc];

}


#pragma mark - View lifecycle
- (void)viewDidLoad
{  
   // aiLoad.hidden=YES;
    NSString *path = [[NSBundle mainBundle] pathForResource:@"glass" ofType:@"wav"];
	AudioServicesCreateSystemSoundID((CFURLRef)[NSURL fileURLWithPath:path], &soundID);
    [super viewDidLoad];
   
	// Erase the view when recieving a notification named "shake" from the NSNotificationCenter object
	// The "shake" nofification is posted by the PaintingWindow object when user shakes the device
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addAnimations) name:@"shake" object:nil];    
}


- (void)viewDidUnload
{
  
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)clickControlButton:(id)sender {

    //添加 
    [self addAnimations];
    //添加    
}

//-(void)sound{
//
//    //添加
//    AudioServicesPlaySystemSound (soundID);
//    
//    
//    
//    NSTimer *addEnemyTimer;
//    addEnemyTimer=[NSTimer scheduledTimerWithTimeInterval:(2.0) target:self selector:@selector(sound) userInfo:nil repeats:NO]; 
//
//}


@end
