//
//  AnimationPauseAppDelegate.h
//  AnimationPause
//
//  Created by gamy on 12-1-5.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AnimationPauseViewController;
@class PaintingWindow;

@interface AnimationPauseAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet PaintingWindow *window;

@property (nonatomic, retain) IBOutlet AnimationPauseViewController *viewController;

@end
