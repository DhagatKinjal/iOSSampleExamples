//
//  AppDelegate.h
//  SPUserResizableView
//
//  Created by Stephen Poletto on 12/10/11.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;

@end
