//
//  AppDelegate.h
//  DroppableViewTest
//
//  Created by Markus Emrich on 25.03.12.
//  Copyright 2012 Markus Emrich. All rights reserved.
//


#import "TestViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic,strong) UIWindow *window;
@property (nonatomic,strong) TestViewController *viewController;

@end
