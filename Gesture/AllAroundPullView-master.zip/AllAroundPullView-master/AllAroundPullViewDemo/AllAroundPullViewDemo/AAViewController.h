//
//  AAViewController.h
//  AllAroundPullViewDemo
//
//  Created by  on 12/09/08.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AAViewController : UIViewController
@property (nonatomic, strong) IBOutlet UIScrollView *scrollView;
@end
