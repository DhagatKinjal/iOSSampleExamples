//
//  AAAppDelegate.h
//  AllAroundPullViewDemo
//
//  Created by  on 12/09/08.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AAViewController;

@interface AAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) AAViewController *viewController;

@end
