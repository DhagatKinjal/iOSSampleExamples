//
//  LineAppDelegate.h
//  Line
//
//  Created by hhyytt on 10-11-14.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LineViewController;

@interface LineAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    LineViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet LineViewController *viewController;

- (IBAction)tts:(id)sender;
- (NSString *)applicationCachesDirectory;

@end

