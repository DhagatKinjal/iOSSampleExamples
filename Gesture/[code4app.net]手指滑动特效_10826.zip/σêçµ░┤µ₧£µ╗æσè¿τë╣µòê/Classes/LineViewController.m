//
//  LineViewController.m
//  Line
//
//  Created by hhyytt on 10-11-14.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

#import "LineViewController.h"
#import "EAGLView.h"

// Uniform index.
enum {
    UNIFORM_TRANSLATE,
    NUM_UNIFORMS
};
GLint uniforms[NUM_UNIFORMS];

// Attribute index.
enum {
    ATTRIB_VERTEX,
    ATTRIB_COLOR,
    NUM_ATTRIBUTES
};

void triangle(CGPoint* vertex, CGPoint p1, CGPoint p2, GLfloat w1);

@interface LineViewController ()
@property (nonatomic, retain) EAGLContext *context;
@property (nonatomic, assign) CADisplayLink *displayLink;
- (void)line;
@end

@implementation LineViewController

@synthesize animating, context, displayLink;

- (void)awakeFromNib
{
    EAGLContext *aContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
    
	timer = 0.0;
    
    if (!aContext)
        NSLog(@"Failed to create ES context");
    else if (![EAGLContext setCurrentContext:aContext])
        NSLog(@"Failed to set ES context current");
    
	self.context = aContext;
	[aContext release];
	
    [(EAGLView *)self.view setContext:context];
    [(EAGLView *)self.view setFramebuffer];
        
    animating = FALSE;
    animationFrameInterval = 1;
    self.displayLink = nil;
}

- (void)dealloc
{    
    // Tear down context.
    if ([EAGLContext currentContext] == context)
        [EAGLContext setCurrentContext:nil];
    
    [context release];
    
    [super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self startAnimation];
    
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [self stopAnimation];
    
    [super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
	[super viewDidUnload];
	
    // Tear down context.
    if ([EAGLContext currentContext] == context)
        [EAGLContext setCurrentContext:nil];
	self.context = nil;	
}

- (NSInteger)animationFrameInterval
{
    return animationFrameInterval;
}

- (void)setAnimationFrameInterval:(NSInteger)frameInterval
{
    /*
	 Frame interval defines how many display frames must pass between each time the display link fires.
	 The display link will only fire 30 times a second when the frame internal is two on a display that refreshes 60 times a second. The default frame interval setting of one will fire 60 times a second when the display refreshes at 60 times a second. A frame interval setting of less than one results in undefined behavior.
	 */
    if (frameInterval >= 1)
    {
        animationFrameInterval = frameInterval;
        
        if (animating)
        {
            [self stopAnimation];
            [self startAnimation];
        }
    }
}

- (void)startAnimation
{
    if (!animating)
    {
        CADisplayLink *aDisplayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(drawFrame)];
        [aDisplayLink setFrameInterval:animationFrameInterval];
        [aDisplayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.displayLink = aDisplayLink;
        
        animating = TRUE;
    }
}

- (void)stopAnimation
{
    if (animating)
    {
        [self.displayLink invalidate];
        self.displayLink = nil;
        animating = FALSE;
    }
}

- (void)easeNail {
	EAGLView *v = (EAGLView *)self.view;
	if (v.index<4 && !v.send) {
		return;
	}
	
	if (v.index<2) {
		return;
	}
	
	CGPoint *p = v.path;
	v.index--;
	
	memmove(p, &(p[1]), sizeof(CGPoint)*(v.index));	
}

- (void)drawFrame
{
	NSTimeInterval dt = CACurrentMediaTime();

	EAGLView *v = (EAGLView *)self.view;

	if (v.send) {
		timer += dt;
		if (timer > 4) {
			timer = 0.0;
			[self easeNail];
		}
	}
	
    [v setFramebuffer];
    
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrthof(0, 320, 480, 0, -1024, 1024);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
 	
	[self line];
    
    [(EAGLView *)self.view presentFramebuffer];
}

- (void)line {

	EAGLView *v = (EAGLView *)self.view;
	if (v.index<2) {
		return;
	}
	
    static const GLubyte squareColors[] = {
        255, 255,   0, 255,
        0,   255, 255, 255,
        0,     0,   0,   0,
        255,   0, 255, 255,
        0,   255, 255, 255,
        0,     0,   0,   0,
        255,   0, 255, 255,
        0,   255, 255, 255,
        0,   255,   0, 255,
        0,     0,   0,   0,
        255,   0, 255, 255,
    };
	
	CGPoint *p = v.path;
	
	{
		CGPoint vertex[1024]={0.0};
			
		memcpy(vertex, p, sizeof(CGPoint)*v.index);
		
		CGPoint pt = ccpSub(p[v.index-1], p[v.index-2]);
		GLfloat angle = ccpToAngle(pt);
		vertex[v.index-1].x += cosf(angle)*10;
		vertex[v.index-1].y += sinf(angle)*10;
		
		glVertexPointer(2, GL_FLOAT, 0, vertex);
		glEnableClientState(GL_VERTEX_ARRAY);
		glColorPointer(4, GL_UNSIGNED_BYTE, 0, squareColors);
		glEnableClientState(GL_COLOR_ARRAY);
		glDrawArrays(GL_LINE_STRIP, 0, v.index);
	
	}
	
	float w = (pt_count/(v.index-1)*0.5);
	{
	
		CGPoint vertex[1024]={0.0};
		
		CGPoint pt = ccpSub(p[v.index-1], p[v.index-2]);
		GLfloat angle = ccpToAngle(pt);
		vertex[0].x = p[v.index-1].x + cosf(angle)*10;
		vertex[0].y = p[v.index-1].y + sinf(angle)*10;
		
		GLint count = 1;
		
		for (int i = (v.index-2); i>0; --i) {
			
			triangle(&(vertex[count]),p[i],p[i-1], w*i);
			count++;
		}
		vertex[count++] = p[0];

		glVertexPointer(2, GL_FLOAT, 0, vertex);
		glEnableClientState(GL_VERTEX_ARRAY);
		glColorPointer(4, GL_UNSIGNED_BYTE, 0, squareColors);
		glEnableClientState(GL_COLOR_ARRAY);
		glDrawArrays(GL_LINE_STRIP, 0, count);
	}
	
	{
		
		CGPoint vertex[1024]={0.0};
		
		CGPoint pt = ccpSub(p[v.index-1], p[v.index-2]);
		GLfloat angle = ccpToAngle(pt);
		vertex[0].x = p[v.index-1].x + cosf(angle)*10;
		vertex[0].y = p[v.index-1].y + sinf(angle)*10;
		
		GLint count = 1;
		
		for (int i = (v.index-2); i>0; --i) {
			
			triangle(&(vertex[count]),p[i],p[i-1], -w*i);
			count++;
		}
		vertex[count++] = p[0];
		
		glVertexPointer(2, GL_FLOAT, 0, vertex);
		glEnableClientState(GL_VERTEX_ARRAY);
		glColorPointer(4, GL_UNSIGNED_BYTE, 0, squareColors);
		glEnableClientState(GL_COLOR_ARRAY);
		glDrawArrays(GL_LINE_STRIP, 0, count);
	}
	
}


@end


void triangle(CGPoint* vertex, CGPoint p1, CGPoint p2, GLfloat w) {
	
	CGPoint pt = ccpSub(p1, p2);
	GLfloat angle = ccpToAngle(pt);
	
	GLfloat x = sinf(angle) * w;
	GLfloat y = cosf(angle) * w;
	vertex->x = p1.x+x;
	vertex->y = p1.y-y;
}
