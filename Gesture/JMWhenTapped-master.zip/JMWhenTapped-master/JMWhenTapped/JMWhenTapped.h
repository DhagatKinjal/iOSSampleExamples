//
//  JMWhenTapped.h
//  JMWhenTappedDemo
//
//  Created by Jake Marsh on 4/27/11.
//  Copyright 2011 Rubber Duck Software. All rights reserved.
//

#import "UIView+WhenTappedBlocks.h"
