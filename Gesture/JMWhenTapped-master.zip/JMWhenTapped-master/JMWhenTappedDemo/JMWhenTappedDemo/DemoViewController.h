//
//  JMWhenTappedDemoViewController.h
//  JMWhenTappedDemo
//
//  Created by Jake Marsh on 4/27/11.
//  Copyright 2011 Rubber Duck Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoViewController : UIViewController

@end