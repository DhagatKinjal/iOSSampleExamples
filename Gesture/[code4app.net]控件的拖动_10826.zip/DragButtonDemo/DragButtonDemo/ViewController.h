//
//  ViewController.h
//  DragButtonDemo
//
//  Created by zhangmh on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HSCButton.h"
@interface ViewController : UIViewController

@end
