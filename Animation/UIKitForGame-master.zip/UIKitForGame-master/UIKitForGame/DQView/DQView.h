//
//  DQView.h
//  UIViewWithDQFrameDemo
//
//  Created by shuichi on 12/08/09.
//  Copyright (c) 2012年 shuichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DQView : UIView

@end
