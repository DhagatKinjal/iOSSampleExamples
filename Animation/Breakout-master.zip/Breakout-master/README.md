# Breakout
This is a Breakout clone made for the Mobile Computing Course at **Chalmers University of Technology**

![Breakout Screenshot1] (http://img401.imageshack.us/img401/3022/breakout1.png)
![Breakout Screenshot2] (http://img341.imageshack.us/img341/4536/breakout2.png)



