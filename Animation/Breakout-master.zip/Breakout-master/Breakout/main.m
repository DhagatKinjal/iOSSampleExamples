//
//  main.m
//  Breakout
//
//  Created by Tommaso Piazza on 11/4/11.
//  Copyright (c) 2011 ChalmersTH. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BRKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BRKAppDelegate class]));
    }
}
