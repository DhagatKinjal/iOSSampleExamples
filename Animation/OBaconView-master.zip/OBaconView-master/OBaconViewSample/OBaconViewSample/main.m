//
//  main.m
//  OBaconViewSample
//
//  Created by Botond Kis on 06.08.12.
//  Copyright (c) 2012 Botond Kis. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "OBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([OBAppDelegate class]));
    }
}
