//
//  OBCustomItem.h
//  OBaconViewSample
//
//  Created by Botond Kis on 06.08.12.
//  Copyright (c) 2012 Botond Kis. All rights reserved.
//

#import "OBaconViewItem.h"

@interface OBCustomItem : OBaconViewItem
@property (nonatomic, strong) UILabel *itemLabel;

@end
