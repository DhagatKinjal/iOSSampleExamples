//
//  main.m
//  GenieTest
//
//  Created by Jung Kim on 12. 8. 24..
//  Copyright (c) 2012년 AuroraPlanet. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AZAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AZAppDelegate class]));
    }
}
