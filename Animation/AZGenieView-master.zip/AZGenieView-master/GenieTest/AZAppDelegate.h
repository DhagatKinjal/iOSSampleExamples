//
//  AZAppDelegate.h
//  GenieTest
//
//  Created by Jung Kim on 12. 8. 24..
//  Copyright (c) 2012년 AuroraPlanet. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AZViewController;

@interface AZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) AZViewController *viewController;

@end
