AZGenieView
===========

Genie animation effect for iOS UIView