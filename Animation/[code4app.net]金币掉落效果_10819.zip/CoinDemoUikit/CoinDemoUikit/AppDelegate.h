//
//  AppDelegate.h
//  CoinDemoUikit
//
//  Created by gump on 8/31/12.
//  Copyright (c) 2012 gump. All rights reserved.
//

#import "coinView.h"

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,coinViewDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) coinView *coinview;
@end
