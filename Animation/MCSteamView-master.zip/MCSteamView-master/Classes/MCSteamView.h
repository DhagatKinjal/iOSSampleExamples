//
//  SteamView.h
//  Coffee
//
//  Created by Baglan on 3/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCSteamView : UIView

@end
