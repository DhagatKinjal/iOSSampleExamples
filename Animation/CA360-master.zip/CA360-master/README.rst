CA360 - Core Animation Examples for iOS
=======================================

The code in this project was originally created for a presentation at the fall 2009
360idev conference in Denver, CO. I have continued to add to it and update the
examples, and it is now the repository for all of my Core Animation examples
and sample code, whether they are for blog posts, articles or conference
presentations.
