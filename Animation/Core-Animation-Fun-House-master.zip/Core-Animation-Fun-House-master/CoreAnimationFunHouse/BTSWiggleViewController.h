//
//  BTSWiggleViewController.h
//  CoreAnimationFunHouse
//
//  Created by Brian Coyner on 10/5/11.
//  Copyright (c) 2011 Brian Coyner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTSWiggleViewController : UIViewController

@end
