//
//  BTSAppDelegate.m
//  CoreAnimationFunHouse
//
//  Created by Brian Coyner on 9/22/11.
//  Copyright (c) 2011 Brian Coyner. All rights reserved.
//

#import "BTSAppDelegate.h"

@implementation BTSAppDelegate

@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    return YES;
}

@end