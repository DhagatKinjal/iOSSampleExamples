//
//  BTSPulseViewController.h
//  CoreAnimationFunHouse
//
//  Created by Brian Coyner on 9/30/11.
//  Copyright (c) 2011 Brian Coyner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTSPulseViewController : UIViewController

@end
