//
//  main.m
//  CoreAnimationFunHouse
//
//  Created by Brian Coyner on 9/22/11.
//  Copyright (c) 2011 Brian Coyner. All rights reserved.
//

#import "BTSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BTSAppDelegate class]));
    }
}