//
//  ViewController.h
//  BCGenieEffect
//
//  Created by Bartosz Ciechanowski on 10.12.2012.
//  Copyright (c) 2012 Bartosz Ciechanowski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
