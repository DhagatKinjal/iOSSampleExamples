//
//  BasicViewController.h
//  Animations
//
//  Created by Jeremy Gale on 2012-03-20.
//  Copyright (c) 2012 Force Grind Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicViewController : UIViewController

@end
