//
//  main.m
//  JSTween
//
//  Created by Dominik Hofmann on 5/31/11.
//  Copyright 2011 Jetsetter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PRTweenExampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PRTweenExampleAppDelegate class]));
    }
}
