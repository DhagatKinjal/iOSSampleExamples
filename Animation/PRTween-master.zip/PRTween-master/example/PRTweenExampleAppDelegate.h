
#import <UIKit/UIKit.h>

@class PRTweenExampleViewController;

@interface PRTweenExampleAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet PRTweenExampleViewController *viewController;

@end
