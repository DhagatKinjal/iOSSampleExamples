//
//  SecondTutorialSheet.h
//  QBAnimationSequenceTest
//
//  Created by questbeat on 2012/09/29.
//  Copyright (c) 2012年 questbeat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondTutorialSheet : UIView

@end
