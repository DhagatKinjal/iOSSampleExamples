//
//  ViewController.h
//  TBHintViewDemo
//
//  Created by Stefan Immich on 4/9/12.
//  Copyright (c) 2012 touchbee Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction) hint1;
-(IBAction) hint2;
-(IBAction) hint3;
-(IBAction) hint4;
-(IBAction) hint5;

@end
