//
//  SGSelectViewController.h
//  SGSelectViewController
//
//  Created by Maco_Tasu on 12/11/18.
//  Copyright (c) 2012年 MacoTasu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class SGSelectViewController;
@interface SGSelectViewController : UIViewController
@property(nonatomic , weak)UIButton *selectBtn;
-(void)sgViewAppear;

@end
