//
//  ViewController.h
//  SGSelectViewController
//
//  Created by Maco_Tasu on 12/11/18.
//  Copyright (c) 2012年 MacoTasu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)tap:(id)sender;
@property(nonatomic,weak)UIButton *selectBtn;

@end
