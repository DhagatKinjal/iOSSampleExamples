//
//  AppDelegate.h
//  UIMenuBarDemo
//
//  Created by su xinde on 13-3-10.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@end
