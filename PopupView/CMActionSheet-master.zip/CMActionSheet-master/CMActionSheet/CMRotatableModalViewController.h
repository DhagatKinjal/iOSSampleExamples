//
//  CMRotatableModalViewController
//
//  Created by Constantine Mureev on 09.08.12.
//  Copyright (c) 2012 Team Force LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMRotatableModalViewController : UIViewController

@property (retain) UIViewController *rootViewController;

@end
