//
//  AWIconSheetTests.h
//  AWIconSheetTests
//
//  Created by Narcissus on 10/26/12.
//  Copyright (c) 2012 Narcissus. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface AWIconSheetTests : SenTestCase

@end
