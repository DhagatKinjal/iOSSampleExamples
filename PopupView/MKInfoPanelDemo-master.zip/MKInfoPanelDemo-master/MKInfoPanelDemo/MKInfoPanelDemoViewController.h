//
//  MKInfoPanelDemoViewController.h
//  MKInfoPanelDemo
//
//  Created by Mugunth on 25/04/11.
//  Copyright 2011 Steinlogic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKInfoPanelDemoViewController : UIViewController {
    
}

-(IBAction) button1Tapped:(id) sender;
-(IBAction) button2Tapped:(id) sender;
-(IBAction) button3Tapped:(id) sender;
-(IBAction) button4Tapped:(id) sender;
@end
