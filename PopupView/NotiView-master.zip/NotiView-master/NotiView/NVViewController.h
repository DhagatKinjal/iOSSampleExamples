//
//  NVViewController.h
//  NotiView
//
//  Created by Mathieu Bolard on 24/07/12.
//  Copyright (c) 2012 Mathieu Bolard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NVViewController : UIViewController {
    IBOutlet UISwitch *_randomcolors;
}
- (IBAction)test:(id)sender;
@end
