//
//  CQMFloatingControllerTests.h
//  CQMFloatingControllerTests
//
//  Created by Hiroki Kokubun on 12/05/14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CQMFloatingControllerTests : SenTestCase

@end
