//
//  CQMFloatingControllerTests.m
//  CQMFloatingControllerTests
//
//  Created by Hiroki Kokubun on 12/05/14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CQMFloatingControllerTests.h"

@implementation CQMFloatingControllerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in CQMFloatingControllerTests");
}

@end
