PushBackAnimation
=================

Example animation for iOS that sends one view into the background as another view slides up. The inspiration for this was from the National Geographic Parks app (see http://pttrns.com/p/180 for an example or the app itself).

To see the animation in action check out the [animation.gif](https://github.com/carsonmcdonald/PushBackAnimation/blob/master/animation.gif) found in the repo.

License
=======

MIT, see the LICENSE file.
