//
//  popoverTests.h
//  popoverTests
//
//  Created by Oliver Rickard on 21/08/2012.
//  Copyright (c) 2012 Oliver Rickard. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface popoverTests : SenTestCase

@end
