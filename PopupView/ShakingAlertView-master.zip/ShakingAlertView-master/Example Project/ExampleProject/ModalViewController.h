//
//  ModalViewController.h
//  ShakingAlertView
//
//  Created by Luke on 21/09/2012.
//  Copyright (c) 2012 Luke Stringer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController

@end
