//
//  AppDelegate.h
//  ShakingAlertView
//
//  Created by Luke on 23/09/2012.
//  Copyright (c) 2012 Luke Stringer. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
