//
//  MMViewController.h
//  MMFloatingNotificationSample
//
//  Created by Yichao Peak ji on 12-2-23.
//  Copyright (c) 2012 PeakJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MMFloatingNotification.h"

@interface MMViewController : UIViewController

@end
