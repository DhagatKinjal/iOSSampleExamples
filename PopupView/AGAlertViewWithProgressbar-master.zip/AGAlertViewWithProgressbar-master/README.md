AGAlertViewWithProgressbar
==========================