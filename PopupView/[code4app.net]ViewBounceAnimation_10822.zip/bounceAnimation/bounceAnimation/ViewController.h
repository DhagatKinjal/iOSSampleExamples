//
//  ViewController.h
//  bounceAnimation
//
//  Created by JianYe on 12-12-18.
//  Copyright (c) 2012年 JianYe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic,retain)IBOutlet UIView *subview;
@end
