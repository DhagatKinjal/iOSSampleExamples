//
//  main.m
//  WCAlertViewExample
//
//  Created by Michał Zaborowski on 20.10.2012.
//  Copyright (c) 2012 whitecode. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WCAppDelegate class]));
    }
}
