//
//  KNAboutViewController.h
//  KNSemiModalViewControllerDemo
//
//  Created by Kent Nguyen on 3/5/12.
//  Copyright (c) 2012 Kent Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KNAboutViewController : UIViewController

-(IBAction)blogButtonDidTouch:(id)sender;
-(IBAction)twitterButtonDidTouch:(id)sender;

@end
