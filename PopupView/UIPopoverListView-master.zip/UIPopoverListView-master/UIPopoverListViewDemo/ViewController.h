//
//  ViewController.h
//  UIPopoverListViewDemo
//
//  Created by su xinde on 13-3-13.
//  Copyright (c) 2013年 su xinde. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIPopoverListView.h"

@interface ViewController : UIViewController <UIPopoverListViewDataSource, UIPopoverListViewDelegate>

@end
