//
//  NotificationViewController.h
//  Notification
//
//  Created by Jeff Hodnett on 13/09/2011.
//  Copyright 2011 Applausible. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationViewController : UIViewController {
    
}

-(IBAction)showNotification:(id)sender;

@end
