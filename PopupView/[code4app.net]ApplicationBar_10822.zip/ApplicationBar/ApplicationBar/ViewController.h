//
//  ViewController.h
//  ApplicationBar
//
//  Created by 剑锋 屠 on 4/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "IBXApplicationBar.h"
#import "IBXNavigationBar.h"

@interface ViewController : UIViewController <IBXApplicationBarDelegate, IBXNavigationBarDelegate>

@end
