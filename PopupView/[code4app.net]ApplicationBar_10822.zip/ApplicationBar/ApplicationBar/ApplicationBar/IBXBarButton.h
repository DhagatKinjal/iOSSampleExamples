//
//  IBXBarButton.h
//  ApplicationBar
//
//  Created by Instbox.com on 4/13/12.
//  Copyright (c) 2012 VNT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBXBarButton : UIButton

@end
