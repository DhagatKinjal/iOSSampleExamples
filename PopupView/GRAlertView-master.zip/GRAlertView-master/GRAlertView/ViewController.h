//
//  ViewController.h
//  GRAlertView
//
//  Created by Göncz Róbert on 12/13/12.
//  Copyright (c) 2012 Göncz Róbert. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
