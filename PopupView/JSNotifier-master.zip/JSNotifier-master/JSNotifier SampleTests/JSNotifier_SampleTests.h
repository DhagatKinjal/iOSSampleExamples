//
//  JSNotifier_SampleTests.h
//  JSNotifier SampleTests
//
//  Created by Jonah Siegle on 12-01-21.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface JSNotifier_SampleTests : SenTestCase

@end
