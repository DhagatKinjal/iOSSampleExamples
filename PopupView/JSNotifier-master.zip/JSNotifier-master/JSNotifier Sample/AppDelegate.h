//
//  AppDelegate.h
//  JSNotifier Sample
//
//  Created by Jonah Siegle on 12-01-21.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
