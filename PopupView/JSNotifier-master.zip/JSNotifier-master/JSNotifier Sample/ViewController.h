//
//  ViewController.h
//  JSNotifier Sample
//
//  Created by Jonah Siegle on 12-01-21.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JSNotifier.h"


@interface ViewController : UIViewController

- (IBAction)succsess:(id)sender;
- (IBAction)error:(id)sender;
- (IBAction)activity:(id)sender;
- (IBAction)loop:(id)sender;

@end
