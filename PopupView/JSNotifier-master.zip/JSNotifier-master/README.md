JSNotifier
==========

A simple class for iOS that provides users with notifications in a simple way.