//
//  AppDelegate.h
//  CircularTimerDemo
//
//  Created by Bernat Bombi Fernandez on 20/01/13.
//  Copyright (c) 2013 Crowd Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
