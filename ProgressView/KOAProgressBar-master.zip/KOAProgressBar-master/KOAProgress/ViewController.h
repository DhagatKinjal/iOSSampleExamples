//
//  ViewController.h
//  KOAProgress
//
//  Created by Miroslav Perović on 7/5/12.
//  Copyright (c) 2012 KeepOnApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KOAProgressBar;

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet KOAProgressBar *progressBar;
@end
