//
//  KOAProgressTests.h
//  KOAProgressTests
//
//  Created by Miroslav Perović on 7/5/12.
//  Copyright (c) 2012 KeepOnApps. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface KOAProgressTests : SenTestCase

@end
