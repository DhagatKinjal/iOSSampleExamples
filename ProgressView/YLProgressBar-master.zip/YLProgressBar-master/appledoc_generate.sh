#!/bin/bash

###
# You need appledoc 2.1 (https://github.com/tomaz/appledoc/) to generate the documentation thanks to this script
###

mkdir documentation

/Applications/appledoc -h AppledocSettings.plist ./YLProgressBar 