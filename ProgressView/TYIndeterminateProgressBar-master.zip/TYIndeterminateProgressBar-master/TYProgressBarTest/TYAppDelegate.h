//
//  TYAppDelegate.h
//  TYProgressBarTest
//
//  Created by Tejaswi Y on 3/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TYViewController;

@interface TYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TYViewController *viewController;

@end
