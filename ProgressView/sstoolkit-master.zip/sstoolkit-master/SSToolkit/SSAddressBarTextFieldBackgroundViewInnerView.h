//
//  SSAddressBarTextFieldBackgroundViewInnerView.h
//  SSToolkit
//
//  Created by Sam Soffes on 2/8/11.
//  Copyright 2011 Sam Soffes. All rights reserved.
//

@interface SSAddressBarTextFieldBackgroundViewInnerView : UIView
@end
