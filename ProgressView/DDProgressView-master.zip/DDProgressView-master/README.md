About
=====

**DDProgressView** is a custom progress view à la Twitter for iPhone.

DDProgressView works on both iOS and Mac OS. You must also compile the `AppKitCompatibility.m` file when targeting Mac OS.

Screenshot
==========

![Gray on Black DDProgressView](https://github.com/0xced/DDProgressView/raw/master/Screenshot.png)

![DDProgressView using the emptyColor property](https://github.com/ddeville/DDProgressView/raw/master/Screenshot2.png)
