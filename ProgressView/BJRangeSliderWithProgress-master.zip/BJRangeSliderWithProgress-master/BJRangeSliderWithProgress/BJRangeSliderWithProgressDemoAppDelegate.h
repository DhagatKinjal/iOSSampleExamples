//
//  BJRangeSliderWithProgressAppDelegate.h
//  BJRangeSliderWithProgress
//
//  Created by Barrett Jacobsen on 7/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BJRangeSliderWithProgressDemoViewController;

@interface BJRangeSliderWithProgressDemoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) BJRangeSliderWithProgressDemoViewController *viewController;

@end
