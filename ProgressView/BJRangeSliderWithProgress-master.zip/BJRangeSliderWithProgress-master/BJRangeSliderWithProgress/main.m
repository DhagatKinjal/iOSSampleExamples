//
//  main.m
//  BJRangeSliderWithProgress
//
//  Created by Barrett Jacobsen on 7/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BJRangeSliderWithProgressDemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BJRangeSliderWithProgressDemoAppDelegate class]));
    }
}
