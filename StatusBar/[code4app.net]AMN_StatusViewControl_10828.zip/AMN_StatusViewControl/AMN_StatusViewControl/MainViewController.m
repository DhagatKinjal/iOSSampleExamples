//
//  MainViewController.m
//  AMN_StatusViewControl
//
//  Created by Amana Qi on 12-6-22.
//  Copyright (c) 2012年 __Amana__. All rights reserved.
//

#import "MainViewController.h"
#import "AMN_StatusViewControl.h"

//总运行时间
#define RUNTIME         40
//单条运行时间
#define EACHTIME        10
//每条间隔时间
#define INTERVALTIME    5

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //设置显示数据，也可数据库获得
    NSMutableArray *iAsgArray = [[NSMutableArray alloc] initWithObjects:@"今天晴间多云 风力1－2级 适宜洗车", @"明天小雨转阴 风力2－3级 出门请带伞", @"后天大暴雨 风力4－6级 请关闭好门窗", nil];
    
	_statusView = [[AMN_StatusViewControl alloc] init];
    _statusView.msgArray = iAsgArray;
    [_statusView setBgImage:[UIImage imageNamed:@"status_bg"]];
    _statusView.runTime = RUNTIME;
    _statusView.eachTime = EACHTIME;
    _statusView.intervalTime = INTERVALTIME;
    [_statusView showStatusMessage];
    [iAsgArray release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc
{
    [_statusView release];
    [super dealloc];
}

@end
