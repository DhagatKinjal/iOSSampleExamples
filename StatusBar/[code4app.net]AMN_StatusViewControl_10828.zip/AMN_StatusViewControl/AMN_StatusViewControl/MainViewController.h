//
//  MainViewController.h
//  AMN_StatusViewControl
//
//  Created by Amana Qi on 12-6-22.
//  Copyright (c) 2012年 __Amana__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AMN_StatusViewControl;

@interface MainViewController : UIViewController
{
    AMN_StatusViewControl *_statusView;
}

@end
