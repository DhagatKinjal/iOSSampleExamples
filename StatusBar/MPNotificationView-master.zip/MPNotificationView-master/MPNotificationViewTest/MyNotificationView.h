//
//  MyNotificationView.h
//  MPNotificationViewTest
//
//  Created by 利辺羅 on 2013/04/12.
//  Copyright (c) 2013年 Moped Inc. All rights reserved.
//

#import "MPNotificationView.h"

@interface MyNotificationView : MPNotificationView

@end

