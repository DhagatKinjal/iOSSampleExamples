//
//  MPAppDelegate.h
//  MPNotificationViewTest
//
//  Created by Engin Kurutepe on 1/4/13.
//  Copyright (c) 2013 Moped Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
