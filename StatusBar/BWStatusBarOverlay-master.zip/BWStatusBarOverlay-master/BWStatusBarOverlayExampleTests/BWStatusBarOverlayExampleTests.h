//
//  BWStatusBarOverlayExampleTests.h
//  BWStatusBarOverlayExampleTests
//
//  Created by Bruno Wernimont on 4/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface BWStatusBarOverlayExampleTests : SenTestCase

@end
