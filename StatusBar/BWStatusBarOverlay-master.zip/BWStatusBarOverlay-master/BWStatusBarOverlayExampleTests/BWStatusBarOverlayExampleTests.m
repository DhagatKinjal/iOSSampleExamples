//
//  BWStatusBarOverlayExampleTests.m
//  BWStatusBarOverlayExampleTests
//
//  Created by Bruno Wernimont on 4/07/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BWStatusBarOverlayExampleTests.h"

@implementation BWStatusBarOverlayExampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in BWStatusBarOverlayExampleTests");
}

@end
