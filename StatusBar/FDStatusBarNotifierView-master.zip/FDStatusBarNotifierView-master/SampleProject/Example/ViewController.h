//
//  ViewController.h
//  Example
//
//  Created by Francesco Di Lorenzo on 06/09/12.
//  Copyright (c) 2012 Francesco Di Lorenzo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FDStatusBarNotifierView.h"

@interface ViewController : UIViewController <FDStatusBarNotifierViewDelegate>

@property (weak, nonatomic) IBOutlet UITextField *messageField;

- (IBAction)showMessage;
- (IBAction)showMessageNoAutohide:(id)sender;
- (IBAction)hideButtonTapped:(id)sender;


@end
