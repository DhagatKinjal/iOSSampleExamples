//
//  ViewController.m
//  CustomStatueBar
//
//  Created by 贺 坤 on 12-5-21.
//  Copyright (c) 2012年 深圳市瑞盈塞富科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "CustomStatueBar.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize button;

- (void)viewDidLoad
{
    [super viewDidLoad];
    statueBar= [[CustomStatueBar alloc]initWithFrame:CGRectMake(0, 0, 320, 20)];
    [statueBar showStatusMessage:@"message new!"];
	// Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)buttonPressed:(id)sender{
    [statueBar changeMessge:@"it is a new message!"];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

@end
