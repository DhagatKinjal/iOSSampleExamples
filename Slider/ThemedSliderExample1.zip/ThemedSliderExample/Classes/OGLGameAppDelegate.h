//
//  Tutorial1.h
//  OGLGame
//
//

#import <UIKit/UIKit.h>

@class EAGLView;

@interface OGLGameAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    EAGLView *glView;
}

@end

