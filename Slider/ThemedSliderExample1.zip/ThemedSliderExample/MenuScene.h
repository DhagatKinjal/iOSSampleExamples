//
//  MenuState.h
//  OGLGame
//
//

#import <Foundation/Foundation.h>
#import "AbstractScene.h"

@interface MenuScene : AbstractScene {
	
	Image *menuBackground;
}

@end
