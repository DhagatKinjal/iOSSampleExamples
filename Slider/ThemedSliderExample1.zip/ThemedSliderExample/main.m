//
//  main.m
//  OGLGame
//
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"OGLGameAppDelegate");
    [pool release];
    return retVal;
}
