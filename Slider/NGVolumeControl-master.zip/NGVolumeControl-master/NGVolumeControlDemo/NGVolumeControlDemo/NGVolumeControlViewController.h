//
//  NGVolumeControlViewController.h
//  NGVolumeControlDemo
//
//  Created by Tretter Matthias on 28.02.12.
//  Copyright (c) 2012 NOUS Wissensmanagement GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NGVolumeControlViewController : UIViewController

@end
