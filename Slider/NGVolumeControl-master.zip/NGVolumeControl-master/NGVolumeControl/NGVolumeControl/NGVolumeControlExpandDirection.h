//
//  NGVolumeControlExpandDirection.h
//  NGVolumeControl
//
//  Created by Tretter Matthias on 28.02.12.
//  Copyright (c) 2012 NOUS Wissensmanagement GmbH. All rights reserved.
//

typedef enum {
  NGVolumeControlExpandDirectionUp,
  NGVolumeControlExpandDirectionDown
} NGVolumeControlExpandDirection;