//
//  NGVolumeSlider.h
//  NGVolumeControl
//
//  Created by Matthias Tretter on 15.10.12.
//  Copyright (c) 2012 NOUS Wissensmanagement GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>


/** Custom subclass to increase touch area */
@interface NGVolumeSlider : UISlider

@end
