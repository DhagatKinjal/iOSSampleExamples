
@class DemoViewController;

@interface DemoAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) DemoViewController *viewController;

@end
