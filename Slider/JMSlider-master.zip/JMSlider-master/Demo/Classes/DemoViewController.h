//  Created by Jason Morrissey - jasonmorrissey.org

#import <Foundation/Foundation.h>
#import "JMSlider.h"

@interface DemoViewController : UIViewController <JMSliderDelegate>

@end
