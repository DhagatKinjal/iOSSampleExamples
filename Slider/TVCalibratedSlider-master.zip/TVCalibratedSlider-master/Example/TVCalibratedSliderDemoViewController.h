//
//  TVScaledSliderDemoViewController.h
//  TVScaledSliderDemoViewController
//
//  Created by TaviscaIos on 9/12/12.
//  Copyright (c) 2012 Tavisca. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVCalibratedSliderDemoViewController : UIViewController
@end
