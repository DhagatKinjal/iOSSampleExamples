//
//  AppDelegate.h
//  TVCalibratedSlider
//
//  Created by TaviscaIOS on 9/20/12.
//  Copyright (c) 2012 Tavisca. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
