//
//  NYAppDelegate.h
//  NYSliderPopoverDemo
//
//  Created by Cassius Pacheco on 27/12/12.
//  Copyright (c) 2012 Nyvra Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
