//
//  RootViewController.h
//  RETrimControlExample
//
//  Created by Roman Efimov on 1/18/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RETrimControl.h"

@interface RootViewController : UIViewController <RETrimControlDelegate>

@end
