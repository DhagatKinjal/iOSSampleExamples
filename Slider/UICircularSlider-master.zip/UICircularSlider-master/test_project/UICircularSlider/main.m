//
//  main.m
//  UICircularSlider
//
//  Created by Zouhair Mahieddine on 02/03/12.
//  Copyright (c) 2012 Zouhair Mahieddine. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UICircularSliderAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([UICircularSliderAppDelegate class]));
	}
}
