//
//  main.m
//  RangeSelectorSample
//
//  Created by Antonio Cabezuelo Vivo on 26/01/13.
//  Copyright (c) 2013 Antonio Cabezuelo Vivo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ACVAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ACVAppDelegate class]));
    }
}
