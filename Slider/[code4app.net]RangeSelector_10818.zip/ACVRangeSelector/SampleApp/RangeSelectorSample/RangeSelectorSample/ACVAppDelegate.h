//
//  ACVAppDelegate.h
//  RangeSelectorSample
//
//  Created by Antonio Cabezuelo Vivo on 26/01/13.
//  Copyright (c) 2013 Antonio Cabezuelo Vivo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ACVViewController;

@interface ACVAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ACVViewController *viewController;

@end
