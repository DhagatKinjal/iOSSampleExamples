//
//  RootViewController.h
//  NDRotatingControllerView
//
//  Created by Nathan Day on 14/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController

@end
