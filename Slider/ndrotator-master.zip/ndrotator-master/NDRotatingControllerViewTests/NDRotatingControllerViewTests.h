//
//  NDRotatingControllerViewTests.h
//  NDRotatingControllerViewTests
//
//  Created by Nathan Day on 14/07/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NDRotatingControllerViewTests : SenTestCase

@end
