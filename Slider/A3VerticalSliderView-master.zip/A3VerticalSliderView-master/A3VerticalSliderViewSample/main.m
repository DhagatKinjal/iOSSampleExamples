//
//  main.m
//  A3VerticalSliderViewSample
//
//  Created by Botond Kis on 12.10.12.
//  Copyright (c) 2012 AllAboutApps. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "A3AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([A3AppDelegate class]));
    }
}
