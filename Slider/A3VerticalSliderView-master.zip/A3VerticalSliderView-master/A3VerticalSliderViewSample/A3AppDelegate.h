//
//  A3AppDelegate.h
//  A3VerticalSliderViewSample
//
//  Created by Botond Kis on 12.10.12.
//  Copyright (c) 2012 AllAboutApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@class A3ViewController;

@interface A3AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) A3ViewController *viewController;

@end
