//
//  JSTableViewController.h
//  CoreTextHyperlinkView
//
//  Created by James Addyman on 11/03/2013.
//
//

#import <UIKit/UIKit.h>
#import "JSCoreTextView.h"

@interface JSTableViewController : UITableViewController <JSCoreTextViewDelegate>

@end
