//
//  FTCoreTextAppDelegate.h
//  FTCoreText
//
//  Created by Francesco Frison on 18/08/2011.
//  Copyright 2011 Fuerte International. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FTCoreTextAppDelegate : NSObject <UIApplicationDelegate>

@property (unsafe_unretained, nonatomic) UIViewController *controller;

@end
