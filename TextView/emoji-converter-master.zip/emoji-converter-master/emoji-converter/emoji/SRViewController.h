//
//  SRViewController.h
//  emoji
//
//  Created by 石瑞 on 6/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SREmojiConvertor.h"

@interface SRViewController : UIViewController

@end
