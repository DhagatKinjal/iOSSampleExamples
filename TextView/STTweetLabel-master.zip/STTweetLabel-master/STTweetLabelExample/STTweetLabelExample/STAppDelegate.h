//
//  STAppDelegate.h
//  STTweetLabelExample
//
//  Created by Sebastien Thiebaud on 12/16/12.
//  Copyright (c) 2012 Sebastien Thiebaud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
