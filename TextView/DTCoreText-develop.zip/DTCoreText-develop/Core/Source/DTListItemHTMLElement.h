//
//  DTHTMLElementLI.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 27.12.12.
//  Copyright (c) 2012 Drobnik.com. All rights reserved.
//

#import "DTCoreText.h"

/**
 Specialized subclass of <DTHTMLElement> that deals with list items.
 */
@interface DTListItemHTMLElement : DTHTMLElement

@end
