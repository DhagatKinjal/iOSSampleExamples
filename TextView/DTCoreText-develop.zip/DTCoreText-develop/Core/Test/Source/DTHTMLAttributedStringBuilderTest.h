//
//  DTHTMLAttributedStringBuilderTest.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 25.12.12.
//  Copyright (c) 2012 Drobnik.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DTHTMLAttributedStringBuilderTest : SenTestCase

@end
