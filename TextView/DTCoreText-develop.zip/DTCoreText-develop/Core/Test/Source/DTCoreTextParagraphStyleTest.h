//
//  DTCoreTextParagraphStyleTest.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 2/25/13.
//  Copyright (c) 2013 Drobnik.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DTCoreTextParagraphStyleTest : SenTestCase

@end
