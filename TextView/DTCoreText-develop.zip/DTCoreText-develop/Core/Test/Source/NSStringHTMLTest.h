//
//  NSStringHTMLTest.h
//  DTCoreText
//
//  Created by Claus Broch on 11/01/11.
//  Copyright 2011 Drobnik.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NSStringHTMLTest : SenTestCase {

}

@end
