//
//  NSStringCSSTest.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 1/5/13.
//  Copyright (c) 2013 Drobnik.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NSStringCSSTest : SenTestCase

@end
