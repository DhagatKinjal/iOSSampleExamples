//
//  UITextField+YISwipeShiftCaret.h
//  YISwipeShiftCaret
//
//  Created by Yasuhiro Inami on 2012/11/03.
//  Copyright (c) 2012年 Yasuhiro Inami. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (YISwipeShiftCaret)

@property (nonatomic) NSRange selectedRange;

@end
