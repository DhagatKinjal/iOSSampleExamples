//
//  ViewController.h
//  YISwipeShiftCaretDemo
//
//  Created by Yasuhiro Inami on 2012/11/03.
//  Copyright (c) 2012年 Yasuhiro Inami. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
