#Demo Files for "Stupid Core Text Tricks"
Presented to the Atlanta iOS Developer Meetup
May 18, 2011

by Warren Moore

An iOS project containing a couple of examples of Core Text usage.
