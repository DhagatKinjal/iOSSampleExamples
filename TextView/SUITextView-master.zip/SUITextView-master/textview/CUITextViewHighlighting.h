//
//  CUITextViewHighlighting.h
//  textview
//
//  Created by Volodymyr Boichentsov on 11/6/11.
//  Copyright (c) 2011 www.developers-life.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <Foundation/Foundation.h>

#import "CUITextView.h"

@interface CUITextViewHighlighting : CUITextView

@end
