Subclass of UITextView with syntax highlighting for iOS 5.0 not finished (just sample)

With new iOS 6.0 everyone junior developer can do code editor application with syntax highlighting. Because *UITextView* has attribute *attributedText*, which has enough parameters and functionality for it.

So, I want to say, my old project does not have sense. :)

The last build shared on git hub and everyone can modify it and try to finish, because it still not completed. Still has a problem with word wrap.

Maybe someone will get something new for self. Because this project used CoreText and CoreGraphics framework.

Enjoy!

- - -

Blog Post http://www.developers-life.com/uitextview-with-syntax-highlighting-for-ios-5-0-not-finished.html<br />
Welcome for any questions

- - -

If you liked it, you can support me:

<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=B4VMLFZ986FNW">
<img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!" />
</a>