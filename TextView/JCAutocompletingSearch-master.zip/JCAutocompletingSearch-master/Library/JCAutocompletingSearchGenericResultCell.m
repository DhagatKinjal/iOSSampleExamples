#import "JCAutocompletingSearchGenericResultCell.h"

@implementation JCAutocompletingSearchGenericResultCell

@end
