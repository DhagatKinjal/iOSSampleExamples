#import <UIKit/UIKit.h>

@interface JCAutocompletingSearchGenericResultCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel* resultLabel;

@end
