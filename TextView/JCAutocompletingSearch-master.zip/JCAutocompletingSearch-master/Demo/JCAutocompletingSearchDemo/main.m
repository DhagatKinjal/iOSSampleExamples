//
//  main.m
//  JCAutocompletingSearchDemo
//
//  Created by James Coleman on 9/19/12.
//  Copyright (c) 2012 James Coleman. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JCAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([JCAppDelegate class]));
  }
}
