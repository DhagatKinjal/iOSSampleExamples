#import <UIKit/UIKit.h>
#import "JCAutocompletingSearchViewControllerDelegate.h"

@interface JCAppDelegate : UIResponder <UIApplicationDelegate, JCAutocompletingSearchViewControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
