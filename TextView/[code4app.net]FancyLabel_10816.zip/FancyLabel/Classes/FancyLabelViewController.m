//
//  FancyLabelViewController.m
//  FancyLabel
//
//  Created by Craig Hockenberry on 10/1/08.
//  Copyright The Iconfactory 2008. All rights reserved.
//

#import "FancyLabelViewController.h"

@implementation FancyLabelViewController

// Override initWithNibName:bundle: to load the view using a nib file then perform additional customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		// Custom initialization
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleTweetNotification:) name:IFTweetLabelURLNotification object:nil];
    }
    return self;
}

// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {

	CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
	//applicationFrame.origin = CGPointZero;

	UIView *contentView = [[[UIView alloc] initWithFrame:applicationFrame] autorelease];

	[contentView setBackgroundColor:[UIColor orangeColor]];


	IFTweetLabel *tweetLabel = [[IFTweetLabel alloc] initWithFrame:CGRectMake(10.0f, 50.0f, applicationFrame.size.width - 20.0f, applicationFrame.size.height - 50.0f - 40.0f)];
	[tweetLabel setFont:[UIFont boldSystemFontOfSize:18.0f]];
	[tweetLabel setTextColor:[UIColor whiteColor]];
	[tweetLabel setBackgroundColor:[UIColor clearColor]];
	[tweetLabel setNumberOfLines:0];
	[tweetLabel setText:@"This is a #话题# of regular expressions with http://example.com links as used in @微博 链接 http://www.baidu.com 百度一下."];
	[tweetLabel setLinksEnabled:YES];
	[contentView addSubview:tweetLabel];
    [tweetLabel release];
	self.view = contentView;
}


/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self 
                                                    name:IFTweetLabelURLNotification 
                                                  object:nil];

    [super dealloc];
}

- (void)handleTweetNotification:(NSNotification *)notification
{
	NSLog(@"handleTweetNotification: notification = %@", notification.object);
}

@end
