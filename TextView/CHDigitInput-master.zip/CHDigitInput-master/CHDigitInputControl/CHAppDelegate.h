//
//  CHAppDelegate.h
//  CHDigitInputControl
//
//  Created by Clemens Hammerl on 27.10.12.
//  Copyright (c) 2012 Clemens Hammerl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CHAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
