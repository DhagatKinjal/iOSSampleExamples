//
//  CHTestController.h
//  CHDigitInputControl
//
//  Created by Clemens Hammerl on 27.10.12.
//  Copyright (c) 2012 Clemens Hammerl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHDigitInput.h"

@interface CHTestController : UIViewController
{
    CHDigitInput *digitInput;
}

@end
