//
//  ViewController.h
//  GGHashtagMentionController
//
//  Created by John Z Wu on 9/22/12.
//  Copyright (c) 2012 John Z Wu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GGHashtagMentionController.h"

@interface ViewController : UIViewController <GGHashtagMentionDelegate, UITableViewDataSource, UITableViewDelegate>

@end
