//
//  UIView+Screenshot.h
//  FlipViewTest
//
//  Created by Mac Pro on 6/6/12.
//  Copyright (c) 2012 Dawn(use for learn,base on CAShowcase demo). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView(screenshot)
- (UIImage *)screenshot;

@end