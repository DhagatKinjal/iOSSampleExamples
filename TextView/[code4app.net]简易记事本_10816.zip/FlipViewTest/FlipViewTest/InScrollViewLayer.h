//
//  InScrollViewLayer.h
//  FlipViewTest
//
//  Created by Mac Pro on 6/6/12.
//  Copyright (c) 2012 Dawn(use for learn,base on CAShowcase demo). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InScrollViewLayer : CALayer
@property (nonatomic,strong) UIImage *image;
@end
