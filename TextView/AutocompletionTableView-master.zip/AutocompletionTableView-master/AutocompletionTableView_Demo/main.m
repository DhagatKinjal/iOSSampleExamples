//
//  main.m
//  AutocompletionTableView_Demo
//
//  Created by Gushin Arseniy on 13.03.12.
//  Copyright (c) 2012 Arseniy Gushin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ACDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ACDAppDelegate class]));
    }
}
