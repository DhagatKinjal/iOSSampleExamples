//
//  ACDViewController.h
//  AutocompletionTableView_Demo
//
//  Created by Gushin Arseniy on 13.03.12.
//  Copyright (c) 2012 Arseniy Gushin. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AutocompletionTableViewDelegate;

@interface ACDViewController : UIViewController <AutocompletionTableViewDelegate>

@end
