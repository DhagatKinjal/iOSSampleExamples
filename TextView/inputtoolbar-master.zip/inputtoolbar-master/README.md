# Messages style input toolbar for iOS

An free version of an expandable input toolbar in the style of the native iPhone messages app

![InputToolbar screenshot][1]
![InputToolbar screenshot 2][2]

  [1]: https://github.com/brandonhamilton/inputtoolbar/raw/master/Screenshot.png
  [2]: https://github.com/brandonhamilton/inputtoolbar/raw/master/Screenshot_2.png
