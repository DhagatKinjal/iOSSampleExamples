//
//  ViewController.h
//  JYTextFieldDemo
//
//  Created by kinglate on 13-1-24.
//  Copyright (c) 2013年 joyame. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYTextField;
@interface ViewController : UIViewController
{
	JYTextField *_txt1;
	JYTextField *_txt2;
}
@end
