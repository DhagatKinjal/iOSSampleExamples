//
//  AppDelegate.h
//  JYTextFieldDemo
//
//  Created by kinglate on 13-1-24.
//  Copyright (c) 2013年 joyame. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
