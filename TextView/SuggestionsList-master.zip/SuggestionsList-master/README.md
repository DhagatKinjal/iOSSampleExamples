***Suggestions List PopOver for iPad*** 

Simply copy SuggestionsList class to your project and use as in ViewController.h example.

[Visit my blog](http://tetek.wordpress.com   "blog")

**License**

The code is licensed under [WTFPL](http://en.wikipedia.org/wiki/WTFPL)
