//
//  RCViewController.h
//  RCLabel
//
//  Created by Hang Chen on 7/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCViewController : UITableViewController {
    
	NSMutableArray *dataArray;
}

@property (nonatomic, retain) NSMutableArray *dataArray;

@end
