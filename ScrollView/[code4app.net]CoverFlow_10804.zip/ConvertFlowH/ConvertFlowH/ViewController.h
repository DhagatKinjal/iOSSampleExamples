//
//  ViewController.h
//  ConvertFlowH
//
//  Created by HuLiangJun on 12-11-14.
//  Copyright (c) 2012年 HuLiangJun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define SCROLL_PIXELS 60.0
#define COVER_WIDTH_HEIGHT 128.0

@interface CFView : UIScrollView<UIScrollViewDelegate>{
    CAScrollLayer   * cfIntLayer;
    NSMutableArray  * _covers;
    NSTimer         * timer;
    int               selectedCover;
}

-(id)initWithFrame:(struct CGRect)frame covers:(NSMutableArray*)covers;
-(void)layoutLayer:(CAScrollLayer*)layer;

@property (nonatomic,getter = getSelectedCover) int selectedCover;

@end

@interface ViewController : UIViewController
{
    NSMutableArray * covers;
    CFView         * covertFlowView;
}
@end


