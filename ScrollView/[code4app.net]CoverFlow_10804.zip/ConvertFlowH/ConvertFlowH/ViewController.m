//
//  ViewController.m
//  ConvertFlowH
//
//  Created by HuLiangJun on 12-11-14.
//  Copyright (c) 2012年 HuLiangJun. All rights reserved.
//

#import "ViewController.h"


@implementation CFView

-(id)initWithFrame:(struct CGRect)frame covers:(NSMutableArray *)covers{
    self=[super initWithFrame:frame];
    if (self!=nil) {
        _covers=covers;
        selectedCover=0;
        
        self.showsVerticalScrollIndicator=YES;
        self.showsHorizontalScrollIndicator=NO;
        self.delegate=self;
        self.scrollsToTop=NO;
        self.bouncesZoom=NO;
        
        cfIntLayer=[[CAScrollLayer alloc] init];
        cfIntLayer.bounds=CGRectMake(0, 0, frame.size.width, frame.size.height+COVER_WIDTH_HEIGHT);
        
        cfIntLayer.position=CGPointMake(160.0, 304.0);
        cfIntLayer.frame=frame;
        
        for (int i=0; i<[_covers count]; i++) {
            NSLog(@"Initializing cfIntLayer layer %d\n",i);
            
            UIImageView * background=[[[UIImageView alloc] initWithImage:[_covers objectAtIndex:i]] autorelease];
            
            background.frame=CGRectMake(0, 0, COVER_WIDTH_HEIGHT, COVER_WIDTH_HEIGHT);
            
            [cfIntLayer addSublayer:background.layer];
        }
        
        self.contentSize=CGSizeMake(320.0, (frame.size.height+(SCROLL_PIXELS*([_covers count]-1))));
        
        [self.layer addSublayer:cfIntLayer];
        [self  layoutLayer:cfIntLayer];
                                    
        
    }
    return  self;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    selectedCover=(int)roundf(self.contentOffset.y/SCROLL_PIXELS);
    
    if (selectedCover>[_covers count]-1) {
        selectedCover=[_covers count]-1;
    }
    [self layoutLayer:cfIntLayer];
}


-(void)setSelectedCover:(int)index{
    if (index!=selectedCover) {
        selectedCover=index;
        
        [self layoutLayer:cfIntLayer];
        self.contentOffset=CGPointMake(self.contentOffset.x, selectedCover*SCROLL_PIXELS);
    }
}

-(int)getSelectedCover{
    return selectedCover;
}

-(void)layoutLayer:(CAScrollLayer *)layer{
    CALayer * sublayer;
    NSArray * array;
    size_t i,count;
    
    CGRect rect,cfImageRect;
    
    CGSize cellSize,spacing,margin,size;
    
    CATransform3D leftTransform,rightTransfrom,sublayerTransform;
    
    float  zCenterPosition,zSidePosion;
    float  siderSpacingFactor,rowScaleFactor;
    float  angle=1.39;
    int    x;
    
    size =[layer bounds].size;
    zCenterPosition=60;
    zSidePosion=0;
    siderSpacingFactor=.85;
    rowScaleFactor=.55;
    leftTransform=CATransform3DMakeRotation(angle, -1, 0, 0);
    rightTransfrom=CATransform3DMakeRotation(-angle, -1, 0, 0);
    
    margin=CGSizeMake(5.0, 5.0);
    spacing=CGSizeMake(5.0, 5.0);
    
    cellSize=CGSizeMake(COVER_WIDTH_HEIGHT, COVER_WIDTH_HEIGHT);
    
    margin.width+=(size.width-cellSize.width*[_covers count]-spacing.width*([_covers count]-1))*0.5;
    
    margin.width=floor(margin.width);
    
    array=[layer sublayers];
    count=[array count];
    sublayerTransform=CATransform3DIdentity;
    
    sublayerTransform.m34=-0.006;
    
    
    [CATransaction begin];
    [CATransaction setValue:[NSNumber numberWithFloat:0.3f] forKey:@"animationDuration"];
    
    for (i=0; i<count; i++) {
        sublayer=[array objectAtIndex:i];
        x=i;
        
        rect.size=*(CGSize*)&cellSize;
        rect.origin=CGPointZero;
        cfImageRect=rect;
        
        
        rect.origin.x=size.width/2-cellSize.width/2;
        
        rect.origin.y=margin.height+x*(cellSize.height+spacing.height);
        
        [[sublayer superlayer] setSublayerTransform:sublayerTransform];
        
        if (x<selectedCover) {
            rect.origin.y+=cellSize.height*siderSpacingFactor*(float)(selectedCover-x-rowScaleFactor);
            
            sublayer.zPosition=zSidePosion-2.0*(selectedCover-x);
            sublayer.transform=leftTransform;
        }else if (x>selectedCover){
            rect.origin.y-=cellSize.height*siderSpacingFactor*(float)(x-selectedCover-rowScaleFactor);
            
            sublayer.zPosition=zSidePosion-2.0*(x-selectedCover);
            sublayer.transform=rightTransfrom;
        }
        
        else{
            sublayer.transform=CATransform3DIdentity;
            sublayer.zPosition=zCenterPosition;
            
            [layer scrollToPoint:CGPointMake(0, rect.origin.y-(([layer bounds].size.height-cellSize.width)/2.0))];
            
            layer.position=CGPointMake(160.0f, 240.0f+(selectedCover*SCROLL_PIXELS));
        }
        [sublayer setFrame:rect];
        
    }
    [CATransaction commit];
}


@end

@interface ViewController ()

@end

@implementation ViewController

-(id)init{
    self=[super init];
    
    if (self!=nil) {
        covers=[[NSMutableArray alloc] init];
        
        for (int i=1; i<=6; i++) {
            NSLog(@"Loading demoo image %d \n",i);
//            UIImage * image=[[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.zdziarski.com/demo/%d.png",i]]]];
            UIImage * image=[[UIImage alloc] init];
            image=[UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i]];
            
            [covers addObject:image];
            
        }
    }
    return  self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    covertFlowView=[[CFView alloc] initWithFrame:self.view.frame covers:covers];
    
    covertFlowView.selectedCover=2;
    self.view=covertFlowView;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
