//
//  AppDelegate.h
//  ConvertFlowH
//
//  Created by HuLiangJun on 12-11-14.
//  Copyright (c) 2012年 HuLiangJun. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
