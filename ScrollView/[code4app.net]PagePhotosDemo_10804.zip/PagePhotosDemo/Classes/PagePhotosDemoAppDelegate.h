//
//  PagePhotosDemoAppDelegate.h
//  PagePhotosDemo
//
//  Created by junmin liu on 10-8-23.
//  Copyright Openlab 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PagePhotosDataSource.h"
#import "PagePhotosView.h"

@interface PagePhotosDemoAppDelegate : NSObject <UIApplicationDelegate, PagePhotosDataSource> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

