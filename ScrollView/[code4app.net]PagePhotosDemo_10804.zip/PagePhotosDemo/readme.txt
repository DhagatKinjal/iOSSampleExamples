/* 
   readme.txt
   PagePhotosDemo

   Created by junmin liu on 10-8-23.
   Copyright 2010 Openlab. All rights reserved.
 */

1. 加入以下文件到项目中
PagePhotosView.h
PagePhotosView.m
PagePhotosDataSource.h


2. 引用头文件
#import "PagePhotosDataSource.h"
#import "PagePhotosView.h"

3. 头文件中声明要实现PagePhotosDataSource接口 
例如：
@interface PagePhotosDemoAppDelegate : NSObject <UIApplicationDelegate, PagePhotosDataSource>

4. 类文件中实现PagePhotosDataSource接口方法
例如：
// 有多少页
//
- (int)numberOfPages {
	return 5;
}

// 每页的图片
//
- (UIImage *)imageAtIndex:(int)index {
	NSString *imageName = [NSString stringWithFormat:@"1933_%d.jpg", index + 1];
	return [UIImage imageNamed:imageName];
}

5. 加入PagePhotosView

	PagePhotosView *pagePhotosView = [[PagePhotosView alloc] initWithFrame: CGRectMake(0, 0, 320, 260) withDataSource: self];
	[window addSubview:pagePhotosView];
	[pagePhotosView release];
