//
//  PanelTableViewAppDelegate.h
//  PanelTableView
//
//  Created by honcheng on 11/27/10.
//  Copyright 2010 honcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PanelTableViewAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

