//
//  SamplePanelsViewControllerForiPad.h
//  SampleApp
//
//  Created by honcheng on 3/12/11.
//  Copyright 2011 honcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SamplePanelsViewController.h"

@interface SamplePanelsViewControllerForiPad : SamplePanelsViewController 
@end
