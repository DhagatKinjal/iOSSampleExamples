//
//  SamplePanelView.h
//  SampleApp
//
//  Created by honcheng on 11/27/10.
//  Copyright 2010 honcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PanelView.h"

@interface SamplePanelView : PanelView 
@end
