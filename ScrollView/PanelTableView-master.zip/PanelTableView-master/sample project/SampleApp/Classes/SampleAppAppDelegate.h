//
//  SampleAppAppDelegate.h
//  SampleApp
//
//  Created by honcheng on 11/27/10.
//  Copyright 2010 honcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleAppAppDelegate : NSObject <UIApplicationDelegate> 
@property (nonatomic, strong) IBOutlet UIWindow *window;



@end

