HMScrollView
============

Customized scroll view, the scroll view support tap action and download the images from internet asynchronously.