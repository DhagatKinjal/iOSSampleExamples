ZGParallelView
==============

**This project is preparing for deleting.**

For reason, please see [issue8](https://github.com/zhigang1992/ZGParallelView/issues/8)

I'm truly sorry for those who used this project.

The code have been fixed but will no longer been maintained.

---------
This is a way easier implementation of similiar effect.

https://github.com/zhigang1992/ZGExpandZoomView
