//
//  main.m
//  ScrollXib
//
//  Created by Kevin Liang on 2009/10/5.
//  Copyright My-Diy.com +886-912562925  2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
