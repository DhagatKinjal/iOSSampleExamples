//
//  ScrollXibAppDelegate.h
//  ScrollXib
//
//  Created by Kevin Liang on 2009/10/5.
//

#import <UIKit/UIKit.h>

@class ScrollXibViewController;

@interface ScrollXibAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ScrollXibViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ScrollXibViewController *viewController;

@end

