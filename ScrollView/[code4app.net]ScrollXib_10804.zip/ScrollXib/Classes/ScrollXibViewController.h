//
//  ScrollXibViewController.h
//  ScrollXib
//
//  Created by Kevin Liang on 2009/10/5.
//

#import <UIKit/UIKit.h>
@class scrollX;

@interface ScrollXibViewController : UIViewController {
	IBOutlet UIScrollView *scr1;
}
@property (retain, nonatomic) UIScrollView *scr1;
@end

