//
//  scrollX.m
//
//  Created by Kevin Liang on 2009/10/5.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "scrollX.h"

@implementation scrollX

//@synthesize img1;
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {

    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end