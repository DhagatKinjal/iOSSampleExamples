//
//  UIView.m
//
//  Created by Kevin Liang on 2009/10/5.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "UIView.h"

@implementation UIView

@end
