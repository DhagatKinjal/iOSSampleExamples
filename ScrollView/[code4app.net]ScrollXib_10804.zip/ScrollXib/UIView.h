//
//  UIView.h
//
//  Created by Kevin Liang on 2009/10/5.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface UIView : UIResponder {

}

@end
