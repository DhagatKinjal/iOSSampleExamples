//
//  AppDelegate.h
//  DVSlideViewController
//
//  Created by Dick Verbunt on 7/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DVSlideViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) DVSlideViewController *viewController;

@end
