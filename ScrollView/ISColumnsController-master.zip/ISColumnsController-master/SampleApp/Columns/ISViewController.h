#import <UIKit/UIKit.h>

@interface ISViewController : UIViewController

- (IBAction)pushViewController;

@end
