## Requirements

iOS 5 or later


## Set up

- add `ISColumnsController/` to your Xcode project
- add `QuartzCore.framework` to "Link Binary With Libraries" (.xcodeproj -> Build Phases)
- set viewControllers of ISColumnsController 
- push ISColumnsController to UINavigationController


## License

MIT
