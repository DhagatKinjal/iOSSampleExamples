//
//  FlowCoverViewController.h
//  FlowCover
//
//  Created by William Woody on 12/13/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FlowCoverView.h"

@interface FlowCoverViewController : UIViewController <FlowCoverViewDelegate>
{

}

- (IBAction)done:(id)sender;

@end

