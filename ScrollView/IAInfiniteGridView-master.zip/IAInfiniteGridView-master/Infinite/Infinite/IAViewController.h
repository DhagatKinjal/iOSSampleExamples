//
//  IAViewController.h
//  Infinite
//
//  Created by Ikhsan Assaat on 10/1/12.
//  Copyright (c) 2012 3kunci. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IAInfiniteGridView.h"

@interface IAViewController : UIViewController <IAInfiniteGridDataSource, IAInfiniteGridDelegate>

@end
