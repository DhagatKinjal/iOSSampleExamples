//
//  main.m
//  WheelComponent
//
//  Created by Ahmed Ragab on 1/4/13.
//  Copyright (c) 2013 AhmedRagab. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GNAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GNAppDelegate class]));
    }
}
