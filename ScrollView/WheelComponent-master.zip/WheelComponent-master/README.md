WheelComponent
==============

Component like the one in iAd app of Apple
