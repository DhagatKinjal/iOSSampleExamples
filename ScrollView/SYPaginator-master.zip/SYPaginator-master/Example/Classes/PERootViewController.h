//
//  PERootViewController.h
//  Paginator Example
//
//  Created by Sam Soffes on 3/8/12.
//  Copyright (c) 2012 Synthetic. All rights reserved.
//

@interface PERootViewController : SYPaginatorViewController
@end
