//
//  SYPaginator.h
//  SYPaginator
//
//  Created by Sam Soffes on 3/8/12.
//  Copyright (c) 2012 Synthetic. All rights reserved.
//

#import <SYPaginator/SYPaginatorView.h>
#import <SYPaginator/SYPaginatorViewController.h>
#import <SYPaginator/SYPageView.h>
#import <SYPaginator/SYPageControl.h>
