//
//  AnotherViewController.h
//  CycleScrollDemo
//
//  Created by Eric on 12-6-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnotherViewController : UIViewController

@property (retain, nonatomic) IBOutlet UILabel *lb;
@end
