//
//  PageControlDemoAppDelegate_iPhone.m
//  PageControlDemo
//
//  Created by honcheng on 5/14/11.
//  Copyright 2011 BuUuK Pte Ltd. All rights reserved.
//

#import "PageControlDemoAppDelegate_iPhone.h"

@implementation PageControlDemoAppDelegate_iPhone


@end
