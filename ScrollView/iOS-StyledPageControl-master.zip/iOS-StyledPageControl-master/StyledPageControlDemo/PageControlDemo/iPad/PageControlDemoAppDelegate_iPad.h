//
//  PageControlDemoAppDelegate_iPad.h
//  PageControlDemo
//
//  Created by honcheng on 5/14/11.
//  Copyright 2011 BuUuK Pte Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PageControlDemoAppDelegate.h"

@interface PageControlDemoAppDelegate_iPad : PageControlDemoAppDelegate {
    
}

@end
