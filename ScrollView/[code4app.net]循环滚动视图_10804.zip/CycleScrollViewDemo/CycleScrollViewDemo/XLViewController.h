//
//  XLViewController.h
//  CycleScrollViewDemo
//
//  Created by xie liang on 9/14/12.
//  Copyright (c) 2012 xie liang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLCycleScrollView.h"

@interface XLViewController : UIViewController
<XLCycleScrollViewDatasource,XLCycleScrollViewDelegate>

@end
