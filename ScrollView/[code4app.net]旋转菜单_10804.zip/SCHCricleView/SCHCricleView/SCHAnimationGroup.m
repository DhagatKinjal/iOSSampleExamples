//
//  SCHAnimationGroup.m

//
//  Created by 魏巍 on 12-9-26.
//
//

#import "SCHAnimationGroup.h"

@interface SCHAnimationGroup ()

@end

@implementation SCHAnimationGroup

@synthesize animation_tag = _animation_tag;

@end
