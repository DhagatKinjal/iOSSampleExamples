# Developed by litl

This project was conceived of with the help of the full software team at litl.

## litl iOS Team

* [Brad Taylor](https://github.com/btaylor) (maintainer, initial developer)
* [Ash Atkins](https://github.com/aatkins)
* [Clay Bridges](https://github.com/cbridges)
* [Brian Connatser](https://github.com/connatser)
* [Walter Hatcher](https://github.com/whatcher)
* [Erik Hunter](http://github.com/ehunter)

## Patches and Suggestions

Add yourself as a contributor!

* (your name here)
