//
//  UIPickerViewUAppDelegate.h
//  UIPickerViewU
//
//  Created by Paul Ingendorf on 2008-05-28.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UIPickerViewUViewController;

@interface UIPickerViewUAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet UIPickerViewUViewController *viewController;
	UIPickerView *myPickerView;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) UIPickerViewUViewController *viewController;
@property (nonatomic, retain) UIPickerView *myPickerView;

@end

