//
//  UIPickerViewUAppDelegate.m
//  UIPickerViewU
//
//  Created by Paul Ingendorf on 2008-05-28.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "UIPickerViewUAppDelegate.h"
#import "UIPickerViewUViewController.h"

@implementation UIPickerViewUAppDelegate

@synthesize window;
@synthesize viewController;
@synthesize myPickerView;

- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	
	// Override point for customization after app launch	
	myPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 20, 300, 120)];
	myPickerView.delegate = self;
    [window addSubview:viewController.view];
	[window addSubview:myPickerView];
	[window makeKeyAndVisible];

}


- (void)dealloc {
    [viewController release];
	[window release];
	[super dealloc];
}



- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSUInteger)row forComponent:(NSUInteger)component; {
	NSMutableArray *strings = [NSMutableArray arrayWithCapacity:10];
	[strings addObject:@"Zero"];
	[strings addObject:@"One"];
	[strings addObject:@"Two"];
	[strings addObject:@"Three"];
	[strings addObject:@"Four"];
	[strings addObject:@"Five"];
	[strings addObject:@"Six"];
	[strings addObject:@"Seven"];
	[strings addObject:@"Eight"];
	[strings addObject:@"Nine"];
	return [strings objectAtIndex:(row%10)];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSUInteger)row inComponent:(NSUInteger)component {
	[self pickerViewLoaded:nil];
}

- (NSUInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSUInteger)component {
	return 16384;
}


-(void)pickerViewLoaded: (id)blah {
	NSUInteger max = 16384;
	NSUInteger base10 = (max/2)-(max/2)%10;
	[myPickerView selectRow:[myPickerView selectedRowInComponent:0]%10+base10 inComponent:0 animated:false];
}


- (NSUInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
	return 1;
}

@end
