

#import <SenTestingKit/SenTestingKit.h>


@interface testpickerviewTests : SenTestCase {
@private
    
}

@end
