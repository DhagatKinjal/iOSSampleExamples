

#import <UIKit/UIKit.h>

@class testpickerviewViewController;

@interface testpickerviewAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet testpickerviewViewController *viewController;

@end
