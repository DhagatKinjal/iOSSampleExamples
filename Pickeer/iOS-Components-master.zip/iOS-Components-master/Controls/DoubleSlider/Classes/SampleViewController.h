//
//  SampleViewController.h
//  Sample
//
//  Created by Dimitris on 14/07/2010.
//  Copyright locus-delicti.com 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleViewController : UIViewController {
	//two labels to show the currently selected values
	UILabel *leftLabel;
	UILabel *rightLabel;
}

@end

