//
//  Dial_ExampleTests.m
//  Dial ExampleTests
//
//  Created by Dimitris on 03/04/2011.
//  Copyright 2011 unit9.com. All rights reserved.
//

#import "Dial_ExampleTests.h"


@implementation Dial_ExampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Dial ExampleTests");
}

@end
