//
//  Dial_ExampleTests.h
//  Dial ExampleTests
//
//  Created by Dimitris on 03/04/2011.
//  Copyright 2011 unit9.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Dial_ExampleTests : SenTestCase {
@private
    
}

@end
