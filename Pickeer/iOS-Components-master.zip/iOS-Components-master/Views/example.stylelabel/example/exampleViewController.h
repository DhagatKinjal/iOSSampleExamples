//
//  exampleViewController.h
//  example
//
//  Created by Dimitris on 14/05/2011.
//  Copyright 2011 unit9.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StyleLabel;

@interface exampleViewController : UIViewController {
    StyleLabel *styleLabel;
}

@end
