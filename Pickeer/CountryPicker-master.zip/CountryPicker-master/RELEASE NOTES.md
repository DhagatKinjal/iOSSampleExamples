Version 1.0.2

- Capitalized Japan
- Added South Sudan
- Refactored to make subclassing easier

Version 1.0.1

- Added ARC support
- Added example project

Version 1.0

- Initial release