# GM AFPickerView

* Parameterized images 
* Picker Animation
* Picker Toolbar
* Cocoapod compatiable
`dependency 'AFPickerView', :git => 'https://github.com/fanyuanheng/AFPickerView.git', :tag => '0.3'`
