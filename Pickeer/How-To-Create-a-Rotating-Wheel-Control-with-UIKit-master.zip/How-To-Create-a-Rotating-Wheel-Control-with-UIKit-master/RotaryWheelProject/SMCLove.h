//
//  SMCLove.h
//  RotaryWheelProject
//
//  Created by cesarerocchi on 2/14/12.
//  Copyright (c) 2012 studiomagnolia.com. All rights reserved.


#import <Foundation/Foundation.h>

@interface SMClove : NSObject

@property float minValue;
@property float maxValue;
@property float midValue;
@property int value;

@end
