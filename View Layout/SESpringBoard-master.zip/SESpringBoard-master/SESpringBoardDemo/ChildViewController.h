//
//  ChildViewController.h
//  SESpringBoardDemo
//
//  Created by Sarp Erdag on 11/5/11.
//  Copyright (c) 2011 Sarp Erdag. All rights reserved.
//



@interface ChildViewController : UIViewController {
    
}

@end
