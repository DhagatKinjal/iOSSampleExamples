/* 
 * Copyright (c) 2011, Nehira.com
 * All rights reserved.
 * 
 * @author Philip Kluz
 * @project ZUUIRevealController 0.9.5 Tutorial
 * @date 07.02.2012
 */

#import <UIKit/UIKit.h>

@interface MapViewController : UIViewController

@end