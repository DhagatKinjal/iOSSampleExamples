//
//  NRAppDelegate.h
//  NRGridViewSampleApp
//
//  Created by Louka Desroziers on 03/02/12.
//  Copyright (c) 2012 PixiApps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
