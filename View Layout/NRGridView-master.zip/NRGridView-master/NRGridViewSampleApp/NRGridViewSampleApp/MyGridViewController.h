//
//  MyGridViewController.h
//  NRGridViewSampleApp
//
//  Created by Louka Desroziers on 04/02/12.
//  Copyright (c) 2012 Novedia Regions. All rights reserved.
//

#import "NRGridViewController.h"

@interface MyGridViewController : NRGridViewController

@end
