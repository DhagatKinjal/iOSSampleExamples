//
//  main.m
//  NRGridViewSampleApp
//
//  Created by Louka Desroziers on 03/02/12.
//  Copyright (c) 2012 PixiApps. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NRAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NRAppDelegate class]));
    }
}
