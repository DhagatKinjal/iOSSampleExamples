//
//  MainViewController.h
//  SlidingGridView
//
//  Created by Dmitry Klimkin on 5/12/12.
//  Copyright (c) 2012 Dmitry Klimkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UITableViewController

@end
