SlidingGridView / SlidingListView
==================

Grid and List views to display sliding subviews animation.

##Download
    $ git clone https://github.com/kronik/SlidingGridView.git
    $ cd SlidingGridView/

##Usage
Please check out the demo project included.