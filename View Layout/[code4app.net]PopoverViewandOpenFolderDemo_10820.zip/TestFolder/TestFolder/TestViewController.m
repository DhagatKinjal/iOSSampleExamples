//
//  TestViewController.m
//  TestFolder
//
//  Created by yangjunying on 12-7-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TestViewController.h"
#import "TestTableViewControllerViewController.h"

@interface TestViewController ()

- (void)Pop:(id)sender;
- (void)OpenFolder;

@end

@implementation TestViewController

@synthesize mybutton;

- (void)dealloc
{
    self.mybutton = nil;
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
   self.mybutton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.mybutton.frame = CGRectMake(100, 300, 200, 44);
    [self.mybutton setTitle:@"open" forState:UIControlStateNormal];
    [self.view addSubview:self.mybutton];
    [self.mybutton addTarget:self action:@selector(OpenFolder) forControlEvents:UIControlEventTouchUpInside];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    self.mybutton = nil;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationItem.rightBarButtonItem =
    [[[UIBarButtonItem alloc] initWithTitle:@"pop"  
                                      style:UIBarButtonItemStyleBordered 
                                     target:self
                                     action:@selector(Pop:)] autorelease];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    if([[OpenFolder ShareOpenFolder] IsOpened])
    {
        CGRect rc = self.mybutton.frame;
        [[OpenFolder ShareOpenFolder] ReFreshCurrentOpenFolder:rc];
        [[OpenFolder ShareOpenFolder].contentController willAnimateRotationToInterfaceOrientation:toInterfaceOrientation duration:duration];
    }
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
//    if([popoverController isKindOfClass:[UIPopoverController class]])
    {
        [popoverController release];
    }
}

- (void)Pop:(id)sender
{
    TestTableViewControllerViewController *tbc = [[[TestTableViewControllerViewController alloc] init] autorelease];
    
    tbc.title = @"test pop";
    FPPopoverController *fpop = [[FPPopoverController alloc] initWithViewController:tbc];
    fpop.arrowDirection = FPPopoverArrowDirectionUp;
    fpop.delegate = self;
    
    fpop.contentSize = CGSizeMake(240, 240);
    [fpop presentPopoverFromBarButtonItem:sender];
}

- (void)OpenFolder
{
    TestTableViewControllerViewController *tbc = [[[TestTableViewControllerViewController alloc] init] autorelease];
    
    tbc.title = @"folder";
    UINavigationController *nav = [[[UINavigationController alloc] initWithRootViewController:tbc] autorelease];
    
    [tbc.view setBackgroundColor:[UIColor redColor]];
    CGRect rc = self.mybutton.frame;
    //        
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:self.mybutton,@"button",nil];
    //        
    [[OpenFolder ShareOpenFolder] openFolderWithController:nav fromRect:rc containerView:self.view delegate:self userInfo:dict animated:YES];
}

- (CGFloat)OpenFolder:(OpenFolder*)theFolder contentViewHeightOrWidth:(UIViewController*)contentController orientation:(SplitOrientation)splitOrientation userInfo:(id)userInfo
{
    return 200;
}

@end
