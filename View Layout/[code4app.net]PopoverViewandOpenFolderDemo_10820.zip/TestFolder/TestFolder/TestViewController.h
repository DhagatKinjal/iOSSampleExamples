//
//  TestViewController.h
//  TestFolder
//
//  Created by yangjunying on 12-7-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FPPopoverController.h"
#import "OpenFolder.h"

@interface TestViewController : UIViewController<FPPopoverControllerDelegate,OpenFolderDelegate>

@property(nonatomic,retain) UIButton *mybutton;

@end
