//
//  JSBadgeSamplesViewController.h
//  JSBadgeView_SampleProject
//
//  Created by Javier Soto on 7/24/12.
//  Copyright (c) 2012 Javier Soto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSBadgeSamplesViewController : UIViewController

@end
