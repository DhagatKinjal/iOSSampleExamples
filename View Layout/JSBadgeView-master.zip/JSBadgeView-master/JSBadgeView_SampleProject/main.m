//
//  main.m
//  JSBadgeView_SampleProject
//
//  Created by Javier Soto on 7/24/12.
//  Copyright (c) 2012 Javier Soto. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JSAppDelegate class]));
    }
}
