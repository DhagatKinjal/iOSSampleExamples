#import "LBorderView.h"


@interface ViewController : UIViewController
{
    __weak IBOutlet LBorderView *_borderView1;
    __weak IBOutlet LBorderView *_borderView2;
    __weak IBOutlet LBorderView *_borderView3;
    __weak IBOutlet LBorderView *_borderView4;
}


@end