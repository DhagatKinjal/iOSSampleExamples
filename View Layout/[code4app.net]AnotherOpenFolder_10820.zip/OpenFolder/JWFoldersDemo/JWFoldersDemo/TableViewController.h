//
//  TableViewController.h
//  JWFoldersDemo
//
//  Created by 周栋梁 on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UIViewController
<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,retain) IBOutlet UITableView *iTableView;

@end
