#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIViewController *sampleFolder;//视图
    
    IBOutlet UISegmentedControl * changeSC;
    IBOutlet UIButton * bt;
    int up_down;//0 代表向上展开，1代表向下展开
}

@property(nonatomic,retain) IBOutlet UISegmentedControl * changeSC;
@property(nonatomic,retain) IBOutlet UIButton * bt;

- (IBAction)openFolder:(id)sender;
- (IBAction)changeDirection:(id)sender;

@end
