#import <QuartzCore/QuartzCore.h>
#import "ViewController.h"
#import "JWFolders.h"

#import "FolderViewController.h"
#import "TableViewController.h"

@implementation ViewController
@synthesize changeSC;//用来切换上下的seg
@synthesize bt;//展开按钮

- (void)viewDidLoad {
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"wallpaper"]];
}

#pragma mark - Folder Example

- (IBAction)changeDirection:(id)sender
{
    if ([changeSC selectedSegmentIndex] == 0) {
        up_down = 0;//向上展开
        [bt setFrame:CGRectMake((320-69)/2, 250, 69, 78)];
    }else {
        up_down = 1;//向下展开
        [bt setFrame:CGRectMake((320-69)/2, 250-78, 69, 78)];
    }
}

- (IBAction)openFolder:(id)sender {
    NSLog(@"即将展开.");
    //构造展开视图
    if (up_down == 0) {
        sampleFolder = [[FolderViewController alloc] initWithNibName:NSStringFromClass([FolderViewController class]) bundle:nil];
    }else {
        sampleFolder = [[TableViewController alloc] initWithNibName:NSStringFromClass([TableViewController class]) bundle:nil];
    }
    
    CGPoint openPoint = CGPointMake(140.0f,self.view.frame.size.height - 210); //arbitrary point,x不起作用，y是展开的起始点
    //展开
    [JWFolders openFolderWithContentView:sampleFolder.view position:openPoint containerView:self.view sender:self direction:up_down];
    /*
    [JWFolders openFolderWithContentView:sampleFolder.view
                                position:openPoint 
                           containerView:self.view 
                                  sender:self 
                               openBlock:^(UIView *contentView, CFTimeInterval duration, CAMediaTimingFunction *timingFunction) {
                                   //perform custom animation here on contentView if you wish
                                   //NSLog(@"Folder view: %@ is opening with duration: %f", contentView, duration);
                                   NSLog(@"打开");
                               }
                              closeBlock:^(UIView *contentView, CFTimeInterval duration, CAMediaTimingFunction *timingFunction) {
                                  //also perform custom animation here on contentView if you wish
                                   //NSLog(@"Folder view: %@ is closing with duration: %f", contentView, duration);
                                   NSLog(@"准备关闭");
                              }
                         completionBlock:^ {
                             //the folder is closed and gone, lets do something cool!
                              NSLog(@"视图已经关闭.");
                         }
     ];
    */
    
}


@end
