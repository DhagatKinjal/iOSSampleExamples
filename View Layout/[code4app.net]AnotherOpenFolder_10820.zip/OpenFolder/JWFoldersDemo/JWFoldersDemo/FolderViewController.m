#import "FolderViewController.h"

@implementation FolderViewController


- (void)viewDidLoad {
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"noise"]];
    //perhaps you might want to add an inner shadow to your view for a more convincing effect
}


@end
