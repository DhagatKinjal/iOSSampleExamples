//
//  AlignmentAttributedLabelViewController.h
//  NimbusCatalog
//
//  Created by Jeroen Trappers on 18/12/12.
//  Copyright (c) 2012 Nimbus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlignmentAttributedLabelViewController : UIViewController

@end
