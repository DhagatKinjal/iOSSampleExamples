//
//  PSStackedViewGlobal.m
//  PSStackedView
//
//  Created by Peter Steinberger on 9/8/11.
//  Copyright (c) 2011 Peter Steinberger. All rights reserved.
//

#import "PSStackedView.h"

PSSVLogLevel kPSSVDebugLogLevel = PSSVLogLevelError;