//
//  PSStackedViewSegue.h
//  PSStackedView
//
//  Created by Marcel Ball on 12-01-19.
//  Copyright (c) 2012 Peter Steinberger. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSStackedViewSegue : UIStoryboardSegue

@end
