//
//  CSBulletListView.h
//  CSLinearLayoutView
//
//  Created by Charles Scalesse on 4/29/12.
//  Copyright (c) 2012 Charles Scalesse. All rights reserved.
//

#import "CSLinearLayoutView.h"

@interface CSBulletListView : CSLinearLayoutView

@property (nonatomic, retain) NSMutableArray *list;

@end
