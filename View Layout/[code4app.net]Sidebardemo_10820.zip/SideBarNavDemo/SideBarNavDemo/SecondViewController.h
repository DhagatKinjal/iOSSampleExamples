//
//  SeconViewController.h
//  SideBarNavDemo
//
//  Created by JianYe on 12-12-12.
//  Copyright (c) 2012年 JianYe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@end
