//
//  FirstViewController.h
//  SideBarNavDemo
//
//  Created by JianYe on 12-12-11.
//  Copyright (c) 2012年 JianYe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
@property (strong,nonatomic)IBOutlet UILabel *titleLabel;

@property (assign,nonatomic) int index;
@end
