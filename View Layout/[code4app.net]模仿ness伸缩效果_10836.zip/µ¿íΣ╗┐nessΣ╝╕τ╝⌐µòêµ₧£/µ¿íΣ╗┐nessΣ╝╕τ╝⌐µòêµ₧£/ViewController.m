//
//  ViewController.m
//  模仿ness伸缩效果
//
//  Created by hanqing wang on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    
    
    Boolean isOpen;
    
}

@end

@implementation ViewController
@synthesize mainView;
@synthesize btn;
@synthesize img;
@synthesize view1;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    isOpen = YES;
}

- (void)viewDidUnload
{
    [self setMainView:nil];
    [self setBtn:nil];
    [self setImg:nil];
    [self setView1:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (IBAction)OnClick1:(UIButton *)sender {
    
    if (isOpen) {
        [self.img setHidden:YES];
    }else {
        [self.img setHidden:NO];
    }
    
    [UIView animateWithDuration:.5 animations:^{
        self.mainView.alpha = 1;
//        self.mainView.transform = CGAffineTransformScale(self.btn.transform, 4.2f, 4.2f);
        self.mainView.frame = CGRectMake(self.mainView.frame.origin.x, self.mainView.frame.origin.y, self.mainView.frame.size.width, self.mainView.frame.size.height+(isOpen ? -290 : 290));
        self.btn.frame = CGRectMake(self.btn.frame.origin.x,self.btn.frame.origin.y+(isOpen ? -290 : 290), self.btn.frame.size.width, self.btn.frame.size.height);
        self.view1.frame = CGRectMake(self.view1.frame.origin.x, self.view1.frame.origin.y+(isOpen ? -290 : 290), self.view1.frame.size.width, self.view1.frame.size.height);
        self.img.alpha=0;
    }completion:^(BOOL finished) {
//        self.btn.alpha = 1;
//        self.btn.transform = CGAffineTransformIdentity;
        if (isOpen) {
            [UIView animateWithDuration:.5 animations:^{
                self.img.alpha = 1;  
            }];
            
        }
    }];
    
    isOpen = !isOpen;
    
}
- (void)dealloc {
    [mainView release];
    [btn release];
    [img release];
    [view1 release];
    [super dealloc];
}
@end
