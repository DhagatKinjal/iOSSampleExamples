//
//  main.m
//  MWFSlideNavigationViewControllerDemo
//
//  Created by Meiwin Fu on 24/1/12.
//  Copyright (c) 2012 –MwF. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MWFAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MWFAppDelegate class]));
    }
}
