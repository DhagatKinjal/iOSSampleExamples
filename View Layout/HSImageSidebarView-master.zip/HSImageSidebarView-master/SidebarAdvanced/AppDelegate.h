//
//  AppDelegate.h
//  SidebarAdvanced
//
//  Created by BJ Homer on 5/3/12.
//  Copyright (c) 2012 Instructure. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
