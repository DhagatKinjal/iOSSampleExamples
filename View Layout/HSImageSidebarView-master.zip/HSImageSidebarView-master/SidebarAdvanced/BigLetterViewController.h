//
//  BigLetterViewController.h
//  SidebarAdvanced
//
//  Created by BJ Homer on 5/3/12.
//  Copyright (c) 2012 Instructure. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BigLetterViewController : UIViewController

- (UIImage *)snapshot;

@end
