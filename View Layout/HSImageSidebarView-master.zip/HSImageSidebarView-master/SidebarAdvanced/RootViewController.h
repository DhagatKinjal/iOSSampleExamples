//
//  ViewController.h
//  SidebarAdvanced
//
//  Created by BJ Homer on 5/3/12.
//  Copyright (c) 2012 Instructure. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

- (void)useThumbnail:(UIImage *)thumb forChildController:(UIViewController *)child;

@end
