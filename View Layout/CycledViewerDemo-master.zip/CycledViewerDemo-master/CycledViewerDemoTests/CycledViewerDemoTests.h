//
//  CycledViewerDemoTests.h
//  CycledViewerDemoTests
//
//  Created by xiaohaibo on 12-12-23.
//  Copyright (c) 2012年 xiaohaibo. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CycledViewerDemoTests : SenTestCase

@end
