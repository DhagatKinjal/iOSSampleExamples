//
//  KLNoteViewControllerTests.m
//  KLNoteViewControllerTests
//
//  Created by Kieran Lafferty on 2012-12-29.
//  Copyright (c) 2012 Kieran Lafferty. All rights reserved.
//

#import "KLNoteViewControllerTests.h"

@implementation KLNoteViewControllerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in KLNoteViewControllerTests");
}

@end
