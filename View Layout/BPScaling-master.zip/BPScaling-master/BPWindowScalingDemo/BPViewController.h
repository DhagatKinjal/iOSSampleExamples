//
//  BPViewController.h
//  BPAppScale
//
//  Created by Brian Partridge on 10/30/12.
//  Copyright (c) 2012 Brian Partridge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPViewController : UIViewController <UITextFieldDelegate>

@end
