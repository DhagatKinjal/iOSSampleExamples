//
//  RNExampleViewController.h
//  RNSwipeViewController
//
//  Created by Ryan Nystrom on 10/31/12.
//  Copyright (c) 2012 Ryan Nystrom. All rights reserved.
//

#import "RNSwipeViewController.h"

@interface RNExampleViewController : RNSwipeViewController
<RNSwipeViewControllerDelegate>

@end
