//
//  GHAppDelegate.h
//  GHSidebarNav
//
//  Created by Greg Haines on 11/20/11.
//

#import <Foundation/Foundation.h>


@interface GHAppDelegate : UIResponder <UIApplicationDelegate>

@end
