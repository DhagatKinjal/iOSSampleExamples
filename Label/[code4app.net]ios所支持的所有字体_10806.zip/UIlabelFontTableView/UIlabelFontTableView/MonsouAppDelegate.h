//
//  MonsouAppDelegate.h
//  UIlabelFontTableView
//
//  Created by monsou on 12-10-11.
//  Copyright (c) 2012年 monsou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MonsouAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
