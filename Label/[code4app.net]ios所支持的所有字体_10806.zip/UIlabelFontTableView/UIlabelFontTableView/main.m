//
//  main.m
//  UIlabelFontTableView
//
//  Created by monsou on 12-10-11.
//  Copyright (c) 2012年 monsou. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MonsouAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MonsouAppDelegate class]));
    }
}
