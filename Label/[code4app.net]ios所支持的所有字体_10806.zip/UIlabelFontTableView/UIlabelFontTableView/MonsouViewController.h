//
//  MonsouViewController.h
//  UIlabelFontTableView
//
//  Created by monsou on 12-10-11.
//  Copyright (c) 2012年 monsou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MonsouViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>{
    IBOutlet UITableView *fontTableView;
}

@end
