//
//  ModalViewController.h
//  MarqueeLabelDemo
//
//  Created by Charles Powell on 6/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController

@end
