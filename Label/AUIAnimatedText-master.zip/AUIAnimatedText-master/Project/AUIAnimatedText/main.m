//
//  main.m
//  AUIAnimatedText
//
//  Created by Adam Siton on 9/20/11.
//  Copyright 2011 Any.do. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
