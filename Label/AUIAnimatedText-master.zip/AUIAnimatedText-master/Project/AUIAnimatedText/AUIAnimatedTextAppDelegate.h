//
//  AUIAnimatedTextAppDelegate.h
//  AUIAnimatedText
//
//  Created by Adam Siton on 9/20/11.
//  Copyright 2011 Adam Siton. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AUIAnimatedTextAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, strong) IBOutlet UIWindow *window;

@end
