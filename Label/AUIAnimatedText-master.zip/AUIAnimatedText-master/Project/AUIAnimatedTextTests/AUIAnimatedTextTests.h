//
//  AUIAnimatedTextTests.h
//  AUIAnimatedTextTests
//
//  Created by Adam Siton on 9/20/11.
//  Copyright 2011 Any.do. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface AUIAnimatedTextTests : SenTestCase {
@private
    
}

@end
