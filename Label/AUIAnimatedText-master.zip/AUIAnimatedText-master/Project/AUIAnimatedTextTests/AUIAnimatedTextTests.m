//
//  AUIAnimatedTextTests.m
//  AUIAnimatedTextTests
//
//  Created by Adam Siton on 9/20/11.
//  Copyright 2011 Any.do. All rights reserved.
//

#import "AUIAnimatedTextTests.h"


@implementation AUIAnimatedTextTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AUIAnimatedTextTests");
}

@end
