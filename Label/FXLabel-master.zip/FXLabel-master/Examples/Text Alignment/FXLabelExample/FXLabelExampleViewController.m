//
//  FXLabelExampleViewController.m
//  FXLabelExample
//
//  Created by Nick Lockwood on 20/08/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import "FXLabelExampleViewController.h"

@implementation FXLabelExampleViewController

//no code needed, everything can be done in nib
//but if you did want to do it in code...

//top left
//label.textAlignment = UITextAlignmentLeft;
//label.contentMode = UIViewContentModeTop;

//top center
//label.textAlignment = UITextAlignmentCenter;
//label.contentMode = UIViewContentModeTop;

//top right
//label.textAlignment = UITextAlignmentRight;
//label.contentMode = UIViewContentModeTop;

//center left
//label.textAlignment = UITextAlignmentLeft;
//label.contentMode = UIViewContentModeCenter;

//center
//label.textAlignment = UITextAlignmentCenter;
//label.contentMode = UIViewContentModeCenter;

//center right
//label.textAlignment = UITextAlignmentRight;
//label.contentMode = UIViewContentModeCenter;

//bottom left
//label.textAlignment = UITextAlignmentLeft;
//label.contentMode = UIViewContentModeBottom;

//bottom center
//label.textAlignment = UITextAlignmentCenter;
//label.contentMode = UIViewContentModeBottom;

//bottom right
//label.textAlignment = UITextAlignmentRight;
//label.contentMode = UIViewContentModeBottom;

@end
