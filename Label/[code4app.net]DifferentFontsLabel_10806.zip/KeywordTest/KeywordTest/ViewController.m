//
//  ViewController.m
//  KeywordTest
//
//  Created by Mac Pro on 4/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "DetailTextView.h"
@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    DetailTextView *label = [[DetailTextView alloc]initWithFrame:self.view.frame];
    [label setText:@"abcdefghijklmnopqrstuvwxyz" WithFont:[UIFont systemFontOfSize:17] AndColor:[UIColor blackColor]];
    [label setKeyWordTextArray:[NSArray arrayWithObjects:@"a",@"d",@"f",@"c",@"w", nil] WithFont:[UIFont fontWithName:@"AcademyEngravedLetPlain" size:25] AndColor:[UIColor blueColor]];
    [label setKeyWordTextArray:[NSArray arrayWithObjects:@"b",@"e",@"g",@"q",@"z", nil] WithFont:[UIFont fontWithName:@"SnellRoundhand" size:35] AndColor:[UIColor redColor]];
    [self.view addSubview:label];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
