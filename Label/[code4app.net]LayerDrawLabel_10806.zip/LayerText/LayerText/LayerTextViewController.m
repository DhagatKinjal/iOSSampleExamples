//
//  LayerTextViewController.m
//  LayerText
//
//  Created by he on 12-9-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LayerTextViewController.h"

@interface LayerTextViewController ()

@end

@implementation LayerTextViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSArray *_tempArray = [NSArray arrayWithObjects:
                           @"Good",
                           @"Good Night",
                           @"Good EveryBody",
                           @"Good Day",
                           @"Good S",
                           @"Good M",nil];
    
    for (int i = 0 ; i <[_tempArray count] ; i ++)
    {
        UIImageView *_tempImageView =  [LKDrawLabBgImage getParameterCreateLabBgImage:[_tempArray objectAtIndex:i] 
                                               strFont:[UIFont fontWithName:@"Times New Roman" size:14.0f]];
        CGRect rectFarme = _tempImageView.frame;
        
        rectFarme.origin.y  = (50 *i) + 5;
        
        _tempImageView.frame = rectFarme;
        
        [self.view addSubview:_tempImageView];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
