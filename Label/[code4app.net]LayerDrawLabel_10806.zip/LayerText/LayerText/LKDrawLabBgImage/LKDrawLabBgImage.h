//
//  LKDrawLabBgImage.h
//  LabGradualchange
//
//  Created by Pemg kare on 4/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface LKDrawLabBgImage : NSObject
/*
 UIFont *_strFont = [UIFont fontWithName: size:];
 传入字体大小和字体
*/

/*
 _strContent:要显示的内容
*/

+ (UIImageView*)getParameterCreateLabBgImage:(NSString*)_strContent strFont:(UIFont*)_strFont;

@end
