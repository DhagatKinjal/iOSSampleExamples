//
//  testTagsTests.h
//  testTagsTests
//
//  Created by Alex on 6/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface testTagsTests : SenTestCase

@end
