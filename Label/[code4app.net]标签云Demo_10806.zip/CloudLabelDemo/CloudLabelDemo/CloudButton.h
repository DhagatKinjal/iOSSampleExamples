//
//  CloudButton.h
//  Test
//
//  Created by zhangmh on 12-7-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CloudButton : UIButton
{

}


@property (nonatomic) CGFloat distanceX;
@property (nonatomic) CGFloat distanceY;

@property (nonatomic) CGFloat acceleration;

@end
