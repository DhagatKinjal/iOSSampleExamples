//
//  CloudButton.m
//  Test
//
//  Created by zhangmh on 12-7-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CloudButton.h"

@implementation CloudButton

@synthesize acceleration;
@synthesize distanceX;
@synthesize distanceY;

//@synthesize bili;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        // Initialization code
    }
    return self;
}


@end
