//
//  ViewController.h
//  CloudLabelDemo
//
//  Created by zhangmh on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CloudView.h"
@interface ViewController : UIViewController<CloudViewDelegate>

@end

