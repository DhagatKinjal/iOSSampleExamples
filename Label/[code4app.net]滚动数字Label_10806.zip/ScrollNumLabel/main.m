//
//  main.m
//  ScrollNumLabel
//
//  Created by zangcw on 12-9-7.
//  Copyright (c) 2012年 zangcw. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZCWAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZCWAppDelegate class]));
    }
}
