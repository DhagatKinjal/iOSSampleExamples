//
//  ZCWAppDelegate.h
//  ScrollNumLabel
//
//  Created by zangcw on 12-9-7.
//  Copyright (c) 2012年 zangcw. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZCWViewController;

@interface ZCWAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ZCWViewController *viewController;

@end
