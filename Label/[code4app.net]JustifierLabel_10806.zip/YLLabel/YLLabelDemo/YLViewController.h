//
//  YLViewController.h
//  YLLabelDemo
//
//  Created by Eric Yuan on 12-11-8.
//  Copyright (c) 2012年 YuanLi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YLLabel;

@interface YLViewController : UIViewController {
    IBOutlet YLLabel* justifyLabel;
}

@end
