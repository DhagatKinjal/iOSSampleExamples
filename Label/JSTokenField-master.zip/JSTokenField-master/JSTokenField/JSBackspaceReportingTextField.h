//
//  JSBackspaceReportingTextField.h
//  JSTokenField
//
//  Created by BJ Homer on 2/18/13.
//  Copyright (c) 2013 JamSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSBackspaceReportingTextField : UITextField

@end
