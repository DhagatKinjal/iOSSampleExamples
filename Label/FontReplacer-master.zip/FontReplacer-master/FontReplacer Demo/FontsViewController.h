//
//  SearchViewController.h
//  FontReplacer Demo
//
//  Created by Cédric Luthi on 11.08.11.
//  Copyright (c) 2011 Cédric Luthi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FontsViewController : UITableViewController
{
	NSArray *familyNames;
}

@end
