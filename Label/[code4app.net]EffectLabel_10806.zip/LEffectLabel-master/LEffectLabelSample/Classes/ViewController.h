#import "LEffectLabel.h"


@interface ViewController : UIViewController


@end