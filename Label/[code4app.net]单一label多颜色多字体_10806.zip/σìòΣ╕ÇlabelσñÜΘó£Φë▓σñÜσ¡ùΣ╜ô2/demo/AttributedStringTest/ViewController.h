//
//  ViewController.h
//  AttributedStringTest
//
//  Created by sun huayu on 13-2-18.
//  Copyright (c) 2013年 sun huayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
}

@end
