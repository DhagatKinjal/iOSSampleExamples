RSMaskedLabel is a UILabel subclass that renders knocked-out text using an inverted mask.

![sample image](https://github.com/robinsenior/RSMaskedLabel/raw/master/rounded.png)
![sample image](https://github.com/robinsenior/RSMaskedLabel/raw/master/square.png)
