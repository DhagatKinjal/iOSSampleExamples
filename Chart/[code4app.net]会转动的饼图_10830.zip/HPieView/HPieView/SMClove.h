//
//  SMRotaryWheel.m
//  RotaryWheelProject
//
//  Created by cesarerocchi on 2/10/12.
//  Copyright (c) 2012 studiomagnolia.com. All rights reserved.

#import <Foundation/Foundation.h>

@interface SMClove : NSObject

@property float minValue;
@property float maxValue;
@property float midValue;
@property int value;

@end
