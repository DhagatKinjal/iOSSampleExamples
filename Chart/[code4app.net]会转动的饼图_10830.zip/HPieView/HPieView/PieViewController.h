//
//  PieViewController.h
//  HPieView
//
//  Created by zzvcom on 12-9-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HPieChartView.h"

@interface PieViewController : UIViewController
{
    
}
@property(nonatomic , strong) HPieChartView * pieview;
@end
