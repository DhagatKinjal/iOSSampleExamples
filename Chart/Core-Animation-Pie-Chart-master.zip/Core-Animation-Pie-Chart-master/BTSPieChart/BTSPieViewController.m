//
//  BTSPieViewController.m
//
//  Copyright (c) 2011 Brian Coyner. All rights reserved.
//

#import "BTSPieViewController.h"

@implementation BTSPieViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

@end
