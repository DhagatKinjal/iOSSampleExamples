//
//  main.m
//  BTSPieChart
//
//  Created by Brian Coyner on 10/15/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "BTSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BTSAppDelegate class]));
    }
}
