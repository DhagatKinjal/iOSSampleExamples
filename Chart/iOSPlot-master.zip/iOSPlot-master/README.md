
iOSPlot
=======

<img width=500 src="http://www.honcheng.com/imagehost/i/img?id=aghob25jaGVuZ3IOCxIFSW1hZ2UY8sCGAgw"/>
<img width=500 src="http://www.honcheng.com/imagehost/i/img?id=aghob25jaGVuZ3IOCxIFSW1hZ2UY6raGAgw"/>


Draw pie charts and line charts in iOS apps

Todo for line chat
------------------
Use gesture/tap to show the value label (or mild statistics) for a data point.
Further break out colors for customization of background, x/y labels, and shadows.
Allow legend labels to appear on either the right or left side of the chart (or not at all).
Use the rendered string width of the legend labels to determine right/left side margin.
If a legend string is significantly long (200% percentage of default margin width?), truncate or abbreviate it to X characters.

Todo for pie chat
-----------------
Use gesture/tap to show the value label
Display legend


Minimum Requirements
--------------------
* ARC - this project uses ARC. If you are not using ARC in your project, add '-fobjc-arc' as a compiler flag for StyledPageControl.h and StyledPageControl.m
* XCode 4.4 and newer (auto-synthesis required)

Contact
-------

[twitter.com/honcheng](http://twitter.com/honcheng)  
[honcheng.com](http://honcheng.com)

![](http://www.cocoacontrols.com/analytics/honcheng/iosplot.png)