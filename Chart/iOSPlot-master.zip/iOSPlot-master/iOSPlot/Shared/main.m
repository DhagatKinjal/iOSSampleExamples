//
//  main.m
//  PlotCreator
//
//  Created by honcheng on 4/23/11.
//  Copyright 2011 honcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
