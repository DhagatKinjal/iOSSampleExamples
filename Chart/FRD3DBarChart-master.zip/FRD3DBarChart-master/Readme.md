FRD3DBarChart

iOS 3D bar chart control made with GLKit.

Sebastien Windal - Free Range Developers.

Licensed under New BSD.

See http://windal.net/blog/?p=153 for documentation.

![Screenshot](screenshot2.png) 
