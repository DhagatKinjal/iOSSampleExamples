//
//  String.h
//  tzz
//
//  Created by zzy on 10/26/11.
//  Copyright 2011 Zhengzhiyu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Helpers)

@end
