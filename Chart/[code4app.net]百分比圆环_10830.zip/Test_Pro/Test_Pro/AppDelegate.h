//
//  AppDelegate.h
//  Test_Pro
//
//  Created by HuHongbing  on 12/18/12.
//  Copyright (c) huhongbin2000@126.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
