

#import <QuartzCore/QuartzCore.h>

@interface KDGoalBarPercentLayer : CALayer

@property (nonatomic) CGFloat percent;
@end
