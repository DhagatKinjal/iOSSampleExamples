//
//  ViewController.m
//  DimensionalHistogram
//
//  Created by benbenxiong on 12-7-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "NTChartView.h"

@interface ViewController ()

@end

@implementation ViewController

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self){
        
        
    }
    return self;    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    int px, py;
    
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
        
        if ( self.interfaceOrientation == UIDeviceOrientationLandscapeLeft || self.interfaceOrientation == UIDeviceOrientationLandscapeRight)
        { 
            px = 1024; 
            py = 768-20;
        }
        else
        {
            px = 768; //tweaked, should be better 
            py = 1024-20;
        }
        
        
    }else {
        
        if ( self.interfaceOrientation == UIDeviceOrientationLandscapeLeft || self.interfaceOrientation == UIDeviceOrientationLandscapeRight)
        { 
            px = 480; 
            py = 320-20;
        }
        else
        {
            px = 320; //tweaked, should be better 
            py = 480-20;
        }
    }
    
    NTChartView *v = [[NTChartView alloc] initWithFrame:CGRectMake(0, 0, px, py)];
	
	NSArray *g1 = [NSArray arrayWithObjects:
                   [NSNumber numberWithFloat:78],
                   [NSNumber numberWithFloat:82],
                   
                   [NSNumber numberWithFloat:90.2],
                   [NSNumber numberWithFloat:94.1],
                   [NSNumber numberWithFloat:92.5],
                   [NSNumber numberWithFloat:93.9],
                   [NSNumber numberWithFloat:95.2],
                   [NSNumber numberWithFloat:93.5],nil];
    
    NSArray *g2 = [NSArray arrayWithObjects:
                   [NSNumber numberWithFloat:38],
                   [NSNumber numberWithFloat:42], 
                   [NSNumber numberWithFloat:50.2],
                   [NSNumber numberWithFloat:54.1],
                   [NSNumber numberWithFloat:52.5],
                   [NSNumber numberWithFloat:53.9],
                   [NSNumber numberWithFloat:55.2],
                   [NSNumber numberWithFloat:53.5],nil];
    
    NSArray *g = [NSArray arrayWithObjects:g1, g2, nil];
    
    NSArray *gt = [NSArray arrayWithObjects:@"xxx",@"yyy", nil];
    NSArray *xL = [NSArray arrayWithObjects:@"2002",@"2003",@"2004",@"2005",@"2006",@"2007",@"2008",@"2009", nil];
    NSArray *ct = [NSArray arrayWithObjects:@"某某历年销量水平柱状图",@"", nil];
    
	v.groupData = g;
    v.groupTitle = gt;
    v.xAxisLabel = xL;
    v.chartTitle = ct;
	
    v.backgroundColor = [UIColor clearColor];
	
    v.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    
    [self.view addSubview:v];
	
	[v release];
    
}

-(void) willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    
    int px, py;
    
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
        
        if ( self.interfaceOrientation == UIDeviceOrientationLandscapeLeft || self.interfaceOrientation == UIDeviceOrientationLandscapeRight)
        { 
            px = 1024; 
            py = 768-20;
        }
        else
        {
            px = 768; //tweaked, should be better 
            py = 1024-20;
        }
        
        
    }else {
        
        if ( self.interfaceOrientation == UIDeviceOrientationLandscapeLeft || self.interfaceOrientation == UIDeviceOrientationLandscapeRight)
        { 
            px = 480; 
            py = 320-20;
        }
        else
        {
            px = 320; //tweaked, should be better 
            py = 480-20;
        }
    }
    
   
    NTChartView *v = [[NTChartView alloc] initWithFrame:CGRectMake(0, 0, px, py)];
	
	NSArray *g1 = [NSArray arrayWithObjects:
                   [NSNumber numberWithFloat:78],
                   [NSNumber numberWithFloat:82],
                   
                   [NSNumber numberWithFloat:90.2],
                   [NSNumber numberWithFloat:94.1],
                   [NSNumber numberWithFloat:92.5],
                   [NSNumber numberWithFloat:93.9],
                   [NSNumber numberWithFloat:95.2],
                   [NSNumber numberWithFloat:93.5],nil];
    
    NSArray *g2 = [NSArray arrayWithObjects:
                   [NSNumber numberWithFloat:38],
                   [NSNumber numberWithFloat:42], 
                   [NSNumber numberWithFloat:50.2],
                   [NSNumber numberWithFloat:54.1],
                   [NSNumber numberWithFloat:52.5],
                   [NSNumber numberWithFloat:53.9],
                   [NSNumber numberWithFloat:55.2],
                   [NSNumber numberWithFloat:53.5],nil];
    
    NSArray *g = [NSArray arrayWithObjects:g1, g2, nil];
    
    NSArray *gt = [NSArray arrayWithObjects:@"xxx",@"yyy", nil];
    NSArray *xL = [NSArray arrayWithObjects:@"2002",@"2003",@"2004",@"2005",@"2006",@"2007",@"2008",@"2009", nil];
    NSArray *ct = [NSArray arrayWithObjects:@"某某历年销量水平柱状图",@"", nil];
    
	v.groupData = g;
    v.groupTitle = gt;
    v.xAxisLabel = xL;
    v.chartTitle = ct;
	
    v.backgroundColor = [UIColor clearColor];
	
    v.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    
    [self.view addSubview:v];
	
	[v release];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
     return YES;
}

@end
