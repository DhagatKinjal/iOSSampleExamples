//
//  ViewController.h
//  CharViewTest
//
//  Created by star  on 9/18/12.
//  Copyright (c) 2012 star . All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController : UIViewController
- (IBAction)clickBtn:(id)sender;
@end
