//
//  ViewController.m
//  CharViewTest
//
//  Created by star  on 9/18/12.
//  Copyright (c) 2012 star . All rights reserved.
//

#import "ViewController.h"
#import "CharViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
 
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (IBAction)clickBtn:(id)sender
{
    CharViewController *kfglVC = [[CharViewController alloc] init];

    [self presentModalViewController:kfglVC animated:YES];
    [kfglVC release];
    
}
@end
