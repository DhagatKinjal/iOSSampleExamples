#import <Foundation/Foundation.h>

/// @file

/// @name Custom Exception Identifiers
/// @{
extern NSString *const CPTException;
extern NSString *const CPTDataException;
extern NSString *const CPTNumericDataException;
/// @}
