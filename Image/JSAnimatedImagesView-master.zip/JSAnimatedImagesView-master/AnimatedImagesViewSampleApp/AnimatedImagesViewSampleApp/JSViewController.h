//
//  JSViewController.h
//  AnimatedImagesViewSampleApp
//
//  Created by Javier Soto on 2/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JSAnimatedImagesView.h"

@interface JSViewController : UIViewController <JSAnimatedImagesViewDataSource>

@end
