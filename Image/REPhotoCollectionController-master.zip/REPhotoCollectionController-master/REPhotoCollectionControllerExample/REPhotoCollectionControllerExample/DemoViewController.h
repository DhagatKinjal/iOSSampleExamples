//
//  DemoViewController.h
//  REPhotoCollectionControllerExample
//
//  Created by Roman Efimov on 7/27/12.
//  Copyright (c) 2012 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>

@class REPhotoCollectionController;

@interface DemoViewController : UIViewController {
    REPhotoCollectionController *photoCollectionController;
}

@end
