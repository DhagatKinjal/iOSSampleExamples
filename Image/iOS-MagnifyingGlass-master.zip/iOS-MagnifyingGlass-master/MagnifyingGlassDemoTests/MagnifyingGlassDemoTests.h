//
//  MagnifyingGlassDemoTests.h
//  MagnifyingGlassDemoTests
//
//  Created by Arnaud Coomans on 30/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MagnifyingGlassDemoTests : SenTestCase

@end
