//
//  ACLoupe.h
//  MagnifyingGlassDemo
//
//  Created by Arnaud Coomans on 18/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ACMagnifyingGlass.h"

@interface ACLoupe : ACMagnifyingGlass

@end
