//
//  TranslucentViewController.h
//  Translucent
//
//  Created by 谢伟 on 11-2-14.
//  Copyright 2011 易联伟达 www.e-linkway.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TranslucentViewController : UIViewController {

}

@end

