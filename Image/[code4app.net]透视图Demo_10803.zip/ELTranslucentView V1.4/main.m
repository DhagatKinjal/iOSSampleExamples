//
//  main.m
//  TranslucentView
//
//  Created by 谢伟 on 11-2-19.
//  Copyright 2011 易联伟达 www.e-linkway.com. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"TranslucentAppDelegate");
    [pool release];
    return retVal;
}
