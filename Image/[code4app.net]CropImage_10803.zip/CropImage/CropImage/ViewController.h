//
//  ViewController.h
//  CropImage
//
//  Created by 杨 烽 on 12-10-24.
//  Copyright (c) 2012年 杨 烽. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KICropImageView.h"

@interface ViewController : UIViewController {
    KICropImageView *_cropImageView;
}

@end
