#import "HFImageEditorViewController.h"

@interface HFImageEditorViewController(SubclassingHooks)
- (void)startTransformHook;
- (void)endTransformHook;
@end


