//
//  main.m
//  ImageEditor
//
//  Created by Heitor Ferreira on 8/28/12.
//

#import <UIKit/UIKit.h>

#import "DemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DemoAppDelegate class]));
    }
}
