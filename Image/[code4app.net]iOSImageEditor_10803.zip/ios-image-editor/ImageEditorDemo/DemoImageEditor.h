#import "HFImageEditorViewController.h"

@interface DemoImageEditor : HFImageEditorViewController

@property(nonatomic,retain) IBOutlet UIBarButtonItem *saveButton;

@end
