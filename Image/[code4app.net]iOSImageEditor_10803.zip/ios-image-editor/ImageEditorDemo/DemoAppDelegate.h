#import <UIKit/UIKit.h>

@class ViewController;

@interface DemoAppDelegate : UIResponder <UIApplicationDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
