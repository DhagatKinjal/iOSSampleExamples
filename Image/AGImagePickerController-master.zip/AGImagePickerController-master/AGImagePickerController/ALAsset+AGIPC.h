//
//  ALAsset+AGIPC.h
//  AGImagePickerController Demo
//
//  Created by Artur Grigor on 19.06.2012.
//  Copyright (c) 2012 - 2013 Artur Grigor. All rights reserved.
//

#import <AssetsLibrary/AssetsLibrary.h>

@interface ALAsset (AGIPC)

- (BOOL)isEqual:(id)object;

@end
