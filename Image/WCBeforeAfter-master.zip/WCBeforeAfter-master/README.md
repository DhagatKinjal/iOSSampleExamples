WCBeforeAfter
=============

Objective-C BeforeAfter show the difference in the reconstruction project. 
It show before and after picture, so that you could easily see how dramatic the changes were.

[![](https://raw.github.com/m1entus/WCBeforeAfter/master/Images/beforeafter1_thumb.png)](https://raw.github.com/m1entus/WCBeforeAfter/master/Images/beforeafter1_thumb.png)
[![](https://raw.github.com/m1entus/WCBeforeAfter/master/Images/beforeafter2_thumb.png)](https://raw.github.com/m1entus/WCBeforeAfter/master/Images/beforeafter2_thumb.png)
[![](https://raw.github.com/m1entus/WCBeforeAfter/master/Images/beforeafter3_thumb.png)](https://raw.github.com/m1entus/WCBeforeAfter/master/Images/beforeafter3_thumb.png)

## Credits

Inspired by jQuery Before/After Plugin

## Contact

[Michal Zaborowski](http://github.com/m1entus) 
