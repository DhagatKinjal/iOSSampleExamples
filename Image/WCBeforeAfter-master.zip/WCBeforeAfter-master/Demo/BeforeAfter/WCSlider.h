//
//  WCSlider.h
//  BeforeAfter
//
//  Created by Michał Zaborowski on 21.11.2012.
//  Copyright (c) 2012 whitecode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WCSlider : UIView

@end
