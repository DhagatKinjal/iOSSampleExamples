//
//  main.m
//  NLImageCropper
//
//  Created by Mirza Bilal on 12/3/12.
//  Copyright (c) 2012 Nixie Life. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NLAppDelegate class]));
    }
}
