//
//  ViewController.m
//  image
//
//  Created by 斌 on 12-10-27.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize img1;
@synthesize img2;
@synthesize img3;
- (void)viewDidLoad
{
    ////////下载图片////////
	//方法一（暴力而有效，必须下载完才进入页面）
    NSURL *url = [NSURL URLWithString:@"http://cc.cocimg.com/bbs/attachment/upload/07/128707.png"];
    UIImage *imga = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:url]];
    img1.image=imga;
    
    
    //方法二 (需要等下载完才显示，但照样可以进入页面)
    NSString *url2=@"http://tp1.sinaimg.cn/2122519000/50/5620445947/1";
    UIImageFromURL( [NSURL URLWithString:url2], ^( UIImage * image )
                   {
                       img2.image=image;
                       NSLog(@"%@",image);
                   }, ^(void){
                       NSLog(@"error!");
                   });
    
    
    ///////下面是关于读取与写入Documents的//////////
    UIImage *bear=[UIImage imageNamed:@"小破熊.png"];
    
    //Document
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    
    
    /*写入图片*/
    //帮文件起个名
    NSString *uniquePath=[[paths objectAtIndex:0] stringByAppendingPathComponent:@"image.png"];
    //将图片写到Documents文件中
    [UIImagePNGRepresentation(bear)writeToFile: uniquePath    atomically:YES];

    /*读取入图片*/
    //因为拿到的是个路径，所以把它加载成一个data对象
    NSData *data=[NSData dataWithContentsOfFile:uniquePath];
    //直接把该图片读出来
    img3.image=[UIImage imageWithData:data];

    
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc {
    [img1 release];
    [img2 release];
    [img3 release];
    [super dealloc];
}

#pragma mark - 方法二
void UIImageFromURL( NSURL * URL, void (^imageBlock)(UIImage * image), void (^errorBlock)(void) )
{
    dispatch_async( dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0 ), ^(void)
                   {
                       NSData * data = [[[NSData alloc] initWithContentsOfURL:URL] autorelease];
                       UIImage * image = [[[UIImage alloc] initWithData:data] autorelease];
                       dispatch_async( dispatch_get_main_queue(), ^(void){
                           if( image != nil )
                           {
                               imageBlock( image );
                           } else {
                               errorBlock();
                           }
                       });
                   });
}

@end
