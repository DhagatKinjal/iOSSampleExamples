//
//  DemoAnnotation.m
//  JCTiledViewDemo
//
//  Created by Jesse Collis
//  Copyright (c) 2012 JC Multimedia Design. All rights reserved.
//

#import "DemoAnnotation.h"

@implementation DemoAnnotation
@synthesize contentPosition = _contentPosition;
@end
