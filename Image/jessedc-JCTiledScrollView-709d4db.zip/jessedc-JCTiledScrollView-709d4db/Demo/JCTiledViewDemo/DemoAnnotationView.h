//
//  DemoAnnotationView.h
//  JCTiledViewDemo
//
//  Created by Jesse Collis
//  Copyright (c) 2012 JC Multimedia Design. All rights reserved.
//

#import "JCAnnotationView.h"

@interface DemoAnnotationView : JCAnnotationView

@property (strong, nonatomic) UIImageView *imageView;

@end
