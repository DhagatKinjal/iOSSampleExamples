//
//  DetailView.h
//  JCTiledViewDemo
//
//  Created by Jesse Collis
//  Copyright 2012 JC Multimedia Design. All rights reserved.
//

@interface DetailView : UIView
@property (strong, nonatomic) UILabel *textLabel;
@end
