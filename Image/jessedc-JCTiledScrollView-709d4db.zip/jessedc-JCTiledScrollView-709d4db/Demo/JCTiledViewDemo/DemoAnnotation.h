//
//  DemoAnnotation.h
//  JCTiledViewDemo
//
//  Created by Jesse Collis
//  Copyright (c) 2012 JC Multimedia Design. All rights reserved.
//

#import "JCAnnotation.h"

@interface DemoAnnotation : NSObject <JCAnnotation>
@end
