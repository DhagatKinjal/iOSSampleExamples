//
//  ADAnnotationTapGestureRecognizer.m
//  JCTiledScrollView
//
//  Created by Anthony DAMOTTE on 02/11/12.
//  Copyright (c) 2012 Orange Business Services IT&Labs. All rights reserved.
//

#import "ADAnnotationTapGestureRecognizer.h"

@implementation ADAnnotationTapGestureRecognizer
@synthesize tapAnnotation = _tapAnnotation;
@end
