//
//  DSAnimationViewController.h
//  DSGraphicsKitProject
//
//  Created by Fabio Angelo Pelosin on 10/07/12.
//  Copyright (c) 2012 Discontinuity s.r.l. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DSAnimationViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *targetView;

@end
