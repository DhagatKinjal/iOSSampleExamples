//
//  DSIconsViewController.h
//  DSGraphicsKitProject
//
//  Created by Fabio Angelo Pelosin on 10/07/12.
//  Copyright (c) 2012 Discontinuity s.r.l. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DSIconsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *view0;
@property (weak, nonatomic) IBOutlet UIImageView *view1;
@property (weak, nonatomic) IBOutlet UIImageView *view2;
@property (weak, nonatomic) IBOutlet UIImageView *view3;
@property (weak, nonatomic) IBOutlet UIImageView *view4;
@property (weak, nonatomic) IBOutlet UIImageView *view5;

@end
