//
//  DSGraphicsKitProjectTests.h
//  DSGraphicsKitProjectTests
//
//  Created by Fabio Angelo Pelosin on 10/07/12.
//  Copyright (c) 2012 Discontinuity s.r.l. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface DSGraphicsKitProjectTests : SenTestCase

@end
