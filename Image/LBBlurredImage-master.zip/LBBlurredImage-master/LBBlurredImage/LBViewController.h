//
//  LBViewController.h
//  Blur
//
//  Created by Luca Bernardi on 11/11/12.
//  Copyright (c) 2012 Luca Bernardi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LBViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIImageView *imageView;

@end
