//
//  ImageRenderView.h
//  MKMovingBlocks
//
//  Created by indideveloper on 8/21/12.
//  Copyright (c) 2012 IndiDeveloper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageRenderView : UIView
- (void)setPositionX:(float)posX;
@end
