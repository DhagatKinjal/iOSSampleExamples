MKMovingBlockAnimation
======================

iOS app using cocos2d animation to render images like moving blocks.
App supports iOS 6 beta 4.