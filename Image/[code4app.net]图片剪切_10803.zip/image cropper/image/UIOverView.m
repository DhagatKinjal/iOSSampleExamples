//
//  UIOverView.m
//  image
//
//  Created by 岩 邢 on 12-7-25.
//  Copyright (c) 2012年 南阳草庐软件有限公司. All rights reserved.
//

#import "UIOverView.h"

@implementation UIOverView


-(id)initWithImage:(UIImage*)img
{
    CGRect r = [[UIScreen mainScreen] bounds];
    self = [super initWithFrame:r];
    if (self) {
        [self setBackgroundColor:([UIColor colorWithRed:0 green:0 blue:0 alpha:0.8])];
        UIButton *btn = [[UIButton alloc]initWithFrame:r];
        [btn setImage:img forState:0];
        [btn addTarget:self action:@selector(btnPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        [btn release];
        [self setWindowLevel:UIWindowLevelStatusBar+1];
        [self setTransform:CGAffineTransformMakeRotation(90* 3.141592653/180)];
        [self makeKeyAndVisible];
    }
    return self;
}

-(IBAction)btnPressed:(id)sender
{
    [self release];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


@end
