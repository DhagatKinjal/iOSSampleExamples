//
//  UIOverView.h
//  image
//
//  Created by 岩 邢 on 12-7-25.
//  Copyright (c) 2012年 南阳草庐软件有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIOverView : UIWindow
{
}

-(id)initWithImage:(UIImage*)img;

-(IBAction)btnPressed:(id)sender;
@end
