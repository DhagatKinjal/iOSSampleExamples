//
//  ViewController.h
//  image
//
//  Created by 岩 邢 on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICliper.h"
#import "UIOverView.h"

@interface ViewController : UIViewController
{
    UICliper *cliper;
    IBOutlet UIImageView *imgView;
    IBOutlet UISlider *s1, *s2, *s3, *s4;
    IBOutlet UILabel *l1, *l2, *l3, *l4;
}


-(IBAction)valueChanged:(id)sender;
-(IBAction)btnView:(id)sender;
-(IBAction)log:(id)sender;
@end
