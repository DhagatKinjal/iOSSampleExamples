//
//  ViewController.m
//  image
//
//  Created by 岩 邢 on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //imgView = [[self.view subviews]objectAtIndex:0];
    cliper = [[UICliper alloc]initWithImageView:imgView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(IBAction)valueChanged:(id)sender
{
    CGRect r = CGRectMake([s1 value], [s2 value], [s3 value], [s4 value]);
    [l1 setText:[NSString stringWithFormat:@"%d", (int)[s1 value]]];
    [l2 setText:[NSString stringWithFormat:@"%d", (int)[s2 value]]];
    [l3 setText:[NSString stringWithFormat:@"%d", (int)[s3 value]]];
    [l4 setText:[NSString stringWithFormat:@"%d", (int)[s4 value]]];
    [cliper setClipRect:r];
}

-(IBAction)btnView:(id)sender
{
    CGRect r = CGRectMake((int)[s1 value], (int)[s2 value], (int)[s3 value], (int)[s4 value]);
    UIImage *img = [cliper getClipImageRect:r];
    [[UIOverView alloc]initWithImage:img];
}

-(IBAction)log:(id)sender
{
    printf("{%d, %d, %d, %d},\r\n", (int)[s1 value], (int)[s2 value], (int)[s3 value], (int)[s4 value]);
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsLandscape( interfaceOrientation );
    //return UIInterfaceOrientationIsPortrait(interfaceOrientation);
}

@end
