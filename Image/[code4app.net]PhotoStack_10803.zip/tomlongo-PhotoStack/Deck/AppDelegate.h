//
//  DeckAppDelegate.h
//  Deck
//
//  Created by Tom Longo on 16/08/12.
//  Copyright (c) 2012 Tom Longo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
