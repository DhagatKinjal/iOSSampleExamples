//
//  NSString+KTString.h
//  Flickr+JSONSample
//
//  Created by Kirby Turner on 3/6/11.
//  Copyright 2011 White Peak Software Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (NSString_KTString)

+ (NSString *)stringWithData:(NSData *)data;

@end
