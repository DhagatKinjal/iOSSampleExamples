#import <UIKit/UIKit.h>
#import "LTransitionImageView.h"


@interface ViewController : UIViewController
{
    LTransitionImageView *_transitionImageView;
}


@end