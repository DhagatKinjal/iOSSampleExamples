vImageCategory
==============

UIImage category which have vImage wrapper functions and the demo project.

###Usage:

Please check out the demo project included.
    
###License:

MIT License
