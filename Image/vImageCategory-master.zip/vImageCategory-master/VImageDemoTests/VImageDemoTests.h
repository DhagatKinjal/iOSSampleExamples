//
//  VImageDemoTests.h
//  VImageDemoTests
//
//  Copyright (c) 2012 Shuichi Tsutsumi. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface VImageDemoTests : SenTestCase

@end
