//
//  ViewController.h
//  VImageDemo
//
//  Copyright (c) 2012 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIButton *startBtn;
- (IBAction)pressBtn;

@end
