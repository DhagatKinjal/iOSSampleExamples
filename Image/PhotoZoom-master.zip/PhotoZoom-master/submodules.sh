#!/bin/sh

git submodule add git@github.com:brennanMKE/OptimizedNetworking.git OptimizedNetworking

