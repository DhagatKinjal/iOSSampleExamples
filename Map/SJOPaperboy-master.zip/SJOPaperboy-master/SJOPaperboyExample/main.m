//
//  main.m
//  SJOPaperboyExample
//
//  Created by Sam Oakley on 17/02/2013.
//  Copyright (c) 2013 Sam Oakley. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SJOAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SJOAppDelegate class]));
    }
}
