//
//  main.m
//  MapRouteDemo
//
//  Created by 5dscape on 12-11-26.
//  Copyright (c) 2012年 kai. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
