//
//  MapAnnotation.m
//  VPPLibraries
//
//  Created by Víctor on 20/10/11.
//  Copyright 2011 Víctor Pena Placer. All rights reserved.
//

#import "MapAnnotationExample.h"


@implementation MapAnnotationExample
@synthesize coordinate;
@synthesize title;
@synthesize subtitle;
@synthesize pinAnnotationColor;
@synthesize opensWhenShown;
@synthesize image;

@end
