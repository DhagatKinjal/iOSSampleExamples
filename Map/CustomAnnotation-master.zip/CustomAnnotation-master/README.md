A demonstration of customizing the callout bubble of an MKAnnotationView.

Thanks to [tappcandy](http://stackoverflow.com/users/450832/tappcandy), [яοвοτағτєяаււ](http://stackoverflow.com/users/355539/), [Cameron Lowell Palmer](http://stackoverflow.com/users/410867/cameron-lowell-palmer) from [stackoverflow](http://stackoverflow.com/) for this compilation.
You can read through this [discussion](http://stackoverflow.com/questions/1565828/how-to-customize-the-callout-bubble-for-mkannotationview) for more insights.

![Custom_Callout](https://dl.dropbox.com/u/58285095/Screen%20shot%202012-09-03%20at%2011.08.44%20PM.png)
![Custom_Callout2](https://dl.dropbox.com/u/58285095/Screen%20shot%202012-09-04%20at%207.01.39%20PM.png)

This module is licensed under the MIT license.

Copyright (C) 2012 raw engineering, inc. www.raweng.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.