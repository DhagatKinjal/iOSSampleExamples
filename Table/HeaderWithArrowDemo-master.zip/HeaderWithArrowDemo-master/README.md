HeaderWithArrowDemo
===================

A demo project that demonstrates how to create a [Foodspotting](http://www.foodspotting.com) style tableView header with an arrow that goes beyond the view's frame.

You can find the tutorial on my blog at: http://iappexperience.com/post/23159426121/how-to-create-an-arrow-that-goes-beyond-parent-views.

![picture](http://f.cl.ly/items/2M0t2722351p2D2I0y1K/TableHeaderWithArrow.png)
