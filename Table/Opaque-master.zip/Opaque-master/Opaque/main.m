//
//  main.m
//  Opaque
//
//  Created by Michael Margolis on 2/21/12.
//  Copyright (c) 2012 Massive Health. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MHAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MHAppDelegate class]));
    }
}
