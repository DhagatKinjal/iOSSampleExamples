//
//  US2ConditionPresent.h
//  US2FormValidationFramework
//
//  Created by Alex Fish on 13/01/2013.
//  Copyright (c) 2013 ustwo™. All rights reserved.
//

#import "US2Condition.h"

/**
 A condition that checks for the presence of a string
 */
@interface US2ConditionPresent : US2Condition

@end
