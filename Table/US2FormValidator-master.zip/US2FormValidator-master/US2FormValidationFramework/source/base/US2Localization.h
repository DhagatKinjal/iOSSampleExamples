//
//  US2Localization.h
//  US2FormValidationFramework
//
//  Created by Ivan on 31.10.12.
//  Copyright (c) 2012 ustwo™. All rights reserved.
//

#import <Foundation/Foundation.h>

#define US2LocalizedString(x, y) NSLocalizedStringFromTable((x), @"US2Localizable", (y))