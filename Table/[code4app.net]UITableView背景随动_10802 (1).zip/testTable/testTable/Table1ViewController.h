//
//  Table1ViewController.h
//  testTable
//
//  Created by 侯 耀东 on 12-12-12.
//  Copyright (c) 2012年 侯 耀东. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Table1ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    //已加背景个数
    NSInteger alreadyAddBg;
    
    // 加载状态
    BOOL _loadingMore;
    UITableView *tableView;
    NSMutableArray *dataArr;
}


@end
