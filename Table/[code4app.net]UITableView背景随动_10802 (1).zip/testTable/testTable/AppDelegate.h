//
//  AppDelegate.h
//  testTable
//
//  Created by 侯 耀东 on 12-12-11.
//  Copyright (c) 2012年 侯 耀东. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
