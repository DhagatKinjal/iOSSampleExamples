//
//  Table1ViewController.m
//  testTable
//
//  Created by 侯 耀东 on 12-12-12.
//  Copyright (c) 2012年 侯 耀东. All rights reserved.
//

#import "Table1ViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation Table1ViewController

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[UIColor redColor]];
    
    tableView = [[UITableView alloc]init];
    [tableView setFrame:self.view.bounds];
    [tableView setBackgroundColor:[UIColor clearColor]];
    [tableView setDelegate:self];
    [tableView setDataSource:self];
    [self.view addSubview:tableView];
    
    alreadyAddBg = 0;
    [self initData];
}

- (void)initData{
    dataArr = [[NSMutableArray alloc]init];
    for (int i=0; i<20; i++) {
        [dataArr addObject:[NSString stringWithFormat:@"%d ---",i]];
    }
    [tableView reloadData];
    [self addBgLayer];
}

#define bgHeight tableView.frame.size.height
#define beginBgY -tableView.frame.size.height
- (void)addBgLayer{
    CGFloat contentHeight = tableView.contentSize.height;
    NSInteger needNum = (contentHeight+bgHeight - beginBgY)/bgHeight + 1;
    if (needNum > alreadyAddBg) {
        for(int i = alreadyAddBg; i < needNum; i++) {
            CGRect rect = CGRectMake(0, beginBgY+i*bgHeight, tableView.frame.size.width,tableView.frame.size.height);
            [self addLayerWithFrame:rect];
        }
        alreadyAddBg = needNum;
    }
}

- (void)addLayerWithFrame:(CGRect)frame{
    CALayer *background = [CALayer layer];
    background.zPosition = -1;
    background.frame = frame;
    background.contents = (__bridge id)([[UIImage imageNamed:@"bg.png"] CGImage]);
    [tableView.layer addSublayer:background];
}

#pragma mark-
#pragma mark-UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

#pragma mark-
#pragma mark-UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)_tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * showUserInfoCellIdentifier = @"ShowUserInfoCell";
    UITableViewCell * cell = [_tableView dequeueReusableCellWithIdentifier:showUserInfoCellIdentifier];
    if (cell == nil)
    {
        // Create a cell to display an ingredient.
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                       reuseIdentifier:showUserInfoCellIdentifier];
        [cell setBackgroundColor:[UIColor clearColor]]; 
    }
    
    // Configure the cell.
    cell.textLabel.text=[dataArr objectAtIndex:indexPath.row];
    return cell;
}

#pragma mark -
#pragma mark - 添加转圈圈footerView

#define RefreshViewHight 60
- (void)addFooterView:(UITableView*)table{
    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, RefreshViewHight)];
    [footView setBackgroundColor:[UIColor clearColor]];
    UIActivityIndicatorView *tableFooterActivityIndicator = [[UIActivityIndicatorView alloc] init];
    [tableFooterActivityIndicator sizeToFit];
    [tableFooterActivityIndicator setCenter:footView.center];
    [tableFooterActivityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
    [tableFooterActivityIndicator startAnimating];
    [footView addSubview:tableFooterActivityIndicator];
    table.tableFooterView = footView;
}

#pragma mark -
#pragma mark - footer加载数据

//是否可以加载更多数据
-(BOOL)isCanLoadData{
    BOOL isCanLoad;
    isCanLoad = YES;
    return isCanLoad;
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    // 下拉到最底部时显示更多数据
    if(!_loadingMore && scrollView.contentOffset.y > ((scrollView.contentSize.height - scrollView.frame.size.height)))    {
        if ([self isCanLoadData]) {
            [self loadDataBegin];
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //如果拖动的距离大于footview的高度，并且没有正在加载数据
    if (scrollView.contentOffset.y + (scrollView.frame.size.height) > scrollView.contentSize.height && !_loadingMore){
        if ([self isCanLoadData]) {
            [self loadDataBegin];
        }
    }
}

// 准备开始加载数据
- (void)loadDataBegin{
    if (_loadingMore == NO){
        _loadingMore = YES;
        [self addFooterView:tableView];
        [self performSelector:@selector(loadDataing) withObject:nil afterDelay:0.2];
    }
}

// 加载数据中
- (void) loadDataing{
    NSInteger num = dataArr.count+20;
    for (int i=dataArr.count; i<num; i++) {
        [dataArr addObject:[NSString stringWithFormat:@"%d ---",i]];
    }
    [tableView reloadData];
    [self addBgLayer];
    
    [self loadDataEnd];
}

// 加载数据完毕
- (void) loadDataEnd{
    _loadingMore = NO;
    tableView.tableFooterView = nil;
}

@end
