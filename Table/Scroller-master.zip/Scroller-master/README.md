Scroller
========

To view Scroller in action, add some contacts in your AddressBook.

[![](http://static.raweng.com/mobile/scroller/scroller-1.png)](http://static.raweng.com/mobile/scroller/scroller-1.png)


Note: 
- As it is an ARC based project so it can work on XCode 4 or higher.
- AddressBook is used just for demo purpose to show the use of Scroller Project.

[we]:http://www.raweng.com
[raw engineering]:http://www.raweng.com