//
//  FMViewController.h
//  FMMoveTableView Sample Code
//
//  Created by Florian Mielke.
//  Copyright 2012 Florian Mielke. All rights reserved.
//  


#import "FMMoveTableView.h"


@interface FMViewController : UITableViewController <FMMoveTableViewDataSource, FMMoveTableViewDelegate>

@end
