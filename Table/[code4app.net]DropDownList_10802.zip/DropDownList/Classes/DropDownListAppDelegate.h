//
//  DropDownListAppDelegate.h
//  DropDownList
//
//  Created by kingyee on 11-9-19.
//  Copyright 2011 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DropDownListViewController;

@interface DropDownListAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DropDownListViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DropDownListViewController *viewController;

@end

