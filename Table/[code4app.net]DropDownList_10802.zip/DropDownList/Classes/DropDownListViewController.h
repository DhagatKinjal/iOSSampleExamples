//
//  DropDownListViewController.h
//  DropDownList
//
//  Created by kingyee on 11-9-19.
//  Copyright 2011 Kingyee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDList.h"
#import "PassValueDelegate.h"

@interface DropDownListViewController : UIViewController <UISearchBarDelegate, PassValueDelegate>{
	IBOutlet UISearchBar *_searchBar;
	IBOutlet UITableView *_tableView;
	DDList				 *_ddList;
	NSMutableArray		 *_resultArray;
	NSString			 *_searchStr;
}

@property (nonatomic, copy)NSString *_searchStr;

- (void)setDDListHidden:(BOOL)hidden;

@end

