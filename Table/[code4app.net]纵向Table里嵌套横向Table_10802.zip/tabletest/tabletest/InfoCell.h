

#import <UIKit/UIKit.h>

@interface InfoCell : UITableViewCell<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *hortable;
    NSInteger porsection;
}


@end
