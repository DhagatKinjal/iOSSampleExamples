//
//  FKRDefaultSearchBarTableViewController.h
//  TableViewSearchBar
//
//  Created by Fabian Kreiser on 10.02.13.
//  Copyright (c) 2013 Fabian Kreiser. All rights reserved.
//

#import "FKRSearchBarTableViewController.h"

@interface FKRDefaultSearchBarTableViewController : FKRSearchBarTableViewController {
    
}

@end