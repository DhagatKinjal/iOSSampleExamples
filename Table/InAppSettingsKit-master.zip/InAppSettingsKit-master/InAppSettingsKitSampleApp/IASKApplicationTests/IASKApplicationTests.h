//
//  IASKApplicationTests.h
//  IASKApplicationTests
//
//  Created by Stephan Diederich on 02.02.13.
//
//

#import <SenTestingKit/SenTestingKit.h>

@interface IASKApplicationTests : SenTestCase

@end
