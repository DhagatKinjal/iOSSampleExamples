模仿天猫app中分类列表打开子分类的效果

## 使用
1. 将Floder目录拖到你的项目中去
2. 添加QuartzCore.framework

具体看实例

![p1](http://ww2.sinaimg.cn/bmiddle/76770db5jw1dwr687gwgmj.jpg)
![p2](http://ww1.sinaimg.cn/bmiddle/76770db5gw1dwr6a3fz5jj.jpg)
![p3](http://ww3.sinaimg.cn/bmiddle/76770db5gw1dwr6b65inej.jpg)