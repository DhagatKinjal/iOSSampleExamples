//
//  cooltableTests.h
//  cooltableTests
//
//  Created by NYZ Star on 8/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface cooltableTests : SenTestCase

@end
