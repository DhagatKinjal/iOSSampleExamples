//
//  CustomCellBackground.m
//  cooltable
//
//  Created by NYZ Star on 8/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import "Common.h"
#import "CustomCellBackground.h"

@implementation CustomCellBackground

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGColorRef redcolor = [UIColor colorWithRed:1.0 green:0 blue:0 alpha:1.0].CGColor;
//    CGContextSetFillColorWithColor(context, redcolor);
//    CGContextFillRect(context, self.bounds);
    //add gradient color
     CGColorRef redcolor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:1.0].CGColor;
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGColorRef lightgraycolor = [UIColor colorWithRed:230.0/255.0 green:230.0/255.0 blue:230.0/255.0 alpha:1.0].CGColor;
    CGColorRef whitecolor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:1.0].CGColor;
    CGRect paperRect = self.bounds;
    drawLinearGradient(context, paperRect, whitecolor, redcolor, lightgraycolor);
    
    //add red stroke path
//    CGColorRef redcolor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:1.0].CGColor;
//    CGRect strokerect = rectFor1PxStroke(CGRectInset(paperRect, 5.0, 5.0));
//    CGContextSetStrokeColorWithColor(context, redcolor);
//    CGContextSetLineWidth(context, 1.0);
//    CGContextStrokeRect(context, strokerect);
    CGRect strokerect = paperRect;
    strokerect.size.height -= 1;
    strokerect = rectFor1PxStroke(strokerect);
    CGContextSetStrokeColorWithColor(context, whitecolor);
    CGContextSetLineWidth(context, 1.0);
    CGContextStrokeRect(context, strokerect);
    
    //add line
    CGColorRef separatorColor = [UIColor colorWithRed:208.0/255.0 green:208.0/255.0 
                                                 blue:208.0/255.0 alpha:1.0].CGColor;
    CGPoint startPoint = CGPointMake(paperRect.origin.x, 
                                     paperRect.origin.y + paperRect.size.height - 1);
    CGPoint endPoint = CGPointMake(paperRect.origin.x + paperRect.size.width - 1, 
                                   paperRect.origin.y + paperRect.size.height - 1);
    draw1PxStroke(context, startPoint, endPoint, separatorColor);

    
    
}


@end
