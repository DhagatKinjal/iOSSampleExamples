//
//  testScorllViewController.m
//  cooltable
//
//  Created by NYZ Star on 8/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "testScorllViewController.h"

@interface testScorllViewController ()

@end

@implementation testScorllViewController
@synthesize leftScrollView = _leftScorllView;
@synthesize rightScrollView = _rightScrollView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.leftScrollView setBackgroundColor:[UIColor redColor]];
    [self.rightScrollView setBackgroundColor:[UIColor greenColor]];
    self.rightScrollView.delegate = self;
    [self.rightScrollView setContentSize:CGSizeMake(100, 1000)];
    UIImageView * iv1 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    iv1.image = [UIImage imageNamed:@"grayArrow.png"];
    [self.rightScrollView addSubview:iv1];
    [iv1 release];
    UIImageView * iv2 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 100, 50, 50)];
    iv2.image = [UIImage imageNamed:@"blackArrow.png"];
    [self.rightScrollView addSubview:iv2];
    [iv2 release];
    UIImageView * iv3 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 200, 50, 50)];
    iv3.image = [UIImage imageNamed:@"blueArrow.png"];
    [self.rightScrollView addSubview:iv3];
    [iv3 release];
    UIImageView * iv4 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    iv4.image = [UIImage imageNamed:@"whiteArrow.png"];
    [self.leftScrollView addSubview:iv4];
    [iv4 release];
    if (_refreshHeaderView == nil) {
        EGORefreshTableHeaderView * view = [[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0, 0-_rightScrollView.bounds.size.height, _rightScrollView.frame.size.width, _rightScrollView.bounds.size.height)];
        view.delegate = self;
        [self.rightScrollView addSubview:view];
        _refreshHeaderView = view;
        [view release];
    }
    [_refreshHeaderView refreshLastUpdatedDate];
    // Do any additional setup after loading the view from its nib.
}

#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
	
	//  should be calling your tableviews data source model to reload
	//  put here just for demo
	_reloading = YES;
	
}

- (void)doneLoadingTableViewData{
	
	//  model should call this when its done loading
	_reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.rightScrollView];
	
}


#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{	
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	
}
//-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
//    [_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
//}

#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view{
	
	[self reloadTableViewDataSource];
	[self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:3.0];
	
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}




- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

@end
