//
//  ViewController.m
//  cooltable
//
//  Created by NYZ Star on 8/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "CustomCellBackground.h"
#import "testScorllViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize thingsLearned=_thingsLearned;
@synthesize thingsToLearn=_thingsToLearn;
@synthesize nav;

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (self) {
        self.thingsLearned = [[NSMutableArray alloc] initWithObjects:@"TableViews",@"UIKit",@"Objective-c",nil];
        self.thingsToLearn = [[NSMutableArray alloc] initWithObjects:@"Draw Rect",@"Draw Gradients",@"Draw Arcs", nil];
    }
    cooltable = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStyleGrouped];
    cooltable.dataSource = self;
    cooltable.delegate =self;
    [self.view addSubview:cooltable];
    
        
    [self.navigationController.navigationBar setHidden:NO];
    if (_refreshHeaderView == nil) {
        EGORefreshTableHeaderView * view = [[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0, 0-cooltable.bounds.size.height, cooltable.frame.size.width, cooltable.bounds.size.height)];
        view.delegate = self;
        [cooltable addSubview:view];
        _refreshHeaderView = view;
        [view release];
    }
    [_refreshHeaderView refreshLastUpdatedDate];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.thingsToLearn=nil;
    self.thingsLearned = nil;
    _refreshHeaderView = nil;
    [self.nav release];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}



#pragma mark - TableView Delegate Methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return [_thingsLearned count];
    }else {
        return [_thingsToLearn count];
    }

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * CellIdentifier = @"cooltable";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        cell.backgroundView = [[[CustomCellBackground alloc] init] autorelease];
        cell.selectedBackgroundView = [[[CustomCellBackground alloc] init] autorelease];
        [cell setBackgroundColor:[UIColor clearColor]];
    }
    if(indexPath.section == 0){
        cell.textLabel.text = [_thingsLearned objectAtIndex:indexPath.row];
    }else {
        cell.textLabel.text = [_thingsToLearn objectAtIndex:indexPath.row];
    }
    
//    [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
//    tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLineEtched;
    return cell;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        return @"Things we will learn";
    }else {
        return @"Things we have learned";
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0 && indexPath.row ==1) {
        testScorllViewController * test = [[testScorllViewController alloc] init];        
        [self.navigationController pushViewController:test animated:NO];
        //[self.nav popToRootViewControllerAnimated:NO];
//        [self.nav pushViewController:test animated:NO];
        //[ViewController ]
    }

}

#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
	
	//  should be calling your tableviews data source model to reload
	//  put here just for demo
	_reloading = YES;
	
}

- (void)doneLoadingTableViewData{
	
	//  model should call this when its done loading
	_reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:cooltable];
	
}


#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{	
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	
}


#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view{
	
	[self reloadTableViewDataSource];
	[self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:3.0];
	
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}



-(void)dealloc{
    [_thingsLearned release];
    _thingsLearned = nil;
    [_thingsToLearn release];
    _thingsToLearn = nil;
    [cooltable release];
    cooltable = nil;
    _refreshHeaderView = nil;
    [super dealloc];
}
@end
