//
//  testScorllViewController.h
//  cooltable
//
//  Created by NYZ Star on 8/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGORefreshTableHeaderView.h"

@interface testScorllViewController : UIViewController<UIScrollViewDelegate,EGORefreshTableHeaderDelegate>{
    IBOutlet UIScrollView * _leftScorllView;
    IBOutlet UIScrollView * _rightScrollView;
    EGORefreshTableHeaderView * _refreshHeaderView;
    BOOL _reloading;

}

@property (nonatomic,retain) UIScrollView * leftScrollView;
@property (nonatomic,retain) UIScrollView * rightScrollView;
-(void)reloadTableViewDataSource;
-(void)doneLoadingTableViewData;

@end
