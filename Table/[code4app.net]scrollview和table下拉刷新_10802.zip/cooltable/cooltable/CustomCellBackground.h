//
//  CustomCellBackground.h
//  cooltable
//
//  Created by NYZ Star on 8/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellBackground : UIView

@end
