//
//  ViewController.h
//  cooltable
//
//  Created by NYZ Star on 8/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "EGORefreshTableHeaderView.h"
#import "testScorllViewController.h"

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,EGORefreshTableHeaderDelegate>{
    NSMutableArray *_thingsToLearn;
    NSMutableArray *_thingsLearned;
    UITableView * cooltable;
    EGORefreshTableHeaderView *_refreshHeaderView;
    BOOL _reloading;

}

@property(copy)NSMutableArray * thingsToLearn;
@property(copy)NSMutableArray * thingsLearned;
@property (nonatomic ,retain) UINavigationController *nav;

-(void)reloadTableViewDataSource;
-(void)doneLoadingTableViewData;
@end
