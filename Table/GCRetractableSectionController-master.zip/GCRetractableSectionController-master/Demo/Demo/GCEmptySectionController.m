//
//  GCEmptySectionController.m
//  Demo
//
//  Created by Guillaume Campagna on 11-04-21.
//  Copyright 2011 LittleKiwi. All rights reserved.
//

#import "GCEmptySectionController.h"

@implementation GCEmptySectionController

- (NSString *)title {
    return NSLocalizedString(@"Empty section",);
}

@end
