//
//  NotificationsViewController.h
//  SettingsExample
//
//  Created by Jake Marsh on 5/22/12.
//  Copyright (c) 2012 Rubber Duck Software. All rights reserved.
//

#import "JMStaticContentTableViewController.h"

@interface NotificationsViewController : JMStaticContentTableViewController

@end
