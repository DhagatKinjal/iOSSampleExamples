//
//  WifiNetwork.m
//  SettingsExample
//
//  Created by Jake Marsh on 5/22/12.
//  Copyright (c) 2012 Rubber Duck Software. All rights reserved.
//

#import "WifiNetwork.h"

@implementation WifiNetwork

@synthesize networkName = _networkName;
@synthesize signalStrength = _signalStrength;
@synthesize secure = _secure;

@end