#import "JMStaticContentTextFieldTableViewCell.h"

@implementation JMStaticContentTextFieldTableViewCell

@synthesize contentTextField = _contentTextField;

@end