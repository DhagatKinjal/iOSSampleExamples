#import <Foundation/Foundation.h>
#import "JMStaticContentTableViewCell.h"

@interface JMStaticContentTextFieldTableViewCell : JMStaticContentTableViewCell

@property (nonatomic, strong) UITextField *contentTextField;

@end