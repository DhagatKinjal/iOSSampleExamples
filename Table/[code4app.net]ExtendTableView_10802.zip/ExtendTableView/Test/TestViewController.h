//
//  TestViewController.h
//  Test
//
//  Created by CNLive  on 11-4-25.
//  Copyright 2011年 cnlive.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>{
    UITableView *tv;
    NSMutableArray *ar;
    BOOL cell0_ison;
    BOOL cell1_ison;
    BOOL cell2_ison;
    BOOL cell3_ison;
    BOOL cell4_ison;
    BOOL cell5_ison;
    
}

@end
