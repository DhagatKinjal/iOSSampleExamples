//
//  TestAppDelegate.h
//  Test
//
//  Created by CNLive  on 11-4-25.
//  Copyright 2011年 cnlive.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TestViewController;

@interface TestAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet TestViewController *viewController;

@end
