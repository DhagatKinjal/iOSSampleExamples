ACTimeScroller
============

A UI Element that hovers beside the scroll bar of a UITableView (Mimicking the Path app).
