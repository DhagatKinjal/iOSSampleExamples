//
//  PSAppDelegate.h
//  ACTimeScrollerDemo
//
//  Created by Andrew Carter on 4/28/13.
//  Copyright (c) 2013 Pinch Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
