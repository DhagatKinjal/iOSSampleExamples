//
//  QProgressElement.h
//
//  Created by Xhacker on 2013-04-12.
//

#import "QuickDialog.h"
#import <Foundation/Foundation.h>

@interface QProgressElement : QElement

@property (nonatomic) float progress;

@end