#import <Foundation/Foundation.h>
#import "QuickDialogController.h"

@interface QuickDialogWebController : QuickDialogController

@property(nonatomic, strong) NSString * url;

- (void)reload;


@end