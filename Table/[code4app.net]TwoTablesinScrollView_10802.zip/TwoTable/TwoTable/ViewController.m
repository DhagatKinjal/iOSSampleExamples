//
//  ViewController.m
//  TwoTable
//
//  Created by Weever Lu on 12-6-1.
//  Copyright (c) 2012年 linkcity. All rights reserved.
//

#import "ViewController.h"
#import "PlainViewController.h"
#import "GroupViewController.h"

@interface ViewController ()

@property (nonatomic, retain) NSArray *array1;
@property (nonatomic, retain) NSArray *array2;

- (void)initData;

@end

@implementation ViewController
@synthesize theScrollView, theTableView1, theTableView2;
@synthesize array1, array2;

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    
    self.theScrollView = nil;
    self.theTableView1 = nil;
    self.theTableView2 = nil;
}

- (void)dealloc
{
    [theScrollView release];
    [theTableView1 release];
    [theTableView2 release];
    
    [array1 release];
    [array2 release];
    
    [super dealloc];
}

- (void)initData {
    
    NSArray *a1 = [[NSArray alloc] initWithObjects:@"A1", @"A2", @"A3", @"A4", @"A5", @"A6", nil];
    NSArray *a2 = [[NSArray alloc] initWithObjects:@"B1", @"B2", @"B3", @"B4", nil];
    self.array1 = a1;
    self.array2 = a2;
    [a1 release];
    [a2 release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.title = @"TableView Plain";
    [self initData];
    
    self.theScrollView.contentSize = CGSizeMake(320*2, self.theScrollView.frame.size.height);
    self.theScrollView.pagingEnabled = YES;
    self.theTableView1.rowHeight = 44;
    self.theTableView2.rowHeight = 60;
    
    self.navigationItem.backBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:nil] autorelease];
}

#pragma mark - UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    if (tableView.tag == 100) {
        return 3;
    }
    if (tableView.tag == 101) {
        return 4;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (tableView.tag == 100) {
        return self.array1.count;
    }
    if (tableView.tag == 101) {
        return self.array2.count;
    }
    return 0;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (tableView.tag == 100) {
        return [NSString stringWithFormat:@"%@ %d", @"Plain", section];
    }
    if (tableView.tag == 101) {
        return [NSString stringWithFormat:@"%@ %d", @"Group", section];
    }
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView.tag == 100) {
        static NSString *cellIdentifier1 = @"cellIdentifier1";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier1];
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier1] autorelease];
            cell.selectionStyle = UITableViewCellSelectionStyleBlue;
            cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
        }
        cell.textLabel.text = [self.array1 objectAtIndex:indexPath.row];
        return cell;
    }
    
    if (tableView.tag == 101) {
        static NSString *cellIdentifier2 = @"cellIdentifier2";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier2];
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier2] autorelease];
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        cell.textLabel.text = [self.array2 objectAtIndex:indexPath.row];
        cell.detailTextLabel.text = [self.array1 objectAtIndex:indexPath.row];
        return cell;
    }

    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSUInteger section = indexPath.section;
    NSUInteger row = indexPath.row;
    
    if (tableView.tag == 100) {
        PlainViewController *viewController = [[PlainViewController alloc] 
                                              initWithNibName:@"PlainViewController" bundle:nil];
        NSString *title = [NSString stringWithFormat:@"Section %d %@", section, [array1 objectAtIndex:row]];
        viewController.title = title;
        [self.navigationController pushViewController:viewController animated:YES];
        [viewController release];
    }
    if (tableView.tag == 101) {
        GroupViewController *viewController = [[GroupViewController alloc] 
                                               initWithNibName:@"GroupViewController" bundle:nil];
        NSString *title = [NSString stringWithFormat:@"Section %d %@", section, [array2 objectAtIndex:row]];
        viewController.title = title;
        [self.navigationController pushViewController:viewController animated:YES];
        [viewController release];        
    }
}
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
    
    NSString *msg = [NSString stringWithFormat:@"Section %d %@", indexPath.section, 
                            [array1 objectAtIndex:indexPath.row]];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" 
                                                    message:msg 
                                                   delegate:nil 
                                          cancelButtonTitle:@"Cancle" 
                                          otherButtonTitles:nil];
    [alert show];
    [alert release];
}
#pragma mark UITableViewDelegate End -

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    float x = scrollView.contentOffset.x;

    if (x > 320/2 && x < 640/2) {
        self.title = @"TableView Group";
    } 
    
    if (x > 0 && x < 320/2) {
        self.title = @"TableView Plain";
    }
}
#pragma mark UIScrollViewDelegate End -



@end
