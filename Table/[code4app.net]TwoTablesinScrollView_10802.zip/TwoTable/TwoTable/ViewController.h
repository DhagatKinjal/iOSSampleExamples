//
//  ViewController.h
//  TwoTable
//
//  Created by Weever Lu on 12-6-1.
//  Copyright (c) 2012年 linkcity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, retain) IBOutlet UIScrollView *theScrollView;
@property (nonatomic, retain) IBOutlet UITableView *theTableView1;
@property (nonatomic, retain) IBOutlet UITableView *theTableView2;

@end
