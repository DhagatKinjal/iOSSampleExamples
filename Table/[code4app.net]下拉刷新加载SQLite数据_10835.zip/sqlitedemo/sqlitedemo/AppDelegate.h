//
//  AppDelegate.h
//  sqlitedemo
//
//  Created by oo on 12-11-28.
//  Copyright (c) 2012年 oo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
