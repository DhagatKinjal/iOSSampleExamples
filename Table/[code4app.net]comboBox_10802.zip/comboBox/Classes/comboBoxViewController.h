//
//  comboBoxViewController.h
//  comboBox
//
//  Created by duansong on 10-7-28.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ComboBoxView.h"

@interface comboBoxViewController : UIViewController {
	ComboBoxView		*_comboBox;
}

@end

