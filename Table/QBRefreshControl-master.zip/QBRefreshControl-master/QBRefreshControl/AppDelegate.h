//
//  AppDelegate.h
//  QBRefreshControl
//
//  Created by Katsuma Tanaka on 2013/01/07.
//  Copyright (c) 2013年 Katsuma Tanaka. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
