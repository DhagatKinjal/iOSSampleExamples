//
//  DemoSectionItemSubclass.h
//  CHTableGroupSelectionView
//
//  Created by Clemens Hammerl on 20.11.12.
//  Copyright (c) 2012 Clemens Hammerl. All rights reserved.
//

#import "CHSectionSelectionItemView.h"

@interface DemoSectionItemSubclass : CHSectionSelectionItemView

@end
