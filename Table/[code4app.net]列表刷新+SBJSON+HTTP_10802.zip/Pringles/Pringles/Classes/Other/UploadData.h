//
//  UploadData.h
//  LiveByTouch
//
//  Created by hao.li on 11-7-28.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UploadData : NSObject {

}

@end
