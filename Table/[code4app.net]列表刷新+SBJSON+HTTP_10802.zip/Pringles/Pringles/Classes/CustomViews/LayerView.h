//
//  LayerView.h
//  LiveByTouch
//
//  Created by hao.li on 11-10-17.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LayerView : UIView {

}

@end
