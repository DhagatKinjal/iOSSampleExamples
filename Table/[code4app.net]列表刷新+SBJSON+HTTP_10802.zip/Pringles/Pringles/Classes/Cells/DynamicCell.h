//
//  DynamicCell.h
//  Pringles
//
//  Created by hao li on 12-3-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseCell.h"

@interface DynamicCell : BaseCell{

    
}

@end
