//
//  Paging.m
//  LiveByTouch
//
//  Created by hao.li on 11-9-26.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Paging.h"


@implementation Paging
@synthesize pageSize,rowCount,current,pageCount,isEnd;
@end
