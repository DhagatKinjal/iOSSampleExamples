@interface UIDevice (Additions) 
@property(readonly) double availableMemory; // MB
@end
