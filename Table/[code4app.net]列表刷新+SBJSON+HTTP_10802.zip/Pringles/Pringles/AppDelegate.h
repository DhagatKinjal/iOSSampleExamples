//
//  AppDelegate.h
//  Pringles
//
//  Created by hao li on 12-3-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SX_Dynamic.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController *viewController;

}

@property (strong, nonatomic) UIWindow *window;

@end
