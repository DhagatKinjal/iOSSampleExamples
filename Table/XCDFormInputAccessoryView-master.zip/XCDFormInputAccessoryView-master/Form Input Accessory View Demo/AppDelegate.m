//
//  AppDelegate.m
//  Form Accessory View Demo
//
//  Created by Cédric Luthi on 10.11.12.
//  Copyright (c) 2012 Cédric Luthi. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window = _window;

- (BOOL) application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	return YES;
}

@end
