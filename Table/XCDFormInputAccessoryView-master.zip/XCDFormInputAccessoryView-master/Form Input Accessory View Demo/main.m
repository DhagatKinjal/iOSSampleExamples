//
//  main.m
//  Form Accessory View Demo
//
//  Created by Cédric Luthi on 10.11.12.
//  Copyright (c) 2012 Cédric Luthi. All rights reserved.
//

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool
	{
		return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
