
@interface RootViewController : UITableViewController

- (void)setEntries:(NSArray *)entries;

@end
