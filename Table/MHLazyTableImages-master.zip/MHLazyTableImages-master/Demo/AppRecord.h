
@interface AppRecord : NSObject

@property (nonatomic, copy) NSString *appName;
@property (nonatomic, copy) NSString *artist;
@property (nonatomic, copy) NSString *imageURLString;
@property (nonatomic, copy) NSString *appURLString;

@end
