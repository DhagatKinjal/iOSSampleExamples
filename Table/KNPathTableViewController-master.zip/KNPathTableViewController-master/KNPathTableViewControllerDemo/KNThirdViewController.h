//
//  KNThirdViewController.h
//  KNPathTableViewControllerDemo
//
//  Created by My Accounts on 13/1/12.
//  Copyright (c) 2012 Anideo. All rights reserved.
//

#import "KNFirstViewController.h"

@interface KNThirdViewController : KNFirstViewController

@end
