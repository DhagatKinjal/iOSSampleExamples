//
//  main.m
//  KNPathTableViewControllerDemo
//
//  Created by My Accounts on 12/1/12.
//  Copyright (c) 2012 Anideo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KNAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([KNAppDelegate class]));
  }
}
