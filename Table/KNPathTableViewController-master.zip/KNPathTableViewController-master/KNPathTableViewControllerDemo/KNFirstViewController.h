//
//  KNFirstViewController.h
//  KNPathTableViewControllerDemo
//
//  Created by Kent Nguyen on 12/1/12.
//  Copyright (c) 2012. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KNPathTableViewController.h"

@interface KNFirstViewController : KNPathTableViewController {
  NSMutableArray * array;
  UILabel * infoLabel;
}

@end
