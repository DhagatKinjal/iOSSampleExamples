//
// DemoTableViewController.h
//
// @author Shiki
//

#import <UIKit/UIKit.h>
#import "STableViewController.h"

@interface DemoTableViewController : STableViewController {
  
  NSMutableArray *items;
}


@end
