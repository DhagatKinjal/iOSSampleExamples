// FNShadowTableController.h
// Created by Axel Schlueter on 11.11.12.
// Copyright (c) 2012 5vor9. All rights reserved.

#import <UIKit/UIKit.h>


@interface FNShadowTableController: UITableViewController

@end
