//
//  ViewController.h
//  ListDemo
//
//  Created by SunJiangting on 12-9-18.
//  Copyright (c) 2012年 SunJiangting. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SListView.h"
#import "SListViewCell.h"

@interface ViewController : UIViewController <SListViewDelegate, SListViewDataSource>

@end
