//
//  AppDelegate.h
//  ListDemo
//
//  Created by SunJiangting on 12-9-18.
//  Copyright (c) 2012年 SunJiangting. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
