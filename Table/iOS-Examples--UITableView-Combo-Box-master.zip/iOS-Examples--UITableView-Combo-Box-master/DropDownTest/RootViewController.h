//
//  RootViewController.h
//  DropDownTest
//
//  Created by Florian Krüger on 4/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {

    NSString *dropDown1;
    NSString *dropDown2;
    
    BOOL dropDown1Open;
    BOOL dropDown2Open;
    
}


@end
