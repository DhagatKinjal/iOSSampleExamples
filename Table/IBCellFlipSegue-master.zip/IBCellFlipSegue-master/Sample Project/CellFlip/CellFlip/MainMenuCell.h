//
//  MainMenuCell.h
//  CellFlip
//
//  Created by Itamar Biton on 2/18/13.
//  Copyright (c) 2013 IBlabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainMenuCell : UITableViewCell

@end
