//
//  Globals.h
//  CellFlip
//
//  Created by Itamar Biton on 1/25/13.
//  Copyright (c) 2013 IBlabs. All rights reserved.
//

#ifndef CellFlip_Globals_h
#define CellFlip_Globals_h

/*--------------------------
 Segue Identifiers
 ---------------------------*/

#define kSegueDetails       @"SegueDetails"
#define kSegueNavigation    @"SegueNavigation"

#endif
