//
//  MainMenuViewController.h
//  CellFlip
//
//  Created by Itamar Biton on 1/25/13.
//  Copyright (c) 2013 IBlabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainMenuViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

- (IBAction)didClickedShowButton:(id)sender;

@end
