//
//  AppDelegate.h
//  Pull-to-Refresh
//
//  Created by iDebug on 12-11-8.
//
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
