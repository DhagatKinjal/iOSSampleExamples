//
//  UIColor+Custom.h
//  ShootStudio
//
//  Created by Tom Fewster on 30/09/2011.
//  Copyright (c) 2011 Tom Fewster. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIColor (Custom)

+ (UIColor *)blueTextColor;

@end
