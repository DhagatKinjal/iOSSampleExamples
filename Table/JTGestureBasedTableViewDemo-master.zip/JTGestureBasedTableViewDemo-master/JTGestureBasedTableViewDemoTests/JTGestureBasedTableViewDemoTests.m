//
//  JTGestureBasedTableViewDemoTests.m
//  JTGestureBasedTableViewDemoTests
//
//  Created by James Tang on 2/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "JTGestureBasedTableViewDemoTests.h"

@implementation JTGestureBasedTableViewDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in JTGestureBasedTableViewDemoTests");
}

@end
