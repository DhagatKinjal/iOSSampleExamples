//
//  AppDelegate.h
//  JTGestureBaseTableViewStoryBoardDemo
//
//  Created by James Tang Chi Chiu on 26/2/12.
//  Copyright (c) 2012 CUHK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
