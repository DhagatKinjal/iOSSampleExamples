//
//  Defines.h
//  YIFullScreenScrollDemo
//
//  Created by Yasuhiro Inami on 12/06/03.
//  Copyright (c) 2012年 Yasuhiro Inami. All rights reserved.
//

#ifndef YIFullScreenScrollDemo_Defines_h
#define YIFullScreenScrollDemo_Defines_h

#import "YIFullScreenScroll.h"

#endif
