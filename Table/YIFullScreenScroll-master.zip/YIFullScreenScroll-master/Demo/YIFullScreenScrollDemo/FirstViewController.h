//
//  FirstViewController.h
//  YIFullScreenScrollDemo
//
//  Created by Yasuhiro Inami on 12/06/03.
//  Copyright (c) 2012年 Yasuhiro Inami. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UITableViewController

- (IBAction)handleToggleButton:(id)sender;
- (IBAction)handleTintColorButton:(id)sender;

@end
