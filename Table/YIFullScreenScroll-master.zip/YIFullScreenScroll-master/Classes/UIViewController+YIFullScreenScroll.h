//
//  UIViewController+YIFullScreenScroll.h
//  YIFullScreenScrollDemo
//
//  Created by Inami Yasuhiro on 13/04/15.
//  Copyright (c) 2013年 Yasuhiro Inami. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YIFullScreenScroll;


@interface UIViewController (YIFullScreenScroll)

@property (nonatomic, strong) YIFullScreenScroll* fullScreenScroll;

@end
