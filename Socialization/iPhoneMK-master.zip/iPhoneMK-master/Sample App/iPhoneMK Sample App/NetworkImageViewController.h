//
//  SecondViewController.h
//  iPhoneMK Sample App
//
//  Created by Michael Kamprath on 2/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MKNetworkImageView.h"

@interface NetworkImageViewController : UIViewController
@property (retain) IBOutlet MKNetworkImageView* imageOne;

@end
