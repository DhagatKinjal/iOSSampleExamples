//
//  AppDelegate.h
//  shejiao
//
//  Created by Steven on 12-11-17.
//  Copyright (c) 2012年 Steven. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
