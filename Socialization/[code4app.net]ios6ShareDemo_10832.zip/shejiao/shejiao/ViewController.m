//
//  ViewController.m
//  shejiao
//
//  Created by Steven on 12-11-17.
//  Copyright (c) 2012年 Steven. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    if ([[[[UIDevice currentDevice] systemVersion] substringToIndex:1] intValue]==6) {
        if([SLComposeViewController class] != nil)
        {
            //[self setButtonStatus];
        } else {
            UIAlertView *osAlert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Your iOS version is NOT 6, can't run the demo." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [osAlert show];
            NSLog(@"Your iOS version is below iOS6");
            
            self.twitterButton.enabled = NO;
            self.twitterButton.alpha = 0.5f;
            
        }
        
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//分享到 Twitter
- (IBAction)sendtotwitter:(id)sender {
    int currentver = [[[[UIDevice currentDevice] systemVersion] substringToIndex:1] intValue];
    //ios5
    if (currentver==5 ) {
        // Set up the built-in twitter composition view controller.
        TWTweetComposeViewController *tweetViewController = [[TWTweetComposeViewController alloc] init];
        // Set the initial tweet text. See the framework for additional properties that can be set.
        [tweetViewController setInitialText:@"IOS5 twitter"];
        // Create the completion handler block.
        [tweetViewController setCompletionHandler:^(TWTweetComposeViewControllerResult result) {
            // Dismiss the tweet composition view controller.
            [self dismissModalViewControllerAnimated:YES];
        }];
        
        // Present the tweet composition view controller modally.
        [self presentModalViewController:tweetViewController animated:YES];
        //ios6
    }else if (currentver==6) {
//        if([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
//        {
            slComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
            [slComposerSheet setInitialText:@"this is ios6 twitter"];
            [slComposerSheet addImage:[UIImage imageNamed:@"ios6.jpg"]];
            [slComposerSheet addURL:[NSURL URLWithString:@"http://www.twitter.com/"]];
            [self presentViewController:slComposerSheet animated:YES completion:nil];
//        }

        [slComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result) {
            NSLog(@"start completion block");
            NSString *output;
            switch (result) {
                case SLComposeViewControllerResultCancelled:
                    output = @"Action Cancelled";
                    break;
                case SLComposeViewControllerResultDone:
                    output = @"Post Successfull";
                    break;
                default:
                    break;
            }
            if (result != SLComposeViewControllerResultCancelled)
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Twitter Message" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                [alert show];
            }
        }];
        
            
        
        
        
    }else{//ios5 以下
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://twitter.com"]];
    }
    
}
//分享到新浪weibo
- (IBAction)sendtoWeibo:(id)sender {
    
    if ([[[[UIDevice currentDevice] systemVersion] substringToIndex:1] intValue]>=6) {
        
        
        // if([SLComposeViewController isAvailableForServiceType:SLServiceTypeSinaWeibo])
        //{
        slComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeSinaWeibo];
        [slComposerSheet setInitialText:@"Sina Weibo"];
        [slComposerSheet addImage:[UIImage imageNamed:@"ios6.jpg"]];
        [slComposerSheet addURL:[NSURL URLWithString:@"http://www.twitter.com/"]];
        [slComposerSheet addURL:[NSURL URLWithString:@"http://www.weibo.com/"]];
        [self presentViewController:slComposerSheet animated:YES completion:nil];
        //}
        [slComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result) {
            NSLog(@"start completion block");
            NSString *output;
            switch (result) {
                case SLComposeViewControllerResultCancelled:
                    output = @"Action Cancelled";
                    break;
                case SLComposeViewControllerResultDone:
                    output = @"Post Successfull";
                    break;
                default:
                    break;
            }
            if (result != SLComposeViewControllerResultCancelled)
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Weibo Message" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                [alert show];
            }
        }];
        
    }else{
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://weibo.com"]];
        
    }
    
    
}
//分享到facebook
- (IBAction)sendtoFacebook:(id)sender {
    if ([[[[UIDevice currentDevice] systemVersion] substringToIndex:1] intValue]>=6) {
        //  if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
        //{
        slComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        [slComposerSheet setInitialText:@"this is facebook"];
        [slComposerSheet addImage:[UIImage imageNamed:@"ios6.jpg"]];
        [slComposerSheet addURL:[NSURL URLWithString:@"http://www.facebook.com/"]];
        [self presentViewController:slComposerSheet animated:YES completion:nil];
        // }
        
        [slComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result) {
            NSLog(@"start completion block");
            NSString *output;
            switch (result) {
                case SLComposeViewControllerResultCancelled:
                    output = @"Action Cancelled";
                    break;
                case SLComposeViewControllerResultDone:
                    output = @"Post Successfull";
                    break;
                default:
                    break;
            }
            if (result != SLComposeViewControllerResultCancelled)
            {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Message" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                [alert show];
            }
        }];
        
    }else{
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.facebook.com"]];
    }
}





- (void)dealloc {
    [_twitterButton release];
    [_facebookButton release];
    [_weiboButton release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setTwitterButton:nil];
    [self setFacebookButton:nil];
    [self setWeiboButton:nil];
    [super viewDidUnload];
}
@end
