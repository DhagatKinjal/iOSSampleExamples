//
//  AKAppDelegate.h
//  AKSegmentedControl Example
//
//  Created by Ali Karagoz on 24/01/13.
//  Copyright (c) 2013 Ali Karagoz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AKSegmentedControl.h"

@interface AKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
