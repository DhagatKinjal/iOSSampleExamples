//
//  main.m
//  AKSegmentedControl Example
//
//  Created by Ali Karagoz on 24/01/13.
//  Copyright (c) 2013 Ali Karagoz. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AKAppDelegate class]));
    }
}
