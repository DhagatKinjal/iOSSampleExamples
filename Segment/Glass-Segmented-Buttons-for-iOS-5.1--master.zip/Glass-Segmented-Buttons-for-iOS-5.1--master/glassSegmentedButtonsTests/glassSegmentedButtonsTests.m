//
//  glassSegmentedButtonsTests.m
//  glassSegmentedButtonsTests
//
//  Created by Keiran Paster on 8/24/12.
//  Copyright (c) 2012 Keiran Paster. All rights reserved.
//

#import "glassSegmentedButtonsTests.h"

@implementation glassSegmentedButtonsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in glassSegmentedButtonsTests");
}

@end
