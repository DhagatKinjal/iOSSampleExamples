//
//  MCSegmentedControlDemoViewController.h
//  MCSegmentedControlDemo
//
//  Created by Matteo Caldari on 13/02/11.
//  Copyright 2011 Matteo Caldari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCSegmentedControlDemoViewController : UIViewController {
	
	UILabel *_testLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *testLabel;

@end
