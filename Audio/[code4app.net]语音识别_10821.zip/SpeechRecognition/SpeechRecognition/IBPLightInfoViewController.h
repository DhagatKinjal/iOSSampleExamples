//
//  IBPLightInfoViewController.h
//  IBPLight
//
//  Created by 朱克锋 on 13-2-17.
//  Copyright (c) 2013年 朱克锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBPLightInfoViewController : UIViewController

@end
