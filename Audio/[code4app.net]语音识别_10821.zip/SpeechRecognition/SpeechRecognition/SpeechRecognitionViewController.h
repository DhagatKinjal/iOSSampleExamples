//
//  SpeechRecognitionViewController.h
//  SpeechRecognition
//
//  Created by 朱克锋 on 13-2-17.
//  Copyright (c) 2013年 朱克锋. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Slt/Slt.h>
@class PocketsphinxController;
@class FliteController;
#import <OpenEars/OpenEarsEventsObserver.h>

@interface SpeechRecognitionViewController : UIViewController<OpenEarsEventsObserverDelegate>
{
    Slt *slt;
    
	OpenEarsEventsObserver *openEarsEventsObserver; 
	PocketsphinxController *pocketsphinxController; 
	FliteController *fliteController;
    
    
    NSString *pathToGrammarToStartAppWith;
	NSString *pathToDictionaryToStartAppWith;
	
	NSString *pathToDynamicallyGeneratedGrammar;
	NSString *pathToDynamicallyGeneratedDictionary;
    
    UIImageView *imgView;
}


@property (nonatomic, strong) Slt *slt;

@property (nonatomic, strong) OpenEarsEventsObserver *openEarsEventsObserver;
@property (nonatomic, strong) PocketsphinxController *pocketsphinxController;
@property (nonatomic, strong) FliteController *fliteController;

@property (nonatomic, copy) NSString *pathToGrammarToStartAppWith;
@property (nonatomic, copy) NSString *pathToDictionaryToStartAppWith;
@property (nonatomic, copy) NSString *pathToDynamicallyGeneratedGrammar;
@property (nonatomic, copy) NSString *pathToDynamicallyGeneratedDictionary;

@property (nonatomic, strong) IBOutlet UIImageView *imgView;
@end
