//
//  main.m
//  SpeechRecognition
//
//  Created by 朱克锋 on 12-11-15.
//  Copyright (c) 2012年 朱克锋. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SpeechRecognitionAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SpeechRecognitionAppDelegate class]));
    }
}
