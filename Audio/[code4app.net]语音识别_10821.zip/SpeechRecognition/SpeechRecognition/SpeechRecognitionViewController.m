//
//  SpeechRecognitionViewController.m
//  SpeechRecognition
//
//  Created by 朱克锋 on 13-2-17.
//  Copyright (c) 2013年 朱克锋. All rights reserved.
//  OpenEars是一个开源的iOS类库，用于在iPhone和iPad实现语音识别功能.
//  本demo利用此开源类库实现了简单的语音识别CHANGE,LEFT,RIGHT,FORWARD,BACKWARD,GO,其他语素需要训练
//GO FORWARD |
//GO BACKWARD |
//TURN RIGHT |
//TURN LEFT |
//CHANGE MODEL;

#import "SpeechRecognitionViewController.h"
#import <OpenEars/PocketsphinxController.h> 
#import <OpenEars/FliteController.h>
#import <OpenEars/LanguageModelGenerator.h>
#import <OpenEars/OpenEarsLogging.h>
#import "IBPLightInfoViewController.h"

@interface SpeechRecognitionViewController ()
{
    BOOL ISfailImg;
    UIButton *startBtn;
    UIButton *stopBtn;
}
@property(nonatomic, retain)IBOutlet UIButton *startBtn;
@property(nonatomic, retain)IBOutlet UIButton *stopBtn; 
@end

@implementation SpeechRecognitionViewController
@synthesize pocketsphinxController;
@synthesize fliteController;
@synthesize openEarsEventsObserver;
@synthesize pathToGrammarToStartAppWith;
@synthesize pathToDictionaryToStartAppWith;
@synthesize pathToDynamicallyGeneratedGrammar;
@synthesize pathToDynamicallyGeneratedDictionary;
@synthesize slt;

@synthesize imgView;
@synthesize startBtn;
@synthesize stopBtn;

#define kLevelUpdatesPerSecond 18 

- (void)viewDidLoad
{
    [super viewDidLoad];
    ISfailImg = NO;
    self.imgView.image = [UIImage imageNamed:@"success.png"];
    self.stopBtn.enabled = NO;
    self.startBtn.enabled = YES;
	[self.openEarsEventsObserver setDelegate:self]; 
    
    [self setPath];
}

-(void)setPath
{
    self.pathToGrammarToStartAppWith = [NSString stringWithFormat:@"%@/%@",[[NSBundle mainBundle] resourcePath], @"OpenEars1.languagemodel"];
    
	self.pathToDictionaryToStartAppWith = [NSString stringWithFormat:@"%@/%@",[[NSBundle mainBundle] resourcePath], @"OpenEars1.dic"];
}

#pragma mark -
#pragma mark button action
-(IBAction)infoBtn:(id)sender
{
    IBPLightInfoViewController *vc = [[IBPLightInfoViewController alloc] initWithNibName:@"IBPLightInfoViewController" bundle:nil];
    [self presentModalViewController:vc animated:YES];
    [vc release];
}

-(IBAction)startBtn:(id)sender
{
    self.stopBtn.enabled = YES;
    self.startBtn.enabled = NO;
    [self startListening];
    [self.fliteController say:[NSString stringWithFormat:@"start, You can sai command."] withVoice:self.slt];
}

-(IBAction)stopBtn:(id)sender
{
    self.stopBtn.enabled = NO;
    self.startBtn.enabled = YES;
    [self.fliteController say:[NSString stringWithFormat:@"stop."] withVoice:self.slt];
    [self.pocketsphinxController stopListening];
}

#pragma mark -
#pragma mark parse func
- (void) pocketsphinxDidReceiveHypothesis:(NSString *)hypothesis recognitionScore:(NSString *)recognitionScore utteranceID:(NSString *)utteranceID
{
	NSLog(@"The received hypothesis is %@ with a score of %@ and an ID of %@", hypothesis, recognitionScore, utteranceID); 

    [self hypothesisAction:hypothesis];
 
	//[self.fliteController say:[NSString stringWithFormat:@"You said %@",hypothesis] withVoice:self.slt];
}

-(void)hypothesisAction:(NSString *)hypothesis
{
    if ([@"CHANGE" isEqualToString:hypothesis]) {
        if (ISfailImg == NO) {
            ISfailImg = YES;
            self.imgView.image = [UIImage imageNamed:@"failure.png"];
        }else
        {
            ISfailImg = NO;
            self.imgView.image = [UIImage imageNamed:@"success.png"];
        }
    }
    if ([@"LEFT" isEqualToString:hypothesis]) {
        self.imgView.center = CGPointMake(260, 210);
    }
    
    if ([@"RIGHT" isEqualToString:hypothesis]) {
        self.imgView.center = CGPointMake(60, 210);
    }
    
    if ([@"GO" isEqualToString:hypothesis]) {
        self.imgView.center = CGPointMake(160, 210);
    }
    
    if ([@"FORWARD" isEqualToString:hypothesis]) {
        self.imgView.center = CGPointMake(160, 50);
    }
    
    if ([@"BACKWARD" isEqualToString:hypothesis]) {
        self.imgView.center = CGPointMake(160, 390);
    }
}

#pragma mark -
#pragma mark Lazy Allocation
- (PocketsphinxController *)pocketsphinxController
{
	if (pocketsphinxController == nil) {
		pocketsphinxController = [[PocketsphinxController alloc] init];
	}
	return pocketsphinxController;
}

- (Slt *)slt
{
	if (slt == nil) {
		slt = [[Slt alloc] init];
	}
	return slt;
}

- (FliteController *)fliteController
{
	if (fliteController == nil) {
		fliteController = [[FliteController alloc] init];
	}
	return fliteController;
}

- (OpenEarsEventsObserver *)openEarsEventsObserver
{
	if (openEarsEventsObserver == nil) {
		openEarsEventsObserver = [[OpenEarsEventsObserver alloc] init];
	}
	return openEarsEventsObserver;
}

- (void) startListening
{
    [self.pocketsphinxController startListeningWithLanguageModelAtPath:self.pathToGrammarToStartAppWith dictionaryAtPath:self.pathToDictionaryToStartAppWith languageModelIsJSGF:FALSE];
}

#pragma mark -
#pragma mark Memory Management

- (void)dealloc
{
    [super dealloc];
	openEarsEventsObserver.delegate = nil;
    //do more here
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
