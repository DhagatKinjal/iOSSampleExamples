int sphinx_lm_convert_main(int argc, char *argv[]);
