iOSMp3Recorder
==============

AVAudioRecorder + lame Mp3 Encoder

##This demo shows:

1.Choose the audio format (MP4AAC, PCM, LoseLess …. )

2.Change the output, Speaker or mic( ear pod ).

3.Convert the Linear PCM To Mp3

##Reference:

http://www.cocoachina.com/bbs/read.php?tid=82730&keyword=lame

http://stackoverflow.com/questions/1022992/how-to-get-avaudioplayer-output-to-the-speaker

