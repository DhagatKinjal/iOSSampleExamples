//
//  Player.h
//  Sound
//
//  Created by app nali on 12-6-1.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OutAudioPlayer.h"
@interface Player : NSObject

@property (nonatomic,retain) OutAudioPlayer *audioPlayer;

-(OSStatus)start;
-(OSStatus)stop;
-(void)cleanup;
-(void)initaliseAudio;
@end
