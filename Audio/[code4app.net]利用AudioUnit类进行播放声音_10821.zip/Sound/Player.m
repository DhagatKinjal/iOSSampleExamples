//
//  Player.m
//  Sound
//
//  Created by app nali on 12-6-1.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "Player.h"
#import <AudioUnit/AudioUnit.h>

#define kOutputBus 0
#define kInputBus 1


@implementation Player
@synthesize audioPlayer;

AudioComponentInstance audioUnit;
AudioStreamBasicDescription audioFormat;

-(OSStatus)start{
    OSStatus status=AudioOutputUnitStart(audioUnit);
    return status;
}


-(OSStatus)stop{
    OSStatus status=AudioOutputUnitStop(audioUnit);
    return  status;
}

-(void)cleanup{
    AudioUnitUninitialize(audioUnit);
}

static OSStatus playbackCallback(void *inRefCon,AudioUnitRenderActionFlags *ioActionFlags,
                                  const AudioTimeStamp *inTimeStamp,
                                  UInt32 inBusNumber,
                                  UInt32 inNumberFrames,
                                  AudioBufferList *ioData){
    Player *player=(Player *)inRefCon;

    for (int i=0; i<ioData->mNumberBuffers; i++) {
        AudioBuffer buffer=ioData->mBuffers[i];
        UInt32 *frameBuffer=buffer.mData;
        for (int index=0; index<inNumberFrames; index++) {
            frameBuffer[index]=[[player audioPlayer] getNextPacket];
        }
    }
    return noErr;
}

-(void)initaliseAudio{
    OSStatus status;
    
    AudioComponentDescription desc;
    desc.componentType=kAudioUnitType_Output;
    desc.componentSubType=kAudioUnitSubType_RemoteIO;
    desc.componentFlags=0;
    desc.componentFlagsMask=0;
    desc.componentManufacturer=kAudioUnitManufacturer_Apple;
    
    AudioComponent inputComponent=AudioComponentFindNext(NULL, &desc);
    
    status=AudioComponentInstanceNew(inputComponent, &audioUnit);
    
    UInt32 flag=1;
    
    status=AudioUnitSetProperty(audioUnit, kAudioOutputUnitProperty_EnableIO,
                                kAudioUnitScope_Output,kOutputBus , &flag, sizeof(flag));
    
    audioFormat.mSampleRate=44100;
    audioFormat.mFormatID=kAudioFormatLinearPCM;
    audioFormat.mFormatFlags=kAudioFormatFlagIsSignedInteger|kAudioFormatFlagIsPacked;
    audioFormat.mFramesPerPacket=1;
    audioFormat.mChannelsPerFrame=2;
    audioFormat.mBitsPerChannel=16;
    audioFormat.mBytesPerPacket=4;
    audioFormat.mBytesPerFrame=4;
    
    status=AudioUnitSetProperty(audioUnit, kAudioUnitProperty_StreamFormat,
                                kAudioUnitScope_Input,
                                kOutputBus, &audioFormat, sizeof(audioFormat));
    AURenderCallbackStruct callbackStruct;
    callbackStruct.inputProc=playbackCallback;
    callbackStruct.inputProcRefCon=self;
    status=AudioUnitSetProperty(audioUnit, kAudioUnitProperty_SetRenderCallback,
                                kAudioUnitScope_Global, kOutputBus, &callbackStruct, sizeof(callbackStruct));
    status=AudioUnitInitialize(audioUnit);
    
   
}


@end














































