//
//  OutAudioPlayer.h
//  Sound
//
//  Created by app nali on 12-5-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioFile.h>

@interface OutAudioPlayer : NSObject{
    AudioStreamBasicDescription basicDescription;
    AudioFileID audioFile;
    UInt32 bufferByteSize;
    SInt64 currentpacket;
    UInt32 packetToRead;
    AudioStreamPacketDescription packetDescription;
    SInt64 packetCount;
    UInt32 *audioData;
    SInt64 packetIndex;
}

-(OSStatus)open:(NSString *)filePath;
-(OSStatus)getFileInfo;
-(UInt32)getNextPacket;
-(SInt64)getIndex;
-(void)reset;
@end
