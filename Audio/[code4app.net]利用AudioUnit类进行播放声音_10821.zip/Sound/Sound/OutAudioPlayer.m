//
//  OutAudioPlayer.m
//  Sound
//
//  Created by app nali on 12-5-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "OutAudioPlayer.h"

@implementation OutAudioPlayer

- (id)init
{
    self = [super init];
    if (self) {
        packetCount=0;
    }
    
    return self;
}

-(void)dealloc{
    [super dealloc];
    free(audioData);
}

-(OSStatus)open:(NSString *)filePath{
    //文件地址
    const UInt8 *buffer=(const UInt8 *)[filePath cStringUsingEncoding:[NSString defaultCStringEncoding]];
    CFIndex bufLen=strlen([filePath cStringUsingEncoding:[NSString defaultCStringEncoding]]);
    CFURLRef audioFileUrl=CFURLCreateFromFileSystemRepresentation(NULL, buffer, bufLen, false);
    
    OSStatus result=AudioFileOpenURL(audioFileUrl, 0x01, 0, &audioFile);
    
    if (result!=noErr) {
        NSLog(@"filePath===%@",filePath);
        packetCount=-1;
    }else
    {
        [self getFileInfo];
        
        
        UInt32 packetReads=packetCount;
        OSStatus result=-1;
        free(audioData);
        UInt32 numBytesRead=-1;
        if (packetCount<=0) {
            
        }else{
            audioData=(UInt32 *)malloc(sizeof(UInt32)*packetCount);
            result=AudioFileReadPackets(audioFile, false, &numBytesRead, NULL, 0, &packetReads, audioData);
        }
        
        if (result==noErr) {
            
        }
    }
    CFRelease(audioFileUrl);
    return result;
}


-(OSStatus)getFileInfo{
    
    OSStatus result=-1;
    double duration;
    if (audioFile==nil) {
        
    }else{
        UInt32 dataSize=sizeof(packetCount);
        result=AudioFileGetProperty(audioFile, kAudioFilePropertyAudioDataPacketCount, &dataSize, &packetCount);
        if (result==noErr) {
            duration=((double)packetCount*2)/44100;
            NSLog(@"duration===%d",packetCount*2);
        }else
        {
            packetCount=-1;
        }
        
    }
    return  result;
}


-(UInt32)getNextPacket{
    UInt32 returnValue=0;
    if (packetIndex>=packetCount) {
        packetIndex=0;
       
        
    }
    returnValue=audioData[packetIndex++];
     
    return returnValue;
}

-(SInt64)getIndex{
    return packetIndex;
}

-(void)reset{
    packetIndex=0;
}

@end
















































