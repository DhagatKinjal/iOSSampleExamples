//
//  SoundViewController.h
//  Sound
//
//  Created by app nali on 12-5-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Player.h"
@interface SoundViewController : UIViewController

@property (nonatomic,retain) Player *audioPlayer;

-(void)start;
-(void)stop;
@end
