//
//  SoundViewController.m
//  Sound
//
//  Created by app nali on 12-5-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "SoundViewController.h"

@implementation SoundViewController

@synthesize audioPlayer;

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIButton *startButton=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 100, 30)];
    [startButton setTitle:@"start" forState:UIControlStateNormal];
    [startButton addTarget:self action:@selector(start) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:startButton];
    [startButton release];
    
    
    UIButton *stopButton=[[UIButton alloc] initWithFrame:CGRectMake(0, 60, 100, 30)];
    [stopButton setTitle:@"stop" forState:UIControlStateNormal];
    [stopButton addTarget:self action:@selector(stop) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:stopButton];
    [stopButton release];
    
    
    audioPlayer=[[Player alloc] init];
    [audioPlayer initaliseAudio];
    
    OutAudioPlayer *outPlayer=[[OutAudioPlayer alloc] init];
    NSString *path=[[NSBundle mainBundle] pathForResource:@"test" ofType:@"wav"];
    NSLog(@"path===%@",path);
    [outPlayer open:path];
    [audioPlayer setAudioPlayer:outPlayer];
}

-(void)start{
    [[audioPlayer audioPlayer] reset];
    [audioPlayer start];
    NSLog(@"start");
}

-(void)stop{
    [audioPlayer stop];
    NSLog(@"stop");
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
