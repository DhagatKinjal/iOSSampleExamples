//
//  SRAppDelegate.h
//  SoundRecorder
//
//  Created by Will Chilcutt on 4/4/12.
//  Copyright (c) 2012 ETSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
