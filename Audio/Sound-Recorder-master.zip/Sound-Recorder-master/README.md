This is a simple app that records audio when the user presses the record button and then playbacks the audio when Play is pressed.


<a target='_blank' title='ImageShack - Image And Video Hosting' href='http://imageshack.us/photo/my-images/404/screenshot20120417at935.png/'><img src='http://img404.imageshack.us/img404/9979/screenshot20120417at935.png' border='0'/></a>

