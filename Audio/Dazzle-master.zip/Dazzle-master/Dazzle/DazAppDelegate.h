//
//  DazAppDelegate.h
//  Dazzle
//
//  Created by Leonhard Lichtschlag on 9/Feb/12.
//  Copyright (c) 2012 Leonhard Lichtschlag. All rights reserved.
//

#import <UIKit/UIKit.h>

// ===============================================================================================================
@interface DazAppDelegate : UIResponder <UIApplicationDelegate>
// ===============================================================================================================

@property (strong, nonatomic) UIWindow *window;


@end

