//
//  DazFireworksController.h
//  Dazzle
//
//  Created by Leonhard Lichtschlag on 14/Feb/12.
//  Copyright (c) 2012 Leonhard Lichtschlag. All rights reserved.
//

#import <UIKit/UIKit.h>

// ===============================================================================================================
@interface DazFireworksController : UIViewController
// ===============================================================================================================


@end


