//
//  main.m
//  Dazzle
//
//  Created by Leonhard Lichtschlag on 9/Feb/12.
//  Copyright (c) 2012 Leonhard Lichtschlag. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DazAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool 
	{
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([DazAppDelegate class]));
	}
}
