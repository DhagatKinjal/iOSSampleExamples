//
//  RootViewController.h
//  AudioSample
//
//  Created by Alex Restrepo on 9/14/09.
//  Copyright Brainchild 2009. All rights reserved.
//

@class CMOpenALSoundManager;
@interface RootViewController : UITableViewController {
	CMOpenALSoundManager *soundMgr;
}

@end
