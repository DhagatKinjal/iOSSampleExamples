//
//  MonthlyEarningViewController.h
//  ConsignmentApp
//
//  Created by uday on 24/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface MonthlyEarningViewController : UIViewController<NSXMLParserDelegate>
{
    AppDelegate *appDel;
    NSMutableData *xmldata;
    NSXMLParser *xml_parser;
   
}
- (IBAction)BackMethod:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *MonthlyEarningLbl;

- (IBAction)MyitemTAB:(id)sender;
- (IBAction)WishlistTAB:(id)sender;
- (IBAction)NewsTAB:(id)sender;
- (IBAction)MoreTAB:(id)sender;


@end
