//
//  MonthlyEarningViewController.m
//  ConsignmentApp
//
//  Created by uday on 24/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "MonthlyEarningViewController.h"
#import "CurrentItemViewController.h"
#import "ConsignorWishListViewController.h"
#import "SocialPageFeedViewController.h"

@interface MonthlyEarningViewController ()

@end

@implementation MonthlyEarningViewController

CurrentItemViewController *objCurrentItemViewController;
SocialPageFeedViewController *objSocialPageFeedViewController;
ConsignorWishListViewController *objConsignorWishListViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
         appDel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        // Custom initialization
    }
    return self;
}
-(void) viewWillAppear:(BOOL)animated
{
    [self.navigationController.navigationBar setHidden:YES];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/monthlyearning"];
    NSString *post =[NSString stringWithFormat:@"table=invoiceitems,invoice,inventory,consignor&fields=sum(invoiceitems.SPRICE) as total&beforeWhere=&afterWhere=1 =1 AND inventory.CONSIGNORI = consignor.ID AND invoice.ID = invoiceitems.INVENTORYI AND invoiceitems.INVENTORYI = inventory.ID AND consignor.ID = '%@' &r_p_p=10&start=0&user=%@&pass=%@",appDel.ConsignorIDStr,appDel.EmailIDstr,appDel.PassStr];
    NSLog(@"%@",post);
    
    /*
     
     table =  “inventory,consignor”
     fields = “CPRICE,ITEMNUM,QUANTITY”
     beforeWhere = “”
     afterWhere = “inventory.CONSIGNORI = consignor.ID AND consignor.ID = '-1'”
     r_p_p = 10
     start  = 0
     user = ak29@gmail.com
     pass = 12345
     */
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];
}
- (void)viewDidLoad
{
//    [self.navigationController.navigationBar setHidden:YES];
//    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/monthlyearning"];
//    NSString *post =[NSString stringWithFormat:@"table=invoiceitems,invoice,inventory,consignor&fields=sum(invoiceitems.SPRICE) as total&beforeWhere=&afterWhere=1 =1 AND inventory.CONSIGNORI = consignor.ID AND invoice.ID = invoiceitems.INVENTORYI AND invoiceitems.INVENTORYI = inventory.ID AND consignor.ID = '%@' &r_p_p=10&start=0&user=%@&pass=%@",appDel.ConsignorIDStr,appDel.EmailIDstr,appDel.PassStr];
//    NSLog(@"%@",post);
//    
//    /*
//     
//     table =  “inventory,consignor”
//     fields = “CPRICE,ITEMNUM,QUANTITY”
//     beforeWhere = “”
//     afterWhere = “inventory.CONSIGNORI = consignor.ID AND consignor.ID = '-1'”
//     r_p_p = 10
//     start  = 0
//     user = ak29@gmail.com
//     pass = 12345
//     */
//    
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
//    [request setHTTPMethod:@"POST"];
//    
//    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
//    xmldata=[[NSMutableData alloc]init];
//    [connection start];

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
#pragma mark ConnectionMethod

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
    NSDictionary *jsonData=[NSJSONSerialization JSONObjectWithData:xmldata options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"%@",jsonData);
    
    NSDictionary* dict=[NSDictionary dictionaryWithDictionary:[jsonData objectForKey:@"response"]];
    //
    NSLog(@"%@",dict);
    NSString* totalstr = [dict objectForKey:@"total"];
    NSLog(@"%@",totalstr);
//    int total=[[dict objectForKey:@"total"]integerValue];
//    int status=[[dict objectForKey:@"status"]integerValue];
//    NSLog(@"%d\n%d",total,status);
   
    _MonthlyEarningLbl.text=[NSString stringWithFormat:@"%@",totalstr];
    
      
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setMonthlyEarningLbl:nil];
   
    [super viewDidUnload];
}
#pragma mark Mymethod

- (IBAction)BackMethod:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)MyitemTAB:(id)sender {
    objCurrentItemViewController=[[CurrentItemViewController alloc]initWithNibName:@"CurrentItemViewController" bundle:nil];
    [self.navigationController pushViewController:objCurrentItemViewController animated:YES];
}

- (IBAction)WishlistTAB:(id)sender {
    objConsignorWishListViewController=[[ConsignorWishListViewController alloc]initWithNibName:@"ConsignorWishListViewController" bundle:nil];
    [self.navigationController pushViewController:objConsignorWishListViewController animated:YES];

}

- (IBAction)NewsTAB:(id)sender {
    objSocialPageFeedViewController=[[SocialPageFeedViewController alloc]initWithNibName:@"SocialPageFeedViewController" bundle:nil];
    [self.navigationController pushViewController:objSocialPageFeedViewController animated:YES];

}

- (IBAction)MoreTAB:(id)sender {
}
@end
