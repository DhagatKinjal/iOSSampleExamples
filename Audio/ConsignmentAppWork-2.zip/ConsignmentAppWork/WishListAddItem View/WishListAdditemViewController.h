//
//  WishListAdditemViewController.h
//  ConsignmentApp
//
//  Created by uday on 26/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BSKeyboardControls.h"
#import "AppDelegate.h"


@interface WishListAdditemViewController : UIViewController<BSKeyboardControlsDelegate>
{
    BOOL keyboardOpened;
    AppDelegate *appDel;
    NSMutableData *xmldata;
    NSString *MYDeviceToken;
}
@property (nonatomic, strong) BSKeyboardControls *keyboardControls1;
@property (strong, nonatomic) IBOutlet UITextField *ItemTypeTextfield;
@property (strong, nonatomic) IBOutlet UITextField *BrandTextfield;
@property (strong, nonatomic) IBOutlet UITextField *ItemDetailsTextfield;
@property (strong, nonatomic) IBOutlet UITextField *ItemSizeTextfield;
- (IBAction)AddBtnMethod:(id)sender;
- (IBAction)Back_Method:(id)sender;

@end
