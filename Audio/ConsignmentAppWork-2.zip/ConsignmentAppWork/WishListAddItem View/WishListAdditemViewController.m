//
//  WishListAdditemViewController.m
//  ConsignmentApp
//
//  Created by uday on 26/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "WishListAdditemViewController.h"
#import "ConsignorWishListViewController.h"


@interface WishListAdditemViewController ()

@end

@implementation WishListAdditemViewController
ConsignorWishListViewController *objConsignorWishListViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        appDel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSArray *fields = @[ self.ItemTypeTextfield,self.BrandTextfield,self.ItemDetailsTextfield,self.ItemSizeTextfield];
    [self setKeyboardControls1:[[BSKeyboardControls alloc] initWithFields:fields]];
    [self.keyboardControls1 setDelegate:self];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setItemTypeTextfield:nil];
    [self setBrandTextfield:nil];
   
    [self setItemSizeTextfield:nil];
    [self setItemDetailsTextfield:nil];
    [super viewDidUnload];
}

#pragma mark TextfieldDelegate Method


- (void)keyboardControlsDonePressed:(BSKeyboardControls *)keyboardControls
{
    [keyboardControls.activeField resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self.keyboardControls1 setActiveField:textField];
    //[self keyboardShow];
    if(textField == _ItemDetailsTextfield)
    {
        [self keyboardShow]; 
    }
    if(textField == _ItemSizeTextfield )
    {
        [self keyboardShow];
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    
    [textField resignFirstResponder];
    [_ItemDetailsTextfield resignFirstResponder];
    [_ItemSizeTextfield resignFirstResponder];
    [_ItemTypeTextfield resignFirstResponder];
    [_BrandTextfield resignFirstResponder];
    return YES;
}




-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if(textField == _ItemDetailsTextfield)
    {
        [self keyboardHide];
    }
    if(textField == _ItemSizeTextfield )
    {
        [self keyboardHide];
    }

    //translate=FALSE;
    //[self keyboardHide];
}
-(void)keyboardShow
{
    CGRect rectFild = self.view.frame;
    rectFild.origin.y -= 80;
    [UIView animateWithDuration:0.25f
                     animations:^{
                         [self.view setFrame:rectFild];
                         
                     }
     ];
    
}
-(void)keyboardHide
{
    CGRect rectFild = self.view.frame;
    rectFild.origin.y += 80;
    [UIView animateWithDuration:0.25f
                     animations:^{
                         [self.view setFrame:rectFild];
                         
                     }
     ];
    
}

#pragma mark My Methods

- (IBAction)AddBtnMethod:(id)sender {
    
    if ([_ItemTypeTextfield.text length]==0 || [_ItemSizeTextfield.text length]==0 || [_ItemDetailsTextfield.text length]==0 || [_BrandTextfield.text length]==0)
    {
        UIAlertView *deviceidalert = [[UIAlertView alloc] initWithTitle:@"SIGN UP" message:@"Pls enter All the Require filed" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [deviceidalert show];
        
    }
    else
    {
        
        
        
        NSString *DetailStr=[NSString stringWithFormat:@"%@",_ItemDetailsTextfield.text];
        NSString *SizeStr=[NSString stringWithFormat:@"%@",_ItemSizeTextfield.text];
        NSString *TypeStr=[NSString stringWithFormat:@"%@",_ItemTypeTextfield.text];
        NSString *BrandStr=[NSString stringWithFormat:@"%@",_BrandTextfield.text];
        
        MYDeviceToken=[NSString stringWithFormat:@"%@",appDel.deviceToken];
        NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
        MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
        
        NSLog(@"%@",MYDeviceToken);
        
        NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/add?table=wishlist_master&nfield=&uniqueField=email"];
        NSString *post =[NSString stringWithFormat:@"c_email=%@&w_type=%@&w_brand=%@&w_desc=%@&w_size=%@",appDel.EmailIDstr,TypeStr,BrandStr,DetailStr,SizeStr];
        NSLog(@"Wishlist:: = %@",post);
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        [request setHTTPMethod:@"POST"];
        
        //[request addValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@\r\n", post] forHTTPHeaderField:@"Content-Type"];
        
        [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
        xmldata=[[NSMutableData alloc]init];
        [connection start];
    }
}

- (IBAction)Back_Method:(id)sender {
    //[self.navigationController popViewControllerAnimated:YES];
    [self dismissModalViewControllerAnimated:YES];
}


#pragma mark ConnectionMethod

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
   [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    objConsignorWishListViewController=[[ConsignorWishListViewController alloc]initWithNibName:@"ConsignorWishListViewController" bundle:nil];
    //[self.navigationController pushViewController:objConsignorWishListViewController animated:YES];
    [self dismissModalViewControllerAnimated:YES];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
   
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
}



@end
