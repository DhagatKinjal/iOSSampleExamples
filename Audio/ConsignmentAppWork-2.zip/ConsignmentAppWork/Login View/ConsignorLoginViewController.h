//
//  ConsignorLoginViewController.h
//  ConsignmentApp
//
//  Created by uday on 22/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BSKeyboardControls.h"
#import "AppDelegate.h"
#import "LeveyTabBarController.h"
#import "LeveyTabBar.h"

@interface ConsignorLoginViewController : UIViewController<BSKeyboardControlsDelegate,NSXMLParserDelegate>
{
    AppDelegate *appDel;
    LeveyTabBarController *leveyTabBarController;
    BOOL keyboardOpened;
    NSMutableData *xmldata;
    NSXMLParser *xml_parser;
    NSMutableArray *jsonArray;
}

@property (nonatomic, strong) BSKeyboardControls *keyboardControls1;
@property (strong, nonatomic) IBOutlet UITextField *UserName_TextField;
@property (strong, nonatomic) IBOutlet UITextField *Password_TextField;
@property (strong,nonatomic) NSString *Consinor;

- (IBAction)Sign_In_Method:(id)sender;




@end
