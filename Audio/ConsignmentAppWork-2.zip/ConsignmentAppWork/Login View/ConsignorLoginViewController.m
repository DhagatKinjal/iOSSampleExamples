//
//  ConsignorLoginViewController.m
//  ConsignmentApp
//
//  Created by uday on 22/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "ConsignorLoginViewController.h"
#import "ConsignmentHomeViewController.h"
#import "ConsignorRegViewController.h"
#import "ConsignorWishListViewController.h"
#import "CurrentItemViewController.h"
#import "CurrentItemViewController.h"
#import "SocialPageFeedViewController.h"
#import "MonthlyEarningViewController.h"
#import "ConsignorWishListViewController.h"
@interface ConsignorLoginViewController ()

@end

@implementation ConsignorLoginViewController
@synthesize Consinor;
ConsignmentHomeViewController *objConsignmentHomeViewController;
ConsignorRegViewController *objConsignorRegViewController;
ConsignorWishListViewController *objConsignorWishListViewController;
CurrentItemViewController *objCurrentItemViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
        appDel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSArray *fields = @[ self.UserName_TextField,self.Password_TextField];
    [self setKeyboardControls1:[[BSKeyboardControls alloc] initWithFields:fields]];
    [self.keyboardControls1 setDelegate:self];
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}



#pragma mark TextfieldDelegate Method


- (void)keyboardControlsDonePressed:(BSKeyboardControls *)keyboardControls
{
    [keyboardControls.activeField resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self.keyboardControls1 setActiveField:textField];
    [self keyboardShow];
    //    if(textField == _UserName_TextField)
    //    {
    //        _Scroll_view.contentOffset=CGPointMake(0, 95);
    //    }
    //    if(textField == _Email_TextField )
    //    {
    //        _Scroll_view.contentOffset = CGPointMake(0, 95);
    //    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    
    [textField resignFirstResponder];
    [_UserName_TextField resignFirstResponder];
    
    [_Password_TextField resignFirstResponder];
    return YES;
}




-(void)textFieldDidEndEditing:(UITextField *)textField
{
    //translate=FALSE;
    [self keyboardHide];
}
-(void)keyboardShow
{
    CGRect rectFild = self.view.frame;
    rectFild.origin.y -= 80;
    [UIView animateWithDuration:0.25f
                     animations:^{
                         [self.view setFrame:rectFild];
                         
                     }
     ];
    
}
-(void)keyboardHide
{
    CGRect rectFild = self.view.frame;
    rectFild.origin.y += 80;
    [UIView animateWithDuration:0.25f
                     animations:^{
                         [self.view setFrame:rectFild];
                         
                     }
     ];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setUserName_TextField:nil];
    [self setPassword_TextField:nil];
   
   
    [super viewDidUnload];
}

#pragma mark MyMethods

- (IBAction)Sign_In_Method:(id)sender {
    
    appDel.EmailIDstr=self.UserName_TextField.text;
    appDel.PassStr=self.Password_TextField.text;
    NSLog(@"%@:%@",appDel.EmailIDstr,appDel.PassStr);

    
    if ([_UserName_TextField.text length]==0 || [_Password_TextField.text length]==0)
    {
        UIAlertView *deviceidalert = [[UIAlertView alloc] initWithTitle:@"" message:@"Please enter all the require fields" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [deviceidalert show];
        
    }
    else
    {
        
        
        
        NSString *NameStr=[NSString stringWithFormat:@"%@",_UserName_TextField.text];
        NSString *PassStr=[NSString stringWithFormat:@"%@",_Password_TextField.text];
       
        
        
        
        
        NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/uservalidation"];
        NSString *post =[NSString stringWithFormat:@"user=%@&pass=%@",NameStr,PassStr];
        NSLog(@"%@",post);
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        [request setHTTPMethod:@"POST"];
        
        //[request addValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@\r\n", post] forHTTPHeaderField:@"Content-Type"];
        
        [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
        xmldata=[[NSMutableData alloc]init];
        [connection start];
    }

}






#pragma mark ConnectionMethod

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
    jsonArray=[[NSMutableArray alloc]init];
    NSDictionary *jsonData=[NSJSONSerialization JSONObjectWithData:xmldata options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"data: %@",jsonData);
    
    NSString* Response =  [jsonData objectForKey:@"response"];
    NSDictionary *dict=[NSDictionary dictionaryWithDictionary:[jsonData objectForKey:@"response"]];
    NSString* status = [dict objectForKey:@"status"];
    NSString* consinor = [dict objectForKey:@"consinor"];
    Consinor = [dict objectForKey:@"consinor"];

    
    NSLog(@"Response: %@", Response);
    NSLog(@"Status: %@", status);
    NSLog(@"Consignor: %@", consinor);
    appDel.ConsignorIDStr=[dict objectForKey:@"consinorid"];
    
    NSLog(@"ConsignorID:::%@",appDel.ConsignorIDStr);
    
    if([status isEqualToString:@"1"] && [consinor isEqualToString:@"0"])
    {
//        objConsignmentHomeViewController=[[ConsignmentHomeViewController alloc]initWithNibName:@"ConsignmentHomeViewController" bundle:nil];
//        [self.navigationController pushViewController:objConsignmentHomeViewController animated:YES];
        objConsignorWishListViewController=[[ConsignorWishListViewController alloc]initWithNibName:@"ConsignorWishListViewController" bundle:nil];
        [self.navigationController pushViewController:objConsignorWishListViewController animated:YES];


    }
    else if ([status isEqualToString:@"1"] && [consinor isEqualToString:@"1"])
    {
//        objCurrentItemViewController=[[CurrentItemViewController alloc]initWithNibName:@"CurrentItemViewController" bundle:nil];
//        [self.navigationController pushViewController:objCurrentItemViewController animated:YES];
        
        ///////
        
        CurrentItemViewController *firstVC = [[CurrentItemViewController alloc] init];
        ConsignorWishListViewController *secondVC=[[ConsignorWishListViewController alloc]init];
        MonthlyEarningViewController *thirdVC = [[MonthlyEarningViewController alloc] init];
        SocialPageFeedViewController *forthVC = [[SocialPageFeedViewController alloc] init];
        ConsignmentHomeViewController *fiveVC = [[ConsignmentHomeViewController alloc] init];
        
        //fourthVC.view.backgroundColor = [UIColor grayColor];
        
        //FirstViewController *fifthVC = [[FirstViewController alloc] init];
        //UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:secondVC];
        //nc.delegate = self;
        //[secondVC release];
        NSArray *ctrlArr = [NSArray arrayWithObjects:firstVC,secondVC,thirdVC,forthVC,fiveVC,nil];
        //[firstVC release];
        //[nc release];
        //[thirdVC release];
        //[fourthVC release];
        //[fifthVC release];
		
        NSMutableDictionary *imgDic = [NSMutableDictionary dictionaryWithCapacity:3];
        [imgDic setObject:[UIImage imageNamed:@"my items up 640-1136.png"] forKey:@"Default"];
        [imgDic setObject:[UIImage imageNamed:@"my items press 640-1136.png"] forKey:@"Highlighted"];
        [imgDic setObject:[UIImage imageNamed:@"my items press 640-1136.png"] forKey:@"Seleted"];
        NSMutableDictionary *imgDic2 = [NSMutableDictionary dictionaryWithCapacity:3];
        [imgDic2 setObject:[UIImage imageNamed:@"wish list up 640-1136.png"] forKey:@"Default"];
        [imgDic2 setObject:[UIImage imageNamed:@"wish list press 640-1136.png"] forKey:@"Highlighted"];
        [imgDic2 setObject:[UIImage imageNamed:@"wish list press 640-1136.png"] forKey:@"Seleted"];
        NSMutableDictionary *imgDic3 = [NSMutableDictionary dictionaryWithCapacity:3];
        [imgDic3 setObject:[UIImage imageNamed:@"earnings up 640-1136.png"] forKey:@"Default"];
        [imgDic3 setObject:[UIImage imageNamed:@"earnings press 640-1136.png"] forKey:@"Highlighted"];
        [imgDic3 setObject:[UIImage imageNamed:@"earnings press 640-1136.png"] forKey:@"Seleted"];
        NSMutableDictionary *imgDic4 = [NSMutableDictionary dictionaryWithCapacity:3];
        [imgDic4 setObject:[UIImage imageNamed:@"news up 640-1136.png"] forKey:@"Default"];
        [imgDic4 setObject:[UIImage imageNamed:@"news press 640-1136.png"] forKey:@"Highlighted"];
        [imgDic4 setObject:[UIImage imageNamed:@"news press 640-1136.png"] forKey:@"Seleted"];
        NSMutableDictionary *imgDic5 = [NSMutableDictionary dictionaryWithCapacity:3];
        [imgDic5 setObject:[UIImage imageNamed:@"more up 640-1136.png"] forKey:@"Default"];
        [imgDic5 setObject:[UIImage imageNamed:@"more press 640-1136.png"] forKey:@"Highlighted"];
        [imgDic5 setObject:[UIImage imageNamed:@"more press 640-1136.png"] forKey:@"Seleted"];
        //	NSMutableDictionary *imgDic5 = [NSMutableDictionary dictionaryWithCapacity:3];
        //	[imgDic5 setObject:[UIImage imageNamed:@"1.png"] forKey:@"Default"];
        //	[imgDic5 setObject:[UIImage imageNamed:@"2.png"] forKey:@"Highlighted"];
        //	[imgDic5 setObject:[UIImage imageNamed:@"2.png"] forKey:@"Seleted"];
        
        NSArray *imgArr = [NSArray arrayWithObjects:imgDic,imgDic2,imgDic3,imgDic4,imgDic5,nil];
        
        leveyTabBarController = [[LeveyTabBarController alloc] initWithViewControllers:ctrlArr imageArray:imgArr];
        [leveyTabBarController.tabBar setBackgroundImage:[UIImage imageNamed:@"footer 640-.png"]];
        [leveyTabBarController setTabBarTransparent:YES];
        
        [leveyTabBarController.view setFrame:CGRectMake(0, 0, 320, 548)];
        
        
        
        [self.view addSubview:leveyTabBarController.view];
        
     
    }
    else
    {
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Please Enter valid Email & Password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alt show];
    }
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
}


@end
