//
//  ConsignorWishListCustomCell.h
//  ConsignmentApp
//
//  Created by uday on 26/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConsignorWishListCustomCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *SizeLbl;
@property (strong, nonatomic) IBOutlet UILabel *TypeLbl;
@property (strong, nonatomic) IBOutlet UILabel *DetailsLbl;


@end
