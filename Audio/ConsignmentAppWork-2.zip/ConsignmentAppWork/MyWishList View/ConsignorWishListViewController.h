//
//  ConsignorWishListViewController.h
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ConsignorWishListViewController : UIViewController<NSXMLParserDelegate>
{
    AppDelegate *appDel;
    NSMutableData *xmldata;
    NSXMLParser *xml_parser;
    NSMutableArray *SizeArr,*TypeArr,*DetailsArr,*IndexArr;
    int totalRecords,NextStart,checkHowManyPress,count;
}
@property (strong, nonatomic) IBOutlet UIButton *BackButtonIBOutlet;
- (IBAction)Back_Method:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *PreviousBtnIBoutlet;
@property (strong, nonatomic) IBOutlet UIButton *NextBtnIBoutlet;
- (IBAction)NextRecords:(id)sender;
- (IBAction)PreviousMethod:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *WishListTB;
- (IBAction)AddWishlist_Method:(id)sender;

- (IBAction)MyItemTAB:(id)sender;
- (IBAction)EarningTAB:(id)sender;
- (IBAction)NewsTAB:(id)sender;
- (IBAction)MoreTab:(id)sender;

@end
