//
//  ConsignorWishListViewController.m
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "ConsignorWishListViewController.h"
#import "ConsignorWishListCustomCell.h"
#import "WishListAdditemViewController.h"
#import "ConsignorLoginViewController.h"
#import "CurrentItemViewController.h"
#import "SocialPageFeedViewController.h"
#import "MonthlyEarningViewController.h"

@interface ConsignorWishListViewController ()

@end

@implementation ConsignorWishListViewController

MonthlyEarningViewController *objMonthlyEarningViewController;
ConsignorLoginViewController *objConsignorLoginViewController;
WishListAdditemViewController *objWishListAdditemViewController;
CurrentItemViewController *objCurrentItemViewController;
SocialPageFeedViewController *objSocialPageFeedViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        appDel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
    }
    return self;
}

- (void)viewDidLoad
{
    if ([objConsignorLoginViewController.Consinor isEqualToString:@"0"]) {
        self.BackButtonIBOutlet.hidden = YES;
    }

    [_PreviousBtnIBoutlet setEnabled:NO];
    checkHowManyPress=1;
    NextStart=0;
    count=1;
    IndexArr=[[NSMutableArray alloc]init];
    
    SizeArr=[[NSMutableArray alloc]init];
    TypeArr=[[NSMutableArray alloc]init];
    DetailsArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getwishlist"];
    NSString *post =[NSString stringWithFormat:@"table=wishlist_master,consignor_user&fields=wishlist_master.w_type,wishlist_master.w_desc,wishlist_master.w_size&beforeWhere=&afterWhere=wishlist_master.c_email = consignor_user.email&r_p_p=10&start=%d&user=%@&pass=%@",NextStart,appDel.EmailIDstr,appDel.PassStr];

    NSLog(@"wishlist id = %@",post);
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark ConnectionMethod

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
    NSDictionary *jsonData=[NSJSONSerialization JSONObjectWithData:xmldata options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"data: %@",jsonData);
    
    
    
    NSDictionary* dict=[NSDictionary dictionaryWithDictionary:[jsonData objectForKey:@"response"]];
    NSArray* MyArray = [dict objectForKey:@"data"];
    
    totalRecords=[[dict objectForKey:@"totalRecord"]integerValue];
    NextStart=[[dict objectForKey:@"nextStart"]integerValue];
    NSLog(@"%d\n%d",totalRecords,NextStart);
    
    
    if(NextStart>totalRecords)
    {
        [_NextBtnIBoutlet setEnabled:NO];
    }
    
    
    for(int i=0;i<MyArray.count;i++)
    {
        //        NSLog(@"Price:: %@",[[MyArray objectAtIndex:i] objectForKey:@"CPRICE"]);
        //        NSLog(@"Item:: %@",[[MyArray objectAtIndex:i] objectForKey:@"DESCRIPTIO"]);
        //        NSLog(@"Qty:: %@",[[MyArray objectAtIndex:i] objectForKey:@"QUANTITY"]);
        
        [TypeArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"w_type"]];
        [SizeArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"w_size"]];
        [DetailsArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"w_desc"]];
    }
    for (int j=0; j<DetailsArr.count; j++)
    {
        [IndexArr addObject:[NSString stringWithFormat:@"%d",count]];
        
        count++;
    }
    
    [_WishListTB reloadData];
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
}


- (void)viewDidUnload {
    [self setWishListTB:nil];
    [self setNextBtnIBoutlet:nil];
    [self setPreviousBtnIBoutlet:nil];
    
    [self setBackButtonIBOutlet:nil];
    [super viewDidUnload];
}



#pragma mark UITableView methods


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section {
    return [TypeArr count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static  NSString *cellIdentifier=@"ConsignorWishListCustomCell";
    
    ConsignorWishListCustomCell *cell = (ConsignorWishListCustomCell *)[_WishListTB  dequeueReusableCellWithIdentifier:cellIdentifier];
    
    
    if(cell==nil)
    {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ConsignorWishListCustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    
    cell.SizeLbl.text = [SizeArr objectAtIndex:indexPath.row];
    cell.TypeLbl.text = [TypeArr objectAtIndex:indexPath.row];
    cell.DetailsLbl.text = [DetailsArr objectAtIndex:indexPath.row];
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    
}
#pragma mark MyMethod

- (IBAction)NextRecords:(id)sender {
    NSLog(@"%d",NextStart);
    NSLog(@"%d",totalRecords);
    [_PreviousBtnIBoutlet setEnabled:YES];
    
    IndexArr=[[NSMutableArray alloc]init];
    
    SizeArr=[[NSMutableArray alloc]init];
    TypeArr=[[NSMutableArray alloc]init];
    DetailsArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getwishlist"];
    NSString *post =[NSString stringWithFormat:@"table=wishlist_master,consignor_user&fields=wishlist_master.w_type,wishlist_master.w_desc,wishlist_master.w_size&beforeWhere=&afterWhere=wishlist_master.c_email = consignor_user.email&r_p_p=10&start=%d&user=%@&pass=%@",NextStart,appDel.EmailIDstr,appDel.PassStr];

    NSLog(@"%@",post);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];
    checkHowManyPress++;
    
    
}

- (IBAction)PreviousMethod:(id)sender {
    
    [_NextBtnIBoutlet setEnabled:YES];
    
    NextStart=NextStart-20;//(11*checkHowManyPress);
    
    NSLog(@"%d",NextStart);
    NSLog(@"%d",totalRecords);
    
    
    IndexArr=[[NSMutableArray alloc]init];
    
    SizeArr=[[NSMutableArray alloc]init];
    TypeArr=[[NSMutableArray alloc]init];
    DetailsArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getwishlist"];
    NSString *post =[NSString stringWithFormat:@"table=wishlist_master,consignor_user&fields=wishlist_master.w_type,wishlist_master.w_desc,wishlist_master.w_size&beforeWhere=&afterWhere=wishlist_master.c_email = consignor_user.email&r_p_p=10&start=%d&user=%@&pass=%@",NextStart,appDel.EmailIDstr,appDel.PassStr];

    NSLog(@"%@",post);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];
    if(NextStart==0)
    {
        count=1;
        [_PreviousBtnIBoutlet setEnabled:NO];
        [_NextBtnIBoutlet setEnabled:YES];
    }
    else{
        
        count=NextStart+1;
    }
    
}

- (IBAction)AddWishlist_Method:(id)sender {
    
    objWishListAdditemViewController=[[WishListAdditemViewController alloc]initWithNibName:@"WishListAdditemViewController" bundle:nil ];
    //[self.navigationController pushViewController:objWishListAdditemViewController animated:YES];
    [self presentModalViewController:objWishListAdditemViewController animated:YES];
    
    
}

- (IBAction)MyItemTAB:(id)sender {
    objCurrentItemViewController=[[CurrentItemViewController alloc]initWithNibName:@"CurrentItemViewController" bundle:nil];
    [self.navigationController pushViewController:objCurrentItemViewController animated:YES];
}

- (IBAction)EarningTAB:(id)sender {
    objMonthlyEarningViewController=[[MonthlyEarningViewController alloc]initWithNibName:@"MonthlyEarningViewController" bundle:nil];
    [self.navigationController pushViewController:objMonthlyEarningViewController animated:YES];
}

- (IBAction)NewsTAB:(id)sender {
    objSocialPageFeedViewController=[[SocialPageFeedViewController alloc]initWithNibName:@"SocialPageFeedViewController" bundle:nil];
    [self.navigationController pushViewController:objSocialPageFeedViewController animated:YES];

}

- (IBAction)MoreTab:(id)sender {
}
- (IBAction)Back_Method:(id)sender {
     //[self.navigationController popViewControllerAnimated:YES];
    [self dismissModalViewControllerAnimated:YES];
}
@end
