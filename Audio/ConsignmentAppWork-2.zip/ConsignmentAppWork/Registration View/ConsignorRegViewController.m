//
//  ConsignorRegViewController.m
//  ConsignmentApp
//
//  Created by uday on 22/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "ConsignorRegViewController.h"
#import "ConsignorLoginViewController.h"

@interface ConsignorRegViewController ()

@end

@implementation ConsignorRegViewController
ConsignorLoginViewController *objConsignorLoginViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSArray *fields = @[ self.UserName_TextField,self.Email_TextField,self.Pass_TextField];
    [self setKeyboardControls1:[[BSKeyboardControls alloc] initWithFields:fields]];
    [self.keyboardControls1 setDelegate:self];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark TextfieldDelegate Method


- (void)keyboardControlsDonePressed:(BSKeyboardControls *)keyboardControls
{
    [keyboardControls.activeField resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self.keyboardControls1 setActiveField:textField];
    
    if(textField == _Pass_TextField || textField==_Email_TextField)
    {
        [self keyboardShow];

    }
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
  

    [textField resignFirstResponder];
    [_UserName_TextField resignFirstResponder];
    [_Email_TextField resignFirstResponder];
    [_Pass_TextField resignFirstResponder];
       return YES;
}




-(void)textFieldDidEndEditing:(UITextField *)textField
{
    //translate=FALSE;
    if(textField == _Pass_TextField || textField==_Email_TextField)
    {
      [self keyboardHide];
        
    }

   
}
-(void)keyboardShow
{
    
    CGRect rectFild = self.view.frame;
    rectFild.origin.y -= 85;
    [UIView animateWithDuration:0.25f
                     animations:^{
                         [self.view setFrame:rectFild];
                         
                     }
     ];
    
}
-(void)keyboardHide
{
    CGRect rectFild = self.view.frame;
    rectFild.origin.y += 85;
    [UIView animateWithDuration:0.25f
                     animations:^{
                         [self.view setFrame:rectFild];
                         
                     }
     ];
    
}


#pragma mark ConnectionMethod

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
    
       
    [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    NSDictionary *jsonData=[NSJSONSerialization JSONObjectWithData:xmldata options:NSJSONReadingMutableContainers error:nil];
    
    NSLog(@"data: %@",jsonData);
    
    
    NSString* Response =  [jsonData objectForKey:@"response"];
    NSDictionary *dict=[NSDictionary dictionaryWithDictionary:[jsonData objectForKey:@"response"]];
    NSString* status = [dict objectForKey:@"status"];
  
    
    NSLog(@"Response: %@", Response);
    NSLog(@"Status: %@", status);
  

    if([status isEqualToString:@"1"])
    {
        objConsignorLoginViewController=[[ConsignorLoginViewController alloc]initWithNibName:@"ConsignorLoginViewController" bundle:nil];
        [self.navigationController pushViewController:objConsignorLoginViewController animated:YES];
    }
    else if ([status isEqualToString:@"-2"])
    {
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"User already exist" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alt show];
    }
    else
    {
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Registration Failed" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alt show];

    }

    


}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];


}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
}

#pragma mark MyMethod

- (IBAction)SignUp_Method:(id)sender {
    
    
    if ([_UserName_TextField.text length]==0 || [_Email_TextField.text length]==0 || [_Pass_TextField.text length]==0)
    {
        UIAlertView *deviceidalert = [[UIAlertView alloc] initWithTitle:@"SIGN UP" message:@"Please enter all the require fields" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
        [deviceidalert show];
        
    }
    else
    {
        
        
        
        NSString *NameStr=[NSString stringWithFormat:@"%@",_UserName_TextField.text];
        NSString *PassStr=[NSString stringWithFormat:@"%@",_Pass_TextField.text];
        NSString *emailStr=[NSString stringWithFormat:@"%@",_Email_TextField.text];
        
        MYDeviceToken=[NSString stringWithFormat:@"%@",appDel.deviceToken];
        NSCharacterSet *doNotWant55 = [NSCharacterSet characterSetWithCharactersInString:@"<>\"\n "];
        MYDeviceToken = [[MYDeviceToken componentsSeparatedByCharactersInSet: doNotWant55] componentsJoinedByString: @""];
        
        NSLog(@"%@",MYDeviceToken);

        
        
        NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/add?table=consignor_user&nfield=&uniqueField=email"];
        NSString *post =[NSString stringWithFormat:@"c_name=%@&c_pass=%@&email=%@&os_type=ios&ai_register_id=%@",NameStr,PassStr,emailStr,MYDeviceToken];
        NSLog(@"%@",post);
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
        [request setHTTPMethod:@"POST"];
        
        //[request addValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@\r\n", post] forHTTPHeaderField:@"Content-Type"];
        
        [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
        xmldata=[[NSMutableData alloc]init];
        [connection start];
    }
    
}

- (IBAction)BackMethod:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


@end
