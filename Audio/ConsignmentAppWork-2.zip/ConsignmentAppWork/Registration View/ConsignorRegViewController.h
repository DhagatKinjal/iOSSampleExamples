//
//  ConsignorRegViewController.h
//  ConsignmentApp
//
//  Created by uday on 22/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BSKeyboardControls.h"
#import "AppDelegate.h"
@interface ConsignorRegViewController : UIViewController<BSKeyboardControlsDelegate,NSXMLParserDelegate,UITextFieldDelegate>
{
    AppDelegate *appDel;
    BOOL keyboardOpened;
    NSMutableData *xmldata;
    NSXMLParser *xml_parser;
    NSString *MYDeviceToken;
}
@property (nonatomic, strong) BSKeyboardControls *keyboardControls1;

@property (strong, nonatomic) IBOutlet UITextField *UserName_TextField;
@property (strong, nonatomic) IBOutlet UITextField *Email_TextField;
@property (strong, nonatomic) IBOutlet UITextField *Pass_TextField;
- (IBAction)SignUp_Method:(id)sender;
- (IBAction)BackMethod:(id)sender;

@end
