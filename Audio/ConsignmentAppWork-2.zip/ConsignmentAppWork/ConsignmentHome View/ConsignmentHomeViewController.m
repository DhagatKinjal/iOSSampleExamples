//
//  ConsignmentHomeViewController.m
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "ConsignmentHomeViewController.h"
#import "ConsignorWishListViewController.h"
#import "CurrentItemViewController.h"
#import "SoldItemListViewController.h"
#import "MonthlyEarningViewController.h"
#import "SocialPageFeedViewController.h"
@interface ConsignmentHomeViewController ()

@end

@implementation ConsignmentHomeViewController
CurrentItemViewController *objCurrentItemViewController;
ConsignorWishListViewController *objConsignorWishListViewController;
SoldItemListViewController *objSoldItemListViewController;
MonthlyEarningViewController *objMonthlyEarningViewController;
SocialPageFeedViewController *objSocialPageFeedViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark MyMethod

- (IBAction)CurrentItem_Method:(id)sender {
    objCurrentItemViewController=[[CurrentItemViewController alloc]initWithNibName:@"CurrentItemViewController" bundle:nil];
    [self.navigationController pushViewController:objCurrentItemViewController animated:YES];
}



- (IBAction)Earning_Method:(id)sender {
    objMonthlyEarningViewController=[[MonthlyEarningViewController alloc]initWithNibName:@"MonthlyEarningViewController" bundle:nil];
    [self.navigationController pushViewController:objMonthlyEarningViewController animated:YES];
}

- (IBAction)WishList_Method:(id)sender {
    objConsignorWishListViewController=[[ConsignorWishListViewController alloc]initWithNibName:@"ConsignorWishListViewController" bundle:nil];
    [self.navigationController pushViewController:objConsignorWishListViewController animated:YES];
}

- (IBAction)NewsFeedTab_method:(id)sender {
    objSocialPageFeedViewController=[[SocialPageFeedViewController alloc]initWithNibName:@"SocialPageFeedViewController" bundle:nil];
    [self.navigationController pushViewController:objSocialPageFeedViewController animated:YES];

}
@end
