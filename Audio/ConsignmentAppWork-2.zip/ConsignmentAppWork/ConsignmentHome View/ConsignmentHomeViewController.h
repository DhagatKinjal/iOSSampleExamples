//
//  ConsignmentHomeViewController.h
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConsignmentHomeViewController : UIViewController
- (IBAction)CurrentItem_Method:(id)sender;

- (IBAction)Earning_Method:(id)sender;
- (IBAction)WishList_Method:(id)sender;
- (IBAction)NewsFeedTab_method:(id)sender;

@end
