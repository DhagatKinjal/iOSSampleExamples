//
//  SocialPageFeedViewController.h
//  ConsignmentApp
//
//  Created by uday on 01/08/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>

@interface SocialPageFeedViewController : UIViewController<FBLoginViewDelegate,UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate>
@property (strong, nonatomic) IBOutlet UIView *SubView;
@property (strong, nonatomic) IBOutlet UIButton *CloseBtn;
- (IBAction)CloseWebMethod:(id)sender;

- (IBAction)BackMethod:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *NewsFeedTB;
@property (strong, nonatomic) IBOutlet UIWebView *WebView;

- (IBAction)MyListTAB:(id)sender;
- (IBAction)WishlistTAB:(id)sender;
- (IBAction)EarningTAB:(id)sender;
- (IBAction)MoreTAB:(id)sender;

@property (strong, nonatomic) IBOutlet FBLoginView *FBLoginView;
@property (strong, nonatomic) NSArray *data1;
@end
