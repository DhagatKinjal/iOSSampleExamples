//
//  SocialPageFeedViewController.m
//  ConsignmentApp
//
//  Created by uday on 01/08/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "SocialPageFeedViewController.h"
#import "MonthlyEarningViewController.h"
#import "CurrentItemViewController.h"
#import "ConsignorWishListViewController.h"
#import "PageFeedCustomCell.h"
@interface SocialPageFeedViewController ()

@end

@implementation SocialPageFeedViewController
@synthesize data1;
MonthlyEarningViewController *objMonthlyEarningViewController;
CurrentItemViewController *objCurrentItemViewController;
ConsignorWishListViewController *objConsignorWishListViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void) NewsFeed:(NSArray *)News
{
    data1=[[NSMutableArray alloc]init];
    data1=News;
    [_NewsFeedTB reloadData];
    // Set up the view controller that will show friend information
//    PageNewsFeedViewController *viewController =
//    [[PageNewsFeedViewController alloc] initWithNibName:@"PageNewsFeedViewController" bundle:nil];//WithStyle:UITableViewStylePlain];
//    viewController.data = News;
//    // Present view controller modally.
//    [self.navigationController pushViewController:viewController animated:YES];//:viewController animated:YES completion:nil];
}
- (void)viewDidLoad
{
     self.FBLoginView.readPermissions = @[@"basic_info"];
    self.FBLoginView.delegate=self;


    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setFBLoginView:nil];
 
    [self setNewsFeedTB:nil];
    [self setWebView:nil];
    [self setCloseBtn:nil];
    [self setSubView:nil];
    [super viewDidUnload];
}




- (void)loginViewShowingLoggedInUser:(FBLoginView *)loginView {
    // Query to fetch the active user's friends, limit to 25.
    NSTimer *myTimer = [NSTimer scheduledTimerWithTimeInterval:10.0 target: self selector: @selector(RefreshAgian) userInfo: nil repeats: YES];

    NSString *query =
    @"SELECT post_id,message,permalink FROM stream WHERE source_id IN ( SELECT page_id FROM page WHERE page_id='182039828560755') LIMIT 50";
    // Set up the query parameter
    NSDictionary *queryParam = @{ @"q": query };
    // Make the API request that uses FQL
    [FBRequestConnection startWithGraphPath:@"/fql"
                                 parameters:queryParam
                                 HTTPMethod:@"GET"
                          completionHandler:^(FBRequestConnection *connection,
                                              id result,
                                              NSError *error) {
                              if (error) {
                                  NSLog(@"Error: %@", [error localizedDescription]);
                              } else {
                                  NSLog(@"Result: %@", result);
                                  // Get the friend data to display
                                  NSArray *NewsFeed = (NSArray *) result[@"data"];
                                  // Show the friend details display
                                  [self NewsFeed:NewsFeed];
                              }
                          }];

}

/*
 * Handle the logged out scenario
 */
- (void)loginViewShowingLoggedOutUser:(FBLoginView *)loginView {

}


-(void) RefreshAgian
{
    NSString *query =
    @"SELECT post_id,message,permalink FROM stream WHERE source_id IN ( SELECT page_id FROM page WHERE page_id='182039828560755') LIMIT 50";
    // Set up the query parameter
    NSDictionary *queryParam = @{ @"q": query };
    // Make the API request that uses FQL
    [FBRequestConnection startWithGraphPath:@"/fql"
                                 parameters:queryParam
                                 HTTPMethod:@"GET"
                          completionHandler:^(FBRequestConnection *connection,
                                              id result,
                                              NSError *error) {
                              if (error) {
                                  NSLog(@"Error: %@", [error localizedDescription]);
                              } else {
                                  NSLog(@"Result: %@", result);
                                  // Get the friend data to display
                                  NSArray *NewsFeed = (NSArray *) result[@"data"];
                                  // Show the friend details display
                                  [self NewsFeed:NewsFeed];
                              }
                          }];
 
}
- (IBAction)BackMethod:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];

}

//- (IBAction)FetchingFeedMethod:(id)sender {
//    // Query to fetch the active user's friends, limit to 25.
//    NSString *query =
//    @"SELECT post_id,message,permalink FROM stream WHERE source_id IN ( SELECT page_id FROM page WHERE page_id='182039828560755') LIMIT 50";
//    // Set up the query parameter
//    NSDictionary *queryParam = @{ @"q": query };
//    // Make the API request that uses FQL
//    [FBRequestConnection startWithGraphPath:@"/fql"
//                                 parameters:queryParam
//                                 HTTPMethod:@"GET"
//                          completionHandler:^(FBRequestConnection *connection,
//                                              id result,
//                                              NSError *error) {
//                              if (error) {
//                                  NSLog(@"Error: %@", [error localizedDescription]);
//                              } else {
//                                  NSLog(@"Result: %@", result);
//                                  // Get the friend data to display
//                                  NSArray *NewsFeed = (NSArray *) result[@"data"];
//                                  // Show the friend details display
//                                 [self NewsFeed:NewsFeed];
//                              }
//                          }];
//
//}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.data1 count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PageFeedCustomCell *cell = (PageFeedCustomCell *)[_NewsFeedTB dequeueReusableCellWithIdentifier:@"PageFeedCustomCell"];
    
    
    if(cell==nil)
    {
        
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PageFeedCustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        
    }
    cell.FeedLbl.text = self.data1[indexPath.row][@"message"];
    //UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.data[indexPath.row][@"pic_square"]]]];
    //cell.imageView.image = image;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //PageFeedCustomCell *cell = (PageFeedCustomCell *)[_NewsFeedTB cellForRowAtIndexPath:indexPath] ;//]:cellIdentifier];
    
    
    if ( ( [data1 count] > 0 ) && ( [indexPath length] > 0 ) )
    {
        
        //_SubView = [[UIView alloc] initWithFrame:CGRectMake(7,15, 306, 445)];
        //_CloseBtn=[[UIButton alloc]initWithFrame:CGRectMake(0 , 0, 28, 25)];
        _SubView.frame=CGRectMake(7,8, 306, 464);

       
        NSString *urlstr=[NSString stringWithFormat:@"%@",[[data1 objectAtIndex:indexPath.row]objectForKey:@"permalink"]];
        NSLog(@"%@",urlstr);
        NSURL *URL = [NSURL URLWithString:urlstr];
        NSURLRequest *requestObj = [NSURLRequest requestWithURL:URL];
        _WebView.delegate = self ;
        
        [_WebView loadRequest:requestObj];
        
        
        
        [self.view addSubview:_SubView];
        
        [self performSelector:@selector(anim) withObject:self afterDelay:0.10];
       
               
        
    }
}
#pragma  mark MyMethod

-(void)anim
{
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlDown
                           forView:_SubView
                             cache:NO];
    
    
    [UIView commitAnimations];
    
}
- (IBAction)CloseWebMethod:(id)sender {
    [self.SubView removeFromSuperview];
     
}
- (IBAction)MyListTAB:(id)sender {
    objCurrentItemViewController=[[CurrentItemViewController alloc]initWithNibName:@"CurrentItemViewController" bundle:nil];
    [self.navigationController pushViewController:objCurrentItemViewController animated:YES];
}

- (IBAction)WishlistTAB:(id)sender {
    objConsignorWishListViewController=[[ConsignorWishListViewController alloc]initWithNibName:@"ConsignorWishListViewController" bundle:nil];
    [self.navigationController pushViewController:objConsignorWishListViewController animated:YES];

}

- (IBAction)EarningTAB:(id)sender {
    objMonthlyEarningViewController=[[MonthlyEarningViewController alloc]initWithNibName:@"MonthlyEarningViewController" bundle:nil];
    [self.navigationController pushViewController:objMonthlyEarningViewController animated:YES];
   }

- (IBAction)MoreTAB:(id)sender {
}
@end
