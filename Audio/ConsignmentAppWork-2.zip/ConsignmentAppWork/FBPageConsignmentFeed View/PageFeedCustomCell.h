//
//  PageFeedCustomCell.h
//  ConsignmentApp
//
//  Created by uday on 01/08/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageFeedCustomCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *FeedLbl;

@end
