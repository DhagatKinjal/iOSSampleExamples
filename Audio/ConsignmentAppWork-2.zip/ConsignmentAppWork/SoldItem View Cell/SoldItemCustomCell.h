//
//  SoldItemCustomCell.h
//  ConsignmentApp
//
//  Created by Credencys on 24/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SoldItemCustomCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *PriceLbl;
@property (strong, nonatomic) IBOutlet UILabel *ItemLbl;
@property (strong, nonatomic) IBOutlet UILabel *QtyLbl;

@end
