//
//  SoldItemListViewController.h
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface SoldItemListViewController : UIViewController<NSXMLParserDelegate>
{
     AppDelegate *appDel;
    NSMutableData *xmldata;
    NSXMLParser *xml_parser;
    NSMutableArray *SoldPriceArr,*SoldItemArr,*SoldQtyArr,*SoldIndexArr;
    int soldtotalRecords,soldNextStart,soldcheckHowManyPress,soldcount;
}
@property (strong, nonatomic) IBOutlet UITableView *SoldItemTB;
- (IBAction)NextRecords:(id)sender;
- (IBAction)PreviousRecords:(id)sender;
- (IBAction)BackMethod:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *NextIBoutlet;
@property (strong, nonatomic) IBOutlet UIButton *PreviousIBoutlet;



@end
