//
//  ViewController.h
//  ConsignmentApp
//
//  Created by uday on 19/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConsignorLoginViewController.h"
#import "ConsignorRegViewController.h"
@interface ViewController : UIViewController
{
   
}
- (IBAction)SignIn_Method:(id)sender;
- (IBAction)SignUp_Method:(id)sender;
@end
