//
//  AppDelegate.h
//  ConsignmentApp
//
//  Created by uday on 19/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate>
{
    UINavigationController *nav;
}
@property (strong, nonatomic) UINavigationController *nav;

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (strong, nonatomic) NSString *ConsignorIDStr;
@property (strong, nonatomic) NSString *EmailIDstr;
@property (strong, nonatomic) NSString *PassStr;





@property (nonatomic, retain) NSString *deviceToken;
@property(nonatomic,retain)NSMutableString *NotificationMessage,*timeNotification;
@end
