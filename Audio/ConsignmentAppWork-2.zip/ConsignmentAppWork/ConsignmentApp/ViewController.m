//
//  ViewController.m
//  ConsignmentApp
//
//  Created by uday on 19/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
ConsignorLoginViewController *objConsignorLoginViewController;
ConsignorRegViewController *objConsignorRegViewController;

- (void)viewDidLoad
{
    [self.navigationController.navigationBar setHidden:YES];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
-(void) viewWillAppear:(BOOL)animated
{
    //[self.navigationController.navigationBar setHidden:YES];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark MyMthods

- (IBAction)SignIn_Method:(id)sender {
    objConsignorLoginViewController=[[ConsignorLoginViewController alloc]initWithNibName:@"ConsignorLoginViewController" bundle:nil];
    [self.navigationController pushViewController:objConsignorLoginViewController animated:YES];
}

- (IBAction)SignUp_Method:(id)sender {
    objConsignorRegViewController=[[ConsignorRegViewController alloc]initWithNibName:@"ConsignorRegViewController" bundle:nil];
    [self.navigationController pushViewController:objConsignorRegViewController animated:YES];
}
@end
