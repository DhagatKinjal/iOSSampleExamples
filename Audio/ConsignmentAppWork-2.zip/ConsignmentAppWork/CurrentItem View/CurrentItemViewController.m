//
//  CurrentItemViewController.m
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "CurrentItemViewController.h"
#import "CurrentItemCustomCell.h"
#import "SoldItemCustomCell.h"
#import "ConsignorWishListViewController.h"
#import "SocialPageFeedViewController.h"
#import "MonthlyEarningViewController.h"

@interface CurrentItemViewController ()

@end

@implementation CurrentItemViewController
MonthlyEarningViewController *objMonthlyEarningViewController;
SocialPageFeedViewController *objSocialPageFeedViewController;
ConsignorWishListViewController *objConsignorWishListViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        appDel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [self.CurrentItemIBoutlet setBackgroundImage:[UIImage imageNamed:@"current selected 640-1136.png"] forState:UIControlStateNormal];
    [self.CurrentItemTB setFrame:CGRectMake(0, 147, 320, 295)];
    [self.view addSubview:self.CurrentItemTB];
    [_PreviousBtnIBoutlet setEnabled:NO];
    checkHowManyPress=1;
    NextStart=0;
    count=1;
    IndexArr=[[NSMutableArray alloc]init];
    
    CurrentItemArr=[[NSMutableArray alloc]init];
    CurrentPriceArr=[[NSMutableArray alloc]init];
    CurrentQtyArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getinventory"];
    NSString *post =[NSString stringWithFormat:@"table=inventory,consignor&fields=CPRICE,DESCRIPTIO,QUANTITY&beforeWhere=&afterWhere=inventory.CONSIGNORI = consignor.ID AND consignor.ID = '%@'&r_p_p=10&start=%d&user=%@&pass=%@",appDel.ConsignorIDStr,NextStart,appDel.EmailIDstr,appDel.PassStr];
    NSLog(@"%@",post);
   
    /*
     table =  “inventory,consignor”
     fields = “CPRICE,ITEMNUM,QUANTITY”
     beforeWhere = “”
     afterWhere = “inventory.CONSIGNORI = consignor.ID AND consignor.ID = '-1'”
     r_p_p = 10
     start  = 0
     user = ak29@gmail.com
     pass = 12345
     */
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
 
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark ConnectionMethod

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    if(checkTB==0)
    {
        
    [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
    NSDictionary *jsonData=[NSJSONSerialization JSONObjectWithData:xmldata options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"data: %@",jsonData);
    
    
    
    NSDictionary* dict=[NSDictionary dictionaryWithDictionary:[jsonData objectForKey:@"response"]];
    NSArray* MyArray = [dict objectForKey:@"data"];
    
    totalRecords=[[dict objectForKey:@"totalRecord"]integerValue];
    NextStart=[[dict objectForKey:@"nextStart"]integerValue];
    NSLog(@"%d\n%d",totalRecords,NextStart);
    
    
    if(NextStart>totalRecords)
    {
         [_NextBtnIBoutlet setEnabled:NO];
    }
        else
        {
             [_NextBtnIBoutlet setEnabled:YES];
        }
    
   
    for(int i=0;i<MyArray.count;i++)
    {
//        NSLog(@"Price:: %@",[[MyArray objectAtIndex:i] objectForKey:@"CPRICE"]);
//        NSLog(@"Item:: %@",[[MyArray objectAtIndex:i] objectForKey:@"DESCRIPTIO"]);
//        NSLog(@"Qty:: %@",[[MyArray objectAtIndex:i] objectForKey:@"QUANTITY"]);
        
        [CurrentItemArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"DESCRIPTIO"]];
        [CurrentPriceArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"CPRICE"]];
        [CurrentQtyArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"QUANTITY"]];
    }
    for (int j=0; j<CurrentItemArr.count; j++)
    {
        [IndexArr addObject:[NSString stringWithFormat:@"%d",count]];
      
        count++;
    }

    [_CurrentItemTB reloadData];
    }
    else
{
    [xmldata appendData:data];
    NSString *str=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str);
    
    NSDictionary *jsonData=[NSJSONSerialization JSONObjectWithData:xmldata options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"data: %@",jsonData);
    
    
    
    NSDictionary* dict=[NSDictionary dictionaryWithDictionary:[jsonData objectForKey:@"response"]];
    NSArray* MyArray = [dict objectForKey:@"data"];
    soldtotalRecords=[[dict objectForKey:@"totalRecord"]integerValue];
    soldNextStart=[[dict objectForKey:@"nextStart"]integerValue];
    NSLog(@"%d\n%d",soldtotalRecords,soldNextStart);
    
    
    if(soldNextStart>soldtotalRecords)
    {
      [_NextBtnIBoutlet setEnabled:NO];
    }
    
    
    for(int i=0;i<MyArray.count;i++)
    {
        NSLog(@"Price:: %@",[[MyArray objectAtIndex:i] objectForKey:@"SPRICE"]);
        NSLog(@"Item:: %@",[[MyArray objectAtIndex:i] objectForKey:@"DESCRIPTIO"]);
        
        
        [SoldItemArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"DESCRIPTIO"]];
        [SoldPriceArr addObject:[[MyArray objectAtIndex:i] objectForKey:@"SPRICE"]];
        
    }
    for (int j=0; j<SoldItemArr.count; j++)
    {
        [SoldIndexArr addObject:[NSString stringWithFormat:@"%d",soldcount]];
        NSLog(@"%d",soldcount);
        soldcount++;
    }
    
    
    [self.SoldItemTB reloadData];

}
  }

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    xml_parser=[[NSXMLParser alloc]initWithData:xmldata];
    [xml_parser setDelegate:self];
    [xml_parser parse];
    
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"" message:@"Error on connection" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alt show];
}


- (void)viewDidUnload {
    [self setCurrentItemTB:nil];
    [self setNextBtnIBoutlet:nil];
    [self setPreviousBtnIBoutlet:nil];
    [self setSoldItemTB:nil];
    [self setCurrentItemIBoutlet:nil];
    [self setSoldItemIBoutlet:nil];
    [super viewDidUnload];
}



#pragma mark UITableView methods


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section {
    if(tableView.tag==0)
    {
        return [CurrentPriceArr count];
    }
    else if(tableView.tag==1)
    {
        return [SoldPriceArr count]; 
    }
    else
    {
        return 1;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(tableView.tag==0)
    {
    static  NSString *cellIdentifier=@"CurrentItemCustomCell";

    CurrentItemCustomCell *cell = (CurrentItemCustomCell *)[_CurrentItemTB dequeueReusableCellWithIdentifier:cellIdentifier];


    if(cell==nil)
    {

          NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CurrentItemCustomCell" owner:self options:nil];
          cell = [nib objectAtIndex:0];

    }
    //NSArray *arr=[data2 objectAtIndex:indexPath.section];
        float finalamount=[[CurrentPriceArr objectAtIndex:indexPath.row] floatValue];
        
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalamount]];
        NSLog(@"formattedNumberString: %@", formattedNumberString);
        
        
        NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalamount];
        
    NSLog(@"%@",formattedNumber);
        
    cell.PriceLbl.text = formattedNumber;
    cell.ItemLbl.text = [CurrentItemArr objectAtIndex:indexPath.row];
    cell.QtyLbl.text = [IndexArr objectAtIndex:indexPath.row];//[CurrentQtyArr objectAtIndex:indexPath.row];
  
    //cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    //cell.selectionStyle=UITableViewCellSelectionStyleGray;
    return cell;
    }
    else
    {
        static  NSString *cellIdentifier=@"SoldItemCustomCell";
        
        SoldItemCustomCell *cell = (SoldItemCustomCell *)[_SoldItemTB dequeueReusableCellWithIdentifier:cellIdentifier];
        
        
        if(cell==nil)
        {
            
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"SoldItemCustomCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            
        }
        float finalamount=[[SoldPriceArr objectAtIndex:indexPath.row] floatValue];
        
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setPositiveFormat:@"###0.##"];
        
        NSString *formattedNumberString = [numberFormatter stringFromNumber:[NSNumber numberWithFloat:finalamount]];
        NSLog(@"formattedNumberString: %@", formattedNumberString);
        
        
        NSString* formattedNumber = [NSString stringWithFormat:@"%.02f", finalamount];
        
        NSLog(@"%@",formattedNumber);
        
        //cell.PriceLbl.text = formattedNumber;
        
        cell.PriceLbl.text = formattedNumber;
        cell.ItemLbl.text = [SoldItemArr objectAtIndex:indexPath.row];
        cell.QtyLbl.text=[SoldIndexArr objectAtIndex:indexPath.row];
        NSLog(@"%@",cell.QtyLbl.text);
        return cell;
 
    }

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    //CurrentItemCustomCell *cell = (CurrentItemCustomCell *)[tableView cellForRowAtIndexPath:indexPath];

    if ( ( [CurrentPriceArr count] > 0 ) && ( [indexPath length] > 0 ) )
    {

       

    }

}
#pragma mark MyMethod

- (IBAction)NextRecords:(id)sender {
    NSLog(@"%d",NextStart);
    NSLog(@"%d",totalRecords);
    [_PreviousBtnIBoutlet setEnabled:YES];
    
    IndexArr=[[NSMutableArray alloc]init];

    CurrentItemArr=[[NSMutableArray alloc]init];
    CurrentPriceArr=[[NSMutableArray alloc]init];
    CurrentQtyArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getinventory"];
    NSString *post =[NSString stringWithFormat:@"table=inventory,consignor&fields=CPRICE,DESCRIPTIO,QUANTITY&beforeWhere=&afterWhere=inventory.CONSIGNORI = consignor.ID AND consignor.ID = '%@'&r_p_p=10&start=%d&user=%@&pass=%@",appDel.ConsignorIDStr,NextStart,appDel.EmailIDstr,appDel.PassStr];
    NSLog(@"%@",post);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];
    checkHowManyPress++;
    
         
}

- (IBAction)PreviousMethod:(id)sender {
    
    [_NextBtnIBoutlet setEnabled:YES];

    NextStart=NextStart-20;//(11*checkHowManyPress);
    
    NSLog(@"%d",NextStart);
    NSLog(@"%d",totalRecords);
   
    
    IndexArr=[[NSMutableArray alloc]init];

    CurrentItemArr=[[NSMutableArray alloc]init];
    CurrentPriceArr=[[NSMutableArray alloc]init];
    CurrentQtyArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getinventory"];
    NSString *post =[NSString stringWithFormat:@"table=inventory,consignor&fields=CPRICE,DESCRIPTIO,QUANTITY&beforeWhere=&afterWhere=inventory.CONSIGNORI = consignor.ID AND consignor.ID = '%@'&r_p_p=10&start=%d&user=%@&pass=%@",appDel.ConsignorIDStr,NextStart,appDel.EmailIDstr,appDel.PassStr];
    NSLog(@"%@",post);
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];
    if(NextStart==0)
    {
        count=1;
        [_PreviousBtnIBoutlet setEnabled:NO];
        [_NextBtnIBoutlet setEnabled:YES];
    }
    else{

        count=NextStart+1;
    }
 
}

- (IBAction)BackMethod:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)CurrentItem_method:(id)sender {
    
    [self.CurrentItemIBoutlet setBackgroundImage:[UIImage imageNamed:@"current selected 640-1136.png"] forState:UIControlStateNormal];
    [self.soldItemIBoutlet setBackgroundImage:[UIImage imageNamed:@"sold up 640-1136.png"] forState:UIControlStateNormal];
    [self.SoldItemTB removeFromSuperview];
    [self.CurrentItemTB setFrame:CGRectMake(0, 147, 320, 295)];
    [self.view addSubview:self.CurrentItemTB];

    checkTB=0;
    [_PreviousBtnIBoutlet setEnabled:NO];
    checkHowManyPress=1;
    NextStart=0;
    count=1;
    IndexArr=[[NSMutableArray alloc]init];
    
    CurrentItemArr=[[NSMutableArray alloc]init];
    CurrentPriceArr=[[NSMutableArray alloc]init];
    CurrentQtyArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/getinventory"];
    NSString *post =[NSString stringWithFormat:@"table=inventory,consignor&fields=CPRICE,DESCRIPTIO,QUANTITY&beforeWhere=&afterWhere=inventory.CONSIGNORI = consignor.ID AND consignor.ID = '%@'&r_p_p=10&start=%d&user=%@&pass=%@",appDel.ConsignorIDStr,NextStart,appDel.EmailIDstr,appDel.PassStr];
    NSLog(@"%@",post);
    
    /*
     table =  “inventory,consignor”
     fields = “CPRICE,ITEMNUM,QUANTITY”
     beforeWhere = “”
     afterWhere = “inventory.CONSIGNORI = consignor.ID AND consignor.ID = '-1'”
     r_p_p = 10
     start  = 0
     user = ak29@gmail.com
     pass = 12345
     */
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];

}

- (IBAction)SoldItem_Method:(id)sender {
    checkTB=1;
    [self.soldItemIBoutlet setBackgroundImage:[UIImage imageNamed:@"sold press 640-1136.png"] forState:UIControlStateNormal];
    [self.CurrentItemIBoutlet setBackgroundImage:[UIImage imageNamed:@"current up 640-1136.png"] forState:UIControlStateNormal];
    [self.CurrentItemTB removeFromSuperview];
    [_PreviousBtnIBoutlet setEnabled:NO];
    soldNextStart= 0;
    soldcount=1;
    SoldIndexArr=[[NSMutableArray alloc]init];
    SoldItemArr=[[NSMutableArray alloc]init];
    SoldPriceArr=[[NSMutableArray alloc]init];
    SoldQtyArr=[[NSMutableArray alloc]init];
    NSURL *url = [NSURL URLWithString:@"http://dev.credencys.com/consignment/index.php/webservice/totalsolditems"];
    NSString *post =[NSString stringWithFormat:@"table=invoice, invoiceitems, inventory, consignor&fields=inventory.DESCRIPTIO, invoiceitems.SPRICE&beforeWhere=&afterWhere=invoice.ID = invoiceitems.INVENTORYI AND invoiceitems.INVENTORYI = inventory.ID AND inventory.CONSIGNORI = consignor.ID AND consignor.ID = '%@'  ORDER BY invoice.DATE DESC&r_p_p=10&start=%d&user=%@&pass=%@",appDel.ConsignorIDStr,soldNextStart,appDel.EmailIDstr,appDel.PassStr];
    NSLog(@"%@",post);
    
    /*table =  “invoice, invoiceitems, inventory, consignor”
     fields = “inventory.DESCRIPTIO, invoiceitems.SPRICE”
     beforeWhere = “”
     afterWhere =  “invoice.ID = invoiceitems.INVENTORYI AND invoiceitems.INVENTORYI = inventory.ID AND inventory.CONSIGNORI = consignor.ID AND consignor.ID = '{loginuserconsignorid}'  ORDER BY invoice.DATE DESC”
     r_p_p = 10
     start  = 0
     user = {login username}
     pass = {login user pass}*/
    
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    xmldata=[[NSMutableData alloc]init];
    [connection start];
    [self.SoldItemTB setFrame:CGRectMake(0, 147, 320, 295)];
    [self.view addSubview:self.SoldItemTB];
    

}
- (IBAction)MoreTAB:(id)sender {
}

- (IBAction)NewsTAB:(id)sender {
       objSocialPageFeedViewController=[[SocialPageFeedViewController alloc]initWithNibName:@"SocialPageFeedViewController" bundle:nil];
    [self.navigationController pushViewController:objSocialPageFeedViewController animated:YES];
}

- (IBAction)EarningTAB:(id)sender {
    objMonthlyEarningViewController=[[MonthlyEarningViewController alloc]initWithNibName:@"MonthlyEarningViewController" bundle:nil];
    [self.navigationController pushViewController:objMonthlyEarningViewController animated:YES];
   

}

- (IBAction)WishListTAB:(id)sender {
    objConsignorWishListViewController=[[ConsignorWishListViewController alloc]initWithNibName:@"ConsignorWishListViewController" bundle:nil];
    [self.navigationController pushViewController:objConsignorWishListViewController animated:YES];
}
@end
