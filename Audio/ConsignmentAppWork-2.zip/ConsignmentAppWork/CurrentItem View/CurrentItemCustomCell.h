//
//  CurrentItemCustomCell.h
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurrentItemCustomCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *PriceLbl;
@property (strong, nonatomic) IBOutlet UILabel *ItemLbl;
@property (strong, nonatomic) IBOutlet UILabel *QtyLbl;

@end
