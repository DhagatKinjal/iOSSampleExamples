//
//  CurrentItemCustomCell.m
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "CurrentItemCustomCell.h"

@implementation CurrentItemCustomCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
