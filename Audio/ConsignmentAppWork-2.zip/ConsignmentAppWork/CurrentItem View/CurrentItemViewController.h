//
//  CurrentItemViewController.h
//  ConsignmentApp
//
//  Created by uday on 23/07/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface CurrentItemViewController : UIViewController<NSXMLParserDelegate,FBLoginViewDelegate>
{
    AppDelegate *appDel;
    NSMutableData *xmldata;
    NSXMLParser *xml_parser;
    NSMutableArray *CurrentPriceArr,*CurrentItemArr,*CurrentQtyArr,*IndexArr;
    int totalRecords,NextStart,checkHowManyPress,count;
    
    
    NSMutableArray *SoldPriceArr,*SoldItemArr,*SoldQtyArr,*SoldIndexArr;
    int soldtotalRecords,soldNextStart,soldcheckHowManyPress,soldcount;
    
    
    int checkTB;
}
- (IBAction)MoreTAB:(id)sender;
- (IBAction)NewsTAB:(id)sender;
- (IBAction)EarningTAB:(id)sender;
- (IBAction)WishListTAB:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *soldItemIBoutlet;
@property (strong, nonatomic) IBOutlet UIButton *CurrentItemIBoutlet;
@property (strong, nonatomic) IBOutlet UIButton *PreviousBtnIBoutlet;
@property (strong, nonatomic) IBOutlet UIButton *NextBtnIBoutlet;
@property (strong, nonatomic) IBOutlet UITableView *CurrentItemTB;
@property (strong, nonatomic) IBOutlet UITableView *SoldItemTB;
- (IBAction)NextRecords:(id)sender;
- (IBAction)PreviousMethod:(id)sender;
- (IBAction)BackMethod:(id)sender;
- (IBAction)CurrentItem_method:(id)sender;
- (IBAction)SoldItem_Method:(id)sender;


@end
