//
//  usworldproAppDelegate.h
//  usworldpro
//
//  Created by 石  on 12-7-24.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class usworldproViewController;

@interface usworldproAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    usworldproViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet usworldproViewController *viewController;

@end

