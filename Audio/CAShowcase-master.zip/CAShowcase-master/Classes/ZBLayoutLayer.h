#import <QuartzCore/QuartzCore.h>

@interface ZBLayoutLayer : CALayer
{
	UIColor *color;
}

@property (retain, nonatomic) UIColor *color;

@end
