//
//  ViewController.h
//  CustomMKAnnotationView
//
//  Created by Jian-Ye on 12-11-22.
//  Copyright (c) 2012年 Jian-Ye. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapViewController.h"
@interface ViewController : UIViewController
<MapViewControllerDidSelectDelegate>
@end
