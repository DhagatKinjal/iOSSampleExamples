#define VOXNAME cmu_us_awb
#define REGISTER_VOX register_cmu_us_awb
#define UNREGISTER_VOX unregister_cmu_us_awb
#define VOXHUMAN "awb"
#define VOXGENDER "unknown"
#define VOXVERSION 1.0
