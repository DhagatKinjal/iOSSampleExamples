#define VOXNAME cmu_us_kal16
#define REGISTER_VOX register_cmu_us_kal16
#define UNREGISTER_VOX unregister_cmu_us_kal16
#define VOXHUMAN "Kevin"
#define VOXGENDER "male"
#define VOXVERSION 1.1
