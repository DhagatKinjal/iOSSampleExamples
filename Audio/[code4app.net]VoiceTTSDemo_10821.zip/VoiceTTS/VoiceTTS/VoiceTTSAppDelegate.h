//
//  VoiceTTSAppDelegate.h
//  VoiceTTS
//
//  Created by 朱克锋 on 12-11-15.
//  Copyright (c) 2012年 朱克锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@class VoiceTTSViewController;

@interface VoiceTTSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) VoiceTTSViewController *viewController;

@end
