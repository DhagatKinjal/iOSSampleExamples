//
//  BBAppDelegate.m
//  BeatBuilder
//
//  Created by Parker Wightman on 7/21/12.
//  Copyright (c) 2012 Parker Wightman. All rights reserved.
//

#import "BBAppDelegate.h"
#import "BBVoice.h"
#import "OALSimpleAudio.h"

@implementation BBAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
        return YES;
}


							
- (void)applicationWillResignActive:(UIApplication *)application    { }
- (void)applicationDidEnterBackground:(UIApplication *)application  { }
- (void)applicationWillEnterForeground:(UIApplication *)application { }
- (void)applicationDidBecomeActive:(UIApplication *)application     { }
- (void)applicationWillTerminate:(UIApplication *)application       { }

@end
