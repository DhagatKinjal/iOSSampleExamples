//
//  main.m
//  BBGroover
//
//  Created by Parker Wightman on 7/26/12.
//  Copyright (c) 2012 Parker Wightman. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BBAppDelegate class]));
    }
}
