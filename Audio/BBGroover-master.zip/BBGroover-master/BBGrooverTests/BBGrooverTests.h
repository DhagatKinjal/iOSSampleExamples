//
//  BBGrooverTests.h
//  BBGrooverTests
//
//  Created by Parker Wightman on 7/26/12.
//  Copyright (c) 2012 Parker Wightman. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface BBGrooverTests : SenTestCase

@end
