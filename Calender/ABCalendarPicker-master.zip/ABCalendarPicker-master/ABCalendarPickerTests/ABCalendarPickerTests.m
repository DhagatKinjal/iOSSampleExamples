//
//  ABCalendarPickerTests.m
//  ABCalendarPickerTests
//
//  Created by Anton Bukov on 09.07.12.
//  Copyright (c) 2013 Anton Bukov. All rights reserved.
//

#import "ABCalendarPickerTests.h"

@implementation ABCalendarPickerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ABCalendarPickerTests");
}

@end
