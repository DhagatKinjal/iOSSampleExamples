//
//  OCTypes.h
//  OCCalendar
//
//  Created by Dermot Daly on 17/05/2012.
//  Copyright (c) 2012 UC Berkeley. All rights reserved.
//

typedef enum {
    OCSelectionSingleDate = 0,
    OCSelectionDateRange
} OCSelectionMode;
