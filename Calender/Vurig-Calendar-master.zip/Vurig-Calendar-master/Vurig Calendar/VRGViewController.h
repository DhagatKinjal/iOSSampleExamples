//
//  VRGViewController.h
//  Vurig Calendar
//
//  Created by in 't Veen Tjeerd on 5/29/12.
//  Copyright (c) 2012 Vurig. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VRGCalendarView.h"

@interface VRGViewController : UIViewController <VRGCalendarViewDelegate>

@end
