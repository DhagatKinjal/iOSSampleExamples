//
//  TimesSquareTestAppTests.m
//  TimesSquareTestAppTests
//
//  Created by Jim Puls on 1/2/13.
//
//

#import "TimesSquareTestAppTests.h"

@implementation TimesSquareTestAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in TimesSquareTestAppTests");
}

@end
