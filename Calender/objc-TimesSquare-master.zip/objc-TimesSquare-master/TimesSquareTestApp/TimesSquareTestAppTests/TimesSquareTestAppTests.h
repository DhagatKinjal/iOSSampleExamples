//
//  TimesSquareTestAppTests.h
//  TimesSquareTestAppTests
//
//  Created by Jim Puls on 1/2/13.
//
//

#import <SenTestingKit/SenTestingKit.h>

@interface TimesSquareTestAppTests : SenTestCase

@end
