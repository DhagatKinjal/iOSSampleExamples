//
//  AppDelegate.h
//  AwesomeMenu
//
//  Created by Levey on 11/30/11.
//  Copyright (c) 2011 Levey & Other Contributors. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AwesomeMenu.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate, AwesomeMenuDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
