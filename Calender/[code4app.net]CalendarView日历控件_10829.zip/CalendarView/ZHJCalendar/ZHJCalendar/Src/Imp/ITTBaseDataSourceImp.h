//
//  ITTBaseDataSourceImp.h
//  ZHJCalendar
//
//  Created by huajian zhou on 12-4-12.
//  Copyright (c) 2012年 itotemstudio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ITTCalendarView.h"

@interface ITTBaseDataSourceImp : NSObject<ITTCalendarViewDataSource>

@end
