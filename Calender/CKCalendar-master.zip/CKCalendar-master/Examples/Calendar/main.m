#import <UIKit/UIKit.h>

#import "CKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CKAppDelegate class]));
    }

}