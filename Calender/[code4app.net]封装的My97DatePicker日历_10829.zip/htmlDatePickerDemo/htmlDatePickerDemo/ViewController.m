//
//  ViewController.m
//  htmlDatePickerDemo
//
//  Created by wu xiaoming on 13-1-23.
//  Copyright (c) 2013年 wu xiaoming. All rights reserved.
//

#import "ViewController.h"
#import "My97DatePicker.h"
@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad
{
    CGRect frame = CGRectMake(131, 155, 122, 29);
    My97DatePicker* piker = [[My97DatePicker alloc] initWithFrame:frame];
    [self.view addSubview:piker];
    [piker release];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)dealloc {
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIDeviceOrientationIsPortrait(interfaceOrientation);
}
#ifdef __IPHONE_6_0
-(BOOL)shouldAutorotate
{
    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    return UIDeviceOrientationIsPortrait(orientation);
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait|UIInterfaceOrientationMaskPortraitUpsideDown;
}
#endif

@end
