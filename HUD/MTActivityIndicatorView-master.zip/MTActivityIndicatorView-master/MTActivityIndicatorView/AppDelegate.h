//
//  AppDelegate.h
//  MTActivityIndicatorView
//
//  Created by jesse on 12-7-19.
//  Copyright (c) 2012年 Jesse Xu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
