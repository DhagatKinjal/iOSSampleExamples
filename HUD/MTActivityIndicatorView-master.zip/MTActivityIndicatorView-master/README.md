Overview
========
This is a metro style activity indicator view.

![Demo Image](http://pic.yupoo.com/jesse0628/C7RlsMfu/medish.jpg)


Usage
-----
Add QuartzCore.framework to your project.

public method:

	- (void)startAnimating;	
	- (void)stopAnimating;
	- (void)stopAnimatingNeedDelay:(NSTimeInterval)time;	
LICENSE
-----
Under the BSD License.