//
//  main.m
//  DejalActivityView
//
//  Created by David Sinclair on 2009-07-29.
//  Copyright Dejal Systems, LLC 2009-2013. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}

