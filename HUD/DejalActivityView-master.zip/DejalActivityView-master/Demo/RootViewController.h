//
//  RootViewController.h
//  DejalActivityView Demo
//
//  Created by David Sinclair on 2009-07-29.
//  Copyright Dejal Systems, LLC 2009-2013. All rights reserved.
//

@interface RootViewController : UITableViewController

@end

