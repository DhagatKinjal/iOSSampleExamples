//
//  SKBounceAnimationTests.h
//  SKBounceAnimationTests
//
//  Created by Soroush Khanlou on 6/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SKBounceAnimationTests : SenTestCase

@end
