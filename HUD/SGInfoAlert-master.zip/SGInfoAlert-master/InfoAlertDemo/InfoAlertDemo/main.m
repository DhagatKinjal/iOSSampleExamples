//
//  main.m
//  InfoAlertDemo
//
//  Created by veryeast on 12-9-7.
//  Copyright (c) 2012年 sagiwei. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
