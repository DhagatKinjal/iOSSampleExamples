//
//  TestViewController.h
//  InfoAlertDemo
//
//  Created by veryeast on 12-9-7.
//  Copyright (c) 2012年 sagiwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>

@end
