//
//  main.m
//  BDKNotifyHUD
//
//  Created by Benjamin Kreeger on 11/2/12.
//  Copyright (c) 2012 Benjamin Kreeger. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BDKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BDKAppDelegate class]));
    }
}
