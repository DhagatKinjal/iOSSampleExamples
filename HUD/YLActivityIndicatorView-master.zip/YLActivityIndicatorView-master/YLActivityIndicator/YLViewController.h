//
//  YLViewController.h
//  YLActivityIndicator
//
//  Created by Eric Yuan on 13-1-15.
//  Copyright (c) 2013年 jimu.tv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YLViewController : UIViewController

@end
