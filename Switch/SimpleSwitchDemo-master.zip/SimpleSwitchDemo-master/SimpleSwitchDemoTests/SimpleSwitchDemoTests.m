//
//  SimpleSwitchDemoTests.m
//  SimpleSwitchDemoTests
//
//  Created by xiao haibo on 8/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SimpleSwitchDemoTests.h"

@implementation SimpleSwitchDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SimpleSwitchDemoTests");
}

@end
