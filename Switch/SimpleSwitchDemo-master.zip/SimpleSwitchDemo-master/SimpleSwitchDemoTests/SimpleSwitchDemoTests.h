//
//  SimpleSwitchDemoTests.h
//  SimpleSwitchDemoTests
//
//  Created by xiao haibo on 8/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SimpleSwitchDemoTests : SenTestCase

@end
