//
//  TestSwitchKnobLayer.h
//  DCRoundSwitchDemo
//
//  Created by Pete Callaway on 30/05/2012.
//

#import "DCRoundSwitchKnobLayer.h"

@interface TestSwitchKnobLayer : DCRoundSwitchKnobLayer

@end
