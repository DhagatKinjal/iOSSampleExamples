//
//  TestSwitch.m
//  DCRoundSwitchDemo
//
//  Created by Pete Callaway on 30/05/2012.
//

#import "TestSwitch.h"
#import "TestSwitchKnobLayer.h"


@implementation TestSwitch

+ (Class)knobLayerClass {
    return [TestSwitchKnobLayer class];
}

@end
