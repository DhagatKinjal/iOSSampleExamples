//
//  TTXibViewController.h
//  TTSwitch
//
//  Created by Scott Penrose on 1/10/13.
//  Copyright (c) 2013 Two Toasters. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTXibViewController : UIViewController

@end
