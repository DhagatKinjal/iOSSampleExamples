//
//  TTXibViewController.m
//  TTSwitch
//
//  Created by Scott Penrose on 1/10/13.
//  Copyright (c) 2013 Two Toasters. All rights reserved.
//

#import "TTXibViewController.h"

#import "TTSwitch.h"

@interface TTXibViewController ()

@property (weak, nonatomic) IBOutlet TTSwitch *defaultSwitch;

@end

@implementation TTXibViewController

@end
