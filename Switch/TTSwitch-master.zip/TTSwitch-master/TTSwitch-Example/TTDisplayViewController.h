//
//  TTDisplayViewController.h
//  TTSwitch
//
//  Created by Scott Penrose on 12/3/12.
//  Copyright (c) 2012 Two Toasters. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTDisplayViewController : UIViewController

@end
