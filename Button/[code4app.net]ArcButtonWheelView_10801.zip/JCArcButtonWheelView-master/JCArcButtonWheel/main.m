//
//  main.m
//  ButtonWheel1
//
//  Created by jjf on 11/2/12.
//  Copyright (c) 2012 johnscode.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
