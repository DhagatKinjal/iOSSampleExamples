//
//  NavBarBackgroundGradientView.h
//  CG Test
//
//  Created by jeff on 5/18/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NavBarBackgroundGradientView : UIView 
{

}

@end
