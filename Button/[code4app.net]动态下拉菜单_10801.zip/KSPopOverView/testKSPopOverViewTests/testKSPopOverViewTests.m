//
//  testKSPopOverViewTests.m
//  testKSPopOverViewTests
//
//  Created by  on 12-5-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "testKSPopOverViewTests.h"

@implementation testKSPopOverViewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in testKSPopOverViewTests");
}

@end
