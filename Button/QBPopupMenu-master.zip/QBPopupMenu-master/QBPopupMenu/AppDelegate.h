//
//  AppDelegate.h
//  QBPopupMenu
//
//  Created by Katsuma Tanaka on 2013/02/01.
//  Copyright (c) 2013年 Katsuma Tanaka. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
