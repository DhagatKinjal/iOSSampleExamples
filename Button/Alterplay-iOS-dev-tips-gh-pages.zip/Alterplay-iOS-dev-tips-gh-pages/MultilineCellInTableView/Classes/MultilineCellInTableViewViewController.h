//
//  MultilineCellInTableViewViewController.h
//  MultilineCellInTableView
//
//  Created by Слава on 02.11.09.
//  Copyright Slava Bushtruk 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultilineCellInTableViewViewController : UITableViewController {

}

@end

