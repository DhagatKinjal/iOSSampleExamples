//
//  RadioButtonViewController.h
//  RadioButton
//
//  Created by ohkawa on 11/03/23.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioButton.h"

@interface RadioButtonViewController : UIViewController<RadioButtonDelegate> {
    
}

@end
