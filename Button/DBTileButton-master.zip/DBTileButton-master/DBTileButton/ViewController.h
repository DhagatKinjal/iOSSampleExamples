//
//  ViewController.h
//  DBTileButton
//
//  Created by Daniel Beard on 19/09/12.
//  Copyright (c) 2012 Daniel Beard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
