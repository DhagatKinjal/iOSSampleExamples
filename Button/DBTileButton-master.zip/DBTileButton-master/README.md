DBTileButton
============

A metro themed UIButton subclass with perspective touch animations for iOS.

http://danielbeard.wordpress.com

http://github.com/daniel-beard

http://github.com/paintstripper

Copyright (C) 2012 Daniel Beard
 
Distributed under [MIT License](http://opensource.org/licenses/mit-license.php)

See a video of it in action - (http://www.youtube.com/watch?v=jk9uoD9curk&feature=youtu.be)

![Image](http://i.imgur.com/4oJ8F.png)
