//
//  main.m
//  ZenPlayerDemo
//
//  Created by 松山 拓矢 on 7/17/12.
//  Copyright (c) 2012 PuKa PuKa. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
