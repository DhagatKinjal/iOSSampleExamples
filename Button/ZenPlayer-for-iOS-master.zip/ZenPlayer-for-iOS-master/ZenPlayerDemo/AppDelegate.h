//
//  AppDelegate.h
//  ZenPlayerDemo
//
//  Created by noradaiko on 7/17/12.
//  Copyright (c) 2012 noradaiko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
