//
//  SSCheckBoxViewViewController.h
//  SSCheckBoxView
//
//  Created by Ahmet Ardal on 12/6/11.
//  Copyright 2011 SpinningSphere Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SSCheckBoxViewViewController: UIViewController
{
    NSMutableArray *checkboxes;
}

@property (nonatomic, retain) NSMutableArray *checkboxes;

@end
