SSCheckBoxView is a check box UI control for iOS apps.

For more info on how to use it in your apps:
http://www.ardalahmet.com/2011/12/07/sscheckboxview-a-check-box-ui-control-for-ios-apps

For any questions and suggestions contact me at:
http://twitter.com/ardalahmet
or
ardalahmet(at)gmail.com

Licensed under the Apache License, Version 2.0 (the "License").
See LICENSE.txt or visit http://www.apache.org/licenses/LICENSE-2.0 for more information.


SSCheckBoxView Screenshot:

![SSCheckBoxView Screenshot](http://farm8.staticflickr.com/7012/6473293001_ab905bc6cc_z.jpg)
