//
//  CXAAppDelegate.h
//  UIMenuItem+CXAImageSupport
//
//  Created by CHEN Xian'an on 1/3/13.
//  Copyright (c) 2013 lazyapps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CXAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
