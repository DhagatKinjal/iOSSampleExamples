#import <UIKit/UIKit.h>

@class QBFlatButton;

@interface ViewController : UIViewController

@end
