//
//  CircleMenuViewController.h
//  KYCircleMenuDemo
//
//  Created by Kjuly on 7/18/12.
//  Copyright (c) 2012 Kjuly. All rights reserved.
//

#import "KYCircleMenu.h"

@interface CircleMenuViewController : KYCircleMenu

@end
