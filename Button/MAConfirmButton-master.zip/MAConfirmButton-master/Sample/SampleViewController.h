//
//  SampleViewController.h
//
//  Created by Mike on 11-04-05.
//  Copyright 2011 Mike Ahmarani. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MAConfirmButton;

@interface SampleViewController : UIViewController <UIAlertViewDelegate> {
	MAConfirmButton *resetButton;
}

@end
