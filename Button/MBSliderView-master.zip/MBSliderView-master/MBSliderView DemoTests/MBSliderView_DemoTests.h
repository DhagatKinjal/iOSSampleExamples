//
//  MBSliderView_DemoTests.h
//  MBSliderView DemoTests
//
//  Created by Mathieu Bolard on 03/02/12.
//  Copyright (c) 2012 Streettours. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MBSliderView_DemoTests : SenTestCase

@end
