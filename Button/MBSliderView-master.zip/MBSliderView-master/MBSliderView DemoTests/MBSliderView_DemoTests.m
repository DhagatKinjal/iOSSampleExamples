//
//  MBSliderView_DemoTests.m
//  MBSliderView DemoTests
//
//  Created by Mathieu Bolard on 03/02/12.
//  Copyright (c) 2012 Streettours. All rights reserved.
//

#import "MBSliderView_DemoTests.h"

@implementation MBSliderView_DemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MBSliderView DemoTests");
}

@end
