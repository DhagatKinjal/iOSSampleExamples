//
//  FAViewController.h
//  FAFancyMenuExample
//
//  Created by Ben Xu on 12-11-21.
//  Copyright (c) 2012年 Fancy App. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FAFancyMenuView.h"
@interface FAViewController : UIViewController<FAFancyMenuViewDelegate>

@end
