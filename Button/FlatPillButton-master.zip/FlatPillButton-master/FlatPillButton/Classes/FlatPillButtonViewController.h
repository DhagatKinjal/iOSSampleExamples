//
//  FlatPillButtonViewController.h
//  FlatPillButton
//
//  Created by Brian Michel on 11/11/12.
//  Copyright (c) 2012 Foureyes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlatPillButtonViewController : UITableViewController

@end
