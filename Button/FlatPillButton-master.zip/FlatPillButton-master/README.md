Flat Pill Button
=====
-----

As I'm sure everyone is well versed in the awesomeness that is Letterpress the app, if you're not, go download it [here](https://itunes.apple.com/us/app/letterpress-word-game/id526619424?mt=8). Basically I fell in love with the super simple flat buttons and wanted to make something that people could use that was a little customizable. It looks pretty close in my opinion, but let me know if you have any problems.

Usage
----

Since this is just a regular button, you only need to set the title color for `UIControlStateNormal` and `UIControlStateDisabled` and everything is taken care of for you by the button class.

Screenshots
-----

![](http://f.cl.ly/items/1o042x36281v203p3736/Screen%20Shot%202012-11-11%20at%208.35.32%20PM.png)

![](http://f.cl.ly/items/3q2r123l2n2y0K2D333f/Screen%20Shot%202012-11-11%20at%208.36.56%20PM.png)

Contact
----
Feel free to contact me if you have any questions or issues, or send me a tweet [@brianmichel](http://www.twitter.com/brianmichel). I've written a blog post regarding how I went about making this button [here](http://brianmichel.tumblr.com/post/35543576256/flatpillbutton-write-up) and would love a critique. Just go ahead and open an issue with the "Critique" label. Thanks!

Also, I can't stress enough, go download [Letterpress](https://itunes.apple.com/us/app/letterpress-word-game/id526619424?mt=8) because it's such an awesome game!