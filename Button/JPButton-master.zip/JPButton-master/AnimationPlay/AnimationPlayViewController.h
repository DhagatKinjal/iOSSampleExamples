//
//  AnimationPlayViewController.h
//  AnimationPlay
//
//  Created by James Pozdena on 5/9/11.
//  Copyright 2011 James Pozdena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JPStupidButton.h"

@interface AnimationPlayViewController : UIViewController {
    IBOutlet JPStupidButton *stickyButton;
}

@end
