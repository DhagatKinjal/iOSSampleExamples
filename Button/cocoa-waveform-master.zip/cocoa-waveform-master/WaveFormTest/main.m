//
//  main.m
//  WaveFormTest
//
//  Created by Gyetván András on 6/28/12.
// This software is free.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
