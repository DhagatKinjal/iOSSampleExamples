//
//  AppDelegate.h
//  WaveFormTestIOS
//
//  Created by Gyetván András on 7/11/12.
// This software is free.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
