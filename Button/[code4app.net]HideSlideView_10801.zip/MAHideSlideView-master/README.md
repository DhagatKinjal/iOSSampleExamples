MAHideSlideView
===============

Sliding view with customizable cover background. Hidden view may be an ImageView or o button. Contains a protocol definition for open and close event management. 