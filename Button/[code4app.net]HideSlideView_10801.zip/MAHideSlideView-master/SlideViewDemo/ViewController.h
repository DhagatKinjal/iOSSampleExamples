//
//  ViewController.h
//  SlideViewControl
//
//  Created by Michele Ambrosi on 20/02/13.
//  Copyright (c) 2013 Intesys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MAHideSlideView.h"

@interface ViewController : UIViewController <MAHideSlideViewDelegate>

@end
