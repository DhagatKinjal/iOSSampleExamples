//
//  ViewController.h
//  ImagePickerDemo
//
//  Created by raozhongxiong on 12-11-20.
//  Copyright (c) 2012年 raozhongxiong. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CustomAlertView;
@interface ViewController : UIViewController
{
    NSMutableArray *imageArray;
    
    IBOutlet UIView *flashView;
    IBOutlet UIView *modeView;
    IBOutlet UIScrollView *scrollView;
    
    BOOL singleMode;    //单张拍摄
    CustomAlertView *alertView;
}

- (IBAction)cancel:(id)sender;
- (IBAction)takePhoto:(id)sender;
- (IBAction)setFlashMode:(UIButton *)flashBtn;
- (IBAction)captureModeChanged:(id)sender;

@end
