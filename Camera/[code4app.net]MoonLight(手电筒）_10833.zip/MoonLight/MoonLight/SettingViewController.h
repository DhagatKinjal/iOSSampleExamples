//
//  SettingViewController.h
//  MoonLight
//
//  Created by chen Jaykie on 12-2-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController

-(IBAction) onBtnClose:(id)sender;
@end
