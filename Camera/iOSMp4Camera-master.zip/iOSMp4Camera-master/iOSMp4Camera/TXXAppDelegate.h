//
//  TXXAppDelegate.h
//  iOSMp4Camera
//
//  Created by Xiaoxuan Tang on 12-12-14.
//  Copyright (c) 2012年 xiaoxuan Tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TXXViewController;

@interface TXXAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TXXViewController *viewController;

@end
