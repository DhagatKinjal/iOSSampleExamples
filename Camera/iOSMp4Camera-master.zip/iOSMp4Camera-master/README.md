iOSMp4Camera
============
A Demo WIth UIIamgePicerView  and AVAssetExportSession

##Attenction This Demo Based iOS 6 SDK...

##This demo shows:
1. Record a Mov Video
2. Convert To Mp4 File With Native API
3. Play The Mp4 File With MPMoviePlayerViewController

##Reference:

http://stackoverflow.com/questions/8474517/mov-to-mp4-video-conversion-iphone-programmatically
