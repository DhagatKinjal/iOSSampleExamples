# PrettyKit 0.2.0

`PrettyKit` is a small set of new widgets and UIKit subclasses that gives you a deeper UIKit customization. You will be able to change their background color, add gradients, shadows, etc.

At the time of writing these docs, there are subclasses for `UITableViewCell`, `UINavigationBar` and `UITabBar`, and several custom cells.

Here are some examples of what you can achieve:

![](https://github.com/vicpenap/PrettyKit/raw/master/Screenshots/grouped_table.png)

![](https://github.com/vicpenap/PrettyKit/raw/master/Screenshots/plain_table.png)

## Documentation

Full documentation can be found here: http://vicpenap.github.com/PrettyKit

## Using it

First:

- Copy all files under the `PrettyKit` folder. 
- `#import "PrettyKit.h"` where you need it.

Then, just change all your references to UI classes to Pretty classes, and you're done.

You'll find further information on how to use the classes in the docs: http://vicpenap.github.com/PrettyKit

## Customization

All Pretty objects' properties have default values, but you can freely change them.

#### Pretty Cell

##### Grouped tables

You can change the cell's appearance as follows:

- cell's shadow (border will be disabled when the shadow is enabled).
- cell's background color or gradient.
- cell's border color (border will be disabled when the shadow is enabled).
- cell's corner radius.
- cell's separator.
- cell's selection gradient.

##### Plain tables

You can change the cell's appearance as follows:

- cell's background color or gradient.
- cell's separator.
- cell's selection gradient.

#### Pretty Navigation Bar

 You can change the navigation bar appearance as follows:
 
 - shadow opacity
 - gradient start color
 - gradient end color
 - top line volor
 - bottom line color
 - corner radius


#### Pretty Tab Bar

 You can change the tab bar appearance as follows:
 
 - gradient start color
 - gradient end color
 - separator line volor

## Performance

Everything is drawn using Core Graphics, so you can expect a nice performance. Particular attention has been paid to non opaque areas, trying to reduce them as much as possible.

![](https://github.com/vicpenap/PrettyKit/raw/master/Screenshots/blended_layers.png)

## Current status

This framework is currently under active development. It is compatible with iOS 4.0 or higher.

## F.A.Q.

**Q. How can I use PrettyNavigationBar?**

A. There are two possibilities:

- Interface Builder

If you're building your interface with Interface Builder, select the navigationBar, go to the Identity inspector and change the class to `PrettyNavigationBar`.

- Programmatically

If you're creating the NavigationController programmatically, create a subclass of `UINavigationController`, override `initWithRootViewController` (or the constructors you want), and add this line:
		
	[self setValue:[[[PrettyNavigationBar alloc] init] autorelease] forKeyPath:@"navigationBar"];

Take into account that this approach is a bit hackish, so it might be a reason for Apple to reject your app. That shouldn't happen, though.

Also take a look at [this stack overflow thread](http://stackoverflow.com/questions/1869331/set-programmatically-a-custom-subclass-of-uinavigationbar-in-uinavigationcontrol), where other approaches are shown.

**Q. I'm stuck with this error: [UINavigationBar setTopLineColor:]: unrecognized selector sent to instance 0x6c5dd50**

A. Make sure the navigation bar is an instance of PrettyNavigationBar. Take a look at the question above.

**Q. Is there a way to use the same PrettyNavigationBar customization in the entire app?**

A. There is, indeed. You can either create a subclass or a category on PrettyNavigationBar, and override the properties you want to change. 

For example, if you want to have a red navigationBar, you can create a `RedNavigationBar` subclass of `PrettyNavigationBar`, and override the properties `topLineColor`, `gradientStartColor`, `gradientEndColor`, `bottomLineColor` and `tintColor`. Then, wherever you want to use the navigation bar, add an `#import "RedNavigationBar.h"` at the top of the code.


## Contribution

Please, please contribute with this project! Fork it, improve it and make me a pull request.

## Changelog

- 2012/08/01: v0.2.0
    - Bug fixing (memory issues, cell drawing, naming colision with new Xcode (DP3))
    - New UITableView category to add a shortcut to drop the top and bottom shadow in plain tables 
    - PrettyNavigationBar can now have rounded corners
    - New widget PrettyToolbar (replacing UIToolbar)
- 2012/04/12: Initial release (v0.1.0)
