//
//  ExampleViewController.h
//  PrettyExample
//
//  Created by Víctor on 29/02/12.
//  Copyright (c) 2012 Victor Pena Placer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleViewController : UITableViewController

@end
