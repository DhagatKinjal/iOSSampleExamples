//
//  RotableTabBarController.h
//  PrettyExample
//
//  Created by Víctor on 10/04/12.
//  Copyright (c) 2012 Victor Pena Placer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RotableTabBarController : UITabBarController

@end
