//
//  ModalViewController.h
//  PrettyExample
//
//  Created by Seth Gholson on 4/25/12.
//  Copyright (c) 2012 NA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController

- (IBAction)onDoneClick:(id)sender;

@end
