//
//  PlainExample.h
//  PrettyExample
//
//  Created by Víctor on 22/03/12.
//  Copyright (c) 2012 Victor Pena Placer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlainExample : UITableViewController

@end
