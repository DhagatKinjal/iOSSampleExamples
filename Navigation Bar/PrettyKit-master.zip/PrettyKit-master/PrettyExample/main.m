//
//  main.m
//  VPPTableViewExample
//
//  Created by Víctor on 28/02/12.
//  Copyright (c) 2012 Victor Pena Placer. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
