NavigationBarWithShadowDemo
===========================

A demo project that demonstrates how to create a UINavigationBar with shadow.

You can find the tutorial on my blog at: http://iappexperience.com/post/23163747135/how-to-draw-shadow-underneath-uinavigationbar.

![picture](http://f.cl.ly/items/2E0I2V0Q2B230e40463d/NavigationBar%20with%20Shadow.png)
