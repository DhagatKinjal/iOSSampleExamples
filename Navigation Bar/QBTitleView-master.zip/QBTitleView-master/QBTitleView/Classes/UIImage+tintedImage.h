//
//  UIImage+tintedImage.h
//  QBTitleView
//
//  Created by Katsuma Tanaka on 2013/01/17.
//  Copyright (c) 2013年 Katsuma Tanaka. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (tintedImage)

- (UIImage *)tintedImageUsingColor:(UIColor *)color;

@end
