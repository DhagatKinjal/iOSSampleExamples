[[SkinnedUI]]
=========

A demo of changging theme/skin.

![Image](http://imglf4.ph.126.net/T74NgNHs0J47dRWavQlE-w==/6598201164121471784.jpg)
![Image](http://imglf6.ph.126.net/92YBa82ILcJQiUKtivHjoQ==/6597232494378860796.jpg)
![Image](http://imglf9.ph.126.net/bxISVxtNaI-0nAfz6xlNzQ==/6597176419285847439.jpg)
![Image](http://imglf4.ph.126.net/NlV0dGxg5lc9BmKo2SNBRQ==/6598195666563332894.jpg)
![Image](http://imglf8.ph.126.net/7lafMlGytaipnbADL1geAg==/6597763558493794428.jpg)
![Image](http://imglf2.ph.126.net/v1oWemwzWjZiWyl3NaSENw==/6598204462656358732.jpg)
