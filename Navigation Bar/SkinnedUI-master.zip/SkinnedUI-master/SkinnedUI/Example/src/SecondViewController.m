//
//  SecondViewController.m
//  SkinnedUI
//
//  Created by QFish on 12/3/12.
//  Copyright (c) 2012 http://QFish.Net All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (id)init
{
    self = [super init];
    if (self) {
        self.title = @"Thx 2 Gavinkwoe";
    }
    return self;
}

@end
