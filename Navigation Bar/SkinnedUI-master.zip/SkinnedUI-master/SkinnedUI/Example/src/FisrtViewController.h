//
//  FisrtViewController.h
//  SkinnedUI
//
//  Created by QFish on 12/2/12.
//  Copyright (c) 2012 http://QFish.Net All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FisrtViewController : BaseViewController

@end
