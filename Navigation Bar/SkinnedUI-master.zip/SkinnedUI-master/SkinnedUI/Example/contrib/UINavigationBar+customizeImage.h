//
//  UINavigationBar+customizeImage.h
//  
//
//  Created by QFish on 8/14/12.
//
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (customizeImage)

- (void)setCustomizeImage:(UIImage *)image
			forBarMetrics:(UIBarMetrics)metrices;

@end
