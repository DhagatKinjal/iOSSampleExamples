//
//  main.m
//  BTFloatingMenu
//
//  Created by Meiwin Fu on 12/1/13.
//  Copyright (c) 2013 BlockThirty. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BTAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([BTAppDelegate class]));
  }
}
