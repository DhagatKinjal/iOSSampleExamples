# BTBreadcrumbView

## Overview

__this is work in progress__

![Screenshot](https://raw.github.com/meiwin/BTBreadcrumbView/master/screenshot.png)

Watch quick demo in [youtube](http://www.youtube.com/watch?v=UQSrwGeOJ0U&feature=youtu.be "BTBreadcrumbView Demo")

A breadcrumb ios control, features:

- Simple API
- Animated transition

## Roadmap

- UI appearance customization
- Configure max allowed width to expand
- Auto retract when idle

## Licensing

BTBreadcrumbView is licensed under MIT License Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
