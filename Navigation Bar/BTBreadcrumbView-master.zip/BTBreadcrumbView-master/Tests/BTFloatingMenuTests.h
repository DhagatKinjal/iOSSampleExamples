//
//  BTFloatingMenuTests.h
//  BTFloatingMenuTests
//
//  Created by Meiwin Fu on 12/1/13.
//  Copyright (c) 2013 BlockThirty. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface BTFloatingMenuTests : SenTestCase

@end
