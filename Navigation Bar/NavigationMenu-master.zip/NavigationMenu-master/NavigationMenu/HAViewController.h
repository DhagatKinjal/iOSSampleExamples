//
//  HAViewController.h
//  NavigationMenu
//
//  Created by Ivan Sapozhnik on 2/19/13.
//  Copyright (c) 2013 Ivan Sapozhnik. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SINavigationMenuView.h"

@interface HAViewController : UIViewController <SINavigationMenuDelegate>

@end
