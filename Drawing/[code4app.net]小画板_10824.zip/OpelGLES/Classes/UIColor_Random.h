
///
//
///

#import <UIKit/UIKit.h>

//category for class of UIColor
@interface UIColor(Random)

//create random color
+ (UIColor *)randomColor;

@end