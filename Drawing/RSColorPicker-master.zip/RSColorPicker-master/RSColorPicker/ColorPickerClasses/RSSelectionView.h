//
//  RSSelectionView.h
//  RSColorPicker
//
//  Created by Ryan Sullivan on 3/12/13.
//  Copyright (c) 2013 Freelance Web Developer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RSSelectionView : UIView

@property (nonatomic) UIColor *selectedColor;

@end
