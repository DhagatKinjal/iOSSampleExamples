//
//  main.m
//  CeedGLDemo
//
//  Created by Raphael Sebbe on 06/11/10.
//  Copyright (c) 2010 Creaceed. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]) {
	return NSApplicationMain(argc,  (const char **) argv);
}
