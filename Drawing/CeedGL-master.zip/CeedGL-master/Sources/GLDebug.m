//
//  GLDebug.m
//  CeedGL
//
//  Created by Raphael Sebbe on 01/11/10.
//  Copyright (c) 2010 Creaceed. All rights reserved.
//

#import "GLDebug.h"

void ceedgl_debug_terminate(void)
{
	printf("assert\n");
}