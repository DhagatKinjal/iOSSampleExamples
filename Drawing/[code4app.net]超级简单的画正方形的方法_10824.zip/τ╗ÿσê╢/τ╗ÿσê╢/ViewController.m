//
//  ViewController.m
//  绘制
//
//  Created by 斌 on 12-10-27.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.hahaview = [[view alloc] initWithFrame:CGRectMake(20, 20, 280, 320)];//初始化、坐标
    _hahaview.backgroundColor = [UIColor clearColor];//要透明的
    [self.view addSubview:_hahaview];//添加
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
