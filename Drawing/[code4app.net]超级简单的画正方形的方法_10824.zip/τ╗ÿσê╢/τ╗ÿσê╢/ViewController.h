//
//  ViewController.h
//  绘制
//
//  Created by 斌 on 12-10-27.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "view.h"

@interface ViewController : UIViewController
@property (strong, nonatomic) view *hahaview;
@end
