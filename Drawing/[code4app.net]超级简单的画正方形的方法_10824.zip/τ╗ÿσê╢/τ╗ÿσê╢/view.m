//
//  view.m
//  绘制
//
//  Created by 斌 on 12-10-27.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import "view.h"

@implementation view


- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGRect rectt = CGRectMake(100 ,100, 100, 100);//坐标
    CGContextSetRGBFillColor(context, 61/ 255.0f, 122/ 255.0f, 160/ 255.0f,0.8);//颜色（RGB）,透明度
    CGContextFillRect(context, rectt);
}

@end
