//
//  AppDelegate.h
//  KZColorPicker
//
//  Created by Alex Restrepo on 9/1/12.
//  Copyright (c) 2012 Alex Restrepo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
