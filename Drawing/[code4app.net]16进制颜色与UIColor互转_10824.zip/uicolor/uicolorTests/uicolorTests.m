//
//  uicolorTests.m
//  uicolorTests
//
//  Created by 彦斌 刘 on 12-5-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "uicolorTests.h"

@implementation uicolorTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in uicolorTests");
}

@end
