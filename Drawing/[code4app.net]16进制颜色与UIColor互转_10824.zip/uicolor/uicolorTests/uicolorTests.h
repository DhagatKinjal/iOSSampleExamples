//
//  uicolorTests.h
//  uicolorTests
//
//  Created by 彦斌 刘 on 12-5-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface uicolorTests : SenTestCase

@end
