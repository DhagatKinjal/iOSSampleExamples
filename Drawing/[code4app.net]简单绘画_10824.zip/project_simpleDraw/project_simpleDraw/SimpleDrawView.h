//
//  SimpleDrawView.h
//  project_simpleDraw
//
//  Created by GXS on 12-10-9.
//  Copyright (c) 2012年 GXS. All rights reserved.
//

#import <UIKit/UIKit.h>

static inline float radians(double degrees)
{
    return degrees * 3.14 / 180;
}

@interface SimpleDrawView : UIView

@property (strong, nonatomic) NSString *draw;

@property (nonatomic) CGPoint beginPoint;

@property (nonatomic) CGPoint endPoint;

@property (strong, nonatomic) NSMutableArray *array_points;





@end
