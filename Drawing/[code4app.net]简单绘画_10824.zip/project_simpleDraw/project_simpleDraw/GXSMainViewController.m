//
//  GXSMainViewController.m
//  project_simpleDraw
//
//  Created by GXS on 12-10-9.
//  Copyright (c) 2012年 GXS. All rights reserved.
//

#import "GXSMainViewController.h"


@interface GXSMainViewController ()

@end

@implementation GXSMainViewController

@synthesize simpleView = _simpleView;

- (void)dealloc
{
    [super dealloc];
//    [_simpleView release];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.simpleView = [[SimpleDrawView alloc] initWithFrame:CGRectMake(20, 20, 280, 320)];
    _simpleView.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:_simpleView];
   
    
    UIButton *lineButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    lineButton.frame = CGRectMake(20, 360, 40, 40);
    [lineButton setTitle:@"line" forState:UIControlStateNormal];
    [lineButton addTarget:self action:@selector(linePressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:lineButton];
    
    UIButton *rectButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    rectButton.frame = CGRectMake(80, 360, 60, 40);
    [rectButton setTitle:@"rectangle" forState:UIControlStateNormal];
    [rectButton addTarget:self action:@selector(rectPressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rectButton];
    
    UIButton *textButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    textButton.frame = CGRectMake(160, 360, 60, 40);
    [textButton setTitle:@"text" forState:UIControlStateNormal];
    [textButton addTarget:self action:@selector(textPressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:textButton];
    
    UIButton *curveButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    curveButton.frame = CGRectMake(240, 360, 60, 40);
    [curveButton setTitle:@"curve" forState:UIControlStateNormal];
    [curveButton addTarget:self action:@selector(curvePressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:curveButton];
    
    
    
}

- (void)linePressed:(id)sender
{
    [_simpleView setDraw:@"line"];
}

- (void)rectPressed:(id)sender
{
    [_simpleView setDraw:@"rectangle"];
}

- (void)textPressed:(id)sender
{
    [_simpleView setDraw:@"text"];
}

- (void)curvePressed:(id)sender
{
    [_simpleView setDraw:@"curve"];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
