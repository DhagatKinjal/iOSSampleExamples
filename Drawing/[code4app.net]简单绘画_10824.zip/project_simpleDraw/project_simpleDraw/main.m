//
//  main.m
//  project_simpleDraw
//
//  Created by GXS on 12-10-9.
//  Copyright (c) 2012年 GXS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GXSAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GXSAppDelegate class]));
    }
}
