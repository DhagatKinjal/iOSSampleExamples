//
//  GXSAppDelegate.h
//  project_simpleDraw
//
//  Created by GXS on 12-10-9.
//  Copyright (c) 2012年 GXS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GXSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
