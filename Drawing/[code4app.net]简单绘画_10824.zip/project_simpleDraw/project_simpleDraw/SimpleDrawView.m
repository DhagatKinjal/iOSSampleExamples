//
//  SimpleDrawView.m
//  project_simpleDraw
//
//  Created by GXS on 12-10-9.
//  Copyright (c) 2012年 GXS. All rights reserved.
//

#import "SimpleDrawView.h"

@implementation SimpleDrawView

@synthesize beginPoint = _beginPoint;
@synthesize endPoint = _endPoint;
@synthesize array_points = _array_points;

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.array_points = [NSMutableArray arrayWithCapacity:10];
    }
    return self;
    NSLog(@"***********************");
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if([_draw isEqualToString:@"line"])
    {
        [self drawLine:context];
    }
    else if ([_draw isEqualToString:@"curve"])
    {
        [self drawCurve:context];
    }
    else if ([_draw isEqualToString:@"rectangle"])
    {
        [self drawRectangle:context];
    }
    else if([_draw isEqualToString:@"text"])
    {
        [self drawText:context];
    }
}


- (void)drawCurve:(CGContextRef)_context
{
    CGContextSetLineWidth(_context, 2);
    CGContextSetRGBFillColor(_context, 0, 0, 0, 1);
    
    CGPoint addPoint[[_array_points count]];
    NSLog(@"%d",[_array_points count]);
    for(int i = 0;i<[_array_points count];i++)
    {
        addPoint[i] = [[_array_points objectAtIndex:i] CGPointValue];
        NSLog(@"i");
    }
    CGContextAddLines(_context, addPoint, sizeof(addPoint)/sizeof(addPoint[0]));
    CGContextStrokePath(_context);
}


- (void)drawText:(CGContextRef)_context
{
    NSMutableString *text = [NSMutableString stringWithCapacity:10];
    for (int i = 0; i<(sqrt((_endPoint.x-_beginPoint.x)*(_endPoint.x-_beginPoint.x) + (_endPoint.y-_beginPoint.y)*(_endPoint.y-_beginPoint.y))/16); i++ ) {
        [text appendFormat:@"%c",arc4random()%97+1];
    }

    // 设置旋转字体
    CGAffineTransform myTextTransform = CGAffineTransformMakeRotation(radians(270));
    CGContextSetTextMatrix(_context, myTextTransform);

    // 设置字体：为16pt Helvetica
    CGContextSelectFont(_context, "Helvetica", 16, kCGEncodingMacRoman);
    //设置文字绘制模式
    // 3种绘制模式：kCGTextFill 填充, kCGTextStroke 描边, kCGTextFillStroke 既填充又描边
    CGContextSetTextDrawingMode(_context, kCGTextStroke); // set drawing mode
    // 设置文本颜色字符为黑色
    CGContextSetRGBFillColor(_context, 0.0, 0.0, 0.0, 1.0); //黑

    CGContextSetTextMatrix(_context, CGAffineTransformMakeScale(1.0, -1.0));

    CGContextShowTextAtPoint(_context, _beginPoint.x, _beginPoint.y, [text cStringUsingEncoding:[NSString defaultCStringEncoding]],
                         text.length);
}




- (void)drawRectangle:(CGContextRef)_context
{
    CGRect rect = CGRectMake(_beginPoint.x, _beginPoint.y, _endPoint.x - _beginPoint.x, _endPoint.y - _beginPoint.y);
    CGContextSetLineWidth(_context, 5);
    CGContextSetRGBFillColor(_context, 0.5, 0.2, 0, 1);
    CGContextFillRect(_context, rect);
    CGContextStrokePath(_context);
    
    CGContextAddRect(_context,rect);
    CGContextSetLineWidth(_context, 3);
    CGContextSetRGBStrokeColor(_context, 0, 0, 0, 1);
    CGContextStrokePath(_context);
    
}



- (void)drawLine:(CGContextRef)_context
{
    CGContextMoveToPoint(_context, _beginPoint.x, _beginPoint.y);
    CGContextAddLineToPoint(_context, _endPoint.x, _endPoint.y);
    CGContextSetLineWidth(_context, 5);
    CGContextSetRGBFillColor(_context, 0, 0, 0, 1);
    
    CGContextStrokePath(_context);    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    self.beginPoint = [touch locationInView:self];
    [_array_points addObject:[NSValue valueWithCGPoint:_beginPoint]];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    self.endPoint = [touch locationInView:self];
    [_array_points addObject:[NSValue valueWithCGPoint:_endPoint]];
    [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_array_points removeAllObjects];
}










@end
