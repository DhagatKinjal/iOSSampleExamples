//
//  CubeFlip.h
//  IOS_3D_UI
//
//  Created by  on 12-9-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CubeFlip : UIViewController
@property (retain, nonatomic) IBOutlet UIImageView *image0;
@property (retain, nonatomic) IBOutlet UIImageView *image1;
@property (retain, nonatomic) IBOutlet UIImageView *image2;
@property (retain, nonatomic) IBOutlet UIImageView *image3;

@end
