//
//  PerspectRotate.h
//  IOS_3D_UI
//
//  Created by  on 9/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PerspectRotate : UIViewController

@property (retain, nonatomic) IBOutlet UIImageView *image;
- (IBAction)buttonPressed:(id)sender;
@end
