//
//  main.m
//  SBTickerViewDemo
//
//  Created by Simon Blommegård on 2011-12-11.
//  Copyright (c) 2011 Doubleint. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SBAppDelegate class]));
    }
}
