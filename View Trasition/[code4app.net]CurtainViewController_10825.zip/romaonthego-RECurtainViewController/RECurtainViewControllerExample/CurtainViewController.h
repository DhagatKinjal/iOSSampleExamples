//
//  CurtainViewController.h
//  RECurtainViewControllerExample
//
//  Created by Roman Efimov on 7/8/12.
//  Copyright (c) 2012 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+RECurtainViewController.h"

@interface CurtainViewController : UIViewController

@end
