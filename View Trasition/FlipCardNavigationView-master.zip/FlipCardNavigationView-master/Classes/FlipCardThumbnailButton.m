//
//  FlipCardThumbnailButton.m
//  FlipCardNavigationView
//
//  Created by Kishikawa Katsumi on 10/03/08.
//  Copyright 2010 Kishikawa Katsumi. All rights reserved.
//

#import "FlipCardThumbnailButton.h"

@implementation FlipCardThumbnailButton

@synthesize row;
@synthesize column;

@end
