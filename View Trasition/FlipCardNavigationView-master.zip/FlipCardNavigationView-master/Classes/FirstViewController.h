//
//  FirstViewController.h
//  FlipCardNavigationView
//
//  Created by Kishikawa Katsumi on 10/03/08.
//  Copyright Kishikawa Katsumi 2010. All rights reserved.
//

#import "FlipCardView.h"

@interface FirstViewController : UIViewController {
    FlipCardView *thumbnailView;
}

@end
