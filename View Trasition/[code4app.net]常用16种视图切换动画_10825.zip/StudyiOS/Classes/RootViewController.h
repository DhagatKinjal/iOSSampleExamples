//
//  RootViewController.h
//  StudyiOS
//
//  Created by Zhang YiCheng on 11-9-27.
//  Copyright 2011 ZhangYiCheng. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

- (IBAction)buttonPressed1:(id)sender;

@end
