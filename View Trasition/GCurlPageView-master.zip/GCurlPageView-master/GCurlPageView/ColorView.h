//
//  ColorView.h
//  GCurlPageView
//
//  Created by gelosie.wang@gmail.com on 12-6-11.
//  Copyright (c) 2012年 gelosie.wang@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColorView : UIView
{
    UILabel *label;
}

@property (nonatomic,assign) NSInteger index;

@end
