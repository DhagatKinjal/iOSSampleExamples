//
//  AppDelegate.h
//  zake
//
//  Created by 斌 on 12-11-7.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{

    UIImageView *zView;//Z图片ImageView
    UIImageView *fView;//F图片ImageView
    

    UIView *rView;//图片的UIView
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
