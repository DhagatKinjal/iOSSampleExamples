//
//  main.m
//  FlipFlop
//
//  Created by Kishyr Ramdial on 2012/08/13.
//  Copyright (c) 2012 entropy|one. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KRAppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([KRAppDelegate class]));
	}
}
