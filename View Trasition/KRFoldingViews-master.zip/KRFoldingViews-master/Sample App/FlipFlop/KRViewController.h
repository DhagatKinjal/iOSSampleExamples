//
//  KRViewController.h
//  FlipFlop
//
//  Created by Kishyr Ramdial on 2012/08/13.
//  Copyright (c) 2012 entropy|one. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KRViewController : UIViewController

@property (nonatomic, strong) NSString *foldingMethod;

@end
