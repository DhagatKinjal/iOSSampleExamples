

#import "EPGLTransitionView.h"
//上下翻转
//
// TBD
//

@interface Demo4Transition : NSObject<EPGLTransitionViewDelegate> {
    float f;
    GLuint woodTexture;
}

@end
