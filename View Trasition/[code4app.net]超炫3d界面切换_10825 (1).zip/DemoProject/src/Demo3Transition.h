

#import "EPGLTransitionView.h"


@interface Demo3Transition : NSObject<EPGLTransitionViewDelegate> {
    float f;
    GLuint woodTexture;
}

@end
