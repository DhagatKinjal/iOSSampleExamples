

#import "EPGLTransitionView.h"
//半翻页
//
// TBD
//

@interface Demo2Transition : NSObject<EPGLTransitionViewDelegate> {
    float f;
}

@end
