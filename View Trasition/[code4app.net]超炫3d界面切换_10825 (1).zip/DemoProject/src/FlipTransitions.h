

#import "EPGLTransitionView.h"

@interface FlipForward : NSObject<EPGLTransitionViewDelegate> {
    float f;
}
@end

@interface FlipBackward : NSObject<EPGLTransitionViewDelegate> {
    float f;
}
@end
