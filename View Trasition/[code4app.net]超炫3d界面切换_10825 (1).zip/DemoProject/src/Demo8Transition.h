

#import "EPGLTransitionView.h"
//横向百叶窗
//
// TBD
//

@interface Demo8Transition : NSObject<EPGLTransitionViewDelegate> {
    float f;
	
	GLfloat vertices[24];
	
	GLfloat texcoords[16];
}

@end
