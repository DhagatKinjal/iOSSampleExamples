//
//  FlipsideView.h
//  DemoProject
//
//  Created by Edward Patel on 2010-02-28.
//  Copyright Memention AB 2010. All rights reserved.
//

@interface FlipsideView : UIView {
	
}

@end
