//
//  PageViewController.h
//  HelloPageCurl
//
//  Created by lin he on 10-3-24.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@interface PageViewController : UIViewController {
	BOOL isCurl;
	UISwitch *switchView;
	UILabel *switchStatusLabel;
}

@end
