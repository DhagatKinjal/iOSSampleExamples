//
//  PageViewController.m
//  HelloPageCurl
//
//  Created by lin he on 10-3-24.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PageViewController.h"

@implementation PageViewController

- (id)init
{
	if (!(self = [super init])) 
		return self;
	self.title = @"Page Curl Demo";
	return self;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	self.view = contentView;
	[contentView release];
	
	switchView = [[[UISwitch alloc] init] autorelease];
	[switchView setCenter:CGPointMake(200.0f,380.0f)];
	[self.view addSubview:switchView];
	
	UIView *frontView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 416.0f)];
	frontView.backgroundColor = [UIColor lightGrayColor];
	switchStatusLabel = [[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 50.0f, 50.0f, 30.0f)] autorelease];
	[frontView addSubview:switchStatusLabel];
	[switchStatusLabel setTextAlignment:UITextAlignmentCenter];
	switchStatusLabel.text=@"OFF";
	[self.view addSubview:frontView];
	
	isCurl=NO;
	self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]
											   initWithTitle:@"Curl" 
											   style:UIBarButtonItemStylePlain 
											   target:self 
											   action:@selector(doCurl)] autorelease];
	
	
}

- (void) doCurl
{
	//创建CATransition对象
	CATransition *animation = [CATransition animation];
	//相关参数设置
	[animation setDelegate:self];
	[animation setDuration:1.0f];
	[animation setTimingFunction:UIViewAnimationCurveEaseInOut];
	//向上卷的参数
	if(!isCurl)
	{
		//设置动画类型为pageCurl，并只卷一半
		[animation setType:@"pageCurl"];   
		animation.endProgress=0.5;
	}
	//向下卷的参数
	else
	{
		//设置动画类型为pageUnCurl，并从一半开始向下卷
		[animation setType:@"pageUnCurl"];
		animation.startProgress=0.5;
	}
	//卷的过程完成后停止，并且不从层中移除动画
	[animation setFillMode:kCAFillModeForwards];
	[animation setSubtype:kCATransitionFromBottom];
	[animation setRemovedOnCompletion:NO];

	isCurl=!isCurl;
	
	[self.view exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
	[[self.view layer] addAnimation:animation forKey:@"pageCurlAnimation"];
	if([switchView isOn])
	{
		switchStatusLabel.text=@"ON";
	}
	else
	{
		switchStatusLabel.text=@"OFF";
	}
}

- (void)dealloc {
    [super dealloc];
}


@end
