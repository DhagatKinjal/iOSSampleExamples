//
//  HelloPageCurlAppDelegate.m
//  HelloPageCurl
//
//  Created by lin he on 10-3-24.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "HelloPageCurlAppDelegate.h"
#import "PageViewController.h"

@implementation HelloPageCurlAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
	PageViewController *pvController = [[PageViewController alloc] init];
	UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:pvController];
	[window addSubview:navController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
