//
//  HelloPageCurlAppDelegate.h
//  HelloPageCurl
//
//  Created by lin he on 10-3-24.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloPageCurlAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

