//
//  CubeConstants.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#define kM34 -0.0005
#define kVerticalTranslateAndAnchorPointZ -240
#define kHorizontalTranslateAndAnchorPointZ -160
#define kMini 25
#define kMax 5
#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)
#define kResponseWidth 40
#define kResponseHeight 44

//手指按下屏幕后的位置范围
typedef enum {
    AreaLeftLocation = 0,
    AreaRightLocation = 1,
    AreaTopLocation=2,
    AreaBottomLocation=3,
    AreaOtherLocation=1000
}AreaLocation;

//手指滑动的方向
typedef enum 
{
    SwipeRightToLeftDirection=0,
    SwipeLeftToRightDirection=1,
    SwipeTopToBottomDirection=2,
    SwipeBottomToTopDirection=3,
    SwipeOtherDirectionDirection=4
}SwipeDirection;

//手指离开屏幕后，当前正方体的状态，那个面对着用户
typedef enum{
    CubeTopState=0,
    CubeFrontState=1,
    CubeBottomState=2,
    CubeLeftState=3,
    CubeRightState=4,
    CubeBackState=5,
    CubeOtherState=6//正在滑动的状态
} CubeState;

#define kRockHorizontalNumber 1.8 //左右摇动
#define kRockVerticalNumber 2.0//上下摇动
