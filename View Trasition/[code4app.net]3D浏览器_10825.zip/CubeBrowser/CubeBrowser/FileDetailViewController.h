//
//  FileDetailViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

@class FileTranserModel;

@interface FileDetailViewController : UIViewController<UIScrollViewDelegate,UIWebViewDelegate>
{}

-(id)initWithFileType:(FileTranserModel *)fileType;

@end
