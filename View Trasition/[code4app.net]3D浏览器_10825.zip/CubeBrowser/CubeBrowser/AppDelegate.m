//
//  AppDelegate.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "MainViewController.h"

@implementation AppDelegate
@synthesize pull_pull,pull_release;
@synthesize mainViewController;
@synthesize window = _window;
@synthesize weiboApi;

- (void)dealloc
{
    self.mainViewController=nil;
    self.weiboApi=nil;
    [_window release];
    [super dealloc];
}

-(void)loadSoundResource
{
    @autoreleasepool {
        NSURL *pullURL=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"pull_pull.wav"];
        AudioServicesCreateSystemSoundID((CFURLRef)pullURL, &pull_pull);
        
        NSURL *releaseURL=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"pull_release.wav"];
        AudioServicesCreateSystemSoundID((CFURLRef)releaseURL, &pull_release);
    }
}


-(void)publishMessageResult:(NSNotification*)notification
{
    NSDictionary* dict = [notification userInfo];
    if (dict) {
        BOOL success=[[dict objectForKey:@"success"] boolValue];
        if (!success) {
            UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:nil 
                                                               message:@"分享到微博失败" 
                                                              delegate:nil
                                                     cancelButtonTitle:@"确定" 
                                                     otherButtonTitles:nil];
            [alertView show];
            [alertView release];
            return;
        }
        NSInteger weiboid=[[dict objectForKey:@"weiboid"] intValue];
        //NSInteger userData = [[dict objectForKey:@"userData"] intValue];
        NSString* result = nil;
        switch (weiboid) {
            case Weibo_Sina:
                result=@"已分享到新浪微博";
                break;
            case Weibo_Tencent:
                result=@"已分享到腾讯微博";
                break;
            case Weibo_Netease:
                result=@"已分享到网易微博";
                break;
            case Weibo_Sohu:
                result=@"已分享到搜狐微博";
                break;
            case Weibo_Max:
                return;
                break;
            default:
                
                break;
        }
        NSLog(@"%@", result);
        UIAlertView* alertView = [[UIAlertView alloc]initWithTitle:nil 
                                                           message:result 
                                                          delegate:nil
                                                 cancelButtonTitle:@"确定" 
                                                 otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];

    weiboApi = [[WeiboCommonAPI alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(publishMessageResult:)
												 name:PublishMessageResultNotification
											   object:nil];

    [NSThread detachNewThreadSelector:@selector(loadSoundResource) toTarget:self withObject:nil];

    mainViewController=[[MainViewController alloc] init];

    self.window.rootViewController=mainViewController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
