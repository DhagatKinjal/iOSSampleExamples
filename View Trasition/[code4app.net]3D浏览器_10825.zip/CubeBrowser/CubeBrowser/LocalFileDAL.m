//
//  LocalFileDAL.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LocalFileDAL.h"
#import "FileTypeModel.h"
#import "FileTranserHelper.h"
#import "FileTranserModel.h"

static LocalFileDAL *instance;

@implementation LocalFileDAL


+(LocalFileDAL *)sharedInstance
{
    if(instance==nil)
    {
        instance=[[LocalFileDAL alloc] init];
    }
    return instance;
}

-(NSMutableArray *)getAllTypeFiles
{ 
    NSMutableArray *datalist=[[[NSMutableArray alloc] init] autorelease];
    
    NSString *homePath=[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    NSArray *namelist=[fileManager contentsOfDirectoryAtPath:homePath error:nil];
    
    
    
    int count=0;
    long totalSize=0;
    NSURL *url=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"Suffix.plist"];
    NSDictionary *suffixDict=[NSDictionary dictionaryWithContentsOfURL:url];
    for(NSString *key in  [suffixDict allKeys])
    {
        count=0;
        totalSize=0;
        NSDictionary *dict=[suffixDict objectForKey:key];
        
        FileTypeModel *typeFile=[[FileTypeModel alloc] init];
        typeFile.fileImgURL=[dict objectForKey:@"Icon"];
        typeFile.fileTypeName=key;
        
        
        id subDict=[dict objectForKey:@"Suffix"];
        if([subDict isKindOfClass:[NSDictionary class]])
        {
            for(NSString *name in namelist)
            {
                for(NSString *suffix in [subDict allKeys])
                {
                    if([name.lastPathComponent hasSuffix:suffix])
                    {
                        NSDictionary *attri=[fileManager attributesOfItemAtPath:[homePath stringByAppendingPathComponent:name] error:nil];
                        NSNumber *fileSize=[attri objectForKey:NSFileSize];
                        totalSize+=[fileSize longValue];
                        count++;
                    }
                }
            }
        }
        typeFile.fileCount=count;
        typeFile.fileTypeDetail=[NSString stringWithFormat:@"(%d%@,%@%@)",count,NSLocalizedString(@"个文件", @""),NSLocalizedString(@"共",@""), [[FileTranserHelper sharedInstance] getFileSizeString:totalSize]];
        [datalist addObject:typeFile];
        [typeFile release];
    }
    return datalist;
}

-(NSMutableArray *)getFileByTypeName:(NSString *)typeName
{
    NSMutableArray *datalist=[[[NSMutableArray alloc] init] autorelease];
    NSString *homePath=[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    NSArray *namelist=[fileManager contentsOfDirectoryAtPath:homePath error:nil];

    NSURL *url=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"Suffix.plist"];
    NSDictionary *suffixDict=[NSDictionary dictionaryWithContentsOfURL:url];
    NSDictionary *typeDict=[suffixDict objectForKey:typeName];
    id subDict=[typeDict objectForKey:@"Suffix"];
    if([subDict isKindOfClass:[NSDictionary class]])
    {
        for(NSString *name in namelist)
        {   
            for(NSString *suffix in [subDict allKeys])
            {
                if([name.lastPathComponent hasSuffix:suffix])
                {
                    NSDictionary *attri=[fileManager attributesOfItemAtPath:[homePath stringByAppendingPathComponent:name] error:nil];
                    NSNumber *fileSize=[attri objectForKey:NSFileSize];
                    FileTranserModel *file=[[FileTranserModel alloc] init];
                    file.fileName=name;
                    file.fileTrueSize=[fileSize longLongValue];
                    file.destationPath=[homePath stringByAppendingPathComponent:name];
                    [datalist addObject:file];
                    [file release];
                }
            }
        }
    }
    return datalist;
}
-(void)dealloc
{
    [instance release];
    [super dealloc];
}
@end
