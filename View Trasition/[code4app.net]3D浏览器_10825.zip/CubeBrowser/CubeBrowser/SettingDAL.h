//
//  SettingDAL.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SettingDAL : NSObject

+(void)setRockRotate:(BOOL)flag;
+(BOOL)shouldRockRotate;
@end
