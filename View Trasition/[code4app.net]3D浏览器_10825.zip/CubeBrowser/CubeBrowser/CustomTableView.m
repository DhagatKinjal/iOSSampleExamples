//
//  CustomTableView.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-1.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CustomTableView.h"
#import "CubeView.h"

@interface CustomTableView ()
{
    
}
@end
@implementation CustomTableView
@synthesize cubeState;


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if(point.y<44)
    {
        return NO;
    }
    if(cubeState==CubeLeftState&&point.x>self.frame.size.width-kResponseWidth)
    {
        return NO;
    }
    if(cubeState==CubeRightState&&point.x<kResponseWidth)
    {
        return NO;
    }
    if(cubeState==CubeTopState&&point.y>self.frame.size.height-kResponseHeight)
    {
        return NO;
    }
    if(cubeState==CubeBottomState&&(point.x<kResponseWidth||point.x>self.frame.size.width-kResponseWidth))
    {
        return NO;
    }
    return YES;
}

@end
