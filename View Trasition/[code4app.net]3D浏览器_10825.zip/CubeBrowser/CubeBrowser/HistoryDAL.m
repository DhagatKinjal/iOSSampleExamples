//
//  HistoryDAL.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "HistoryDAL.h"
#import "PageModel.h"
#import "ArchiverHelper.h"

static HistoryDAL *instance;

@implementation HistoryDAL

+(HistoryDAL *)sharedInstance
{
    if(instance==nil)
    {
        instance=[[HistoryDAL alloc] init];
    }
    return instance;
}

-(void)dealloc
{
    [instance release];
    instance=nil;
    [super dealloc];
}

-(void)insertOneHistory:(PageModel *)model
{
    NSMutableArray *historylist=[[ArchiverHelper sharedInstance] getObjectByPath:kHistoryArchivePath];
    if(historylist==nil)
    {
        historylist=[[[NSMutableArray alloc] init] autorelease];
    }
    [historylist addObject:model];
    [[ArchiverHelper sharedInstance] archiveObject:historylist ByPath:kHistoryArchivePath];
}

-(NSMutableArray *)getHistorylist
{
    NSMutableArray *tmplist=[[ArchiverHelper sharedInstance] getObjectByPath:kHistoryArchivePath];
    NSSortDescriptor *sortDescri=[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO];
    tmplist=[NSMutableArray arrayWithArray:[tmplist sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescri]]];
    return tmplist;
}

-(NSMutableArray *)getHistorylistByType:(HistoryType)type
{
    NSMutableArray *resultlist=[[[NSMutableArray alloc] init] autorelease];
    NSMutableArray *datalist=[self getHistorylist];
    double time=24*60*60.0;
    switch (type) {
        case HistoryToday:
        {
            time=24*60*60.0;
        }
            break;
        case HistoryYeterday:
        {
            time*=2;
        }
            break;
        case HistoryWeek:
        {
            time*=7;
        }
            break;
        case HistoryMonth:
            time*=30;
            break;
        default:
            break;
    }

    for(PageModel *page in datalist)
    {
        NSTimeInterval timeInter=[page.creationDate timeIntervalSinceNow];
        if(timeInter<=time)
        {
            [resultlist addObject:page];
        }
    }
    return resultlist;
}

-(void)updateHistorylist:(NSMutableArray *)hislist
{
    [[ArchiverHelper sharedInstance] archiveObject:hislist ByPath:kHistoryArchivePath];
}

-(void)clearHistory
{
    NSFileManager *fileManager=[NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:kHistoryArchivePath])
    {
        [fileManager removeItemAtPath:kHistoryArchivePath error:nil];
    }
}
@end
