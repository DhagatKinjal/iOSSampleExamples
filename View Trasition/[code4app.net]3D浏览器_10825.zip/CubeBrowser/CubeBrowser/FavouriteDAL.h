
//
//  FavouriteDAL.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PageModel;

#define kFavouriteArchivePath [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"favouritelist"]


@interface FavouriteDAL : NSObject

+(FavouriteDAL *)sharedInstance;

-(BOOL)isAdded:(NSString *)url;
-(void)insertOneFavourite:(PageModel *)model;
-(NSMutableArray *)getFavouritelist;
-(void)updateFavouritelist:(NSMutableArray *)favlist;
-(void)clearFavourite;
@end
