//
//  DownloadingCell.h
//  IphoneReader
//
//  Created by Han Guoxiang on 12-6-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define DetailLabelTextColor [UIColor darkGrayColor]
#define GAP 16 //编辑模式移动的距离
@interface DownloadingCell : UITableViewCell

@property(nonatomic,retain)UIImageView *fileImage;
@property(nonatomic,retain)UIImageView *maskImgView;
@property(nonatomic,retain)UILabel *fileNameLabel;
@property(nonatomic,retain)UILabel *fileSizeLabel;
@property(nonatomic,retain)UIProgressView *proView;
@property(nonatomic,retain)UIButton *operateButton;
@property(nonatomic,retain)UIImageView *stateImgView;
@property(nonatomic,retain)UILabel *stateLabel;
@property(nonatomic,retain)UILabel *remainTimeLabel;

-(void)setClickDelegateState;
-(void)setDoneDelegateNormal;
-(void)setMoveDeleteState;
-(void)setClickDelegateState;
@end
