//
//  RightViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RightViewController.h"
#import "CustomTableView.h"
#import "DownloadingCell.h"
#import "FileTranserModel.h"
#import "Constants.h"
#import "Reachability.h"
#import "UIImageView+WebCache.h"
#import "AppDelegate.h"
#import "UINavigationBar+BackImage.h"

@interface RightViewController ()

@property(nonatomic,retain)UILabel *lblResult;
@property(nonatomic,retain)UINavigationBar *navBar;
@property(nonatomic,retain)CustomTableView *downingTableView;
@property(nonatomic,retain)NSMutableArray *downinglist;
-(void)loadDowningFiles;//加载正在下载的文件
-(void)updateCellError:(DownloadingCell *)cell errorCode:(int)errorCode;
-(void)updateCellState:(NSDictionary *)dict;//设置cell的下载状态  1-indexPath 2-实时的fileTransferModel
-(void)operateAction:(id)sender;//控制暂停、继续的按钮事件
-(void)updateCurrentDatalist:(FileTranserModel *)newFile;
-(BOOL)hasInCurrentQueue:(int)tag;
-(UITableViewCell *)getCellByDownURL:(NSString *)url;
-(void)goHome;
@end

@implementation RightViewController

@synthesize downingTableView;
@synthesize downinglist;
@synthesize navBar;
@synthesize lblResult;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadDowningFiles
{
    @autoreleasepool {
        self.downinglist=[[FileTranserHelper sharedInstance] getArchivelist];
        
        if([self.downinglist count]==0)
        {
            [lblResult performSelectorOnMainThread:@selector(setText:) withObject:NSLocalizedString(@"暂无下载文件", @"") waitUntilDone:YES];
        }
        [downingTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    }
}

-(void)updateCellError:(DownloadingCell *)cell errorCode:(int)errorCode
{
    NSString *stateText=@"";
    UIImage *stateImg=[UIImage imageNamed:k_Downlaod_error];
    UIUserInterfaceIdiom idiom=[[UIDevice currentDevice] userInterfaceIdiom];
    if(idiom==UIUserInterfaceIdiomPad)
    {
        stateImg=[UIImage imageNamed:@"ipad_download_error.png"];
    }
    UIImage *operateImg=[UIImage imageNamed:k_DOWNLOAD_START];
    if(idiom==UIUserInterfaceIdiomPad)
    {
        operateImg=[UIImage imageNamed:@"ipad_download_start.png"];
    }
    NSString *rematinTime=@"";
    
    stateText=[[FileTranserHelper sharedInstance] getErroInfoByHttpErrorCode:errorCode];
    
    [cell.stateImgView setImage:stateImg];
    [cell.stateLabel setText:stateText];
    [cell.stateLabel setTextColor:[UIColor redColor]];
    [cell.remainTimeLabel setText:rematinTime];
    [cell.operateButton setBackgroundImage:operateImg forState:UIControlStateNormal];
}

-(void)updateCellState:(NSDictionary *)dict
{
    UIUserInterfaceIdiom idiom=[[UIDevice currentDevice] userInterfaceIdiom];
    FileTranserModel *fileTransferModel=[dict objectForKey:@"File"];
    DownloadingCell *cell=[dict objectForKey:@"Cell"];
    if(cell==nil)
    {
        cell=(DownloadingCell *)[downingTableView viewWithTag:fileTransferModel.fileID+1000];
    }
    UIImage *stateImg=nil;
    UIImage *operateImg=nil;
    NSString *stateText=nil;
    NSString *rematinTime=nil;
    switch (fileTransferModel.fileTranserState) {
        case FileTransferPause:
            stateImg=[UIImage imageNamed:K_DOWNLOAD_ICON_PAUSE];
            operateImg=[UIImage imageNamed:k_DOWNLOAD_START];
            if(idiom==UIUserInterfaceIdiomPad)
            {
                stateImg=[UIImage imageNamed:@"ipad_download_pause_small.png"];
                operateImg=[UIImage imageNamed:@"ipad_download_start.png"];
            }
            stateText=NSLocalizedString(@"暂停", @"");
            rematinTime=@"";
            break;
        case FileTransferWaiting://正在等待
            stateImg=[UIImage imageNamed:k_DOWNLOAD_ICON_STARING];
            operateImg=[UIImage imageNamed:K_DOWNLOAD_PAUSE];
            if(idiom==UIUserInterfaceIdiomPad)
            {
                stateImg=[UIImage imageNamed:@"ipad_download_downloading.png"];
                operateImg=[UIImage imageNamed:@"ipad_download_pause.png"];
            }
            stateText=NSLocalizedString(@"正在获取...", @"");
            rematinTime=@"--:--:--";
            break;
        case FileTransferWaitOther:
            stateImg=[UIImage imageNamed:@"download_wait.png"];
            operateImg=[UIImage imageNamed:K_DOWNLOAD_PAUSE];
            if(idiom==UIUserInterfaceIdiomPad)
            {
                stateImg=[UIImage imageNamed:@"ipad_download_waiting.png"];
                operateImg=[UIImage imageNamed:@"ipad_download_pause.png"];
            }
            stateText=@"等待";
            rematinTime=@"";
            break;
        case FileTransfering:
        {
            NSString *speed=[[FileTranserHelper sharedInstance] getFileSizeString:fileTransferModel.speed];
            stateText=[NSString stringWithFormat:@"%@/S",speed];
            stateImg=[UIImage imageNamed:k_DOWNLOAD_ICON_STARING];
            operateImg=[UIImage imageNamed:K_DOWNLOAD_PAUSE];
            if(idiom==UIUserInterfaceIdiomPad)
            {
                stateImg=[UIImage imageNamed:@"ipad_download_downloading.png"];
                operateImg=[UIImage imageNamed:@"ipad_download_pause.png"];
            }
            rematinTime=fileTransferModel.remainTime;
        }
            break;
        case FileTransferFinished:
            stateImg=[UIImage imageNamed:K_DOWNLOAD_ICON_PAUSE];
            operateImg=[UIImage imageNamed:k_DOWNLOAD_START];
            if(idiom==UIUserInterfaceIdiomPad)
            {
                stateImg=[UIImage imageNamed:@"ipad_download_pause_small.png"];
                operateImg=[UIImage imageNamed:@"ipad_download_start.png"];
            }
            stateText=@"下载结束";
            rematinTime=@"";
            break;
        case FileTransferFailed:
            [self updateCellError:cell errorCode:fileTransferModel.errorCode];
            break;
        default:
            break;
    }
    
    if(fileTransferModel.fileTranserState!=FileTransferFailed)
    {
        [cell.fileSizeLabel setText:[[FileTranserHelper sharedInstance] getFileSizeString:fileTransferModel.fileTrueSize]];
        [cell.stateLabel setTextColor:DetailLabelTextColor];
        [cell.proView setProgress:fileTransferModel.progress];
        [cell.stateImgView setImage:stateImg];
        [cell.stateLabel setText:stateText];
        [cell.remainTimeLabel setText:rematinTime];
        [cell.operateButton setBackgroundImage:operateImg forState:UIControlStateNormal];
    }
}


-(void)operateAction:(id)sender
{
    DownloadingCell *cell=(DownloadingCell *)[[sender superview] superview];
    NSIndexPath *indexPath=[downingTableView indexPathForCell:cell];
    
    FileTranserModel *curFile=[self.downinglist objectAtIndex:indexPath.row];
    NSLog(@"downoadUrl=%@",curFile.downoadUrl);
    if(![[FileTranserHelper sharedInstance] isStartingFile:curFile.downoadUrl])
    {
        if(![Reachability connectedToNetwork])//自己定义个100吧
        {
            [curFile setFileTranserState:FileTransferFailed];
            curFile.errorCode=100;
            NSDictionary *dict=[NSDictionary dictionaryWithObject:curFile forKey:@"File"];
            [self updateCellState:dict];
        }
        else
        {
            [[FileTranserHelper sharedInstance] startDownloadFile:curFile delegate:self];
        }
    }
    else
    {
        [[FileTranserHelper sharedInstance] cancelForURL:curFile.downoadUrl];
    }
}


-(void)goHome
{
    if([delegate respondsToSelector:@selector(cubeStateDidChanged:cubeState:)])
    {
        [delegate cubeViewClick:[NSNumber numberWithInt:CubeLeftState] obj:nil];
    }
}

-(void)loadView
{
    [super loadView];
    [self.view setBackgroundColor:[UIColor grayColor]];
    
    navBar=[[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
    {
        [navBar setBackgroundImage:[UIImage imageNamed:@"top_bg.png"] forBarMetrics:UIBarMetricsDefault];
    }
    UINavigationItem *navItem=[[UINavigationItem alloc] initWithTitle:NSLocalizedString(@"下载列表", @"")];
    
    UIButton *btnHome=[[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66, 32)] autorelease];
    [btnHome.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [btnHome setBackgroundImage:[UIImage imageNamed:@"account_button.png"] forState:UIControlStateNormal];
    [btnHome setTitle:NSLocalizedString(@"主页", @"") forState:UIControlStateNormal];
    [btnHome addTarget:self action:@selector(goHome) forControlEvents:UIControlEventTouchUpInside];
    navItem.leftBarButtonItem=[[[UIBarButtonItem alloc] initWithCustomView:btnHome] autorelease];
    [btnHome release];
    
    [navBar pushNavigationItem:navItem animated:YES];
    [navItem release];
    [self.view addSubview:navBar];

    
    
    downingTableView=[[CustomTableView alloc] initWithFrame:CGRectMake(0, 44, self.view.frame.size.width, self.view.frame.size.height-44-50)];
    [downingTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [downingTableView setDelegate:self];
    [downingTableView setDataSource:self];
    [self.view addSubview:downingTableView];
    NSLog(@"downingTableView=%@",downingTableView);

    
    lblResult=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, downingTableView.frame.size.width, 30)];
    [lblResult setCenter:CGPointMake(downingTableView.center.x, downingTableView.center.y-70)];
    [lblResult setTextAlignment:UITextAlignmentCenter];
    [lblResult setBackgroundColor:[UIColor clearColor]];
    [downingTableView addSubview:lblResult];

    
    
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    //横幅
    GADBannerView *bannerView_ = [[[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner]autorelease];
    // Specify the ad's "unit identifier." This is your AdMob Publisher ID.
    bannerView_.adUnitID = @"a150697471b0252";
    // Let the runtime know which UIViewController to restore after taking
    // the user wherever the ad goes and add it to the view hierarchy.
    bannerView_.rootViewController = appDelegate.window.rootViewController;
    bannerView_.frame=CGRectMake(0, self.view.frame.size.height-bannerView_.frame.size.height, bannerView_.frame.size.width, bannerView_.frame.size.height);
    [self.view addSubview:bannerView_];
    // Initiate a generic request to load it with an ad.
    [bannerView_ loadRequest:[GADRequest request]];
    
        
    [[FileTranserHelper sharedInstance] setFiletranserDelegate:self];
    self.downinglist=[[[NSMutableArray alloc] init] autorelease];
    
    
    
    //加载正在下载的数据列表
    [NSThread detachNewThreadSelector:@selector(loadDowningFiles) toTarget:self withObject:nil];
}

-(void)releaseCache
{
    self.navBar=nil;
    self.downingTableView=nil;
    self.downinglist=nil;
    self.lblResult=nil;
}

-(void)dealloc
{
    self.delegate=nil;
    [self releaseCache];
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self releaseCache];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.view setHidden:NO];
    [[FileTranserHelper sharedInstance] setFiletranserDelegate:self];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.view setHidden:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [downinglist count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPhone)
    {
        return 74;
    }
    else
    {
        return 84;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier_iPhone";
    DownloadingCell *cell=(DownloadingCell *)[downingTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell==nil)
    {
        cell=[[[DownloadingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier]autorelease];
        [cell.operateButton addTarget:self action:@selector(operateAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    FileTranserModel *fileModel=[downinglist objectAtIndex:indexPath.row];
    
    [cell.proView setProgress:fileModel.progress];
    [cell.fileNameLabel setText:fileModel.fileName];
    [cell.fileSizeLabel setText:[[FileTranserHelper sharedInstance] getFileSizeString:fileModel.fileTrueSize]];
//    [cell.fileImage setImageWithURL:[NSURL URLWithString:fileModel.imgUrl] placeholderImage:[UIImage imageNamed:K_CELL_ICON]];
    NSDictionary *dict=[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:fileModel,cell,nil] forKeys:[NSArray arrayWithObjects:@"File",@"Cell",nil]];
    [self updateCellState:dict];
    return cell;
}

// Override to support editing the table view.

-(void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    if(!editing)
    {
        for(UIView *subView in [downingTableView subviews])
        {
            if([subView isKindOfClass:[DownloadingCell class]])
            {
                DownloadingCell *cell=(DownloadingCell *)subView;
                [cell setDoneDelegateNormal];
            }
        }
    }
    [downingTableView setEditing:editing animated:animated];
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

-(void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    DownloadingCell *cell=(DownloadingCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell setDoneDelegateNormal];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle==UITableViewCellEditingStyleDelete)
    {
        FileTranserModel *fileModel=[self.downinglist objectAtIndex:indexPath.row];
        [[FileTranserHelper sharedInstance] cancelForTag:fileModel.fileID];
        [[FileTranserHelper sharedInstance]  deleteModelFromArchiver:fileModel.fileID];
        NSString *name=[NSString stringWithFormat:@"%@.temp",fileModel.fileName];
        [[FileTranserHelper sharedInstance]  deleteFile:[[[FileTranserHelper sharedInstance] getDowningFolderPath] stringByAppendingPathComponent:name]];
        [self.downinglist removeObjectAtIndex:indexPath.row];
        if([self.downinglist count]==0)
        {
            [lblResult setText:NSLocalizedString(@"暂无下载文件", @"")];
        }
        [downingTableView reloadData];
    }
}

-(BOOL)hasInCurrentQueue:(int)tag//文件是否已经在这个视图的下载队列里了？
{
    for(FileTranserModel *file in downinglist)
    {
        if(file.fileID==tag)
        {
            return YES;
        }
    }
    return NO;
}

-(UITableViewCell *)getCellByDownURL:(NSString *)url
{
    for(UIView *cell in [downingTableView subviews])
    {
        if([cell isKindOfClass:[UITableViewCell class]])
        {
            NSIndexPath *indexPath=[downingTableView indexPathForCell:(UITableViewCell *)cell];
            FileTranserModel *file=[downinglist objectAtIndex:indexPath.row];
            if([url isEqualToString:file.downoadUrl])
            {
                return (UITableViewCell *)cell;
            }
        }
    }
    return nil;
}
#pragma FileTransferHelper的委托
-(void)fileTranserFail:(NSNumber *)tag transerModel:(FileTranserModel *)transerModel
{
    [self updateCurrentDatalist:transerModel];
    NSDictionary *dict=[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:transerModel,[self getCellByDownURL:transerModel.downoadUrl], nil] forKeys:[NSArray arrayWithObjects:@"File",@"Cell", nil]];
    [self performSelectorOnMainThread:@selector(updateCellState:) withObject:dict waitUntilDone:YES];
}

-(void)fileTranserStartNewTask:(NSNumber *)tag transerModel:(FileTranserModel *)transerModel
{
    [lblResult performSelectorOnMainThread:@selector(setText:) withObject:@"" waitUntilDone:YES];
    UITableViewCell *cell=[self getCellByDownURL:transerModel.downoadUrl];
    if(cell==nil)
    {
        [downinglist addObject:transerModel];
        [downingTableView insertRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:[downinglist count]-1 inSection:0]] withRowAnimation:UITableViewRowAnimationTop];
    }
     NSDictionary *dict=[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:transerModel,[self getCellByDownURL:transerModel.downoadUrl], nil] forKeys:[NSArray arrayWithObjects:@"File",@"Cell", nil]];
    [self performSelectorOnMainThread:@selector(updateCurrentDatalist:) withObject:transerModel waitUntilDone:YES];
    [self performSelectorOnMainThread:@selector(updateCellState:) withObject:dict waitUntilDone:YES];
}

-(void)fileTranserCancelTask:(NSNumber *)tag transerModel:(FileTranserModel *)transerModel
{
    [self updateCurrentDatalist:transerModel];
     NSDictionary *dict=[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:transerModel,[self getCellByDownURL:transerModel.downoadUrl], nil] forKeys:[NSArray arrayWithObjects:@"File",@"Cell", nil]];
    [self performSelectorOnMainThread:@selector(updateCellState:) withObject:dict waitUntilDone:YES];
}

-(void)fileTranserResponse:(NSNumber *)tag transerModel:(FileTranserModel *)transerModel
{
    [self updateCurrentDatalist:transerModel];
     NSDictionary *dict=[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:transerModel,[self getCellByDownURL:transerModel.downoadUrl], nil] forKeys:[NSArray arrayWithObjects:@"File",@"Cell", nil]];
    [self performSelectorOnMainThread:@selector(updateCellState:) withObject:dict waitUntilDone:YES];
}

-(void)fileTranserUpdateData:(NSNumber *)tag transerModel:(FileTranserModel *)transerModel
{
    [self updateCurrentDatalist:transerModel];
     NSDictionary *dict=[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:transerModel,[self getCellByDownURL:transerModel.downoadUrl], nil] forKeys:[NSArray arrayWithObjects:@"File",@"Cell", nil]];
    [self performSelectorOnMainThread:@selector(updateCellState:) withObject:dict waitUntilDone:YES];
}

-(void)fileTranserFinished:(NSNumber *)tag transerModel:(FileTranserModel *)transerModel
{
    [NSThread detachNewThreadSelector:@selector(loadDowningFiles) toTarget:self withObject:nil];
}

-(void)updateCurrentDatalist:(FileTranserModel *)newFile
{
    for(FileTranserModel *oldFile in downinglist)
    {
        if([oldFile.downoadUrl isEqualToString:newFile.downoadUrl])
        {
            oldFile.fileTrueSize=newFile.fileTrueSize;
            oldFile.progress=newFile.progress;
            oldFile.remainTime=newFile.remainTime;
            oldFile.fileTranserState=newFile.fileTranserState;
            oldFile.fileTmpSize=newFile.fileTmpSize;
            oldFile.fileTrueSize=newFile.fileTrueSize;
            oldFile.fileTranserState=newFile.fileTranserState;
            oldFile.errorCode=newFile.errorCode;
        }
    }
}

-(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState
{
    [downingTableView setCubeState:[cubeState intValue]];
}
@end
