//
//  HistoryDAL.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

typedef enum{
    HistoryToday=0,
    HistoryYeterday=1,
    HistoryWeek=2,
    HistoryMonth=3
} 
HistoryType;

#import <Foundation/Foundation.h>

#define kHistoryArchivePath [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"historylist"]

@class PageModel;

@interface HistoryDAL : NSObject

+(HistoryDAL *)sharedInstance;

-(void)insertOneHistory:(PageModel *)model;
-(NSMutableArray *)getHistorylist;
-(void)updateHistorylist:(NSMutableArray *)hislist;
-(void)clearHistory;

-(NSMutableArray *)getHistorylistByType:(HistoryType)type;
@end
