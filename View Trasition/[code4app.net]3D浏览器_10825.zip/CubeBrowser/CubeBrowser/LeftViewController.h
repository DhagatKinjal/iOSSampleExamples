//
//  LeftViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomSegmentController.h"
#import "EGORefreshTableHeaderView.h"
#import "CubeViewClickDelegate.h"
#import <iAd/ADBannerView.h>
#import "CustomNavBar.h"

@class CustomTableView;

@interface LeftViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,TypeClickDelegate,EGORefreshTableHeaderDelegate,UIAlertViewDelegate,ADBannerViewDelegate>
{
    BOOL isHistoryLoading;
    BOOL isFavLoading;
}

@property(nonatomic,retain)ADBannerView *adBannerView;
@property(nonatomic,assign)id<CubeViewClickDelegate>delegate;
@property(nonatomic,retain)CustomSegmentController *segmentController;
@property(nonatomic,retain)NSMutableArray *hislist;
@property(nonatomic,retain)NSMutableArray *favlist;
@property(nonatomic,retain)CustomTableView *hisTableView;
@property(nonatomic,retain)CustomTableView *favTableView;
@property(nonatomic,retain)EGORefreshTableHeaderView *hisHeaderView;
@property(nonatomic,retain)EGORefreshTableHeaderView *favHeaderView;

@end
