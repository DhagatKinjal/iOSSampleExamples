//
//  RightViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FileTranserHelper.h"
#import "GADBannerView.h"
#import "CubeViewClickDelegate.h"

@class CustomTableView;

@interface RightViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,FileTranserHelperDelegate>

@property(nonatomic,assign)id<CubeViewClickDelegate>delegate;
@end
