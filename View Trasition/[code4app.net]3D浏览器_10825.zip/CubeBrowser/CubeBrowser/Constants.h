
#define kIPad_horizontal_width 1024
#define kIpad_horizontal_height 748

#define k_iPad_Horizontal_Width 702
#define k_iPad_Horizontal_Height 704
#define k_iPad_Vertical_Width 768
#define k_iPad_Vertical_Height 960

#define k_Font_FamilyName @"Helvetica"
//#define k_Font_FamilyName @"Hiragino Sans GB"

#define NSUSERDEFAULTS  [NSUserDefaults standardUserDefaults]
#define APPDELEGATE (AppDelegate *)[[UIApplication sharedApplication]delegate]
#define k_Idiom [[UIDevice currentDevice] userInterfaceIdiom]

//程序的唯一标示字符串
#define APPGUIDKEY @"GUIDKEY"

//远程web的基础接口地址
#define BASEAPI @"/"
#define IMAGEAPI @""
//启动App Store的链接
#define kAPPSTOREURL @"http://itunes.apple.com/us/app/id%@"

//每页的Cell个数
#define kPageSize @"20"

//排序方式
#define k_order_Key @"order"
#define k_order_time @"time"//最新
#define k_order_down @"down"//热门

//评论的最大字数
#define MAXCOMMENTSIZE 180

//临时下载文件信息的归档地址
#define k_ArchiverPath   [[[[FileHelper getAppRootPath] stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"Downloading"] stringByAppendingPathComponent:@"tempFile"]

#define k_phone_view_width 320
#define k_phone_view_height 367

#define kPad_width 1024
#define kPad_height 748

//其它tableview的布局
#define kTABLEVIEWFRAME CGRectMake(0, 0, 320, 370)

#define kCATALOGTABLEFRAME CGRectMake(0, 32, k_phone_view_width, k_phone_view_height-32)

//Cell的圆滑四角的度数和宽度
#define kCELLBORDERWITH 1.0f
#define kCELLRADIUS 5.0f
#define K_CELL_BG @"cell_bg.png"
#define kCELLNOPICKEY @"noPicture.jpg"
#define kCELLMOREBUTTONKEY @"cell_btn_more.png"
#define K_CELL_FREE @"cell_free.png"
#define k_CELL_BOTTOM_BG @"cell_btn_bg.png"
#define k_Downlaod_error @"download_error.png"
#define k_DOWNLOAD_START @"download_start.png"
#define K_DOWNLOAD_PAUSE @"download_pause.png"
#define K_DOWNLOAD_ICON_PAUSE @"download_icon_pause.png"
#define k_DOWNLOAD_ICON_STARING @"download_icon_starting.png"
#define K_CELL_ICON @"loading.png"
#define k_SearchImage @"btn_search.png"
#define k_SearchImage_Pressed @"tbar_search_down.png"
#define k_btn_freedownload @"btn_freedown.png"
#define k_btn_freedownload_pressed @"btn_freedown_press.png"
#define k_btn_appStoredown @"btn_appStore_download.png"
#define k_btn_appStoredown_pressed @"btn_appStore_download_pressed.png"
#define k_btn_more @"btn_open.png"
#define k_btn_more_pressed @"btn_open_pressed.png"
#define k_btn_more_close @"btn_close.png"
#define k_btn_more_close_pressed @"btn_close_pressed.png"
#define k_cell_detail @"btn_rightdetail.png"
#define k_cell_detail_pressed @"btn_rightdetail_pressed.png"
#define k_bigWaiting @"big_cell_icon_wait.jpg"
#define k_btn_cancel @"btn_cancel.png"
#define k_nav_bg @"top_bg.png"
#define k_nav_back_bg @"tbar_back.png"
#define k_nav_back_pressed_bg @"tbar_back_down.png"
#define k_flash_waiting @"flash_loading.jpg"
#define k_cell_btn @"item_pop_btn_down.png"
#define k_cell_mask_list @"mask_list.png"
#define k_cell_mask_homt @"mask_home.png"
#define k_cell_mask_detail @"mask_detail.png"

//下载处的tableView布局
#define kDOWNTABLEFRAME CGRectMake(0, 32, k_phone_view_width, k_phone_view_height-32-49)//3个表格Frame

//Cell里文件名称大小
#define kCELLFILESIZE 16

//Cell里其它灰色字体大小
#define kCELLOTHERSIZE 12

//主页地址字符串
#define kHOMEURLSTRING @""
//*****************************Cell的布局设置****************

//Cell1的布局带星星的Cell
#define IMAGELOGOVIEWFRAME1 CGRectMake(5, 10, 64, 64)//图片Frame
#define k_Cell_Logo_Frame_iPad CGRectMake(5, 10, 80, 80)
#define TITLELABELFRAME1    CGRectMake(75, 15, 190, 20)//标题Frame
#define k_Cell_Title_Frame_iPad  CGRectMake(91, 10, 500, 25)
#define FREEIMGVIEWFRAME1   CGRectMake(260, 0, 25, 20)//是否免费的图标标志
#define k_Cell_Free_Vertical_Frame_iPad CGRectMake(k_phone_view_width*0.9, 0, 25, 20)
#define k_Cell_Free_horizontal_Frame_iPad CGRectMake(650, 0, 25, 20)
#define GRADELABELFRAME1    CGRectMake(155, 36, 100, 12)//等级评论次数
#define k_Cell_Grade_Frame_iPad  CGRectMake(155, 45, 120, 12)
#define VERSIONLABELFRAME1  CGRectMake(75, 50, 210, 12)//版本其它等信息标签
#define k_Cell_Version_Frame_iPad CGRectMake(91, 70, 500, 15)
#define APPDOWNBUTTONFRAMAE1 CGRectMake(9.5, 95, 94, 30)//app下载按钮的Frame
#define k_Cell_AppButton_Frame_iPad CGRectMake(k_phone_view_width*0.08, 120, 160, 45)
#define DETAILBUTTONFRAME1  CGRectMake(216.5,95, 90, 30)//详细信息按钮的Frame1
#define k_Cell_DetailButton_Frame CGRectMake(k_phone_view_width*0.72,120, 160, 45)
#define FREEDOWNBUTTONFRAME1    CGRectMake(113,95, 94, 30)//免费下载按钮的Frame
#define k_Cell_FreeButton_Frame_iPad CGRectMake(k_phone_view_width*0.40,120, 160, 45)
#define kGRADEFRAME     CGRectMake(75, 35, 120, 50)//整个星星的大小
#define k_Cell_Star_Frame_iPad CGRectMake(91, 45, 60, 20)
#define kDETAILBUTTONFRAME CGRectMake(275, 30, 34, 34)//最右侧详细信息按钮的大小
#define k_RightDetailButton_Frame_iPad CGRectMake(620, 10, 90, 77)
#define k_Cell_Button_BgView_Frame_iPad CGRectMake(0, 100, k_phone_view_width, 80)
#define k_Cell_Button_BgBiew_Frame_iPad2 CGRectMake(0, 110, k_phone_view_width, 80)

//正在下载Cell的布局
#define TITLELABELFRAME2 CGRectMake(70, 10, 140, 18)//标题Frame
#define SIZELABELFRAME2 CGRectMake(k_phone_view_width*0.85, 10, 100, 18)//文件大小
#define PROVIEWFRAME2 CGRectMake(67, 32, 200, 12)//进度条的Frame
#define STATEIMGVIEWFRAME2 CGRectMake(67, 50, 18, 18)//下载速度旁边的图片标志
#define SPEEDLABELFRAME2 CGRectMake(86, 52, 160, 12)//下载速度Frame
#define REMAINLABELFRAME2 CGRectMake(224, 44, 100, 30.0f)//剩余时间Frame
#define OPERATEBUTTONFRAME2 CGRectMake(280, 20, 30, 30)//暂停、播放按钮

//已下载的Cell布局
#define kFINISHEDFIRSTFRAME CGRectMake(70, 5, 150, 20)//第一行的Frame
#define kFINISHEDSECONDFRAME CGRectMake(70, 30, 200, 15)//第二行的Frame
#define kFINISHEDTHIRDFRAME CGRectMake(70, 50, 250, 15)//第三行Frame
#define kFINISHEDBUTTONFRAME CGRectMake(250, 20, 60, 30)//重装或者安装按钮Frame
#define kACTIVEVIEWFRAME CGRectMake(250, 20, 20, 20)

//已经安装的Cell布局
#define kINSTALLEDIMGFRAME CGRectMake(5, 5, 60, 60)//Icon Frame
#define kINSTALLEDFIRSTFRAME CGRectMake(70, 5, 180, 15)//第一行的Frame
#define kINSTALLEDSECONDFRAME CGRectMake(70, 22, 180, 22)//第二行的Frame
#define kINSTALLEDTHIRDFRAME CGRectMake(70, 45, 200, 20)//第三行的Frame
#define kINSTALLEDUPDATEFRAME CGRectMake(220, 20, 60, 30)//升级按钮Frame

//*****************************更多模块里的常量字段*******************

//更多模块里的Cell的标题高宽
#define MOREFONT 16
#define MORETITLEFRAME CGRectMake(30, 8, 200, 30)
#define k_SETTING_TITLE CGRectMake(55, 10, 260, 25)
#define k_More_Switch_Frame_iPad  CGRectMake(350, 15, 80, 30)
#define k_More_Switch_Frame_iPad4 CGRectMake(350, 15, 80, 30)
#define MORESWITCHFRAME CGRectMake(220, 8, 80, 30)
#define MORESWITCHFRAME4 CGRectMake(210	, 8, 80, 30)
#define k_MORE_IMGGRAME CGRectMake(20, 10, 25, 25)

//无线分享软件
#define WIFISHAREKEY @"WifiShare"

//同时下载任务数
#define DOWNINGCOUNTKEY @"DowningCount"

//安装后删除按转包
#define DELETESOURCEAFTERINSTALLKEY @"DeleteSouceAfterInstall"

//下载完后自动安装
#define AUTOINSTALLKEY @"AutoInstall"

//下载时禁止自动锁屏
#define FORBIDLOCKKEY @"ForbidLock"

//清理下载缓存
#define CLEARTMPKEY @"ClearTmp"

//更新气泡提示
#define UPDATENOTIFYKEY @"UpdateNotify"



#define kDetailViewWidth 481
#define kDetailViewFrame CGRectMake(0, 0, kDetailViewWidth, 748)
#define kDetailRightViewFrame CGRectMake(57, 0, 424, 748)
