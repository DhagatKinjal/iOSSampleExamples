//
//  PageModel.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-8-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PageModel : NSObject<NSCoding,NSCopying>

@property(nonatomic,retain)NSString *pageTitle;
@property(nonatomic,retain)NSString *pageIconURL;
@property(nonatomic,retain)NSString *pageURL;
@property(nonatomic,retain)NSString *pageContent;
@property(nonatomic,retain)NSDate *creationDate;

@end
