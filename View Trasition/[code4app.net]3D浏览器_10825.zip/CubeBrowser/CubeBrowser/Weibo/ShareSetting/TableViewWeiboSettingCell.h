//
//  TableViewSettingCell.h
//  CMClient
//
//  Created by wu zhikun on 11-12-23.
//  Copyright (c) 2011年 foread. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewWeiboSettingCell : UITableViewCell{
    UILabel *labelTip;
    UILabel *labelDetail;
    UISwitch *switchSetting;
}

@property (nonatomic, readonly) UIImageView *imageViewIcon;
@property (nonatomic, readonly) UILabel *labelTip;
@property (nonatomic, readonly) UILabel *labelDetail;
@property (nonatomic, readonly) UISwitch *switchSetting;
@end
