//
//  CubeView.h
//  Cube
//  由于每次旋转后要通知视图，所以请把出入的视图控制器里实现如下的方法
//  -(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState
//  
//  Created by 国翔 韩 on 12-7-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//



#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "UIViewController+CubeStateChanged.h"
#import "CubeConstants.h"

@interface CubeView : UIView<UIAccelerometerDelegate>
{
    AreaLocation pointLocation;//手指的落点
    SwipeDirection swipeDirection;//手指滑动的方向
   
    CGFloat currentDegree;//记录当前转过的角度
    CGPoint prePoint;//计算实时的方向
    CGPoint startPoint;//计算滑动的位置比例
    CGFloat movedPath;//转动的界限判断----手指划过的位移,判断是否要恢复到之前的位置还是要旋转到下一个位置
    BOOL isMoving;//是否正在旋转过程中，此时禁止垂直方向滑动
    NSDate *firstDate;
    NSDate *lastDate;
    float preX;
    float preY;
    
    BOOL isRotate;//是否正在晃动翻转
}

@property(nonatomic,assign) CubeState cubeState;
@property(nonatomic,retain) NSArray *viewlist;//6个控制器，顺序为上、中、下、左、右、后

@property(nonatomic,assign)float viewWidth;
@property(nonatomic,assign)float viewHeight;

//正方体的6个视图
@property(nonatomic,retain) UIViewController  *frontViewController;
@property(nonatomic,retain) UIViewController  *topViewController;
@property(nonatomic,retain) UIViewController  *bottomViewController;
@property(nonatomic,retain) UIViewController  *leftViewContorller;
@property(nonatomic,retain) UIViewController  *rightViewController;
@property(nonatomic,retain) UIViewController  *backViewController;

-(void)reloadViewControllers;
-(void)rotateCubeWithDirection:(SwipeDirection)_swipeDirection rotatedDegree:(float)rotatedDegree;
-(void)showViewController:(NSNumber *)cubeState;

@end
