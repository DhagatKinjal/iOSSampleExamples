//
//  UIToolbar+BackImage.m
//  -巴士商店-
//
//  Created by peng wang on 12-3-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIToolbar+BackImage.h"

@implementation UIToolbar (BackImage)

- (void)drawRect:(CGRect)rect {  
    UIImage *image = [UIImage imageNamed: @"station_tab.png"];  
    [image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height+4)];  
}  
@end
