//
//  FilelistViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CubeConstants.h"
#import "MBProgressHUD.h"

@class FileTypeModel;

@interface FilelistViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MBProgressHUDDelegate>

-(id)initWithFileType:(FileTypeModel *)fileType;
@end
