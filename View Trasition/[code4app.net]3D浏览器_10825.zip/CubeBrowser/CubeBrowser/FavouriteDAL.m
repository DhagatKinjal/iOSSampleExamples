//
//  FavouriteDAL.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FavouriteDAL.h"
#import "PageModel.h"
#import "ArchiverHelper.h"

#define kFavouriteArchivePath [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"favouritelist"]
static FavouriteDAL *instance;

@implementation FavouriteDAL

+(FavouriteDAL *)sharedInstance
{
    if(instance==nil)
    {
        instance=[[FavouriteDAL alloc] init];
    }
    return instance;
}

-(void)dealloc
{
    [instance release];
    instance=nil;
    [super dealloc];
}

-(BOOL)isAdded:(NSString *)url
{
    NSMutableArray *tmplist=[self getFavouritelist];
    for(PageModel *page in tmplist)
    {
        if([page.pageURL isEqualToString:url])
        {
            return YES;
        }
    }
    return NO;
}

-(void)insertOneFavourite:(id)model
{
//    if([self isAdded:((PageModel *)model).pageURL])
//    {
//        return;
//    }
    NSMutableArray *historylist=[[ArchiverHelper sharedInstance] getObjectByPath:kFavouriteArchivePath];
    if(historylist==nil)
    {
        historylist=[[[NSMutableArray alloc] init] autorelease];
    }
    [historylist addObject:model];
    [[ArchiverHelper sharedInstance] archiveObject:historylist ByPath:kFavouriteArchivePath];
}

-(NSMutableArray *)getFavouritelist
{
    NSMutableArray *tmplist=[[ArchiverHelper sharedInstance] getObjectByPath:kFavouriteArchivePath];
    NSSortDescriptor *sortDescri=[NSSortDescriptor sortDescriptorWithKey:@"pageURL" ascending:NO];
    tmplist=[NSMutableArray arrayWithArray:[tmplist sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescri]]];
    return tmplist;
}

-(void)updateFavouritelist:(NSMutableArray *)favlist
{
    [[ArchiverHelper sharedInstance] archiveObject:favlist ByPath:kFavouriteArchivePath];
}

-(void)clearFavourite
{
    NSFileManager *fileManager=[NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:kFavouriteArchivePath])
    {
        [fileManager removeItemAtPath:kFavouriteArchivePath error:nil];
    }
}
@end
