//
//  FileTypeCell.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FileTypeCell : UITableViewCell

@property(nonatomic,retain)UIImageView *fileImageView;
@property(nonatomic,retain)UILabel *lblFileName;
@property(nonatomic,retain)UILabel *lblFileDetail;
@end
