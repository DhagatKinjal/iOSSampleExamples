//
//  CustomWebView.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-8-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CustomWebView.h"

@implementation CustomWebView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    CGFloat touchWidth=20;
//    CGFloat touchHeight=70;
    CGRect leftRect=CGRectMake(0, 0, touchWidth, self.frame.size.height);
    if(CGRectContainsPoint(leftRect, point))
    {
        return NO;
    }
    
    CGRect rightRect=CGRectMake(self.frame.size.width-touchWidth, 0, touchWidth, self.frame.size.height);
    if(CGRectContainsPoint(rightRect, point))
    {
        return NO;
    }
    return YES;
}
@end
