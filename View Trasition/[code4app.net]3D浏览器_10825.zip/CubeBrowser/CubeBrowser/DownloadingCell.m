//
//  DownloadingCell.m
//  IphoneReader
//
//  Created by Han Guoxiang on 12-6-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "DownloadingCell.h"
#import "Constants.h"

@implementation DownloadingCell

@synthesize fileImage;
@synthesize maskImgView;
@synthesize fileNameLabel;
@synthesize fileSizeLabel;
@synthesize proView;
@synthesize operateButton;
@synthesize stateLabel;
@synthesize stateImgView;
@synthesize remainTimeLabel;

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //文件图片
        fileImage=[[UIImageView alloc] init];
        [fileImage setTag:505];
        [fileImage setFrame:CGRectMake(5, 5, 60, 63)];
        [fileImage setImage:[UIImage imageNamed:@"down_Icon.png"]];
        [self.contentView addSubview:fileImage];
        
        //文件图片的遮罩
        maskImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:k_cell_mask_list]];
        [maskImgView setFrame:CGRectMake(5, 5, 60, 60)];
        [self.contentView addSubview:maskImgView];
        
        //文件名称
        fileNameLabel=[[UILabel alloc] init];
        [fileNameLabel setFrame:TITLELABELFRAME2];
        [fileNameLabel setFont:[UIFont fontWithName:k_Font_FamilyName size:15]];
        [fileNameLabel setFont:[UIFont boldSystemFontOfSize:15]];
        [fileNameLabel setTag:506];
        [fileNameLabel setBackgroundColor:[UIColor clearColor]];
        [fileNameLabel setTextColor:[UIColor colorWithRed:52/255.0 green:58/255.0 blue:73/255.0 alpha:1.0f]];
        [self.contentView addSubview:fileNameLabel];

        //文件大小
        fileSizeLabel=[[UILabel alloc] init];
        [fileSizeLabel setFrame:CGRectMake(k_phone_view_width*0.70, 12, 100, 12)];
        [fileSizeLabel setTag:507];
        [fileSizeLabel setTextColor:DetailLabelTextColor];
        [fileSizeLabel setBackgroundColor:[UIColor clearColor]];
        [fileSizeLabel setFont:[UIFont fontWithName:@"Helvetica" size:12.0]];
        [self.contentView addSubview:fileSizeLabel];
        
        //进度条
//        proView=[[DDProgressView alloc]init];
//        [proView setFrame:PROVIEWFRAME2];
//        [proView setOuterColor: [UIColor clearColor]];
//        [proView setInnerColor: [UIColor colorWithPatternImage:[UIImage imageNamed:@"progress_bar_bg.png"]]];
////        [proView setEmptyColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"progressBar_EmptyBg.png"]]];
//        [proView setEmptyColor:[UIColor lightGrayColor]];
//        [self.contentView addSubview:proView];
        
        proView=[[UIProgressView alloc]init];
        [proView setFrame:PROVIEWFRAME2];
        [self.contentView addSubview:proView];
        
        //暂停、继续按钮
        operateButton=[[UIButton alloc] init];
        [operateButton setFrame:OPERATEBUTTONFRAME2];
        [operateButton setTag:504];
        [operateButton setBackgroundImage:[UIImage imageNamed:k_DOWNLOAD_START] forState:UIControlStateNormal];
        [self.contentView addSubview:operateButton];
        
        //下载状态的图片和标签
        stateImgView=[[UIImageView alloc] init];
        [stateImgView setFrame:STATEIMGVIEWFRAME2];
        [stateImgView setTag:500];
        [stateImgView setImage:[UIImage imageNamed:K_DOWNLOAD_ICON_PAUSE]];
        [self.contentView addSubview:stateImgView];

        stateLabel=[[UILabel alloc] init];
        [stateLabel setFrame:SPEEDLABELFRAME2];
        [stateLabel setFont:[UIFont fontWithName:@"Helvetica" size:12.0]];
        [stateLabel setBackgroundColor:[UIColor clearColor]];
        [stateLabel setTextColor:DetailLabelTextColor];
        [stateLabel setTag:501];
        [self.contentView addSubview:stateLabel];
        
        remainTimeLabel=[[UILabel alloc] init];
        [remainTimeLabel setFrame:REMAINLABELFRAME2];
        [remainTimeLabel setText:@""];
        [remainTimeLabel setTag:502];
        [remainTimeLabel setBackgroundColor:[UIColor clearColor]];
        [remainTimeLabel setFont:[UIFont fontWithName:@"Helvetica" size:12.0]];
        [remainTimeLabel setTextColor:DetailLabelTextColor];
        [self.contentView addSubview:remainTimeLabel];
        
        UIImageView *bgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:K_CELL_BG]];
        [self setBackgroundView:bgView];
        [bgView release];

        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        
        if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPad)
        {            
            fileImage.frame= CGRectMake(7, 7, 70, 70);
            maskImgView.frame= CGRectMake(fileImage.frame.origin.x, fileImage.frame.origin.y, fileImage.frame.size.width, fileImage.frame.size.height);
            [fileNameLabel setFrame:CGRectMake(91, 10, 210, 25)];
            [fileNameLabel setFont:[UIFont fontWithName:k_Font_FamilyName size:17]];
            [fileNameLabel setFont:[UIFont boldSystemFontOfSize:17]];
            [fileSizeLabel setFrame:CGRectMake(300, fileNameLabel.frame.origin.y, 100, 14)];
            [fileSizeLabel setFont:[UIFont fontWithName:k_Font_FamilyName size:14]];
            [proView setFrame:CGRectMake(fileNameLabel.frame.origin.x,fileNameLabel.frame.origin.y+fileNameLabel.frame.size.height+5,260,12)];
            [stateImgView setFrame:CGRectMake(fileNameLabel.frame.origin.x,proView.frame.origin.y+proView.frame.size.height+8,16,16)];
            [stateImgView setImage:[UIImage imageNamed:@"ipad_download_pause_small.png"]];
            [stateLabel setFrame:CGRectMake(stateImgView.frame.origin.x+stateImgView.frame.size.width,proView.frame.origin.y+proView.frame.size.height+8,150,14)];
            [stateLabel setFont:[UIFont fontWithName:k_Font_FamilyName size:14]];
            [operateButton setFrame:CGRectMake(355, proView.frame.origin.y-23, 59, 55)];
            [operateButton setBackgroundImage:[UIImage imageNamed:@"ipad_download_start.png"] forState:UIControlStateNormal];
            [remainTimeLabel setFrame:CGRectMake(300, stateLabel.frame.origin.y, 130, 14)];
            [remainTimeLabel setFont:[UIFont fontWithName:k_Font_FamilyName size:14]];
        }
    }
    return self;
}

-(void)dealloc
{
    self.fileImage=nil;
    self.maskImgView=nil;
    self.fileNameLabel=nil;
    self.fileSizeLabel=nil;
    self.proView=nil;
    self.operateButton=nil;
    self.stateImgView=nil;
    self.stateLabel=nil;
    self.remainTimeLabel=nil;
    [super dealloc];
}

//0-正常 1-出现左边的删除符号 2-出现右边的删除按钮 3-1和2同时出现
-(void)willTransitionToState:(UITableViewCellStateMask)state
{
//    NSLog(@"%d",state);
    [super willTransitionToState:state];
    switch (state) {
        case 1:
            [self setDoneDelegateNormal];
            [operateButton setHidden:!operateButton.isHidden];
            break;
        case 2:
            [self setMoveDeleteState];
            break;
        case 3:
            [self setClickDelegateState];
            break;
        default:
            break;
    }
}

-(void)setDoneDelegateNormal//结束整个表格的编辑
{
    [UIView beginAnimations:nil context:nil];
    [fileImage setFrame:CGRectMake(fileImage.frame.origin.x, fileImage.frame.origin.y, fileImage.frame.size.width, fileImage.frame.size.height)];
    [maskImgView setFrame:CGRectMake(maskImgView.frame.origin.x, maskImgView.frame.origin.y, maskImgView.frame.size.width, maskImgView.frame.size.height)];
    [stateImgView setFrame:CGRectMake(stateImgView.frame.origin.x, stateImgView.frame.origin.y, stateImgView.frame.size.width, stateImgView.frame.size.height)];
    [stateLabel setFrame:CGRectMake(stateLabel.frame.origin.x, stateLabel.frame.origin.y, stateLabel.frame.size.width, stateLabel.frame.size.height)];
     [operateButton setHidden:NO];
    if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPad)
    {
        [fileNameLabel setFrame:CGRectMake(91, 10, 210, 25)];
        [fileSizeLabel setFrame:CGRectMake(300, fileNameLabel.frame.origin.y, 100, 14)];
        [proView setFrame:CGRectMake(fileNameLabel.frame.origin.x,fileNameLabel.frame.origin.y+fileNameLabel.frame.size.height+5,260,proView.frame.size.height)];
        [operateButton setFrame:CGRectMake(355, proView.frame.origin.y-23, 59, 55)];
        [remainTimeLabel setFrame:CGRectMake(300, stateLabel.frame.origin.y, 130, 14)];
    }
    else
    {
        [fileNameLabel setFrame:TITLELABELFRAME2];
        [fileSizeLabel setFrame:CGRectMake(k_phone_view_width*0.70, 12, 100, 12)];
        [proView setFrame:PROVIEWFRAME2];
        [operateButton setFrame:OPERATEBUTTONFRAME2];
        [remainTimeLabel setFrame:REMAINLABELFRAME2];
    }
    [UIView commitAnimations];
}

-(void)setMoveDeleteState
{
    [UIView beginAnimations:nil context:nil];
    CGFloat gap=20;
    [fileImage setFrame:CGRectMake(fileImage.frame.origin.x, fileImage.frame.origin.y, fileImage.frame.size.width, fileImage.frame.size.height)];
    [maskImgView setFrame:CGRectMake(maskImgView.frame.origin.x, maskImgView.frame.origin.y, maskImgView.frame.size.width, maskImgView.frame.size.height)];
    [fileNameLabel setFrame:CGRectMake(fileNameLabel.frame.origin.x, fileNameLabel.frame.origin.y, fileNameLabel.frame.size.width-gap, fileNameLabel.frame.size.height)];
    [fileSizeLabel setFrame:CGRectMake(fileSizeLabel.frame.origin.x-gap, fileSizeLabel.frame.origin.y, fileSizeLabel.frame.size.width, fileSizeLabel.frame.size.height)];
    [proView setFrame:CGRectMake(proView.frame.origin.x, proView.frame.origin.y, proView.frame.size.width-gap, proView.frame.size.height)];
    [operateButton setHidden:YES];
    [stateImgView setFrame:CGRectMake(stateImgView.frame.origin.x, stateImgView.frame.origin.y, stateImgView.frame.size.width, stateImgView.frame.size.height)];
    [stateLabel setFrame:CGRectMake(stateLabel.frame.origin.x, stateLabel.frame.origin.y, stateLabel.frame.size.width, stateLabel.frame.size.height)];
    [remainTimeLabel setFrame:CGRectMake(remainTimeLabel.frame.origin.x-gap, remainTimeLabel.frame.origin.y, remainTimeLabel.frame.size.width, remainTimeLabel.frame.size.height)];
    [UIView commitAnimations];
}

-(void)setClickDelegateState
{
    [UIView beginAnimations:nil context:nil];
    CGFloat gap=40;
    [fileImage setFrame:CGRectMake(fileImage.frame.origin.x, fileImage.frame.origin.y, fileImage.frame.size.width, fileImage.frame.size.height)];
    [maskImgView setFrame:CGRectMake(maskImgView.frame.origin.x, maskImgView.frame.origin.y, maskImgView.frame.size.width, maskImgView.frame.size.height)];
    [fileNameLabel setFrame:CGRectMake(fileNameLabel.frame.origin.x, fileNameLabel.frame.origin.y, fileNameLabel.frame.size.width-gap, fileNameLabel.frame.size.height)];
    [fileSizeLabel setFrame:CGRectMake(fileSizeLabel.frame.origin.x-gap, fileSizeLabel.frame.origin.y, fileSizeLabel.frame.size.width, fileSizeLabel.frame.size.height)];
    [proView setFrame:CGRectMake(proView.frame.origin.x, proView.frame.origin.y, proView.frame.size.width-gap, proView.frame.size.height)];
    [operateButton setHidden:YES];
    [stateImgView setFrame:CGRectMake(stateImgView.frame.origin.x, stateImgView.frame.origin.y, stateImgView.frame.size.width, stateImgView.frame.size.height)];
    [stateLabel setFrame:CGRectMake(stateLabel.frame.origin.x, stateLabel.frame.origin.y, stateLabel.frame.size.width, stateLabel.frame.size.height)];
    [remainTimeLabel setFrame:CGRectMake(remainTimeLabel.frame.origin.x-gap, remainTimeLabel.frame.origin.y, remainTimeLabel.frame.size.width, remainTimeLabel.frame.size.height)];
    [UIView commitAnimations];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
