//
//  CubeView.m
//  Cube
//
//  Created by 国翔 韩 on 12-7-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CubeView.h"
#import "SettingDAL.h"

@interface CubeView () {
    float _m34;
    float _verticalPointZ;
    float _horizontalPointZ;
}

-(BOOL)canMove:(CubeState)_cubeState pointLocation:(AreaLocation)_pointLocation;//手指落在的区域是否有响应
-(BOOL)isRightDirection:(CubeState)_cubeState swipDirection:(SwipeDirection)swipDirection;
@end

//#define _m34 -0.0005
//#define _verticalPointZ -510
//#define _horizontalPointZ -380
//#define kMini 25
//#define kMax 5
//#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)

@implementation CubeView

@synthesize cubeState;
@synthesize viewlist;
@synthesize viewWidth,viewHeight;
@synthesize frontViewController,topViewController,bottomViewController,leftViewContorller,rightViewController,backViewController;

-(id)init
{
    self=[super init];
    if(self)
    {
        if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPhone)
        {
            viewHeight=480;
            viewWidth=320;
            _verticalPointZ=-240;
            _horizontalPointZ=-160;
            _m34=-0.001;
        }
        else {
            _m34=-0.0006;
            viewHeight=1024;
            viewWidth=768;
            _verticalPointZ=-512;
            _horizontalPointZ=-384;
        }
    }
    return self;
}

-(void)swipeGestureAction:(UIGestureRecognizer *)sender
{
    NSLog(@"23");
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        viewWidth=frame.size.width;
        viewHeight=frame.size.height;
        
//        UISwipeGestureRecognizer *downGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureAction:)];
//        [downGesture setDirection:UISwipeGestureRecognizerDirectionDown];
//        
//        UISwipeGestureRecognizer *upGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureAction:)];
//        [upGesture setDirection:UISwipeGestureRecognizerDirectionUp];
//        
//        UISwipeGestureRecognizer *leftGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureAction:)];
//        [leftGesture setDirection:UISwipeGestureRecognizerDirectionLeft];
//        
//        UISwipeGestureRecognizer *rightGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureAction:)];
//        [rightGesture setDirection:UISwipeGestureRecognizerDirectionRight];
//        
//        [self addGestureRecognizer:downGesture];
//        [self addGestureRecognizer:upGesture];
//        [self addGestureRecognizer:leftGesture];
//        [self addGestureRecognizer:rightGesture];
//        [upGesture release];
//        [leftGesture release];
//        [rightGesture release];
//        [downGesture release];


        
        UIAccelerometer *accel=[UIAccelerometer sharedAccelerometer];
        accel.delegate=self;
        accel.updateInterval=1/10.0f;
    }
    return self;
}

-(void)dealloc
{
    self.viewlist=nil;
    self.frontViewController=nil;
    self.backViewController=nil;
    self.topViewController=nil;
    self.bottomViewController=nil;
    self.leftViewContorller=nil;
    self.rightViewController=nil;
    [super dealloc];
}

-(void)reloadViewControllers
{
    for(UIView *subView in [self subviews])
    {
        [subView removeFromSuperview];
    }
    
    //上面
    self.topViewController=[viewlist objectAtIndex:0];
    [self.topViewController.view setFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    [self.topViewController.view  setBackgroundColor:[UIColor blueColor]];
    [self addSubview:self.topViewController.view];
    
    
    //下面
    self.bottomViewController=[viewlist objectAtIndex:2];
    [self.bottomViewController.view setFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    [self.bottomViewController.view setBackgroundColor:[UIColor yellowColor]];
    [self addSubview:self.bottomViewController.view];

    
    
    //右边
    self.rightViewController=[viewlist objectAtIndex:4];
    [self.rightViewController.view setFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    [self.rightViewController.view setBackgroundColor:[UIColor redColor]];
    [self addSubview:self.rightViewController.view];

    
    //左边
    self.leftViewContorller=[viewlist objectAtIndex:3];
    [self.leftViewContorller.view setFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    [self.leftViewContorller.view setBackgroundColor:[UIColor orangeColor]];
    [self addSubview:self.leftViewContorller.view];
    
    
    
    //前面
    self.frontViewController=[viewlist objectAtIndex:1];
    [self.frontViewController.view setFrame:CGRectMake(0, 0, viewWidth, viewHeight)];
    [self.frontViewController.view setBackgroundColor:[UIColor darkGrayColor]];
    [self addSubview:self.frontViewController.view];
    
    cubeState=CubeFrontState;
    currentDegree=0;
    
    [self rotateCubeWithDirection:SwipeBottomToTopDirection rotatedDegree:currentDegree];
    [self rotateCubeWithDirection:SwipeLeftToRightDirection rotatedDegree:currentDegree];
//    [self rotateCubeWithDirection:SwipeLeftToRightDirection rotatedDegree:40];
}

-(void)rotateCubeWithDirection:(SwipeDirection)_swipeDirection rotatedDegree:(float)rotatedDegree
{
    
    if(_swipeDirection==SwipeBottomToTopDirection||_swipeDirection==SwipeTopToBottomDirection)
    {
        [leftViewContorller.view setHidden:YES];
        [rightViewController.view setHidden:YES];
        [topViewController.view setHidden:NO];
        [bottomViewController.view setHidden:NO];
        
        //正面视图旋转
        CATransform3D frontTransform3D=CATransform3DIdentity;
        frontTransform3D.m34=_m34;
        frontTransform3D=CATransform3DTranslate(frontTransform3D, 1, 0, _verticalPointZ);
        frontTransform3D=CATransform3DRotate(frontTransform3D, DEGREES_TO_RADIANS(rotatedDegree), 1, 0, 0);
        self.frontViewController.view.layer.anchorPointZ=_verticalPointZ;
        self.frontViewController.view.layer.transform=frontTransform3D;
        
        
        //顶部视图
        CATransform3D topTransform3D=CATransform3DIdentity;
        topTransform3D.m34=_m34;
        topTransform3D=CATransform3DTranslate(topTransform3D, 1, 0, _verticalPointZ);
        topTransform3D=CATransform3DRotate(topTransform3D, DEGREES_TO_RADIANS(rotatedDegree)+M_PI_2, 1, 0, 0);
        self.topViewController.view.layer.anchorPointZ=_verticalPointZ;
        self.topViewController.view.layer.transform=topTransform3D;

        //底部视图
        CATransform3D bottomTransform3D=CATransform3DIdentity;
        bottomTransform3D.m34=_m34;
        bottomTransform3D=CATransform3DTranslate(bottomTransform3D, 1, 0, _verticalPointZ);
        bottomTransform3D=CATransform3DRotate(bottomTransform3D, DEGREES_TO_RADIANS(rotatedDegree)-M_PI_2, 1, 0, 0);
        self.bottomViewController.view.layer.anchorPointZ=_verticalPointZ;
        self.bottomViewController.view.layer.transform=bottomTransform3D;
    }
    if(_swipeDirection==SwipeLeftToRightDirection||_swipeDirection==SwipeRightToLeftDirection)
    {
        [leftViewContorller.view setHidden:NO];
        [rightViewController.view setHidden:NO];
        [topViewController.view setHidden:YES];
        [bottomViewController.view setHidden:YES];
        
        
        //正面
        CATransform3D frontTransform3D=CATransform3DIdentity;
        frontTransform3D.m34=_m34;
        frontTransform3D=CATransform3DTranslate(frontTransform3D, 0, 0, _horizontalPointZ);
        frontTransform3D=CATransform3DRotate(frontTransform3D, DEGREES_TO_RADIANS(rotatedDegree), 0, 1, 0);
        frontViewController.view.layer.anchorPointZ=_horizontalPointZ;
        frontViewController.view.layer.transform=frontTransform3D;
        
        
        //左侧
        CATransform3D leftTransform3D=CATransform3DIdentity;
        leftTransform3D.m34=_m34;
        leftTransform3D=CATransform3DTranslate(leftTransform3D, 0, 0, _horizontalPointZ);
        leftTransform3D=CATransform3DRotate(leftTransform3D, DEGREES_TO_RADIANS(rotatedDegree)-M_PI_2, 0, 1, 0);
        self.leftViewContorller.view.layer.anchorPointZ=_horizontalPointZ;
        self.leftViewContorller.view.layer.transform=leftTransform3D;
        
        
        //右侧
        CATransform3D rightTransform3D=CATransform3DIdentity;
        rightTransform3D.m34=_m34;
        rightTransform3D=CATransform3DTranslate(rightTransform3D, 0, 0, _horizontalPointZ);
        rightTransform3D=CATransform3DRotate(rightTransform3D, DEGREES_TO_RADIANS(rotatedDegree)+M_PI_2, 0, 1, 0);
        self.rightViewController.view.layer.anchorPointZ=_horizontalPointZ;
        self.rightViewController.view.layer.transform=rightTransform3D;
    }
}

//在当前正方体的状态下，手指滑动是否有响应,即落点是否在可以滑动的区域内
-(BOOL)canMove:(CubeState)_cubeState pointLocation:(AreaLocation)_pointLocation
{
//    NSLog(@"cubeState=%d",_cubeState);
    if(_cubeState==CubeFrontState)
    {
        //落点在上下左右区域即可
        if(_pointLocation==AreaBottomLocation||_pointLocation==AreaTopLocation||_pointLocation==AreaRightLocation||_pointLocation==AreaLeftLocation)
        {
            return YES;
        }
    }
    
    if(_cubeState==CubeTopState)
    {
        if(_pointLocation==AreaBottomLocation)
        {
            return YES;
        }
    }
    
    if(_cubeState==CubeBottomState)
    {
        if(_pointLocation==AreaTopLocation||_pointLocation==AreaLeftLocation||_pointLocation==AreaRightLocation)
        {
            return YES;
        }
    }
    
    //左侧对着用户,落点只能在右侧才能响应
    if(_cubeState==CubeLeftState)
    {
        if(_pointLocation==AreaRightLocation)
        {
            return YES;
        }
    }
    //右侧对着用户,落点只能再左侧才能响应
    if(_cubeState==CubeRightState)
    {
        if(_pointLocation==AreaLeftLocation)
        {
            return YES;
        }
    }
    if(_cubeState==CubeOtherState)//??
    {
        return NO;
    }
    return NO;
}

//320*480
-(int)getPointLocation:(float)x y:(float)y
{
    float totalHeight=viewHeight;
    float totalWidth=viewWidth;
    
    //手指有感应的区域高和宽
    float targetWidth=kResponseWidth;
    float targetHeight=kResponseHeight;
    if((x>targetWidth&&x<totalWidth-targetWidth))
    {
        if(y>0&&y<targetHeight)//顶部感应区域
        {
            return AreaTopLocation;
        }
        if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPad)
        {
            totalHeight=1024;
        }
        if((y>(totalHeight-targetHeight))&&y<totalHeight)//底部感应区
        {
            return AreaBottomLocation;
        }
    }
    if(y>targetHeight&&y<totalHeight)
    {
        if(x>0&&x<targetWidth)//左侧感应区
        {
            return AreaLeftLocation;
        }
        if((x>(totalWidth-targetWidth))&&x<totalWidth)//右侧感应区
        {
            return AreaRightLocation;
        }
    }
    return AreaOtherLocation;//其它无效感应区域
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    firstDate=[NSDate date];
//    for(UIViewController *vcController in  viewlist)
//    {
//        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(showViewController:) object:[NSNumber numberWithInt:(int)cubeState]];
//        [vcController viewWillAppear:NO];
//    }
    startPoint=[[touches anyObject] locationInView:self];
    
    //初始化信息,得到手指的落点
    pointLocation=(AreaLocation)[self getPointLocation:startPoint.x y:startPoint.y];
    
    if(![self canMove:cubeState pointLocation:pointLocation])
    {
        return;
    }
    swipeDirection=SwipeOtherDirectionDirection;
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"========================,底层的cubeview控件接收了滑动--------------");
    CGPoint endPoint=[[touches anyObject] locationInView:self];
    //通过位移的比例计算转过的角度
    CGFloat movedX=endPoint.x-startPoint.x;
    CGFloat movedY=endPoint.y-startPoint.y;

    //判断手指落点和滑动是否有响应
    if(![self canMove:cubeState pointLocation:pointLocation])
    {
        prePoint=endPoint;
        return;
    }
    prePoint=endPoint;
  
    //确定滑动的方向,并且检查正方体的状态
    if(swipeDirection==SwipeOtherDirectionDirection)
    {
        //左右滑动
        if(fabsf(movedX)>=kMax&&fabsf(movedY)<=kMini)
        {
            if(movedX>0)//向右滑动
            {
                swipeDirection=SwipeLeftToRightDirection;
            }
            if(movedX<0)//向左滑动
            {
                swipeDirection=SwipeRightToLeftDirection;
            }
        }
        
        //上下滑动
        if(fabsf(movedX)<=kMini && fabsf(movedY)>=kMax)
        {
            if(movedY>0)//向下滑动
            {
                swipeDirection=SwipeTopToBottomDirection;
            }
            if(movedY<0)//向上滑动
            {
                swipeDirection=SwipeBottomToTopDirection;
            }
        }
    }

    //如果哪个方向也不是，则不进行任何处理
    if(swipeDirection==SwipeOtherDirectionDirection)
    {
        return;
    }
    
    //根据滑动的距离对相应的视图进行变换
    //这里注意。判断滑动的开始度数要根据 方向和正方体当前的状态 2个条件得出起始角度
    //以前视图为参照物确定反反翻转的角度
    switch (cubeState) {
        case CubeFrontState:
            //如果是上下滑动，则计算Y，不理会X
            if (swipeDirection==SwipeTopToBottomDirection||swipeDirection==SwipeBottomToTopDirection) {
                 currentDegree=-90* (movedY /viewHeight);
                movedPath=movedY;
            }
            //如果是水平滑动，则计算X，不理会Y
            if(swipeDirection==SwipeLeftToRightDirection||swipeDirection==SwipeRightToLeftDirection)
            {
                 currentDegree=90* (movedX /viewWidth);
                movedPath=movedX;
            }
            break;
        case CubeTopState:
            //如果是上下滑动，则计算Y，不理会X
            switch (swipeDirection) {
                case SwipeBottomToTopDirection:
                    currentDegree=-90* (movedY /viewHeight)-90;
                    movedPath=movedY;
                    break;
                default:
                    return;
            }

            break;
        case CubeBottomState:
            switch (swipeDirection) {
                case SwipeTopToBottomDirection:
                    currentDegree=90-90* (fabsf(movedY) /viewHeight);
                    movedPath=movedY;
                    break;
                default:
                    return;
            }
            break;
        case CubeRightState:
            switch (swipeDirection) {
                case SwipeLeftToRightDirection:
                    currentDegree=90* (movedX /viewWidth)-90;
                    movedPath=movedX;
                    break;
                default:
                    return;
            }

            break;
        case CubeLeftState:
            switch (swipeDirection) {
                case SwipeRightToLeftDirection:
                    currentDegree=90-90* (fabsf(movedX) /viewWidth);
                    movedPath=movedX;
                    break;
                default:
                    return;
            }

            break;
        default:
            break;
    }
   if([self isRightDirection:cubeState swipDirection:swipeDirection])
   {
       [self rotateCubeWithDirection:swipeDirection rotatedDegree:currentDegree];
   }
}

-(BOOL)isRightDirection:(CubeState)_cubeState swipDirection:(SwipeDirection)swipDirection
{
    if(cubeState==CubeTopState&&swipeDirection!=SwipeBottomToTopDirection)
    {
        return NO;
    }
    if(cubeState==CubeBottomState&&swipeDirection!=SwipeTopToBottomDirection)
    {
        return NO;
    }
    if(cubeState==CubeLeftState&&swipeDirection!=SwipeRightToLeftDirection)
    {
        return NO;
    }
    if(cubeState==CubeRightState&&swipeDirection!=SwipeLeftToRightDirection)
    {
        return NO;
    }
    return YES;
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    lastDate=[NSDate date];
//    NSTimeInterval timeInterval=[firstDate timeIntervalSinceNow];
    if(![self canMove:cubeState pointLocation:pointLocation])
    {
        return;
    }
    if(![self isRightDirection:cubeState swipDirection:swipeDirection])
    {
        return;
    }
    //2.判断是否可以滑动，并返回原状态
    if(swipeDirection==SwipeTopToBottomDirection||swipeDirection==SwipeBottomToTopDirection)
    {
        //手指滑动过了屏幕的一半1/3-240，则松手后自动继续下移到90度整,或者快速滑动然后不到以后0.5s
        if(fabsf(movedPath)>viewHeight/3)
        {
            if(cubeState==CubeFrontState)
            {
                if(movedPath>0)
                {
                    cubeState=CubeTopState;//顶部对着用户
                    currentDegree=-90;
                }
                else {
                    cubeState=CubeBottomState;
                    currentDegree=90;
                }
            }
            else if(cubeState==CubeBottomState)
            {
                cubeState=CubeFrontState;
                currentDegree=0;
            }
            else if(cubeState==CubeTopState) {
                cubeState=CubeFrontState;
                NSLog(@"++++++++______________12312=====%f",movedPath);
                currentDegree=0;
            }
            else {
                return;
            }
        }
        else
        {
            if(cubeState==CubeBottomState)
            {
                cubeState=CubeBottomState;
                currentDegree=90;
            }
            else if(cubeState==CubeFrontState)
            {
                cubeState=CubeFrontState;
                currentDegree=0;
            }
            else if(cubeState==CubeTopState) {
                cubeState=CubeTopState;
                currentDegree=-90;
            }
            else {
                return;
            }
        }
    }
    
    
    //如果是向右移动
    if(swipeDirection==SwipeLeftToRightDirection||swipeDirection==SwipeRightToLeftDirection)
    {
        if(fabsf(movedPath)>viewWidth/3)
        {
            if(cubeState==CubeFrontState)
            {
                if(movedPath>0)
                {
                    cubeState=CubeLeftState;
                    currentDegree=90;
                }
                else {
                    cubeState=CubeRightState;
                    currentDegree=-90;
                }
            }
            else if(cubeState==CubeRightState)
            {
                cubeState=CubeFrontState;
                currentDegree=0;
            }
            else if(cubeState==CubeLeftState) {
                cubeState=CubeFrontState;
                currentDegree=0;
            }
            else {
                return;
            }
        }
        else
        {
            if(cubeState==CubeFrontState)
            {
                cubeState=CubeFrontState;
                currentDegree=0;
            }
            else if(cubeState==CubeRightState)
            {
                cubeState=CubeRightState;
                currentDegree=-90;
            }
            else if(cubeState==CubeLeftState) {
                cubeState=CubeLeftState;
                currentDegree=90;
            }
            else {
                return;
            }
        }
    }
   
    [self showViewController:[NSNumber numberWithInt:cubeState]];
    //手指离开屏幕，旋转视图到指定位置
    [UIView beginAnimations:nil context:nil];
    [self rotateCubeWithDirection:swipeDirection rotatedDegree:currentDegree];
    [UIView commitAnimations];
}


-(void)showViewController:(NSNumber *)_cubeState
{
    for(UIViewController *vcController in viewlist)
    {
        if([vcController respondsToSelector:@selector(cubeStateDidChanged: cubeState:)])
        {
            [vcController cubeStateDidChanged:self cubeState:_cubeState];
        }

    }
    switch (cubeState) {
        case CubeTopState:
            [self bringSubviewToFront:topViewController.view];
            break;
        case CubeLeftState:
            [self bringSubviewToFront:leftViewContorller.view];
            break;
        case CubeRightState:
            [self bringSubviewToFront:rightViewController.view];
            break;
        case CubeFrontState:
            [self bringSubviewToFront:frontViewController.view];
            break;
        case CubeBottomState:
            [self bringSubviewToFront:bottomViewController.view];
            break;
        default:
            break;
    }

    NSLog(@"_cubeState=%d",[_cubeState intValue]);
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    return YES;
}


#pragma mark - accelerometer delegate

-(void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
    if(isRotate)
    {
        return;
    }
    if([SettingDAL shouldRockRotate])
    {
        CGFloat durationTime=0.3;
        if((acceleration.x-preX)<-kRockHorizontalNumber)//向左
        {
            isRotate=YES;
            [UIView animateWithDuration:durationTime animations:^(void){
                if(cubeState==CubeLeftState)
                {
                    cubeState=CubeFrontState;
                    [self rotateCubeWithDirection:SwipeRightToLeftDirection rotatedDegree:0];
                }
                else if(cubeState==CubeFrontState)
                {
                    cubeState=CubeRightState;
                    [self rotateCubeWithDirection:SwipeRightToLeftDirection rotatedDegree:-90];
                }
//                [self showViewController:[NSNumber numberWithInt:cubeState]];
            } completion:^(BOOL finished){
                isRotate=NO;
                [self showViewController:[NSNumber numberWithInt:cubeState]];
            }];
        }
        else if((acceleration.x-preX)>kRockHorizontalNumber)//向右
        {
            isRotate=YES;
            [UIView animateWithDuration:durationTime animations:^(void){
                if(cubeState==CubeRightState)
                {
                    cubeState=CubeFrontState;
                    [self rotateCubeWithDirection:SwipeLeftToRightDirection rotatedDegree:0];
                }
                else if(cubeState==CubeFrontState)
                {
                    cubeState=CubeLeftState;
                    [self rotateCubeWithDirection:SwipeRightToLeftDirection rotatedDegree:90];
                }
//                [self showViewController:[NSNumber numberWithInt:cubeState]];
                
            } completion:^(BOOL finished){
                isRotate=NO;
                [self showViewController:[NSNumber numberWithInt:cubeState]];
            }];
        }
        else if((acceleration.y-preY)<-kRockVerticalNumber)//向下
        {
            isRotate=YES;
            [UIView animateWithDuration:durationTime animations:^(void){
                if(cubeState==CubeBottomState)
                {
                    cubeState=CubeFrontState;
                    [self rotateCubeWithDirection:SwipeTopToBottomDirection rotatedDegree:0];
                }
                else if(cubeState==CubeFrontState)
                {
                    cubeState=CubeTopState;
                    [self rotateCubeWithDirection:SwipeTopToBottomDirection rotatedDegree:-90];
                }
            } completion:^(BOOL finished){
                [self showViewController:[NSNumber numberWithInt:cubeState]];
                isRotate=NO;
            }];

        }
        else if((acceleration.y-preY)>kRockVerticalNumber)//向上
        {
            isRotate=YES;
            [UIView animateWithDuration:durationTime animations:^(void){
                if(cubeState==CubeTopState)
                {
                    cubeState=CubeFrontState;
                    [self rotateCubeWithDirection:SwipeBottomToTopDirection rotatedDegree:0];
                }
                else if(cubeState==CubeFrontState)
                {
                    cubeState=CubeBottomState;
                    [self rotateCubeWithDirection:SwipeBottomToTopDirection rotatedDegree:90];
                }

            } completion:^(BOOL finished){
                [self showViewController:[NSNumber numberWithInt:cubeState]];
                isRotate=NO;
            }];
        }
//        [self showViewController:[NSNumber numberWithInt:cubeState]];
//        NSLog(@"x=%f    y=%f     z=%f   cubeState=%d",acceleration.x,acceleration.y,acceleration.z,cubeState);
        preX=acceleration.x;
        preY=acceleration.y;
    }
}

@end
