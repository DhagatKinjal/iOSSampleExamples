//
//  FrontViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "ASIHTTPRequest.h"
#import "CustomWebView.h"
#import "CustomNavBar.h"

@class CustomTextField;

@class CustomToolbar;

@interface FrontViewController : UIViewController<UIWebViewDelegate,UITextFieldDelegate,UIScrollViewDelegate,ASIHTTPRequestDelegate>
{
    BOOL isEditing;
}
@property(nonatomic,retain)IBOutlet CustomWebView *webView;
@property(nonatomic,retain)CustomNavBar *navBar;
@property(nonatomic,retain)CustomToolbar *bottomTb;
@property(nonatomic,retain)NSMutableArray *contentlist;
@property(nonatomic,retain)IBOutlet UITextField *txtSite;
@property(nonatomic,retain)IBOutlet UILabel *lbl3;
@property(nonatomic,retain)IBOutlet UILabel *lbl4;
@property(nonatomic,retain)IBOutlet UILabel *lbl5;

@end
