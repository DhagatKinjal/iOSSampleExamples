//
//  PageModel.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-8-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "PageModel.h"

@implementation PageModel

@synthesize pageTitle,pageURL,pageContent,creationDate,pageIconURL;

-(void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:pageTitle forKey:@"pageTitle"];
    [aCoder encodeObject:pageIconURL forKey:@"pageIconURL"];
    [aCoder encodeObject:creationDate forKey:@"creationDate"];
    [aCoder encodeObject:pageURL forKey:@"pageURL"];
    [aCoder encodeObject:pageContent forKey:@"pageContent"];
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if(self=[super init])
    {
        self.pageTitle=[aDecoder decodeObjectForKey:@"pageTitle"];
        self.pageIconURL=[aDecoder decodeObjectForKey:@"pageIconURL"];
        self.pageURL=[aDecoder decodeObjectForKey:@"pageURL"];
        self.pageContent=[aDecoder decodeObjectForKey:@"pageContent"];
        self.creationDate=[aDecoder decodeObjectForKey:@"creationDate"];
    }
    return self;
}

-(id)copyWithZone:(NSZone *)zone
{
    PageModel *copy=[[self class] copyWithZone:zone];
    copy.pageIconURL=self.pageIconURL;
    copy.pageTitle=self.pageTitle;
    copy.pageURL=self.pageURL;
    copy.pageContent=self.pageContent;
    copy.creationDate=self.creationDate;
    return copy;
}

-(NSComparisonResult)compare:(PageModel *)other
{
    return [self.creationDate compare:other.creationDate];
}

-(void)dealloc
{
    self.pageTitle=nil;
    self.pageURL=nil;
    self.creationDate=nil;
    self.pageContent=nil;
    [super dealloc];
}

@end
