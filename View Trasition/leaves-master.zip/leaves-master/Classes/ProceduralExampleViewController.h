//
//  MinimalExampleViewController.h
//  Leaves
//
//  Created by Tom Brow on 4/20/10.
//  Copyright 2010 Tom Brow. All rights reserved.
//

#import "LeavesViewController.h"


@interface ProceduralExampleViewController : LeavesViewController {

}

@end
