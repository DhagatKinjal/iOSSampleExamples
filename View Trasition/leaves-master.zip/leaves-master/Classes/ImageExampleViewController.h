//
//  ExampleViewController.h
//  Leaves
//
//  Created by Tom Brow on 4/18/10.
//  Copyright 2010 Tom Brow. All rights reserved.
//

#import "LeavesViewController.h"

@interface ImageExampleViewController : LeavesViewController {
	NSArray *images;
}

@end
